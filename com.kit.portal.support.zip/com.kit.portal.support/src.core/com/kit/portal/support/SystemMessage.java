package com.kit.portal.support;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sapportals.portal.navigation.INavigationGenerator;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;


/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class SystemMessage extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";

	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		boolean check = this.checkDate(request, response);
		if (check)
			response.include(request, request.getResource(IResource.JSP, "jsp/SysMsg.jsp"));	
		
//		IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
//		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
//		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
//		
//		Hashtable environment = helperService.getEnvironment(request);
//		
//		String msgURL = "dzbank/systemmsg/index.html"; //"/com.sap.portal.resourcerepository/repo/dzbank/systemmsg/index.html"; //request.getComponentContext().getProfile().getProperty("com.dzbank.portal.msgURL");
//		response.write("<script>console.log(\"System Nachrichten... \");</script>");
//		try {
//			IResource resource = resourceRepository.getResource(msgURL, IResource.STATIC_PAGE, false);
//			String htmlPath = resource.getResourceInformation().getURL(request);
//			response.write("<script>console.log(\"Resource: " + htmlPath + "\"); </script>");
//			//window.open('"+ htmlPath +"', \"_blank\", \"toolbar=no, scrollbars=yes, resizable=yes, top=100, left=100, width=700, height=700\");
//		} catch (ResourceNotFoundException e) {
//			// TODO Auto-generated catch block
//			response.write("<script>console.log(\"ResourceNotFoundException \");</script>");
//			e.printStackTrace();
//		} catch (InvalidResourcePathException e) {
//			// TODO Auto-generated catch block
//			response.write("<script>console.log(\"InvalidResourcePathException \");</script>");
//			e.printStackTrace();
//		}
	}
	

	public boolean checkDate(IPortalComponentRequest request, IPortalComponentResponse response){
		boolean check = false;
		response.write("<script>console.log(\"In check date method \"); </script>");
		String startDate = request.getComponentContext().getProfile().getProperty("com.kit.portal.support.StartDate");
		String endDate = request.getComponentContext().getProfile().getProperty("com.kit.portal.support.EndDate");		
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		try {
			Date sDate = formatter.parse(startDate);
			Date eDate = formatter.parse(endDate);
			Date date = new Date();
			response.write("<script>console.log(\"Start date: " + sDate.toString() + " end date: " + eDate.toString() + " and current: "+ date.toString() +"\"); </script>");
			if(date.after(sDate) && date.before(eDate))
				check = true;
			response.write("<script>console.log(\"CHECK: "+ check +"\"); </script>");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return check;
	}	
 
	
}