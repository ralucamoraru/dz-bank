package com.dzbank.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;
import com.sapportals.portal.prt.util.html.HtmlDocType;

public class Html5DocType extends HtmlDocType
{

	@Override
	public void output(StringBuffer strbuf)
	{
		strbuf.append("<!DOCTYPE html>");
	}

	@Override
	public void output(Writer writer)
	{
		try {
			writer.write("<!DOCTYPE html>");
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}
}
