package com.dzbank.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

/**
 * 		<script src="resources/sap-ui-core.js"
				id="sap-ui-bootstrap"				
				data-sap-ui-libs="sap.m, sap.ui.commons, sap.ui.table"
				data-sap-ui-theme="sap_bluecrystal"
				data-sap-ui-xx-bindingSyntax="complex"
				data-sap-ui-compatVersion="edge">
		</script>
 * @author xne7010
 *
 */
public class HTMLSAPUI5Bootstrap extends HtmlScript
{
	String	id;
	String dataLib;
	String binding;
	String compatVersion;

	public HTMLSAPUI5Bootstrap()
	{
		this("/sapui5/resources/sap-ui-core.js");

	}

	public HTMLSAPUI5Bootstrap(String src)
	{
		setTag("script");
		setId("sap-ui-bootstrap");
		setType("text/javascript");
		setId("sap-ui-bootstrap");
		setDataLib("sap.m, sap.ui.commons, sap.ui.table");
		setcompatVersion("edge");
		setBinding("complex");
		setSrc(src);

	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.id != null) {
			strbuf.append(" id=\"").append(this.id).append("\"");
		}
		
		if (this.dataLib != null) {
			strbuf.append(" data-sap-ui-libs=\"").append(this.dataLib).append("\"");
		}
		
		if (this.binding != null) {
			strbuf.append(" data-sap-ui-xx-bindingSyntax=\"").append(this.binding).append("\"");
		}
		
		if (this.compatVersion != null) {
			strbuf.append(" data-sap-ui-compatVersion=\"").append(this.compatVersion).append("\"");
		}
	}

	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (isXHTMLCompliant() && this.type != null) {
				this.type = "text/javascript";
			}

			if (this.id != null) {
				writer.write(" id=\"");
				writer.write(this.id);
				writer.write("\"");
			}
			
			if (this.dataLib != null) {
				writer.write(" data-sap-ui-libs=\"");
				writer.write(this.dataLib);
				writer.write("\"");
			}
			
			if (this.binding != null) {
				writer.write(" data-sap-ui-xx-bindingSyntax=\"");
				writer.write(this.binding);
				writer.write("\"");
			}
			
			if (this.compatVersion != null) {
				writer.write(" data-sap-ui-compatVersion=\"");
				writer.write(this.compatVersion);
				writer.write("\"");
			}

		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getId()
	{
		return id;
	}

	public void setId(String id)
	{
		this.id = id;
	}
	
	public String getDataLib()
	{
		return dataLib;
	}

	public void setDataLib(String dataLib)
	{
		this.dataLib = dataLib;
	}
	
	public String getBinding()
	{
		return binding;
	}

	public void setBinding(String binding)
	{
		this.binding = binding;
	}
	
	public String getcompatVersion()
	{
		return compatVersion;
	}

	public void setcompatVersion(String compatVersion)
	{
		this.compatVersion = compatVersion;
	}

}
