package com.dzbank.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlStyle extends HtmlNormalElement implements IHtmlUniqueElement
{

	protected String	uniqueId;
	protected String	type;
	protected String	media;

	public HtmlStyle()
	{
		setTag("style");
	}

	public HtmlStyle(String type, String media, String content)
	{
		setTag("style");
		setType(type);
		setMedia(media);
		setUniqueId(content);
		this.addElement(content);
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (isXHTMLCompliant() && this.type != null) {
			this.type = "text/css";
		}

		if (this.type != null) {
			strbuf.append(" type=\"");
			strbuf.append(this.type);
			strbuf.append("\"");
		}
		if (this.media != null) {
			strbuf.append(" media=\"");
			strbuf.append(this.media);
			strbuf.append("\"");
		}
	}

	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (isXHTMLCompliant() && this.type != null) {
				this.type = "text/css";
			}

			if (this.type != null) {
				writer.write(" type=\"");
				writer.write(this.type);
				writer.write("\"");
			}
			if (this.media != null) {
				writer.write(" media=\"");
				writer.write(this.media);
				writer.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public String getMedia()
	{
		return this.media;
	}

	public HtmlStyle setMedia(String media)
	{
		this.media = media;
		return this;
	}

	public String getType()
	{
		return this.type;
	}

	public HtmlStyle setType(String type)
	{
		this.type = type;
		return this;
	}

	public HtmlStyle setContent(String style)
	{
		this.addElement(style);
		return this;
	}

}
