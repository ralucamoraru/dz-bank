package com.dzbank.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Iterator;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;
import com.sapportals.portal.prt.util.html.HtmlContainer;
import com.sapportals.portal.prt.util.html.IHtmlOutputable;
import com.sapportals.portal.prt.util.html.IHtmlUniqueObject;

public class HtmlConditionalComment extends HtmlNormalElement implements IHtmlUniqueElement, IHtmlDeferrable
{
	protected String	condition			= null;
	protected boolean	isDownlevelRevealed	= false;

	public HtmlConditionalComment(String condition)
	{
		this.condition = condition;
		this.isDownlevelRevealed = false;
	}

	public HtmlConditionalComment(String condition, boolean isDownlevelRevealed)
	{
		this.condition = condition;
		this.isDownlevelRevealed = isDownlevelRevealed;
	}

	@Override
	public void output(StringBuffer strbuf)
	{
		if (this.isNewLine) {
			strbuf.append("\n");
		}
		if (this.condition != null) {
			if (this.isDownlevelRevealed) {
				strbuf.append("<![if ");
			} else {
				strbuf.append("<!--[if ");
			}
			strbuf.append(this.condition);
			strbuf.append("]>");
		}
		super.outputChildren(strbuf);
		if (this.condition != null) {
			if (this.isDownlevelRevealed) {
				strbuf.append("<![endif]>");
			} else {
				strbuf.append("<![endif]-->");
			}
		}
	}

	@Override
	public void output(Writer writer)
	{
		try {
			if (this.isNewLine) {
				writer.write("\n");
			}
			if (this.condition != null) {
				if (this.isDownlevelRevealed) {
					writer.write("<![if ");
				} else {
					writer.write("<!--[if ");
				}
				writer.write(this.condition);
				writer.write("]>");
			}
			super.outputChildren(writer);
			if (this.condition != null) {
				if (this.isDownlevelRevealed) {
					writer.write("<![endif]>");
				} else {
					writer.write("<![endif]-->");
				}
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getCondition()
	{
		return this.condition;
	}

	public HtmlConditionalComment setCondition(String condition)
	{
		this.condition = condition;
		return this;
	}

	public boolean isDownlevelRevealed()
	{
		return this.isDownlevelRevealed;
	}

	public HtmlConditionalComment setDownlevelRevealed(boolean isDownlevelRevealed)
	{
		this.isDownlevelRevealed = isDownlevelRevealed;
		return this;
	}

	@Deprecated
	public HtmlContainer addElement(IHtmlOutputable element)
	{
		super.addElement(element);
		return this;
	}

	public HtmlConditionalComment addElement(IHtmlElement element)
	{
		super.addElement(element);
		return this;
	}

	public HtmlConditionalComment addElements(IHtmlElement... elements)
	{
		for (IHtmlElement element : elements) {
			super.addElement(element);
		}
		return this;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	@SuppressWarnings("all")
	public String getUniqueId()
	{
		StringBuilder uid = new StringBuilder();
		uid.append(this.condition + ',' + this.isDownlevelRevealed);
		for (Iterator<IHtmlOutputable> it = this.getHtmlElements().iterator(); it.hasNext();) {
			IHtmlOutputable element = it.next();
			if (element instanceof IHtmlUniqueObject) {
				IHtmlUniqueObject uniqueElement = (IHtmlUniqueObject) element;
				uid.append(uniqueElement.getUniqueId());
			} else {
				uid.append(element.toString());
			}
		}
		return uid.toString();
	}

}
