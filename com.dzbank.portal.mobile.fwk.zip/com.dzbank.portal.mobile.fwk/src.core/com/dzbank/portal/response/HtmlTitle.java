package com.dzbank.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlTitle extends com.sapportals.portal.prt.util.html.HtmlTitle
{

	protected boolean	isNewLine			= false;
	protected boolean	isXHTMLCompliant	= false;
	protected String	uniqueId;

	public HtmlTitle()
	{
		setTag("title");
	}

	public HtmlTitle(String title)
	{
		setTag("title");
		setUniqueId(title);
		setTitleAttr(title);
	}

	@Override
	public void output(StringBuffer strbuf)
	{
		String tagName = getTag();
		if (this.isNewLine) {
			strbuf.append("\n");
		}
		strbuf.append("<");
		strbuf.append(tagName);
		outputAttributes(strbuf);
		strbuf.append(">");
		strbuf.append(this.m_title);
		strbuf.append("</");
		strbuf.append(tagName);
		strbuf.append(">");
	}

	@Override
	public void output(Writer writer)
	{
		try {
			if (this.isNewLine) {
				writer.write("\n");
			}
			writer.write("<");
			writer.write(getTag());
			outputAttributes(writer);
			writer.write(">");
			writer.write(this.m_title);
			writer.write("</");
			writer.write(getTag());
			writer.write(">");
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public com.dzbank.portal.response.HtmlTitle setTitleAttr(String title)
	{
		this.m_title = title;
		return this;
	}

	public com.dzbank.portal.response.HtmlTitle setNewLine(boolean isNewLine)
	{
		this.isNewLine = isNewLine;
		return this;
	}

	public com.dzbank.portal.response.HtmlTitle setXHTMLCompliant(boolean isXHTMLCompliant)
	{
		this.isXHTMLCompliant = isXHTMLCompliant;
		return this;
	}

	public boolean isXHTMLCompliant()
	{
		return this.isXHTMLCompliant || super.isThreadXHTMLCompliant();
	}
}
