package com.dzbank.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;
import com.sapportals.portal.prt.util.html.HtmlContainerIdentifiable;

public class HtmlNormalElement extends HtmlContainerIdentifiable implements IHtmlElement
{

	protected boolean	isNewLine			= false;
	protected boolean	isXHTMLCompliant	= false;

	protected void outputStartTag(StringBuffer strbuf)
	{
		if (this.isNewLine) {
			strbuf.append("\n");
		}
		if (hasTag()) {
			strbuf.append("<");
			strbuf.append(getTag());
			outputAttributes(strbuf);
			strbuf.append(">");
		}
	}

	protected void outputEndTag(StringBuffer strbuf)
	{
		if (hasTag() && requireClosingTag()) {
			strbuf.append("</");
			strbuf.append(getTag());
			strbuf.append(">");
		}
	}

	protected void outputStartTag(Writer writer)
	{
		try {
			if (this.isNewLine) {
				writer.write("\n");
			}
			if (hasTag()) {
				writer.write("<");
				writer.write(getTag());
				outputAttributes(writer);
				writer.write(">");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	protected void outputEndTag(Writer writer)
	{
		try {
			if (hasTag() && requireClosingTag()) {
				writer.write("</");
				writer.write(getTag());
				writer.write(">");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public HtmlNormalElement setNewLine(boolean isNewLine)
	{
		this.isNewLine = isNewLine;
		return this;
	}

	public HtmlNormalElement setXHTMLCompliant(boolean isXHTMLCompliant)
	{
		this.isXHTMLCompliant = isXHTMLCompliant;
		return this;
	}

	public boolean isXHTMLCompliant()
	{
		return this.isXHTMLCompliant || super.isThreadXHTMLCompliant();
	}
}
