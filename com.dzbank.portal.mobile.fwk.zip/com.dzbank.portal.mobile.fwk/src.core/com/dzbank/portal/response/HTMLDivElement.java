package com.dzbank.portal.response;

public class HTMLDivElement extends HtmlNormalElement implements IHtmlDeferrable
{

	HTMLDivElement(String id)
	{
		setID(id);
		setNewLine(true);
		setTag("DIV");

	}
}
