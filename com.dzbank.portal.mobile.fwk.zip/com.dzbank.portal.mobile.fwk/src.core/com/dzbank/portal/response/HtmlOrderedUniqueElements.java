package com.dzbank.portal.response;

import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HtmlOrderedUniqueElements implements IHtmlUniqueElement
{

	protected Map<String, IHtmlUniqueElement>	elementMap;
	protected List<IHtmlUniqueElement>			elementList;
	private String								uniqueId;

	public HtmlOrderedUniqueElements(String uniqueId)
	{
		this.elementMap = new HashMap<String, IHtmlUniqueElement>();
		this.elementList = new ArrayList<IHtmlUniqueElement>();
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void destroy()
	{
		removeAllUniqueElements();
		if (this.elementMap != null) {
			this.elementList = null;
			this.elementMap = null;
		}
	}

	public int getElementCount()
	{
		int count = 0;
		for (IHtmlUniqueElement element : this.elementList) {
			// get count of element's children
			count += element.getElementCount();
			// count element itself
			count++;
		}
		return count;
	}

	public void output(StringBuffer strbuf)
	{
		for (IHtmlUniqueElement element : this.elementList) {
			element.output(strbuf);
		}
	}

	@Deprecated
	public void output(PrintWriter writer)
	{
		for (IHtmlUniqueElement element : this.elementList) {
			element.output(writer);
		}
	}

	public void output(Writer writer)
	{
		for (IHtmlUniqueElement element : this.elementList) {
			element.output(writer);
		}
	}

	public void addUniqueElement(IHtmlUniqueElement element)
	{
		String id = element.getUniqueId();
		if (id == null) throw new Error("[HtmlOrderedUniqueElements.addUniqueElement] Cannot register a unique element which is not identified.");

		if (element == null) throw new Error("[HtmlOrderedUniqueElements.addUniqueElement] Cannot register a null element.");

		if (!this.elementMap.containsKey(id)) {
			this.elementMap.put(id, element);
			this.elementList.add(element);
		}
	}

	public void addUniqueElement(String id, IHtmlElement element)
	{
		if (id == null) throw new Error("[HtmlOrderedUniqueElements.addUniqueElement] Cannot register a unique element which is not identified.");

		if (element instanceof IHtmlUniqueElement) {
			addUniqueElement((IHtmlUniqueElement) element);
		} else {
			HtmlUniqueElementWrapper wrapper = new HtmlUniqueElementWrapper(element);
			addUniqueElement(wrapper);
		}
	}

	public void removeUniqueElement(String id)
	{
		if (id == null) throw new Error("[HtmlOrderedUniqueElements.removeUniqueElement] Cannot register a unique element which is not identified.");

		this.elementList.remove(id);
		this.elementMap.remove(id);
	}

	public List<IHtmlUniqueElement> getUniqueElements()
	{
		return this.elementList;
	}

	public IHtmlUniqueElement getUniqueElement(String id)
	{
		return this.elementMap.get(id);
	}

	public void removeAllUniqueElements()
	{
		if (this.elementMap != null) {
			for (IHtmlUniqueElement element : this.elementList) {
				element.destroy();
			}

			this.elementMap.clear();
			this.elementList.clear();
		}
	}
}
