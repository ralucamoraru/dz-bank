package com.dzbank.portal.response;

import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.resource.IResource;

public interface IHtmlBundleElement extends IHtmlElement
{
	public void add(IPortalComponentRequest request, IResource resource);
}
