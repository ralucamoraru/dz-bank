package com.dzbank.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlMeta extends HtmlVoidElement implements IHtmlUniqueElement
{

	protected String	name	= null;
	protected String	content	= null;
	protected String	uniqueId;

	public HtmlMeta(String name, String content)
	{
		setTag("meta");

		this.name = name;
		this.content = content;
		setUniqueId(name + content);
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.name != null) {
			strbuf.append(" name=\"");
			strbuf.append(this.name);
			strbuf.append("\"");
		}
		if (this.content != null) {
			strbuf.append(" content=\"");
			strbuf.append(this.content);
			strbuf.append("\"");
		}
		requireClosingTag(true);
	}

	public void outputAttributes(java.io.Writer out)
	{
		super.outputAttributes(out);

		try {
			if (this.name != null) {
				out.write(" name=\"");
				out.write(this.name);
				out.write("\"");
			}
			if (this.content != null) {
				out.write(" content=\"");
				out.write(this.content);
				out.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
		requireClosingTag(true);
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public HtmlMeta setNameAttr(String name)
	{
		this.name = name;
		return this;
	}

	public String getName()
	{
		return this.name;
	}

	public HtmlMeta setContent(String content)
	{
		this.content = content;
		return this;
	}

	public String getContent()
	{
		return this.content;
	}
}
