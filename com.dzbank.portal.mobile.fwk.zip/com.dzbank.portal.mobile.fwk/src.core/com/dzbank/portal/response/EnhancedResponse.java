package com.dzbank.portal.response;

import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.connection.IPortalResponse;
import com.sapportals.portal.prt.connection.PortalHtmlResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.resource.IResourceInformation;
import com.sapportals.portal.prt.util.html.Html;
import com.sapportals.portal.prt.util.html.HtmlBody;
import com.sapportals.portal.prt.util.html.HtmlContainerIdentifiableWithUniqueManager;
import com.sapportals.portal.prt.util.html.HtmlDocType;
import com.sapportals.portal.prt.util.html.HtmlDocument;
import com.sapportals.portal.prt.util.html.HtmlHead;
import com.sapportals.portal.prt.util.html.IHtmlUniqueObject;

public class EnhancedResponse {

	private static final String ORDERED_ELEMENTS = "orderedElements";

	private HtmlDocument htmlDocument;
	private boolean isNewLine = false;
	private boolean isXHTMLCompliant = false;
	private IPortalComponentRequest request;

	// private IPortalComponentResponse response;

	public EnhancedResponse(IPortalComponentRequest request) {
		this.htmlDocument = getHtmlDocument(request);
		this.request = request;
		// this.response = response;
	}

	public EnhancedResponse(IPortalComponentRequest request, boolean isNewLine, boolean isXHTMLCompliant) {
		this(request);
		this.isNewLine = isNewLine;
		this.isXHTMLCompliant = isXHTMLCompliant;
	}

	// ------------------------------------------------------

	public void setDocTypeToHtml40Transitional() {
		if (htmlDocument != null) {
			htmlDocument.setDocType(new HtmlDocType.Html40Transitional());
		}
	}

	public void setDocTypeToHtml5() {
		if (htmlDocument != null) {
			htmlDocument.setDocType(new Html5DocType());
		}
	}

	public void setHttpEquivMetaAtFirstPosition(String httpEquiv, String content) {
		if (htmlDocument != null) {
			htmlDocument.getHead().getHtmlElements().add(0, HtmlFactory.createHttpEquivMeta(httpEquiv, content));
		}
	}

	public void initSAPUI5(String theme, String themeRoot, String libs, String preloadMode, String locale, boolean debug, boolean trace, boolean debugSAPUI5js,
			boolean enableCacheBuster) {
		this.setDocTypeToHtml5();
		this.setHttpEquivMetaAtFirstPosition("X-UA-Compatible", "IE=Edge");
		this.include(HtmlFactory.createSAPUI5Config(theme, themeRoot, libs, locale, preloadMode, debug, trace));
		//this.include(HtmlFactory.createSAPUI5Bootstrap(debugSAPUI5js, enableCacheBuster));
		this.include(HtmlFactory.createSAPUI5BootstrapFromBackend(debugSAPUI5js, enableCacheBuster));
	}

	public void initSAPUI5Deferred(String theme, String themeRoot, String libs, String preloadMode, String locale, boolean debug, boolean trace, boolean debugSAPUI5js,
			boolean enableCacheBuster, boolean includeLoadingAnimation) {
		this.setDocTypeToHtml5();
		this.setHttpEquivMetaAtFirstPosition("X-UA-Compatible", "IE=Edge");
		if (includeLoadingAnimation) {
			this
					.include(HtmlFactory
							.createStyle("text/css", "all",
									"#MHPLoadingImageDIV{position:absolute;top:0;left:0;width:100%;height:100%;}#MHPLoadingImage{position:absolute;top:50%;left:50%;}"));// background-color:#000000;filter:alpha(opacity=40);
			this.defer(HtmlFactory.createLoadingAnimationDIV());
		}
		this.defer(HtmlFactory.createSAPUI5Config(theme, themeRoot, libs, locale, preloadMode, debug, trace));
		this.defer(HtmlFactory.createSAPUI5BootstrapFromBackend(debugSAPUI5js, enableCacheBuster));
		//this.defer(HtmlFactory.createSAPUI5Bootstrap(debugSAPUI5js, enableCacheBuster));
	}

	public void initSAPUI5FromHANA(String theme, String themeRoot, String libs, String locale, boolean debug, boolean trace, boolean debugSAPUI5js) {
		this.setDocTypeToHtml5();
		this.setHttpEquivMetaAtFirstPosition("X-UA-Compatible", "IE=Edge");
		this.include(HtmlFactory.createSAPUI5Config(theme, themeRoot, libs, locale, null, debug, trace));
		this.include(HtmlFactory.createSAPUI5BootstrapFromHANA(debugSAPUI5js));
	}

	public void initSAPUI5FromHANADeferred(String theme, String themeRoot, String libs, String locale, boolean debug, boolean trace, boolean debugSAPUI5js,
			boolean includeLoadingAnimation) {
		this.setDocTypeToHtml5();
		this.setHttpEquivMetaAtFirstPosition("X-UA-Compatible", "IE=Edge");
		if (includeLoadingAnimation) {
			this
					.include(HtmlFactory
							.createStyle("text/css", "all",
									"#MHPLoadingImageDIV{position:absolute;top:0;left:0;width:100%;height:100%;}#MHPLoadingImage{position:absolute;top:50%;left:50%;}"));// background-color:#000000;filter:alpha(opacity=40);
			this.defer(HtmlFactory.createLoadingAnimationDIV());
		}
		this.include(HtmlFactory.createSAPUI5Config(theme, themeRoot, libs, locale, null, debug, trace));
		this.include(HtmlFactory.createSAPUI5BootstrapFromHANA(debugSAPUI5js));
	}

	public void setTitle(String title) {
		if (htmlDocument != null) {
			HtmlTitle htmlTitle = new HtmlTitle(title);
			htmlTitle.setNewLine(this.isNewLine);
			htmlTitle.setXHTMLCompliant(this.isXHTMLCompliant);
			htmlDocument.setTitle(htmlTitle);
		}
	}

	public void setTitle(String title, String lang) {
		if (htmlDocument != null) {
			HtmlTitle htmlTitle = new HtmlTitle(title);
			htmlTitle.setNewLine(this.isNewLine);
			htmlTitle.setXHTMLCompliant(this.isXHTMLCompliant);
			htmlTitle.addAttribute("lang", lang);
			htmlDocument.setTitle(htmlTitle);
		}
	}

	public void addHtmlAttribute(String name, String value) {
		if (htmlDocument != null) {
			Html html = htmlDocument.getHtml();
			html.addAttribute(name, value);
		}
	}

	public void addHeadAttribute(String name, String value) {
		if (htmlDocument != null) {
			HtmlHead htmlHead = htmlDocument.getHead();
			htmlHead.addAttribute(name, value);
		}
	}

	public void addBodyAttribute(String name, String value) {
		if (htmlDocument != null) {
			HtmlBody htmlBody = htmlDocument.getBody();
			htmlBody.addAttribute(name, value);
		}
	}

	public void removeBodyClass() {
		if (htmlDocument != null) {
			HtmlBody htmlBody = htmlDocument.getBody();
			htmlBody.removeAttribute("class");
		}
	}

	public void setBodyClass(String clazz) {
		if (htmlDocument != null) {
			HtmlBody htmlBody = htmlDocument.getBody();
			htmlBody.setClass(clazz);
		}
	}

	public void setBodyStyle(String style) {
		if (htmlDocument != null) {
			HtmlBody htmlBody = htmlDocument.getBody();
			htmlBody.setStyle(style);
		}
	}

	public void setBodyId(String id) {
		if (htmlDocument != null) {
			HtmlBody htmlBody = htmlDocument.getBody();
			htmlBody.setID(id);
		}
	}

	// ------------------------------------------------------

	public void include(IHtmlElement htmlElement) {
		if (htmlDocument != null) {
			htmlElement.setNewLine(this.isNewLine);
			htmlElement.setXHTMLCompliant(this.isXHTMLCompliant);
			HtmlHead htmlHead = htmlDocument.getHead();
			if (htmlElement instanceof IHtmlUniqueObject) {
				addUniqueHeadElement(htmlHead, htmlElement);
			} else {
				htmlHead.addElement(htmlElement);
			}
		}
	}

	public void include(IResource resource) {
		if (htmlDocument != null) {
			IResourceInformation resourceInformation = resource.getResourceInformation();
			String type = resourceInformation.getType();
			IHtmlElement htmlElement = null;
			if (type.equals(IResource.CSS)) {
				htmlElement = new HtmlLink("stylesheet", resourceInformation.getURL(request), null, null);
			} else if (type.equals(IResource.SCRIPT)) {
				htmlElement = new HtmlScript(resourceInformation.getURL(request), null, false);
			}
			if (htmlElement != null) {
				htmlElement.setNewLine(this.isNewLine);
				htmlElement.setXHTMLCompliant(this.isXHTMLCompliant);
				HtmlHead htmlHead = htmlDocument.getHead();
				if (htmlElement instanceof IHtmlUniqueObject) {
					addUniqueHeadElement(htmlHead, htmlElement);
				} else {
					htmlHead.addElement(htmlElement);
				}
			}
		}
	}

	public void defer(IHtmlDeferrable htmlElement) {
		if (htmlDocument != null) {
			htmlElement.setNewLine(this.isNewLine);
			htmlElement.setXHTMLCompliant(this.isXHTMLCompliant);
			HtmlBody htmlBody = htmlDocument.getBody();
			// must add htmlElement as unique object, otherwise it wouldn't
			// appear before the closing tag of the body
			addUniqueBodyElement(htmlBody, htmlElement);
		}
	}

	public void defer(IResource resource) {
		if (htmlDocument != null) {
			IResourceInformation resourceInformation = resource.getResourceInformation();
			String type = resourceInformation.getType();
			IHtmlElement htmlElement = null;
			if (type.equals(IResource.SCRIPT)) {
				htmlElement = new HtmlScript(resourceInformation.getURL(request), null, false);
			}
			if (htmlElement != null) {
				htmlElement.setNewLine(this.isNewLine);
				htmlElement.setXHTMLCompliant(this.isXHTMLCompliant);
				HtmlBody htmlBody = htmlDocument.getBody();
				// must add htmlElement as unique object, otherwise it wouldn't
				// appear before the closing tag of the body
				addUniqueBodyElement(htmlBody, htmlElement);
			}
		}
	}

	// ------------------------------------------------------

	private void addUniqueHeadElement(HtmlHead htmlHead, IHtmlElement htmlElement) {
		addUniqueElement(htmlHead, htmlElement);
	}

	private void addUniqueBodyElement(HtmlBody htmlBody, IHtmlElement htmlElement) {
		addUniqueElement(htmlBody, htmlElement);
	}

	private void addUniqueElement(HtmlContainerIdentifiableWithUniqueManager html, IHtmlElement htmlElement) {
		IHtmlUniqueObject orderedElements = html.getUniqueObject(ORDERED_ELEMENTS);
		if (orderedElements == null) {
			orderedElements = new HtmlOrderedUniqueElements(ORDERED_ELEMENTS);
			html.addUniqueObject(orderedElements);
		}
		if (orderedElements instanceof HtmlOrderedUniqueElements) {
			IHtmlUniqueElement uniqueElement;
			if (htmlElement instanceof IHtmlUniqueElement) {
				uniqueElement = (IHtmlUniqueElement) htmlElement;
			} else {
				uniqueElement = new HtmlUniqueElementWrapper(htmlElement);
			}
			((HtmlOrderedUniqueElements) orderedElements).addUniqueElement(uniqueElement);
		}
	}

	// ------------------------------------------------------

	@SuppressWarnings("all")
	private HtmlDocument getHtmlDocument(IPortalComponentRequest request) {
		HtmlDocument htmlDocument = (HtmlDocument) request.getValue("htmlDocument");
		if (htmlDocument != null) {
			return htmlDocument;
		}
		IPortalResponse portalResponse = (IPortalResponse) request.getValue(IPortalResponse.class.getName());
		if (portalResponse instanceof PortalHtmlResponse) {
			PortalHtmlResponse portalHtmlResponse = (PortalHtmlResponse) portalResponse;
			htmlDocument = portalHtmlResponse.getHtmlDocument();
			request.putValue("htmlDocument", htmlDocument);
			return htmlDocument;
		}
		return null;
	}
}
