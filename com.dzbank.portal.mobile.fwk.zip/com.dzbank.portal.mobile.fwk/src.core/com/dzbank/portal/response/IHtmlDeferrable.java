package com.dzbank.portal.response;

import com.sapportals.portal.prt.util.html.IHtmlOutputable;

public interface IHtmlDeferrable extends IHtmlElement, IHtmlOutputable
{

}
