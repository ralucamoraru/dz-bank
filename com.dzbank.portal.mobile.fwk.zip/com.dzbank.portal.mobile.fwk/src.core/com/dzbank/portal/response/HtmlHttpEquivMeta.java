package com.dzbank.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlHttpEquivMeta extends HtmlVoidElement implements IHtmlUniqueElement
{

	protected String	httpEquiv	= null;
	protected String	content		= null;
	protected String	uniqueId;

	public HtmlHttpEquivMeta(String httpEquiv, String content)
	{
		setTag("meta");

		this.content = content;
		this.httpEquiv = httpEquiv;
		setUniqueId(httpEquiv + content);
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.httpEquiv != null) {
			strbuf.append(" http-equiv=\"");
			strbuf.append(this.httpEquiv);
			strbuf.append("\"");
		}
		if (this.content != null) {
			strbuf.append(" content=\"");
			strbuf.append(this.content);
			strbuf.append("\"");
		}
		requireClosingTag(true);
	}

	public void outputAttributes(java.io.Writer out)
	{
		super.outputAttributes(out);

		try {
			if (this.httpEquiv != null) {
				out.write(" http-equiv=\"");
				out.write(this.httpEquiv);
				out.write("\"");
			}
			if (this.content != null) {
				out.write(" content=\"");
				out.write(this.content);
				out.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
		requireClosingTag(true);
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public HtmlHttpEquivMeta setHttpEquiv(String httpEquiv)
	{
		this.httpEquiv = httpEquiv;
		return this;
	}

	public String getHttpEquiv()
	{
		return this.httpEquiv;
	}

	public HtmlHttpEquivMeta setContent(String content)
	{
		this.content = content;
		return this;
	}

	public String getContent()
	{
		return this.content;
	}
}
