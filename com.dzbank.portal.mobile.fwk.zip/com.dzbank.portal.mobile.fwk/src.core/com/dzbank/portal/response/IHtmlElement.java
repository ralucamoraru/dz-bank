package com.dzbank.portal.response;

import com.sapportals.portal.prt.util.html.IHtmlOutputable;

public interface IHtmlElement extends IHtmlOutputable
{

	public IHtmlElement setNewLine(boolean isNewLine);
	public IHtmlElement setXHTMLCompliant(boolean isXHTMLCompliant);
	public boolean isXHTMLCompliant();

}
