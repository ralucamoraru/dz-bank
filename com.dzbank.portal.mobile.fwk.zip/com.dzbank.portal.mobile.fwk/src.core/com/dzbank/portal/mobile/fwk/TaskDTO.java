package com.dzbank.portal.mobile.fwk;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TaskDTO implements Serializable {
	private String id;
	private String type;
	private String text;
	private String heading;
	private String approveURL;
	private String rejectURL;

	
	public TaskDTO() {

	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}


	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}


	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}


	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}


	/**
	 * @return the heading
	 */
	public String getHeading() {
		return heading;
	}


	/**
	 * @param heading the heading to set
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}


	/**
	 * @return the approveURL
	 */
	public String getApproveURL() {
		return approveURL;
	}


	/**
	 * @param approveURL the approveURL to set
	 */
	public void setApproveURL(String approveURL) {
		this.approveURL = approveURL;
	}


	/**
	 * @return the rejectURL
	 */
	public String getRejectURL() {
		return rejectURL;
	}


	/**
	 * @param rejectURL the rejectURL to set
	 */
	public void setRejectURL(String rejectURL) {
		this.rejectURL = rejectURL;
	}



}
