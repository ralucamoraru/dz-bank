package com.dzbank.portal.mobile.fwk;

import java.io.Serializable;

@SuppressWarnings("serial")
public class NotificationsDTO implements Serializable {
	private String id = "";
	private String text;
	private String heading;
	
	public NotificationsDTO() {

	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}


	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}


	/**
	 * @return the heading
	 */
	public String getHeading() {
		return heading;
	}


	/**
	 * @param heading the heading to set
	 */
	public void setHeading(String heading) {
		this.heading = heading;
	}

}
