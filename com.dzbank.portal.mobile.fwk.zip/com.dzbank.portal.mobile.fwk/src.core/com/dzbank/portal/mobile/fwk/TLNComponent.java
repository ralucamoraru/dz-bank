package com.dzbank.portal.mobile.fwk;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.naming.NamingException;
import javax.naming.directory.NoSuchAttributeException;

import com.dzbank.portal.mobile.utils.NavNode;
import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.util.StringUtils;

@SuppressWarnings("unchecked")
public class TLNComponent { //extends AbstractPortalComponent 
		
	public String portalPath = "";

	public boolean isSFUser(IPortalComponentRequest request){
		boolean sf = false;
		NavigationNodes initialNodes = getInvInitialNodes(request);
		for (Iterator it = initialNodes.iterator(); it.hasNext();) {
			INavigationNode aNode = (INavigationNode) it.next();			
			if (aNode.getName().contains("sf_anmeldung")){
				sf = true;			
			}
		}
		return sf;
	}
	
	public String writeFirstLevel(IPortalComponentRequest request, IPortalComponentResponse resp) {

		String response = "";
		NavigationNodes initialNodes = getInitialNodes(request);
		if (initialNodes == null) {
			return "Keine Knoten";
		}
		IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		this.portalPath = aliasHelper.getPath(request);
		
		String viewAs = this.getNLSString(request, "VIEW_AS_TEXT");
		
		String name; // navigation node full path name
		String title; // navigation node title
		int showType; // 0: Same window, 1: New window, 2: New portal window
		String windowName; // Relevant when showType=1
		int windowWidth; // Relevant when showType=1
		int windowHeight; // Relevant when showType=1
		String windowFeatures; // Relevant when showType=1
		boolean hasChildren; //navigation node has children
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		
		//INavigationNode current = navHelperService.getCurrentNavNode(request);
		response = response + "<div class='view-select'>";
		for (Iterator it = initialNodes.iterator(); it.hasNext();) {
			INavigationNode selNode = (INavigationNode) it.next();
			if (NavNode.isInPath(selNode, request) )
				response = response + "<a href='#'>" + viewAs + "&nbsp;<b>" + selNode.getTitle(request.getLocale()) + "</b></a>";
		}
		response = response + "<ul>";
		

		for (Iterator it = initialNodes.iterator(); it.hasNext();) {
			INavigationNode navigationNode = (INavigationNode) it.next();
			
			String filterId = NavNode.getFilterId(navigationNode); // non-null
			if (filterId.equals("hidden")) {
				continue;				
			}
			title = navigationNode.getTitle(request.getLocale());
			name = StringUtils.escapeToJS(navigationNode.getName());
			showType = navigationNode.getShowType();

			// Getting the navigation node properties:
			try {
				windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");
			} catch (NoSuchAttributeException e) {
				windowFeatures = "toolbar,location,status,scrollbars,directories,menubar,resizable";
			}
			try {
				windowName = navigationNode.getWindowName();
			} catch (UnsupportedOperationException e) {
				windowName = "DefaultExternal";
			}
			try {
				windowHeight = navigationNode.getExtWindowHeight();
			} catch (UnsupportedOperationException e) {
				windowHeight = -1;
			}
			try {
				windowWidth = navigationNode.getExtWindowWidth();
			} catch (UnsupportedOperationException e) {
				windowWidth = -1;
			}
			try {
				hasChildren = navigationNode.hasChildren();
			} catch (NamingException e) {
				//@TODO 
			}
			
			String quickLink1 = NavNode.getQuickLink(navigationNode);
			if (NavNode.isInPath(navigationNode, request) )
			{	

		//		response = response + "<a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>Meine Ansicht als&nbsp;<b>" + title + "</b></a>";
		//		response = response + "<ul>";
				response = response + "<li><a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "' class='active'>" + title + "</a></li>";
			}else{	
				response = response + "<li><a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a></li>";				
			}			
		}
		response = response + "</ul>";
		response = response + "</div>";

		return response;
	}
	

	
	public void renderSecondLevel(IPortalComponentRequest request, IPortalComponentResponse response, INavigationNode currentNode) {
		NavigationNodes navigationNodes = null;
		try {
			if(currentNode != null && currentNode.hasChildren())
				navigationNodes = currentNode.getChildren();
			else
				navigationNodes = null;
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (navigationNodes == null) {
			return;
		}
		Iterator it = navigationNodes.iterator();
		INavigationNode navigationNode;
		String name; // navigation node full path name
		String title; // navigation node title
		int showType; // 0: Same window, 1: New window, 2: New portal window
		String windowName; // Relevant when showType=1
		int windowWidth; // Relevant when showType=1
		int windowHeight; // Relevant when showType=1
		String windowFeatures; // Relevant when showType=1
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
				NavigationEventsHelperService.KEY);
		boolean isSelectedNode = false;
		//navHelperService.getCurrentLaunchNavNode(request);
	//	resp = resp + "<div id='menu'> <ul>	";

		response.write("<div id='mainnav'>	");
		response.write("<ul id='nav'>");	
		int nodeNb = 0;
		while (it.hasNext()) {
			nodeNb++;
			navigationNode = (INavigationNode) it.next();
			title = navigationNode.getTitle(request.getLocale());
			name = StringUtils.escapeToJS(navigationNode.getName());
			showType = navigationNode.getShowType();
			String quickLink1 = NavNode.getQuickLink(navigationNode);
//			if (this.currentNode != null){
//				try {
//					isSelectedNode = name.equals(this.currentNode.getFirstChild().getName());
//				} catch (NamingException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
			if (isSelectedNode)
				response.write("<script>console.log(\"Is selected Node: "+ name +" //\")</script>");
			// Getting the navigation node properties:
			try {
				windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");
			} catch (NoSuchAttributeException e) {
				windowFeatures = "toolbar,location,status,scrollbars,directories,menubar,resizable";
			}
			try {
				windowName = navigationNode.getWindowName();
			} catch (UnsupportedOperationException e) {
				windowName = "DefaultExternal";
			}
			try {
				windowHeight = navigationNode.getExtWindowHeight();
			} catch (UnsupportedOperationException e) {
				windowHeight = -1;
			}
			try {
				windowWidth = navigationNode.getExtWindowWidth();
			} catch (UnsupportedOperationException e) {
				windowWidth = -1;
			}
			if(NavNode.isInPath(navigationNode, request) || isSelectedNode){
				if(nodeNb ==1)
					response.write("<li class='first'>");
				else
					response.write("<li>");
				try {
					if(navigationNode.hasChildren()){
						NavigationNodes kids = navigationNode.getChildren();
						if (NavNode.isInPath(navigationNode, request))
							response.write("<a class=\"hassub active\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
						else
							response.write("<a class=\"hassub\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
						response.write("<ul>");
						this.renderNextLevel(request, response, kids, 3, navigationNode.getFirstChild());
						response.write("</ul>");
					}else{
						if (NavNode.isInPath(navigationNode, request))
							response.write("<a class=\"active\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");						
						else
							response.write("<a class=\"\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");						
					}
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				response.write("</li>");
			}else{
				if(nodeNb ==1)
					response.write("<li class='first'>");
				else
					response.write("<li>");
				try {
					if(navigationNode.hasChildren()){
						NavigationNodes kids = navigationNode.getChildren();
						response.write("<a class=\"hassub\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
						response.write("<ul>");
						this.renderNextLevel(request, response, kids, 3, navigationNode.getFirstChild());
						response.write("</ul>");
					}else{
						response.write("<a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");						
					}
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				response.write("</li>");
			}			
		}
				
		response.write("</ul>");
		response.write("</div>");
	}
	
	private void renderNextLevel(IPortalComponentRequest request, IPortalComponentResponse response, NavigationNodes navigationNodes, int level, INavigationNode selectedNode) {
		if (navigationNodes == null) {
			return;
		}
		Iterator it = navigationNodes.iterator();
		INavigationNode navigationNode;
		String name; // navigation node full path name
		String title; // navigation node title
		int showType; // 0: Same window, 1: New window, 2: New portal window
		String windowName; // Relevant when showType=1
		int windowWidth; // Relevant when showType=1
		int windowHeight; // Relevant when showType=1
		String windowFeatures; // Relevant when showType=1
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
				NavigationEventsHelperService.KEY);
		boolean isSelectedNode = false;

		int nodeNb = 0;
		while (it.hasNext()) {
			nodeNb++;
			navigationNode = (INavigationNode) it.next();
			title = navigationNode.getTitle(request.getLocale());
			name = StringUtils.escapeToJS(navigationNode.getName());
			showType = navigationNode.getShowType();
			String quickLink1 = NavNode.getQuickLink(navigationNode);
			isSelectedNode = name.equals(selectedNode.getName());
			if (isSelectedNode)
				response.write("<script>console.log(\"Is selected Node: "+ name +" //\")</script>");
			// Getting the navigation node properties:
			try {
				windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");
			} catch (NoSuchAttributeException e) {
				windowFeatures = "toolbar,location,status,scrollbars,directories,menubar,resizable";
			}
			try {
				windowName = navigationNode.getWindowName();
			} catch (UnsupportedOperationException e) {
				windowName = "DefaultExternal";
			}
			try {
				windowHeight = navigationNode.getExtWindowHeight();
			} catch (UnsupportedOperationException e) {
				windowHeight = -1;
			}
			try {
				windowWidth = navigationNode.getExtWindowWidth();
			} catch (UnsupportedOperationException e) {
				windowWidth = -1;
			}
			response.write("<li>");
			if(NavNode.isInPath(navigationNode, request) || isSelectedNode){					
				try {
					if(navigationNode.hasChildren()){
						if(level == 3){
							NavigationNodes kids = navigationNode.getChildren();
							if (NavNode.isInPath(navigationNode, request))
								response.write("<a class=\"hassub active\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
							else
								response.write("<a class=\"hassub\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
							response.write("<ul>");
							this.renderNextLevel(request, response, kids, 4, navigationNode.getFirstChild());
							response.write("</ul>");							
						}else if (level == 4){
							if (NavNode.isInPath(navigationNode, request))
								response.write("<a class=\"active\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");	
							else
								response.write("<a class=\"\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");	
						}

					}else{
						if (NavNode.isInPath(navigationNode, request))
							response.write("<a class=\"active\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");			
						else
							response.write("<a class=\"\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");			
					}
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else{
				try {
					if(navigationNode.hasChildren()){
						if(level == 3){
							NavigationNodes kids = navigationNode.getChildren();
							response.write("<a class=\"hassub\" title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");
							response.write("<ul>");
							this.renderNextLevel(request, response, kids, 4, navigationNode.getFirstChild());
							response.write("</ul>");							
						}else if (level == 4){
							response.write("<a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");							
						}

					}else{
						response.write("<a title='"+ title +"' id='"+ NavNode.getId(navigationNode) +"' href='" + getHref(navigationNode, this.portalPath, quickLink1, null, null)+ "'>"+ title +"</a>");						
					}
				} catch (NamingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
			response.write("</li>");
		}

	}	
		
		private void renderNavNodes(IPortalComponentRequest request, IPortalComponentResponse response, NavigationNodes navigationNodes, int level) {
			String resp = "";
			if (navigationNodes == null) {
				return;
			}
			NavigationNodes children;
			Iterator it = navigationNodes.iterator();
			INavigationNode navigationNode;
			String name; // navigation node full path name
			String title; // navigation node title
			int showType; // 0: Same window, 1: New window, 2: New portal window
			String windowName; // Relevant when showType=1
			int windowWidth; // Relevant when showType=1
			int windowHeight; // Relevant when showType=1
			String windowFeatures; // Relevant when showType=1
			NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
					NavigationEventsHelperService.KEY);
			navHelperService.getCurrentLaunchNavNode(request);
			resp = resp + "<div id='menu'> <ul>	";
		//	response.write("<div id='menu'>	");
		//	response.write("<ul>");	
			while (it.hasNext()) {
				navigationNode = (INavigationNode) it.next();
				title = navigationNode.getTitle(request.getLocale());
				name = StringUtils.escapeToJS(navigationNode.getName());
				showType = navigationNode.getShowType();

				// Getting the navigation node properties:
				try {
					windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");
				} catch (NoSuchAttributeException e) {
					windowFeatures = "toolbar,location,status,scrollbars,directories,menubar,resizable";
				}
				try {
					windowName = navigationNode.getWindowName();
				} catch (UnsupportedOperationException e) {
					windowName = "DefaultExternal";
				}
				try {
					windowHeight = navigationNode.getExtWindowHeight();
				} catch (UnsupportedOperationException e) {
					windowHeight = -1;
				}
				try {
					windowWidth = navigationNode.getExtWindowWidth();
				} catch (UnsupportedOperationException e) {
					windowWidth = -1;
				}
					
				response.write("<td id='" + title + "' ");
				// Set up EPCM.doNavigate() link
				response.write("onclick=\"EPCM.doNavigate('" + name + "'," + showType + ",'height= " + windowHeight + ",width=" + windowWidth + ","
						+ windowFeatures + "','" + windowName + "')\" >");

				if (level == 0) {
					response.write("<br><br><strong><b><i>");
				}
				if (level == 1) {
					response.write("<b>");
				}
				for (int i = 0; i < level; i++) {
					response.write("&nbsp &nbsp &nbsp");
				}
				response.write("<a href=\"#" + title + "\">");
				response.write(title);
				response.write("</a>");
				if (level == 0) {
					response.write("</strong></b></i>");
				}
				if (level == 1) {
					response.write("</b>");
				}
				response.write("</td></tr>");

//				// Get children nodes and call renderNavNodes recursively
//				try {
//					children = navigationNode.getChildren();
//					renderNavNodes(request, response, children, level + 1);
//				} catch (NamingException ne) {
//					//loc.errorT(LoggingUtils.getErrorLog(ne));
//				}
			}
		}
		
		
	
	
	private static NavigationNodes getInitialNodes(IPortalComponentRequest request) {	
	  //use the INavigationService instead of NavigationEventsHelperService to be able to input the environment as parameter 	  
	     INavigationService service = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
	     NavigationNodes initialNodes = null;	  
	     try {
		 initialNodes = service.getInitialNodes(getEnvironment(request));
	     } catch (NamingException ne) {
		 //@TODO 
	     }
	     return initialNodes;
	 }
	
	
	private static NavigationNodes getInvInitialNodes(IPortalComponentRequest request) {	
	  //use the INavigationService instead of NavigationEventsHelperService to be able to input the environment as parameter 	  
	     INavigationService service = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
	     NavigationNodes initialNodes = null;	  
	     try {
		 initialNodes = service.getInitialNodesWithInivisible(getEnvironment(request));
	     } catch (NamingException ne) {
		 //@TODO 
	     }
	     return initialNodes;
	 }
	
	 /**
	  * 
	  * @param request
	  * @return
	  */
	 private static Hashtable getEnvironment(IPortalComponentRequest request) 
	 {
	    // HttpSession session = request.getServletRequest().getSession();	     
	     NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY); 
	     Hashtable environment = navHelperService.getEnvironment(request); 
	     return environment;
	 }

	private static String getDescription(INavigationNode node, Locale locale) {
		String description = node.getDescription(locale);
		if (description != null && !description.startsWith("com.sap.")) {
			return description;
		}
		return null;
	}

	private static String getHref(INavigationNode node, String portalPath, String quickLink1, String quickLink2, String quickLink3) {
		if (quickLink1 != null) {
			if (quickLink2 == null) {
				return portalPath + '/' + quickLink1;
			} else if (quickLink3 == null) {
				return portalPath + '/' + quickLink1 + '/' + quickLink2;
			} else {
				return portalPath + '/' + quickLink1 + '/' + quickLink2 + '/' + quickLink3;
			}
		}
		return portalPath + "?NavigationTarget=" + node.getHashedName();
	}
	
	private String getNLSString(IPortalComponentRequest request, String resource_key) {
		try {
			ResourceBundle bundle = request.getResourceBundle();
			if (bundle != null) {
				return bundle.getString(resource_key);
			}
			return resource_key;
		} catch (MissingResourceException e) {
			return resource_key;
		}
	}

/*	
	public void doJson(IPortalComponentRequest request, IPortalComponentResponse response) {
		HttpServletResponse servletResponse = request.getServletResponse(true);

		servletResponse.setContentType("text/json");

		try {
		
			servletResponse.getWriter().write(writeFirstLevel(request).toString());
		} catch (IOException e) {
		}
	}
	
	 private JSONArray getThirdLevel(NavigationNodes childNodes, Locale
	 locale, String portalPath, String quickLink1, String quickLink2) {
	 JSONArray jsonResponse = new JSONArray();
	 if (childNodes != null) {
	 for (Iterator it = childNodes.iterator(); it.hasNext(); ) {
	 INavigationNode node = (INavigationNode) it.next();
					
	 JSONObject jsonNode = new JSONObject();
	 jsonNode.put("id", NavNode.getId(node));
	 jsonNode.put("title", node.getTitle(locale));
	 jsonNode.put("description", getDescription(node, locale));
	 String quickLink3 = NavNode.getQuickLink(node);
	 jsonNode.put("href", getHref(node, portalPath, quickLink1, quickLink2,
	 quickLink3));
					
	 jsonResponse.add(jsonNode);
	 }
	 }
	 return jsonResponse;
	 }
	
	private static JSONArray getSecondLevel(NavigationNodes childNodes, Locale locale, String portalPath, Hashtable env, String quickLink1) {
		JSONArray jsonResponse = new JSONArray();
		if (childNodes != null) {
			int num = childNodes.size();
			int c = 0;
			for (Iterator it = childNodes.iterator(); it.hasNext(); c++) {
				INavigationNode node = (INavigationNode) it.next();

				JSONObject jsonNode = new JSONObject();
				jsonNode.put("id", NavNode.getId(node));
				jsonNode.put("title", node.getTitle(locale));
				jsonNode.put("tooltip", getDescription(node, locale));
				String quickLink2 = NavNode.getQuickLink(node);
				jsonNode.put("href", getHref(node, portalPath, quickLink1, quickLink2, null));
				// jsonNode.put("nodes", getThirdLevel(NavNode.getChildren(node,
				// env), locale, portalPath, quickLink1, quickLink2));

				// if (num % 4 != 0 && num < 12) {
				// jsonNode.put("css", W[num][c]);
				// }

				jsonResponse.add(jsonNode);
			}
		}
		return jsonResponse;
	}	
	
	public static JSON getFooter(IPortalComponentRequest request) {

	    NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
			NavigationEventsHelperService.KEY);
	    NavigationNodes initialNodes = getInitialNodes(request);
	    Hashtable env = getEnvironment(request);
	    Locale locale = request.getLocale();
	    
	    JSONObject jsonFooter = new JSONObject();
	    for (Iterator it = initialNodes.iterator(); it.hasNext();) {
		INavigationNode node = (INavigationNode) it.next(); 
		String mergeId = NavNode.getMergeId(node); 		
		if (mergeId.equals("footer")) {			  
		    INavigationGenerator navigationService = (INavigationGenerator)PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		    String portalFullPath = navigationService.getPortalURL(request, null);
		    portalFullPath = portalFullPath +  "?NavigationTarget=" + node.getHashedName();
		    String quickLink1 = NavNode.getQuickLink(node);
		    IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		    String portalPath = aliasHelper.getPath(request);
		    jsonFooter.put("title", node.getTitle(locale));		   
		    jsonFooter.put("links", getSecondLevel(NavNode.getChildren(node, env), locale, portalPath, env, quickLink1));		   
		
//		    try {
//			URL obj = new URL(portalFullPath);
//			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
//			con.setRequestMethod("GET");
//			InputStream is = con.getInputStream();			
//			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
//			StringBuilder out = new StringBuilder();
//			String newLine = System.getProperty("line.separator");
//			String line;
//			while ((line = reader.readLine()) != null) {
//			    out.append(line);
//			    out.append(newLine);
//			}
//			jsonFooter = JSONObject.fromObject(out.toString());
//			//loc.debugT("Retrieved catalog: \n" + json.toString());
//			//return jsonFooter;
//		    } catch (MalformedURLException e) {
//			//	loc.errorT(LoggingUtils.getErrorLog(e));
//		    } catch (IOException e) {
//			//	loc.errorT(LoggingUtils.getErrorLog(e));
//		    }
		    		    
		}
	    }
	    return jsonFooter;
	}
	
	private static JSONObject getPicProducts(IPortalComponentRequest request) {
		String picRoot = Config.getPICRoot();
		String url = picRoot + PIC_URL_PRODUCTS;

		IUserContext userCtx = request.getUser();
		HttpSession session = request.getServletRequest().getSession();
		String brandID = (String) session.getAttribute(XPortConstants.SESSION_PARAM_CURRENT_BRAND_ID);
		UserHeaderDataDTO userHeaderData = (UserHeaderDataDTO) session.getAttribute(XPortConstants.SESSION_PARAM_USER_HEADER_DATA);
		Set<CustomerIDDTO> customers = userHeaderData.getCustomerIDs(brandID);
		String customerId = "";
		for (CustomerIDDTO customerIDDTO : customers) {
			customerId = customerIDDTO.getId();
			break;
		}

		String paramURL = url + "?userid=" + userCtx.getUniqueID() + "&username=" + userCtx.getDisplayName() + "&locale=" + "en-GB" + "&brandid="
				+ brandID + "&customerid=" + customerId;
		loc.debugT("Requested PIC URL for products is : " + paramURL);
		try {
			URL obj = new URL(paramURL);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();
			con.setRequestMethod("GET");
			InputStream is = con.getInputStream();

			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			StringBuilder out = new StringBuilder();
			String newLine = System.getProperty("line.separator");
			String line;
			while ((line = reader.readLine()) != null) {
				out.append(line);
				out.append(newLine);
			}
			loc.debugT("Requested PIC result string is : " + out);
			
			JSONObject json = JSONObject.fromObject(out.toString());
			//loc.debugT("Retrieved catalog: \n" + json.toString());
			return json;
		} catch (MalformedURLException e) {
			loc.errorT(LoggingUtils.getErrorLog(e));
		} catch (Exception e) {
			loc.errorT(LoggingUtils.getErrorLog(e));
		}
		return null;
	}	
	
	public static JSON getJson(IPortalComponentRequest request) {
		
		return writeFirstLevel(request);
	}	
	
	private static JSONArray writeFirstLevel(IPortalComponentRequest request) {
		JSONArray jsonResponse = new JSONArray();
		HttpSession session = request.getServletRequest().getSession();
		String brandID = (String) session.getAttribute(XPortConstants.SESSION_PARAM_CURRENT_BRAND_ID);
		String country = (String) session.getAttribute(XPortConstants.SESSION_PARAM_CURRENT_COUNTRY);
		//get data for FirstSpirit @TODO update constants
		Hashtable FSMap = (Hashtable)request.getServletRequest().getSession().getAttribute("cfMap");
		
		Locale locale = request.getLocale();
		//RM: changed to update environment for FS Content Filtering > see new methods getInitialNodes and getEnwironment
		NavigationNodes initialNodes = getInitialNodes(request);
		Hashtable env = getEnvironment(request);
		env.put(ENV_ATTRIBUTE_BRAND, brandID);
		env.put(ENV_ATTRIBUTE_COUNTRY, country);
		env.put(ENV_ATTRIBUTE_FS_PARAMETERS, FSMap);
		IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		String portalPath = aliasHelper.getPath(request);

		for (Iterator it = initialNodes.iterator(); it.hasNext();) {
			INavigationNode node = (INavigationNode) it.next();

			String filterId = NavNode.getFilterId(node); // non-null
			if (filterId.equals("hidden")) {
				continue;				
			}

			String mergeId = NavNode.getMergeId(node); // non-null
			if (mergeId.equals("footer")|| mergeId.equals("startpage")) { //|| mergeId.equals("startpage")
				continue;
			}			
			
			boolean isProducts = mergeId.equals("pic_products");

			JSONObject jsonNode = new JSONObject();
			jsonNode.put("flyout", isProducts);
			jsonNode.put("id", NavNode.getId(node));
			jsonNode.put("title", node.getTitle(locale));
			jsonNode.put("tooltip", getDescription(node, locale));
			String quickLink1 = NavNode.getQuickLink(node);
			jsonNode.put("href", getHref(node, portalPath, quickLink1, null, null));
			
			if (isProducts) {
				Config cfg  = Config.getInstance(request);
				jsonNode.put("root", cfg.getPicRoot());
			// *********** old server Side Call ****************START
//			JSONObject picProducts = getPicProducts(request);
//			if (isProducts && picProducts!=null) {
//				jsonNode.put("root", Config.getPICRoot());
//				// TODO Comment this out for PI Center Integration Clientside
//				// call ********************************START
//				JSONArray jsonCats = picProducts.getJSONArray("categories");
//				ArrayList<ArrayList<JSONObject>> rows = new ArrayList<ArrayList<JSONObject>>();
//				ArrayList<JSONObject> row = null;
//				
//				for (int i = 0; i < jsonCats.size(); i++) {
//					JSONObject jsonCat = jsonCats.getJSONObject(i);
//					if (i % 6 == 0) {
//						row = new ArrayList<JSONObject>();
//						row.add(jsonCat);
//						rows.add(row);
//					} else {
//						row.add(jsonCat);
//					}
//				}
//				jsonNode.put("rows", rows);
				// TODO Comment this out for PI Center Integration Clientside
				// call ********************************END
			// *********** old server Side Call ****************START
			
			
			} else {
//				try {
//				    NavigationNodes children = node.getChildrenWithInivisible(env);
//				} catch (NamingException e) {
//				    // TODO Auto-generated catch block
//				    e.printStackTrace();
//				}   
			    jsonNode.put("nodes", getSecondLevel(NavNode.getChildren(node, env), locale, portalPath, env, quickLink1));
			}

			jsonResponse.add(jsonNode);
		}
		return jsonResponse;
	}	
	*/
}
