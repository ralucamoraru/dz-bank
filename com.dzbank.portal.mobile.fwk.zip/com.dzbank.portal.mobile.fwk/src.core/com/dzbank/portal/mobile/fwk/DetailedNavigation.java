package com.dzbank.portal.mobile.fwk;

 
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;

public class DetailedNavigation extends AbstractPortalComponent
{
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		//IPortalComponentContext myContext = request.getComponentContext();
		//IPortalComponentProfile profile = myContext.getProfile();
		//String parameter = profile.getProperty("p1");
		// all necessary rendering is done in the JSP
		response.include(request, request.getResource(IResource.JSP, "jsp/DetailedNavigation.jsp"));
	}
	

}