package com.dzbank.portal.mobile.fwk;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.NamingException;
import javax.naming.directory.NoSuchAttributeException;

import com.dzbank.portal.mobile.utils.NavNode;
import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.util.StringUtils;


public class AufgabenComponent extends AbstractPortalComponent{ //extends AbstractPortalComponent 
		
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		response.write("<div class=\"col-md-12\" id=\"contentFullscreen3\">");	
		response.write("<lyt:containerWithTrayDesign id=\"hiddenContentArea\" wrappingMethod=\"none\">");	
		response.write("<ul class=\"nav navbar-nav navbar-right\">");	
		response.write("<li class=\"dropdown help-link\">");	
		response.write("<a target=\"_blank\" href=\"/irj/go/km/docs/documents/DZ%20BANK/My%20HR%20Admin/MyHR_Tutorials/aufgaben.html\" role=\"button\">Hilfe<span class=\"caret\"></span></a>");	
		response.write("</li>");	
		response.write("<li class=\"dropdown help-link\">");	
		response.write("<a href=\"#\" role=\"button\" onclick=\"javascript:showTasksApp();return false;\">Schlie�en<span class=\"caret\"></span></a>");	
		response.write("</li>");	
		response.write("</ul>");	
		response.write("<div class=\"row app_title\">	");	
		response.write("<header>");	
		response.write("<h3>Aufgaben</h3>");
		response.write("</header>");
		response.write("</div>");
		response.write("<div id=\"aufgaben_wd\" class=\"application\">");
		response.write("<lyt:IViewContent/>");
		response.write("</div>");
		response.write("</lyt:containerWithTrayDesign> ");
		response.write("</div>");

	}



}
