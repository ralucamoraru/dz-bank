package com.dzbank.portal.mobile.fwk;

 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.NoSuchAttributeException;

import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapconsulting.portal.utils.html.elements.HtmlFactory;
import com.sapportals.portal.navigation.INavigationConstants;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.util.StringUtils;


public class Masthead extends AbstractPortalComponent
{
	
	public static String PCD_INVISIBLE = "com.sapportals.portal.navigation.Invisible";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		
		EnhancedPortalResponse epResponse = new EnhancedPortalResponse(request);
		// <!doctype html>
		epResponse.setDocTypeToHtml5();
		String browserDocumentMode = "ie=edge,chrome=1";
		request.getServletResponse(false).addHeader("X-UA-Compatible", browserDocumentMode);		
		// <meta http-equiv='x-ua-compatible' content='ie=edge,chrome=1'>
		epResponse.include(HtmlFactory.createHttpEquivMeta("X-UA-Compatible", browserDocumentMode));
		// <meta charset='utf-8'>
		epResponse.include(HtmlFactory.createCharsetMeta("UTF-8"));			
		// <meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=0'>
		epResponse.include(HtmlFactory.createMeta("viewport", "width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=0,initial-scale=1.0"));
		//<meta name="description" content="">
		epResponse.include(HtmlFactory.createMeta("description", "MyHR Portal"));
		// <meta name='apple-mobile-web-app-capable' content='yes'>
		epResponse.include(HtmlFactory.createMeta("apple-mobile-web-app-capable", "yes"));
		// <meta name='apple-mobile-web-app-status-bar-style' content='black'>
		epResponse.include(HtmlFactory.createMeta("apple-mobile-web-app-status-bar-style", "black"));
		
		epResponse.setTitle("MyHR 2.0 Mobile Portal");
		
		epResponse.removeBodyClass();
		
		// all necessary rendering is done in the JSP
		response.include(request, request.getResource(IResource.JSP, "jsp/Masthead.jsp"));
			
	}
	
	private NavigationNodes getInitialNodes(IPortalComponentRequest request) {
		INavigationService service = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		NavigationNodes initialNodes = null;
		
		try {
			initialNodes = service.getInitialNodes(this.getEnvironment(request));
		} catch (NamingException ne) {
			//loc.errorT("Error getting initial nodes! " + LoggingUtils.getErrorLog(ne));
		}
		return initialNodes;
	}
	
	public Hashtable getEnvironment(IPortalComponentRequest request) {
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
				NavigationEventsHelperService.KEY);
		Hashtable environment = navHelperService.getEnvironment(request);

		return environment;
	}
	
	private void checkNavNodes(IPortalComponentRequest request, IPortalComponentResponse response, NavigationNodes navigationNodes, int level) {
		if (navigationNodes == null) {
			return;
		}
		NavigationNodes children;
		Iterator it = navigationNodes.iterator();
		INavigationNode navigationNode;
		String name; // navigation node full path name
		String title; // navigation node title

		while (it.hasNext()) {
			navigationNode = (INavigationNode) it.next();
			title = navigationNode.getTitle(request.getLocale());
			name = StringUtils.escapeToJS(navigationNode.getName());
			try {
				String invisible = navigationNode.getAttributeValue(PCD_INVISIBLE).toString();
				response.write("<script>console.log(\"Node: " + name + " >> "+invisible+"////\");</script>");

			} catch (NoSuchAttributeException e) {
				response.write("<script>console.log(\"Node: " + name + " >> ERROR////\");</script>");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				//windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");

			// Get children nodes and call renderNavNodes recursively
//			try {
//				children = navigationNode.getChildren();
//				renderNavNodes(request, response, children, level + 1);
//			} catch (NamingException ne) {
//				//loc.errorT(LoggingUtils.getErrorLog(ne));
//			}
		}
	}
	


	public static NavigationNodes getPathNodes(IPortalComponentRequest request) {
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);

		List list = helperService.getNavNodesListForPath(request, INavigationConstants.NAVIGATION_CONTEXT_ATTR);
		NavigationNodes nodes = new NavigationNodes();
		for (Iterator it = list.iterator(); it.hasNext();) {
			nodes.add(it.next());
		}

		return nodes;
	}
	
	


}