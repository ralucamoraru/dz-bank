package com.dzbank.portal.mobile.fwk;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.dzbank.portal.mobile.utils.PCD;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;

public class TasksApprove extends AbstractPortalComponent {
	
//	private static final String ODATA_HOST = "https://dkassaphrt.dzbank.vrnet:44320";
	private static final String ODATA_ACTIONS_URL = "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/";

	private static final String CONFIG_SYSTEM_ALIAS = "custom.portal.SystemAlias";
	
	public String backendHost = "";
	
	private static final Map<String,String> approvalMap;
	static {
	    approvalMap = new HashMap<String,String>();
	    approvalMap.put("ANAB_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'");
	    approvalMap.put("ANAB_REJECT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Decline?$format=json&POWL='MSS_POWL_LEA_APPROVAL'");
	    approvalMap.put("ANAB_CLICK", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/onClick?$format=json&POWL='MSS_POWL_LEA_APPROVAL'");
	    approvalMap.put("CICO_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='MSS_POWL_CICO_APPROVAL'");
	    approvalMap.put("CICO_REJECT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Decline?$format=json&POWL='MSS_POWL_CICO_APPROVAL'");
	    approvalMap.put("LSO_CLICK", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/onClick?$format=json&POWL='ZHR_LSO_APPROVALS'");
	    approvalMap.put("LSO_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='ZHR_LSO_APPROVALS'");
	    approvalMap.put("LSO_REJECT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Decline?$format=json&POWL='ZHR_LSO_APPROVALS'");
	    approvalMap.put("ZEITGUTSCHRIFT_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='ZHR_TIME_TRANSFER_APPROVAL'");
	    approvalMap.put("ZEITGUTSCHRIFT_REJECT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Decline?$format=json&POWL='ZHR_TIME_TRANSFER_APPROVAL'");
	    approvalMap.put("GIFT_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='ZHR_GIFTBOOK_POWL'");
	    approvalMap.put("AZG_COMMENT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Comment?$format=json&POWL='ZHR_AZGV_POWL'");
	    //@TODO
	    approvalMap.put("RUM_APPROVE", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Approve?$format=json&POWL='ZMSS_RUM'");
	    approvalMap.put("RUM_REJECT", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/Decline?$format=json&POWL='ZMSS_RUM'");
	    approvalMap.put("RUM_CLICK", "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/onClick?$format=json&POWL='ZMSS_RUM'");


	}


	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
	//	response.write("Der Kunde ist Kaiser!");

		this.backendHost = PCD.getSystemRoot(this.getProperty(request, CONFIG_SYSTEM_ALIAS));
		
		HttpServletResponse servletResponse = request.getServletResponse(true);
		servletResponse.setContentType("application/json");
		servletResponse.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP																								// 1.1.
		servletResponse.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		servletResponse.setDateHeader("Expires", 0);
		
		String objectID = request.getParameter("DATA");
		String typ = request.getParameter("TYP");
		
		String ret = "";
		
		if(typ.equalsIgnoreCase("ANAB_APPROVE") || typ.equalsIgnoreCase("ANAB_REJECT")){
			ret = this.approveANAB(request, objectID, typ);
		}
		else if (typ.equalsIgnoreCase("ZEITGUTSCHRIFT_APPROVE") || typ.equalsIgnoreCase("ZEITGUTSCHRIFT_REJECT")){
			ret = this.approveZEITG(request, objectID, typ);
		}
		else if (typ.equalsIgnoreCase("CICO_APPROVE") || typ.equalsIgnoreCase("CICO_REJECT")){
			ret = this.approveCICO(request, objectID, typ);
		}
		else if (typ.equalsIgnoreCase("GIFT_APPROVE")){
			ret = this.approveGIFT(request, objectID, typ);
		}
		else if (typ.equalsIgnoreCase("AZG_COMMENT")){
			String comment = request.getParameter("COMMENT");
			ret = this.approveAZG(request, objectID, typ, comment);
		}
		if(typ.equalsIgnoreCase("LSO_APPROVE") || typ.equalsIgnoreCase("LSO_REJECT")){
			ret = this.approveLSO(request, objectID, typ);
		}
		
		if(ret.startsWith("Success"))
			response.write("{\"result\" : \"" + ret + "\", \"data\" :\"" + objectID + "\", \"typ\" :\"" + typ + "\", \"status\" :\"" + "ok" + "\"}");
		if(ret.startsWith("Error"))
			response.write("{\"result\" : \"" + ret + "\", \"data\" :\"" + objectID + "\", \"typ\" :\"" + typ + "\", \"status\" :\"" + "error" + "\"}");
	}
	
	public String approveANAB(IPortalComponentRequest request, String data, String typ) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='REQUEST_ID_=_" + data + "'";
		String ret = "";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success!";
	    	 }else
	    		 ret = "Error: in data d" + d.toString();
	    }else
	    	ret = "Error: json response is null";
	   // ret = ret + " the URL: " + url;
	    
	    
	   //ret = ret + out.toString();

	} catch (Exception e) {
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}
	
	public String approveGIFT(IPortalComponentRequest request, String data, String typ) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='DOCUMENTNR_=_" + data + "'";
		String ret = "return: ";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success!";
	    	 }else
	    		 ret = "Error in data d";
	    }else
	    	ret = "json response is null";
	   // ret = ret + " the URL: " + url;
	    
	    
	   //ret = ret + out.toString();

	} catch (Exception e) {
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}
	
	public String approveCICO(IPortalComponentRequest request, String data, String typ) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='REQ_ID_=_" + data + "'";
		String ret = "return: ";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success!";
	    	 }else
	    		 ret = "Error in data d" + d.toString();
	    }else
	    	ret = "json response is null";
	   // ret = ret + " the URL: " + url;
	    
	    
	   //ret = ret + out.toString();

	} catch (Exception e) {
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}
	
	public String approveZEITG(IPortalComponentRequest request, String data, String typ) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 
		String[] str = data.split("_");
		String param = "PERNR_=_" + str[0] +"__BEGDA_=_"  + str[1] +"__ENDDA_=_" + str[2] +"__BEGUZ_=_"  + str[3] +"__ENDUZ_=_" + str[4] + "'";
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='PERNR_=_" + str[0] +"__BEGDA_=_"  + str[1] +"__ENDDA_=_" + str[2] +"__BEGUZ_=_"  + str[3] +"__ENDUZ_=_" + str[4] + "'";
		String ret = "return: ";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success! Param " + param;
	    	 }else
	    		 ret = "Error in data d. Param " + param;
	    }else
	    	ret = "json response is null Param " + param;
	   // ret = ret + " the URL: " + url;
	    
	    
	   //ret = ret + out.toString();

	} catch (Exception e) {
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}

	public String approveAZG(IPortalComponentRequest request, String data, String typ, String comment) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 

		String ret = "";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		String comm = URLEncoder.encode(comment, "UTF-8");
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='BELEGNR_=_" + data + "__COMMENT_=_" + comm+ "'";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    ret = "Error: " + out.toString();
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success!";
	    	 }else
	    		 ret = "Error: in data d";
	    }else
	    	ret = "Error: json response is null";

	} catch (Exception e) {
		
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}

	public String approveLSO(IPortalComponentRequest request, String data, String typ) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
	//	String url = "https://dkassaphrt.dzbank.vrnet:44320" + "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/" + "Approve?$format=json&POWL='MSS_POWL_LEA_APPROVAL'&DATA='REQUEST_ID_=_005056A25C151EE7ACD103C8BE8A5888'"; 
		String url = this.backendHost + approvalMap.get(typ) + "&DATA='WI_ID_=_" + data + "'";
		String ret = "";
		//response.write("Approval tasks comp");
		try {
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
	    URL obj = new URL(url);
	    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
	    con.setRequestMethod("GET");
	    con.setRequestProperty("Cookie", cookiesAsString);
	  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
	    InputStream res = con.getInputStream();
	    	    
	    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
	    StringBuilder out = new StringBuilder();
	    String newLine = System.getProperty("line.separator");
	    String line;
	    while ((line = reader.readLine()) != null) {
	        out.append(line);
	        out.append(newLine);
	    }
	    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
	    if(jsonObject != null){
	    	JSONObject d = (JSONObject) jsonObject.get("d");
	    	 if(d != null && d.containsKey("POWL")){
	    		ret = "Success!";
	    	 }else
	    		 ret = "Error: in data d" + d.toString();
	    }else
	    	ret = "Error: json response is null";
	   // ret = ret + " the URL: " + url;
	    
	    
	   //ret = ret + out.toString();

	} catch (Exception e) {
		//response.write(e.getMessage());
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	} 
	//	response.write("<script>console.log(\"APPROVAL: "+ret+"\");</script>");
		return ret;
	}
	
	public static String getProperty(IPortalComponentRequest request, String key) {
		IPortalComponentContext myContext = request.getComponentContext();
		IPortalComponentProfile profile = myContext.getProfile();
		if (profile == null)
			return "";
		String prop = profile.getProperty(key);
		return prop == null ? "" : prop;
	}
}
