package com.dzbank.portal.mobile.fwk;


import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;

public class PageLayout extends AbstractPortalComponent {
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		
		// all necessary rendering is done in the JSP
		response.include(request, request.getResource(IResource.JSP, "jsp/framework.jsp"));
	}
}

