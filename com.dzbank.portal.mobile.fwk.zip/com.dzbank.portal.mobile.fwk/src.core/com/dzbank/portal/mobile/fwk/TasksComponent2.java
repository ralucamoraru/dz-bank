package com.dzbank.portal.mobile.fwk;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.servlet.http.Cookie;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.dzbank.portal.mobile.utils.PCD;
import com.dzbank.portal.mobile.utils.Utils;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;

public class TasksComponent2 extends AbstractPortalComponent {
	
	//private static final String ODATA_HOST = "https://dkassaphrt.dzbank.vrnet:44320";
	private static final String CONFIG_SYSTEM_ALIAS = "custom.portal.SystemAlias";
	private static final String ODATA_URL = "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/";
	private static final String ODATA_ACTIONS_URL = "/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX_ACTIONS/";
	private static final String ODATA_URL_JSON_FILTER = "?$format=json";
	private static final String ENTITY_URL_ANAB = "MSS_POWL_LEA_APPROVALCollection";
	private static final String ENTITY_URL_LSO = "ZHR_LSO_APPROVALSCollection";
	private static final String ENTITY_URL_CICO= "MSS_POWL_CICO_APPROVALCollection";
	private static final String ENTITY_URL_GIFT = "ZHR_GIFTBOOK_POWLCollection";
	private static final String ENTITY_URL_TIME_TRANSFER = "ZHR_TIME_TRANSFER_APPROVALCollection";
	private static final String ENTITY_URL_AZG = "ZHR_AZGV_POWLCollection";
	private static final String ENTITY_URL_RUM = "ZMSS_RUMCollection";
	
	public String backendHost = "";
	
	private String headingANAB = "Abwesenheitsantrag";
	private String headingLSO = "Training";
	private String headingAZG = "AZG Versto�";
	private String headingGIFT = "Giftbook Eintrag";
	private String headingCICO = "Zeitkorrektur";
	private String headingZEITGUT = "Zeitgutschrift";


	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
	//	response.write("Der Kunde ist Kaiser!");
		this.backendHost = PCD.getSystemRoot(this.getProperty(request, CONFIG_SYSTEM_ALIAS));
		
		this.headingANAB = this.getNLSString(request, "HEADING_ANAB");
		this.headingAZG = this.getNLSString(request, "HEADING_AZG");
		this.headingLSO = this.getNLSString(request, "HEADING_LSO");
		this.headingGIFT = this.getNLSString(request, "HEADING_GIFT");
		this.headingCICO = this.getNLSString(request, "HEADING_CICO");
		this.headingZEITGUT = this.getNLSString(request, "HEADING_ZEITGUT");
		
		response.include(request, request.getResource(IResource.SCRIPT, "scripts/task-utils.js"));	
		EnhancedPortalResponse epr = new EnhancedPortalResponse(request);
		epr.setDocTypeToHtml5();
		epr.setTitle("MyHR");
		epr.removeBodyClass();
		
		
		//response.write("<script>console.log(\"System property!!!!: "+system+"\");</script>");
		
		//Locale currentLocale = request.getUser().getLocale();
		this.callTasksoData(request, response);
	//	response.include(request, request.getResource(IResource.STATIC_PAGE, "webapp/fragment.html"));
	}
	
	public void callTasksoData(IPortalComponentRequest request, IPortalComponentResponse response) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
		
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		
		String actionSuccessTitle = this.getNLSString(request, "TASK_SUCCESS_TITLE");
		String actionFehlerTitle = this.getNLSString(request, "TASK_FEHLER_TITLE");
		String actionSuccessText = this.getNLSString(request, "TASK_SUCCESS_TEXT");
		String actionFehlerText = this.getNLSString(request, "TASK_FEHLER_TEXT");
		String noTaskTitle = this.getNLSString(request, "NO_TASK_TITLE");
		String noTaskText = this.getNLSString(request, "NO_TASK_TEXT");

//		while (cook.toString().indexOf("MYSAPSSO2") == -1){
//			cook =  request.getServletRequest().getCookies();
//		}
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
		response.write("<script>console.log(\"COOKIE: " + cookiesAsString + "\");</script>");
		List<TaskDTO> taskList = new ArrayList<TaskDTO>();
		taskList = this.getANABTasks(cookiesAsString, taskList);
		taskList = this.getCorrectionsTasks(cookiesAsString, taskList);
		taskList = this.getTimeTransferTasks(cookiesAsString, taskList);
		taskList = this.getAZGTasks(cookiesAsString, taskList);		
		taskList = this.getLSOTasks(cookiesAsString, taskList);
		taskList = this.getGiftbookTasks(cookiesAsString, taskList);

		
		//response.write("<div class=\"colossal-link-container mCustomScrollbar\" data-mcs-theme='light' data-mcs-axis='y'>");	
		response.write("<div class=\"row\">");	
		
		 response.write("<div class=\"col-md-3 hide\">");
		 response.write("<div class=\"colossal-link-container\">");
		 response.write("<div id='task-box-ok' class=\"task-box hide\">");	
		 response.write("<h2>" + actionSuccessTitle + "</h2>");
		 response.write("<p>" + actionSuccessText + "</p>");
		 response.write("</div>");
		 response.write("</div>");
		 response.write("</div>");
		 
		 response.write("<div class=\"col-md-3 hide\">");
		 response.write("<div class=\"colossal-link-container\">");
		 response.write("<div id='task-box-error' class=\"task-box hide\">");	
		 response.write("<h2>" + actionFehlerTitle + "</h2>");
		 response.write("<p>" + actionFehlerText + "</p>");
		 response.write("</div>");
		 response.write("</div>");
		 response.write("</div>");
		 
		if(taskList.size() == 0){
			 response.write("<div class=\"col-md-3\">");
			 response.write("<div class=\"colossal-link-container\">");
			 response.write("<div class=\"task-box\">");	
			 response.write("<h2>" + noTaskTitle + "</h2>");
			 response.write("<p>" + noTaskText + "</p>");
			 response.write("</div>");
			 response.write("</div>");
			 response.write("</div>");
		}else{
			for (int i = 0; i < taskList.size(); i++) {
				TaskDTO task = taskList.get(i);
				// response.write("TASK: " + task.getHeading() + ": " + task.getText() + "; ");
				 response.write("<div class=\"col-md-3\">");
				 response.write("<div class=\"colossal-link-container\">");
				 response.write("<div class=\"task-box\" id='" + task.getId() + "'>");	
				 response.write("<h2>" + task.getHeading() + "</h2>");
				 response.write("<p>" + task.getText() + "</p>");
				 if(task.getType().equals("ANAB")){
					 response.write("<a class=\"task-box-approve\" href=\"#\" onclick=\"javascript:approveTask('"+task.getId()+"', 'ANAB_APPROVE');return false;\" title='Genehmigen'></a>");
					 response.write("<a class=\"task-box-reject\" onclick=\"javascript:approveTask('" + task.getId() +"', 'ANAB_REJECT');return false;\" title='Ablehnen'></a>"); //'"+task.getRejectURL()+"'
				 }
				 else if(task.getType().equals("ZEITG")){
					 response.write("<a class=\"task-box-approve\" href=\"#\" onclick=\"javascript:approveTask('"+task.getId()+"', 'ZEITGUTSCHRIFT_APPROVE');return false;\" title='Genehmigen'></a>");
					 response.write("<a class=\"task-box-reject\" onclick=\"javascript:approveTask('" + task.getId() +"', 'ZEITGUTSCHRIFT_REJECT');return false;\" title='Ablehnen'></a>"); //'"+task.getRejectURL()+"'
				 }
				 else if(task.getType().equals("CICO")){
					 response.write("<a class=\"task-box-approve\" href=\"#\" onclick=\"javascript:approveTask('"+task.getId()+"', 'CICO_APPROVE');return false;\" title='Genehmigen'></a>");
					 response.write("<a class=\"task-box-reject\" onclick=\"javascript:approveTask('" + task.getId() +"', 'CICO_REJECT');return false;\" title='Ablehnen'></a>"); //'"+task.getRejectURL()+"'
				 }
				 else if(task.getType().equals("GIFT")){
					 response.write("<a class=\"task-box-approve\" href=\"#\" onclick=\"javascript:approveTask('"+task.getId()+"', 'GIFT_APPROVE');return false;\" title='Genehmigen'></a>");
				 }
				 else if(task.getType().equals("AZG")){
					 response.write("<a class=\"task-box-comment\" href=\"#\" onclick=\"javascript:commentAZG('"+task.getId()+"', 'AZG_COMMENT');return false;\" title='Kommentieren'></a>");
					 response.write("<div class='task-box-azg'><textarea name='azg' id='azg_" +task.getId() + "' value='' placeholder='Kommentar eingeben' data-autogrow='' class='form-control' style='overflow: hidden; min-height: 2em;'></textarea></div>");
				 }
				 else if(task.getType().equals("LSO")){
					 response.write("<a class=\"task-box-approve\" href=\"#\" onclick=\"javascript:approveTask('"+task.getId()+"', 'LSO_APPROVE');return false;\" title='Genehmigen'></a>");
					 response.write("<a class=\"task-box-reject\" onclick=\"javascript:approveTask('" + task.getId() +"', 'LSO_REJECT');return false;\" title='Ablehnen'></a>"); //'"+task.getRejectURL()+"'
				 }

				 response.write("</div>");
				 response.write("</div>");
				 response.write("</div>");
			}
		}
		
		response.write("</div>");

	}
	
	private List<TaskDTO> getANABTasks(String cookie, List<TaskDTO> taskList){
		String url = this.backendHost + ODATA_URL + ENTITY_URL_ANAB + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    		    
		    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String name = task.get("NAMEOWN").toString();
				String id = task.get("REQUEST_ID").toString();
				String type = task.get("SUBTYPE_DESCRIPTION").toString();
				String startDate = this.formatDateNoTime(task.get("BEGDA").toString());
				String endDate = this.formatDateNoTime(task.get("ENDDA").toString());
				String startTime = this.formatTimePT(task.get("BEGIN_TIME").toString());
				String endTime = this.formatTimePT(task.get("END_TIME").toString());
				String fullText = name + ", " + type + " vom " + startDate + " " + startTime + " bis " + endDate + " " + endTime;
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingANAB);
				aTask.setType("ANAB");
				aTask.setText(fullText);
				aTask.setId(id);
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	
	private List<TaskDTO> getLSOTasks(String cookie, List<TaskDTO> taskList){
		String url = this.backendHost + ODATA_URL + ENTITY_URL_LSO + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String text = task.get("WI_TEXT").toString();
				String id = task.get("WI_ID").toString();
				String dueDate = this.formatStringDate(task.get("WI_END_TS").toString());
				String sentDate = this.formatStringDate(task.get("WI_CD_TS").toString());
				String fullText = text + " vom " + sentDate + ", f�llig am " + dueDate;
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingLSO);
				aTask.setText(fullText);
				aTask.setType("LSO");
				aTask.setId(id);
								
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	private List<TaskDTO> getAZGTasks(String cookie, List<TaskDTO> taskList){
		String url = this.backendHost + ODATA_URL + ENTITY_URL_AZG + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String name = task.get("NAME").toString();
				String type = task.get("ZTEXT").toString();
				String sentDate = this.formatDateNoTime(task.get("DATUM").toString());
				String fullText = name + ", " + type + " am " + sentDate;
				String id = task.get("BELEGNR").toString();
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingAZG);
				aTask.setText(fullText);
				aTask.setType("AZG");
				aTask.setId(id);
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}

	private List<TaskDTO> getGiftbookTasks(String cookie, List<TaskDTO> taskList){
		
		String url = this.backendHost + ODATA_URL + ENTITY_URL_GIFT + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String name = task.get("ENAME").toString();
				String type = task.get("TYPE").toString();
				String value = task.get("VALUE").toString();
				String id = task.get("DOCUMENTNR").toString();
				String currency = task.get("WAERS").toString();
				String date = this.formatDateNoTime(task.get("RECEIVE_DATE").toString());
				String from = task.get("NAME_GIVER").toString();
				String fromFirma = task.get("COMPANY_GIVER").toString();
				String fullText = name + ", " + type + " in Wert von " + value + currency + " from " + from + ", " + fromFirma + " am " + date;
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingGIFT);
				aTask.setText(fullText);
				aTask.setType("GIFT");
				aTask.setId(id);				
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	private List<TaskDTO> getCorrectionsTasks(String cookie, List<TaskDTO> taskList){
		
		String url = this.backendHost + ODATA_URL + ENTITY_URL_CICO + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String name = task.get("EMP_NAME").toString();
				String type = task.get("CORR_TYPE").toString();
				String newTime = this.formatTimePT(task.get("NEW_TIME").toString());
				String newDate = this.formatDateNoTime(task.get("NEW_DATE").toString());
				String id = task.get("REQ_ID").toString();
				
				String fullText = name + ", " + type + " am " + newDate + " um " + newTime;
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingCICO);
				aTask.setText(fullText);
				aTask.setType("CICO");
				aTask.setId(id);				
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	private List<TaskDTO> getTimeTransferTasks(String cookie, List<TaskDTO> taskList){
		
		String url = this.backendHost + ODATA_URL + ENTITY_URL_TIME_TRANSFER + ODATA_URL_JSON_FILTER; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    con.disconnect();
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String name = task.get("Z_EMNAM").toString();
				String type = task.get("Z_SUBTYPE_DESCRIPTION").toString();
				String fromDate = this.formatDateNoTime(task.get("BEGDA").toString());
				String toDate = this.formatDateNoTime(task.get("ENDDA").toString());
				String fromTime = this.formatTimePT(task.get("BEGUZ").toString());
				String toTime = this.formatTimePT(task.get("ENDUZ").toString());
				String grund = task.get("PREAS").toString();
				String fullText = name + ", " + type + " von " + fromDate + " " + fromTime + " bis " + toDate + " " + toTime + ", " + grund;
				//for oData call
				String idPernr = task.get("PERNR").toString();
				String idBegda = this.formatDateForID(task.get("BEGDA").toString());
				String idEndda = this.formatDateForID(task.get("ENDDA").toString());
				String idBeguz = this.formatTime(task.get("BEGUZ").toString());
				String idEnduz = this.formatTime(task.get("ENDUZ").toString());
				String id = idPernr + "_" + idBegda + "_" +  idEndda + "_" + idBeguz + "_" + idEnduz;
				
				TaskDTO aTask = new TaskDTO();
				aTask.setHeading(this.headingZEITGUT);
				aTask.setText(fullText);
				aTask.setType("ZEITG");
				aTask.setId(id);				
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	private String formatDate(String oDataDate){
		
		oDataDate = oDataDate.substring(oDataDate.indexOf("(")+1, oDataDate.indexOf(")"));
		Timestamp stamp = new Timestamp(Long.parseLong(oDataDate));
		Date date = new Date(stamp.getTime());
		String formatted = new SimpleDateFormat("dd.MM.yyyy' 'HH:mm:ss").format(date);
		
		return formatted;
	}
	
	private String formatDateNoTime(String oDataDate){
		
		oDataDate = oDataDate.substring(oDataDate.indexOf("(")+1, oDataDate.indexOf(")"));
		Timestamp stamp = new Timestamp(Long.parseLong(oDataDate));
		Date date = new Date(stamp.getTime());
		String formatted = new SimpleDateFormat("dd.MM.yyyy").format(date);
		
		return formatted;
	}
	
	
	private String formatDateForID(String oDataDate){
		
		oDataDate = oDataDate.substring(oDataDate.indexOf("(")+1, oDataDate.indexOf(")"));
		Timestamp stamp = new Timestamp(Long.parseLong(oDataDate));
		Date date = new Date(stamp.getTime());
		String formatted = new SimpleDateFormat("yyyyMMdd").format(date);
		
		return formatted;
	}
	
	private String formatTime(String time){
		//PT00H00M00S
		String h = time.substring(2, 4);
		String m = time.substring(5, 7);
		String s = time.substring(8, 10);		
		return h + m + s;
	}
	
	private String formatTimePT(String time){
		//PT00H00M00S
		String h = time.substring(2, 4);
		String m = time.substring(5, 7);
		String s = time.substring(8, 10);		
		return h + ":" + m + ":" + s;
	}
	
	private String formatStringDate(String oDataDate){
		//20161222235959
		String formatted = "N/A";
		try {
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date date1 = dateformat.parse(oDataDate);
			formatted = new SimpleDateFormat("dd.MM.yyyy' 'HH:mm:ss").format(date1);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return formatted;
	}
	
	public static String getProperty(IPortalComponentRequest request, String key) {
		IPortalComponentContext myContext = request.getComponentContext();
		IPortalComponentProfile profile = myContext.getProfile();
		if (profile == null)
			return "";
		String prop = profile.getProperty(key);
		return prop == null ? "" : prop;
	}
	
	private String getNLSString(IPortalComponentRequest request, String resource_key) {
		try {
			ResourceBundle bundle = request.getResourceBundle();
			if (bundle != null) {
				return bundle.getString(resource_key);
			}
			return resource_key;
		} catch (MissingResourceException e) {
			return resource_key;
		}
	}
}
