package com.dzbank.portal.mobile.fwk;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpSession;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IEvent;

public class NotificationsComponent extends AbstractPortalComponent {
	
	private static final String ODATA_URL = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZODATA_NOTIFICATIONS_SRV/Feeds?$format=json&$filter=Userid eq 'XNE7010'";

	private static final String ODATA_URL_JSON_FILTER = "?$format=json";

	protected void doBeforeContent(IPortalComponentRequest request, IEvent event) {
		HttpSession session = request.getServletRequest().getSession();
//		session.setAttribute("com.sap.portal.themes.lafservice.requiredThemeParts", "");
	}

	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
	//	response.write("Der Kunde ist Kaiser!");
		EnhancedPortalResponse epr = new EnhancedPortalResponse(request);
		epr.setDocTypeToHtml5();
		epr.removeBodyClass();
		
	//	response.write("Der Kunde ist Kaiser und sein ID ist: " + userID);
		//Locale currentLocale = request.getUser().getLocale();
		this.calloData(request, response);
	//	response.include(request, request.getResource(IResource.STATIC_PAGE, "webapp/fragment.html"));
	}
	
	public void calloData(IPortalComponentRequest request, IPortalComponentResponse response) {
		//String url = "https://dkassaphrt.dzbank.vrnet:44320/sap/opu/odata/SAP/ZHR_ODATA_MSS_INBOX/ZHR_LSO_APPROVALSCollection?$format=json";
		String userID = request.getUser().getName();
		String url = ODATA_URL + userID + "'";
		String cookiesAsString = "";
		Cookie[] cook =  request.getServletRequest().getCookies();
		for (int i = 0; i < cook.length; i++) {			
			Cookie cookie = cook[i];
			String cookieName = cookie.getName();
			String cookieValue = cookie.getValue();
			cookiesAsString = cookiesAsString + cookieName + "=" + cookieValue + "; ";
		//	response.write("COOKIE: " + cookiesAsString);
		}
		
		List<NotificationsDTO> notList = new ArrayList<NotificationsDTO>();
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookiesAsString);

		    InputStream res = con.getInputStream();		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String text = task.get("WI_TEXT").toString();
				String dueDate = this.formatStringDate(task.get("WI_END_TS").toString());
				String sentDate = this.formatStringDate(task.get("WI_CD_TS").toString());
				String fullText = text + " vom " + sentDate + ", f�llig am " + dueDate;
				NotificationsDTO aNot = new NotificationsDTO();
				aNot.setHeading("Training");
				aNot.setText(fullText);
								
				notList.add(aNot);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		notList = this.getLSOTasks(cookiesAsString, notList);

		
		response.write("<div class=\"colossal-link-container mCustomScrollbar\" data-mcs-theme='light' data-mcs-axis='y'>");			
		for (int i = 0; i < notList.size(); i++) {
			NotificationsDTO task = notList.get(i);
			// response.write("TASK: " + task.getHeading() + ": " + task.getText() + "; ");
			 response.write("<div class=\"task-box\">");	
			 response.write("<h2>" + task.getHeading() + "</h2>");
			 response.write("<p>" + task.getText() + "</p>");
			 response.write("<a class=\"task-box-reject\" href=\"#\" title='Ablehnen'></a>");
			 response.write("<a class=\"task-box-approve\" href=\"#\" title='Genehmigen'></a>");	
			 response.write("</div>");
		}
		response.write("</div>");

		  //  servletResponse.getWriter().write(json.toString());
		 //   response.write("<script>console.log("+ out.toString()  +")</script>");
		   
		
		  
//		 response.write("<script>console.log(document.cookie)</script>");		
	//	response.write("<script>console.log(new window.XMLHttpRequest());document.domain=\"dzbank.vrnet\"; $.ajax({method	: 'POST', url: '"+ url +"', async	: false, crossDomain: true}).done(function(result) {$( '#content').html(result);}).fail(function(result) {alert( 'Error getting Short Profile!' );});	</script>");
		
	}
	
	private List<NotificationsDTO> getLSOTasks(String cookie, List<NotificationsDTO> taskList){
		String url = ODATA_URL ; 
		
		try {
		    URL obj = new URL(url);
		    HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		    con.setRequestMethod("GET");
		    con.setRequestProperty("Cookie", cookie);
		  //  con.setRequestProperty("Cookie", "MYSAPSSO2=AjExMDAgAA5wb3J0YWw6WE5FNzAxMIgAE2Jhc2ljYXV0aGVudGljYXRpb24BAAdYTkU3MDEwAgADMDAwAwADVjE1BAAMMjAxNzEwMTUxMzMxBQAEAAAACAoAB1hORTcwMTD%2FAQQwggEABgkqhkiG9w0BBwKggfIwge8CAQExCzAJBgUrDgMCGgUAMAsGCSqGSIb3DQEHATGBzzCBzAIBATAiMB0xDDAKBgNVBAMTA1YxNTENMAsGA1UECxMESjJFRQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcxMDE1MTMzMTM4WjAjBgkqhkiG9w0BCQQxFgQULYGWeHdb1t9PYQkrK5hKgQPBoC4wCQYHKoZIzjgEAwQuMCwCFAHK2wm2NU8c9EAC2YELIGwuo1r4AhQepNXrT2OKe6xtVsXDv0zL5EBWIw%3D%3D; SAPWP_active=1; sap-usercontext=sap-language=DE&sap-client=002; SAP_SESSIONID_HRT_002=m-m-xpzgNeSc4ujdwCK6XwTEo4mxthHnulAAUFaiXBU%3d");
		    InputStream res = con.getInputStream();
		    	    
		    BufferedReader reader = new BufferedReader(new InputStreamReader(res));
		    StringBuilder out = new StringBuilder();
		    String newLine = System.getProperty("line.separator");
		    String line;
		    while ((line = reader.readLine()) != null) {
		        out.append(line);
		        out.append(newLine);
		    }
		    JSONObject jsonObject = (JSONObject)JSONValue.parse(out.toString());
		    JSONObject data = (JSONObject) jsonObject.get("d");
		    
		    JSONArray results = (JSONArray) data.get("results");
			// JSONArray results1 = (JSONArray) jsonObject.get("results");
			Iterator resultsIterator = results.iterator();
			
			while (resultsIterator.hasNext()) {
				JSONObject task = (JSONObject) (resultsIterator.next());
				String text = task.get("WI_TEXT").toString();
				String dueDate = this.formatStringDate(task.get("WI_END_TS").toString());
				String sentDate = this.formatStringDate(task.get("WI_CD_TS").toString());
				String fullText = text + " vom " + sentDate + ", f�llig am " + dueDate;
				NotificationsDTO aTask = new NotificationsDTO();
				aTask.setHeading("Training");
				aTask.setText(fullText);
								
				taskList.add(aTask);
			}

		} catch (Exception e) {
			//response.write(e.getMessage());
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		return taskList;
	}
	
	
	private String formatDate(String oDataDate){
		
		oDataDate = oDataDate.substring(oDataDate.indexOf("(")+1, oDataDate.indexOf(")"));
		Timestamp stamp = new Timestamp(Long.parseLong(oDataDate));
		Date date = new Date(stamp.getTime());
		String formatted = new SimpleDateFormat("dd.MM.yyyy' 'HH:mm:ss").format(date);
		
		return formatted;
	}
	
	private String formatStringDate(String oDataDate){
		//20161222235959
		String formatted = "N/A";
		try {
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date date1 = dateformat.parse(oDataDate);
			formatted = new SimpleDateFormat("dd.MM.yyyy' 'HH:mm:ss").format(date1);
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return formatted;
	}
}
