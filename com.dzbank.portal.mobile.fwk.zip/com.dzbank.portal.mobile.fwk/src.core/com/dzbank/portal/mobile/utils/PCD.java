package com.dzbank.portal.mobile.utils;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import com.sap.security.api.UMFactory;
import com.sap.security.api.umap.system.ExceptionInImplementationException;
import com.sap.security.api.umap.system.ISystemLandscapeObject;
import com.sap.security.api.umap.system.ISystemLandscapeWrapper;

public class PCD {
	
	public static String SYSTEM_PROTOCOL_PARAM = "wap.WAS.protocol"; 
	public static String SYSTEM_HOST_PARAM = "wap.WAS.hostname"; 
	
	public static ISystemLandscapeObject getSystemObject(String aliasName) {
		List<ISystemLandscapeWrapper> landscapes = UMFactory.getSystemLandscapeWrappers();
		ISystemLandscapeObject systemLandscapeObject = null;
		try {
			for (ISystemLandscapeWrapper systemLandscape : landscapes) {
				if (systemLandscape.getSystemByAlias(aliasName) != null) {
					systemLandscapeObject = systemLandscape.getSystemByAlias(aliasName);
				}
			}
		} catch (ExceptionInImplementationException e) {
			e.printStackTrace();
		}
		return systemLandscapeObject;
	}
	
	  /**
     * Get Root Path of system Object<br>
     * <br> <b><code>protocol://host:port<code></b>
     * @param systemAlias
     * @return
    */
    public static String getSystemRoot(String systemAlias) {

		ISystemLandscapeObject system = getSystemObject(systemAlias);
		if (system != null) 
		{
			String protocol = "";
			String host = "";
			if (system.getAttribute(SYSTEM_PROTOCOL_PARAM) != null)
				protocol = system.getAttribute(SYSTEM_PROTOCOL_PARAM).toString().toLowerCase();
			if (system.getAttribute(SYSTEM_HOST_PARAM) != null)
				host = system.getAttribute(SYSTEM_HOST_PARAM).toString();
			
			return protocol + "://" + host;
			
		} else {
			return null;
		}
    }

}
