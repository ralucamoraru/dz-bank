<div class="team-calendar">
	<div class="dates">		
		<ul>
			<li><span>1</span></li>
			<li><span>2</span></li>
			<li><span>3</span></li>
			<li><span>4</span></li>
			<li><span>5</span></li>
			<li><span>6</span></li>
			<li><span>7</span></li>
			<li><span>8</span></li>
			<li><span>9</span></li>
			<li><span>10</span></li>
			<li><span>11</span></li>
			<li><span>12</span></li>
			<li><span>13</span></li>
			<li><span>14</span></li>
		</ul>
	</div>

	<div class="events">		
		<ul>
			<li class="events-group">
				<div class="member">
					<span>Max Mustermann</span>
				</div>
				<ul>
					<li class="single-event" data-start="1" data-end="1" data-content="event-abs-circuit" data-event="event-1" style="width: 28px;left:0;">
						<span data-uk-tooltip title="Dienstreise" style="width:18px"></span>
					</li>
					<li class="single-event" data-start="3" data-end="4" data-content="event-abs-circuit" data-event="event-1" style="width: 57px;left: 58px;">
						<span data-uk-tooltip title="Dienstreise" style="width:47px"></span>
					</li>
				</ul>
			</li>
			<li class="events-group">
				<div class="member">
					<span>Olaf Osterhase</span>
				</div>
				<ul>
					<li class="single-event" data-start="monday" data-end="tuesday" data-content="event-abs-circuit" data-event="event-1">
						<a href="#0">
							<em class="event-name">abwesend</em>
						</a>
					</li>
				</ul>
			</li>
			<li class="events-group">
				<div class="member">
					<span>Mark Pfennig</span>
				</div>
				<ul>
					<li class="single-event" data-start="monday" data-end="tuesday" data-content="event-abs-circuit" data-event="event-1">
						<a href="#0">
							<em class="event-name">abwesend</em>
						</a>
					</li>
				</ul>
			</li>
		</ul>
	</div>
</div>