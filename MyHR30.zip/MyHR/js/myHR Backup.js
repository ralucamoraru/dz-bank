$(document).ready(function() {
	
	
	//Navigation aus JSON lesen und in HTML ausgeben.
	// Level 1
	$.getJSON('/json/nav.json', function(data) {
	  $.each( data, function( key, val ) {
	    $('nav ul').append("<li id='" + key + "'><a href='#Tab"+ val.id + "'>" + val.title + "</a></li>");
			$('#TabMenu').append("<div id='Tab" + val.id + "'>" +
				"<div class='smart-grid'>" +
					"<div class='gutter-sizer'></div>" +
					"<div class='smartgrid-sizer'></div>" +
				"</div>" +
			"</div>"
			);
			getSubNav(val, val.sub);
			// Level 2 (Smartblocks)
			function getSubNav (parent_data, sub_data) {
				$.each(sub_data, function(sub_key, sub_val) {
					$('#Tab'+ parent_data.id + ' .smart-grid').append("<div class='smart-block smart-width-" + sub_val.smart_width + " smart-height-" + sub_val.smart_height + " " + sub_val.smart_class + "'>" +
					"<div class='uk-panel uk-panel-box'>" +
						"<h3>" + sub_val.title + "</h3>" +
					"</div>"
					);
					if(sub_val.smart_class == "important-links") {
						getImportantLinks(parent_data, sub_val.important_links);
					};
				});
			}
	  });
		var $smartgrid = $('.smart-grid').packery({
			initLayout: false,
		  itemSelector: '.smart-block',
		  columnWidth: '.smartgrid-sizer',
		  gutter: '.gutter-sizer',
		  percentPosition: true,
			stagger: 30
		});
		$( "#TabMenu" ).tabs();
		
		// Smartblocks Wichtige Links
		function getImportantLinks(parent_data, important_links) {
			$.each(important_links, function(link_key, link_val) {
				//console.log(link_val.title);
				//console.log(parent_data.id);
			});
		}
		
		// Navigation, aktiver Menüpunkt: Berechnung der Position des Pfeils
		$('.uk-subnav a').on('click', function() {
			var nav_position = $(this).offset().left - $('nav').offset().left + ($(this).width() / 2 - 6);
			$('nav').css('background-position-x', nav_position + 'px');
			rearrangeSmartblocks($smartgrid);
		});
		$smartgrid.packery();
		// make all items draggable
		var $smartblocks = $smartgrid.find('.smart-block').draggable({
	    containment: ".smart-grid",
	    scroll: false,
	    stop: function (event, ui) {
	        //positions[this.id] = ui.position
				console.log($(this).attr("style"));
	        //localStorage.positions = JSON.stringify(positions)
			}
    });
		// bind drag events to Packery
		$smartgrid.packery('bindUIDraggableEvents', $smartblocks);
	});
	
	// Fix für das kaputte Layout aufgrund von Tabs
	function rearrangeSmartblocks($smartgrid) {
		$smartgrid.packery( 'option', { transitionDuration: 0 });
	  $smartgrid.packery('layout');
	  // re-enable transition
	  $smartgrid.packery( 'option', { transitionDuration: '0.4s' });
	}
	
	// Größenanpassung der Smartblocks
	function resizeSmartblocks($smartgrid) {
		$('.smart-block i').on( 'click', function() {
			var smartWidths = $(this).parents('.smart-block').attr('class').split(/\s+/);
			$.each(smartWidths, function(index, item) {
	      // Find class that starts with smart-width-
	      if(item.indexOf("smart-width-") == 0){
	        // Store it
	        currentSmartWidth = item;
					newSmartWidth = +item.split("smart-width-").pop() + 1;
	      }
		   }); 
		  $(this).parents('.smart-block').removeClass(currentSmartWidth);
			$(this).parents('.smart-block').addClass('smart-width-' + newSmartWidth);
		  // trigger layout after item size changes
		  $smartgrid.packery('layout');
		});	
	}
	
	//Globale Einstellungen aus JSON lesen und HTML entsprechend anpassen.
	$.getJSON('/json/global-settings.json', function(data) {
		// Rundungen der Smartblocks
		$('body').addClass(data.roundness.class);
	});

});