$(document).ready(function() {
	
	$.getJSON('/json/nav.json', function(data) {
		
		var tab_menu_template = $('#TabMenuTemplate').html();
	  Mustache.parse(tab_menu_template);   // optional, speeds up future uses
	  var rendered = Mustache.render(tab_menu_template, data, {my_tasks: 'my-tasks.mustache'});
	  $('#TabMenu').html(rendered);
		
		var test_template = $('#ChartsTemplate').html();
		Mustache.parse(test_template);   // optional, speeds up future uses
		var rendered = Mustache.render(test_template, data);
		$('#ChartScripts').html(rendered);

		
		var $smartgrid = $('.smart-grid').packery({
			initLayout: false,
		  itemSelector: '.smart-block',
		  columnWidth: '.smartgrid-sizer',
		  gutter: '.gutter-sizer',
		  percentPosition: true,
			stagger: 30
		});
		
		$( "#TabMenu" ).tabs();
		
		// Navigation, aktiver Menüpunkt: Berechnung der Position des Pfeils
		$('.uk-subnav a').on('click', function() {
			var nav_position = $(this).offset().left - $('nav').offset().left + ($(this).width() / 2 - 6);
			$('nav').css('background-position-x', nav_position + 'px');
			rearrangeSmartblocks($smartgrid);
		});
		$smartgrid.packery();
		
		// Charts werden nur bei der ersten Anzeige animiert (bei Seitenaufruf bzw. erster Klick auf einen neuen Tab)
		$('.uk-subnav :not(#Home) a').one('click', function() {
			//var clickedTab = $(this).attr('href');
			pieChart.destroy();
			eval($('#ChartScripts').html());
			// setTimeout (function() {
			// 	$('#'+clickedTab).find('.chart-number').fadeIn();
			// }, 1000);
		});
		
		// make all items draggable
		var $smartblocks = $smartgrid.find('.smart-block').each( function( i, gridItem ) {
		  var draggie = new Draggabilly( gridItem );
		  // bind drag events to Packery
		  $smartgrid.packery( 'bindDraggabillyEvents', draggie );
		});
		
		// Charts
		var primary_color = $('h3').css("color");
		var secondary_color = $('.logo-portal span').css("color");
		
		// findChartValues(data);
		//
		// function findChartValues(data) {
		// 	//console.log(parent_data);
		//
		// 	$.each( data, function( key, value ) {
		// 		if( (typeof value === "object") && (value !== null) ) {
		// 			//console.log(value);
		// 			if (value.smart_class == "chart") {
		// 				//console.log(value.chart_data);
		// 				if (value.chart_data) {
		// 					$.each( value.chart_data, function(sub_key, sub_value) {
		// 						writeChart(value, sub_value.label, sub_value.value);
		// 					});
		// 				}
		// 				//console.log(value.label + ": " + value.value);
		// 			}
		// 			findChartValues(value);
		// 		}
		// 	});
		// }
		//
		// function writeChart(value, chart_label, chart_value) {
		// 	console.log(value.id +" + "+ chart_label+ " + "+ chart_value);
		// 	$('body').append('<script>' +
		// 	'var ' + value.id + 'Canvas = document.getElementById("' + value.id + '");\n' +
		// 	'var' + value.id + 'Data = {' +
		// 		'labels: [' +
		// 			'"' + chart_label + '"' +
		// 		']' +
		// 	'}' +
		// 	'</script>');
		// }
		
		// var HomeAbwesenheitenCanvas = document.getElementById("HomeAbwesenheiten");
		// var HomeAbwesenheitenData = {
		// 	    labels: [
		// 	      "Anwesenheiten",
		// 	      "Abwesenheiten"
		// 	    ],
		// 	    datasets: [
		// 	      {
		// 	        data: [9, 3],
		// 	        backgroundColor: [
		// 	          secondary_color,
		// 						primary_color
		// 	        ]
		// 	      }]
		// };
		// var pieChart = new Chart(HomeAbwesenheitenCanvas, {
		//   type: 'doughnut',
		//   data: HomeAbwesenheitenData,
		// 	options: {
		//     legend: {
		//       display: false
		//     },
		// 		cutoutPercentage: 90
		// 	}
		// });

		$('.my-tasks .actions a').click(function(event) {
			event.preventDefault();
			//console.log($(this).closest('li'));
			//$(this).closest('li').remove();
			//$(this).closest('li').hide("slide", { direction: "left" }, 500);
			$(this).closest('li').slideUp();
			if ($(this).hasClass("uk-icon-check")) {
				UIkit.notify("Erfolgreich bestätigt", {
					pos: 'bottom-center',
					status: 'success'
				});
				
			} else {
				UIkit.notify("Erfolgreich abgelehnt", {
					pos: 'bottom-center',
					status: 'success'
				});
			}
		});
		
		eval($('#ChartScripts').html());
		
	});
	
	
	// Fix für das kaputte Layout aufgrund von Tabs
	function rearrangeSmartblocks($smartgrid) {
		$smartgrid.packery( 'option', { transitionDuration: 0 });
	  $smartgrid.packery('layout');
	  // re-enable transition
	  $smartgrid.packery( 'option', { transitionDuration: '0.4s' });
	}
	
	// Größenanpassung der Smartblocks
	function resizeSmartblocks($smartgrid) {
		$('.smart-block i').on( 'click', function() {
			var smartWidths = $(this).parents('.smart-block').attr('class').split(/\s+/);
			$.each(smartWidths, function(index, item) {
	      // Find class that starts with smart-width-
	      if(item.indexOf("smart-width-") == 0){
	        // Store it
	        currentSmartWidth = item;
					newSmartWidth = +item.split("smart-width-").pop() + 1;
	      }
		   });
		  $(this).parents('.smart-block').removeClass(currentSmartWidth);
			$(this).parents('.smart-block').addClass('smart-width-' + newSmartWidth);
		  // trigger layout after item size changes
		  $smartgrid.packery('layout');
		});
	}
	
	$( "#HelpDialogue .top" ).click(function() {
	  $( "#HelpDialogue .bottom" ).slideToggle( 300, function() {
	    // Animation complete.
	  });
	});
	
	
	
	
	
	// var myDoughnutChart = new Chart(ctx, {
	//     type: 'doughnut',
	//     data: piedata,
	//     options: options
	// });
	
	// Layover: Blur des Contents beim Öffnen
	// $('.modal-trigger').click(function () {
	//       $("#Page").css({
	// 			"filter": "blur(5px)",
	// 			"transform": "translate3d(0.0,0.0,0.0)"
	//       });
	// });
	
	

});