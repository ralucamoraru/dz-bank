<div class="uk-container uk-container-center uk-margin-top">
	<?php #include ('calendar.php'); ?>
	<div id="TabMenu">
		<script id="TabMenuTemplate" type="x-tmpl-mustache">
			<nav>
				<ul class="uk-subnav">
				{{#data}}
					<li id="{{id}}"><a href="#Tab{{id}}">{{title}}</a></li>
				{{/data}}
				</ul>
	 		</nav>
			
			{{#data}}
			<div id="Tab{{id}}">
				<div class="smart-grid">
					<div class="gutter-sizer"></div>
					<div class="smartgrid-sizer"></div>
					{{#sub}}
					<div class="smart-block smart-width-{{smart_width}} smart-height-{{smart_height}} {{smart_class}}">
						<div class="uk-panel uk-panel-box" style="background-image: url({{background_image}});">
							<h3>{{title}}</h3>
							{{#important_links.length}}
							<ul class="border-separated-lists">
								{{#important_links}}
								<li>
									<a href="{{link}}"><i class="uk-icon-arrow-right"></i>{{title}}</a>
								</li>
								{{/important_links}}
							</ul>
							{{/important_links.length}}
							
							{{#my_tasks.length}}
								<ul class="border-separated-lists">
									{{#my_tasks}}
									<li class="{{class}}">
										<span class="bold">{{date}} - {{title}}</span>
										<span>{{description}}</span>
										<div class="actions">
											<a href="#" class="uk-icon-close"></a>
											<a href="#" class="uk-icon-check"></a>
										</div>
									</li>
									{{/my_tasks}}
								</ul>
							{{/my_tasks.length}}
							
							{{#infobox_notes.length}}
							<ul class="border-separated-lists">
								{{#infobox_notes}}
								<li class="{{class}}">
								  <img src="{{user_image}}" alt="{{user_name}}"></img>
									<span class="bold">{{user_name}}</span> <span class="date">{{date}}</span><br>
									<p>{{note}}</p>
								</li>
								{{/infobox_notes}}
							</ul>
							{{/infobox_notes.length}}
							
							{{#chart_data.length}}
								<canvas id="{{id}}"></canvas>
							{{/chart_data.length}}
							
							{{#events.length}}
							<br>
							<img src="media/team-kalender.jpg" alt="" class="show-on-desktop">
							<img src="media/team-kalender-800px.jpg" alt="" class="show-on-tablet">
							<img src="media/team-kalender-480px.jpg" alt="" class="show-on-phone">
							<br><br><br>
							{{/events.length}}
							
						</div>
					</div>
					{{/sub}}
				</div>
			</div>
			{{/data}}
		</script>
	</div>
	<script id="ChartScripts">

	</script>
	<script id="ChartsTemplate" type="x-tmpl-mustache">
	
	{{#data}}
		{{#sub}}
			{{#chart_data.length}}
				var {{id}}Canvas = document.getElementById("{{id}}");
				var {{id}}Data = {
			    labels: [
						{{#chart_data}}
			      	"{{label}}",
						{{/chart_data}}
			    ],
			    datasets: [{
		        data: [
							{{#chart_data}}
				      	{{value}},
							{{/chart_data}}
						],
		        backgroundColor: [
							{{#chart_data}}
				      	"{{color}}",
							{{/chart_data}}
		        ]
		      }]
				};
				var pieChart = new Chart({{id}}Canvas, {
				  type: 'doughnut',
				  data: {{id}}Data,
					options: {
				    legend: {
				      display: false
				    },
						cutoutPercentage: 90
					}
				});
			{{/chart_data.length}}
		{{/sub}}
	{{/data}}

	</script>
	
	
	<div id="HelpDialogue">
		<div class="help-section top">
			<i class="uk-icon-comment-o"></i><span>Haben Sie Fragen?</span>
		</div>
		<div class="help-section bottom">
			<p><a href="">FAQ</a><br>
			<a href="">Kontakt</a></p>
		</div>
	</div>
</div>



