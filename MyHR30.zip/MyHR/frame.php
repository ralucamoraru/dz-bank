<!DOCTYPE html>
<html lang="de">
    <head>
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
      <title>MyHR</title>
      <link rel="stylesheet" href="css/uikit.min.css" />
			<link rel="stylesheet" href="css/components/tooltip.almost-flat.min.css" />
			<link rel="stylesheet" href="css/MyHR.css" />
			<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
			<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      <script src="js/jquery.min.js"></script>
			<script src="js/jquery-ui.js"></script>
			<script src="js/draggabilly.pkgd.min.js"></script>
			<script src="js/mustache.min.js"></script>
      <script src="js/uikit.min.js"></script>
			<script src="js/components/sticky.js"></script>
			<script src="js/components/slideshow.min.js"></script>
			<script src="js/components/notify.min.js"></script>
			<script src="js/components/tooltip.js"></script>
			<script src="js/packery.pkgd.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
			<script src="js/myHR.js"></script>
    </head>
    <body>
			<div id="Page">
				<!-- Laden der Komponente Header -->
				<?php include ('header.php'); ?>
			
				<!-- Laden der Komponente Content -->
				<?php include ('content.php'); ?>
				
				<!-- This is a button toggling the modal -->
				<button class="uk-button modal-trigger" data-uk-modal="{target:'#Zeitkontenuebersicht'}">Modal öffnen</button>
			</div>
				<!-- Laden des Layovers -->
				<?php include ('layover.php'); ?>
    </body>
</html>