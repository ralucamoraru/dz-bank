<div id="Zeitkontenuebersicht" class="uk-modal">
	<div class="uk-modal-dialog">
		<a class="uk-modal-close uk-close"></a>
		<h2>Zeitkontenübersicht</h2>
	  <img src="media/Tabelle-1.jpg" alt="" style="margin-bottom: 112px;">
		<img src="media/Tabelle-2.jpg" alt="" style="margin-bottom: 81px;">
		<div class="call-to-action">
			<button class="primary-button button" type="button">Wichtige Aktion ausführen</button><button class="secondary-button button" type="button">Weitere Aktion ausführen</button><button type="button" class="button uk-modal-close">Abbrechen</button>
		</div>
	</div>
</div>