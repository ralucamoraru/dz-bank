<header data-uk-sticky>
	<div data-uk-dropdown="{mode:'click'}" class="header-menu menu-burger">
	  <i class="uk-icon-bars"></i>
	  <div class="uk-dropdown">
			Megamenü
		</div>
	</div>
	<span class="logo logo-portal">
		<span>My</span><span>HR</span>
	</span>
	<img src="images/DZPrivatbank-Logo.jpg" alt="DZ Privatbank Logo" class="logo logo-company" style="height:21px;">
	<div class="header-menu menu-settings">
		<i class="uk-icon-cog"></i>
	</div>
</header>