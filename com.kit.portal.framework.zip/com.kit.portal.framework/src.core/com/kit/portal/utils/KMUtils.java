package com.kit.portal.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.lang.StringUtils;

import com.sap.security.api.IUser;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sap.tc.logging.Location;
import com.sapportals.wcm.WcmException;
import com.sapportals.wcm.repository.AuthorizationRequiredException;
import com.sapportals.wcm.repository.Content;
import com.sapportals.wcm.repository.ICollection;
import com.sapportals.wcm.repository.IResource;
import com.sapportals.wcm.repository.IResourceContext;
import com.sapportals.wcm.repository.IResourceFactory;
import com.sapportals.wcm.repository.IResourceList;
import com.sapportals.wcm.repository.ResourceContext;
import com.sapportals.wcm.repository.ResourceException;
import com.sapportals.wcm.repository.ResourceFactory;
import com.sapportals.wcm.service.urimapper.IUriMapperService;
import com.sapportals.wcm.service.urimapper.UriMapperServiceFactory;
import com.sapportals.wcm.util.uri.RID;
/**
 * @author ralucamoraru@gmail.com
 */
public class KMUtils {

	private static Location location = Location.getLocation(KMUtils.class);
	
	/**
	 * 
	 * @param rid
	 * @return
	 * @throws Exception
	 */
  public static IResource getResource(String rid) throws Exception {
    IUser user = getServiceUser("xne7010");

    return getResource(rid, user);
  }

	/**
	 * @return
	 * @throws UMException
	 */
	private static ResourceContext getResourceContext(IUser user) throws UMException, NamingException {
		return ResourceContext.getInstance(user);
	}
  

	/**
	 * @param res
	 * @return
	 * @throws ResourceException
	 */
	public static String getIdForResource(IResource res) throws ResourceException {
		if (res == null) {
			return null;
		}
		RID rid = res.getRID();
		if (rid == null) {
			return null;
		}
		return rid.getPath();
	}

	/**
	 * @param folder
	 * @return
	 * @throws MHPException
	 */
	public static IResourceList getResourcesFromFolder(String folder, IUser user) throws Exception {
		try {
			// init KM resourcecontext and -factory
			ResourceContext resourceCtx = getResourceContext(user);
			IResourceFactory resourceFactory = ResourceFactory.getInstance();

			// return the folders children
			RID rid = RID.getRID(folder);
			ICollection collection = (ICollection) resourceFactory.getResource(rid, resourceCtx);

			return collection.getChildren();
		} catch (Exception e) {
			location.errorT("Could not read KM resources from folder " + folder + " - " + e.getMessage());
			throw new Exception(e);
		}
	}	
	
	/**
	 * 
	 * @param rid
	 * @param user
	 * @return
	 * @throws Exception
	 */
  public static IResource getResource(String rid, IUser user) throws Exception {
    if (rid == null) {
      throw new Exception("RID is not specified.");
    }

    if (rid.startsWith("/irj/go/km/docs/")) {
      rid = rid.replaceFirst("/irj/go/km/docs", "");
    }

    if (rid.startsWith("/guid/")) {
      IUriMapperService uriMapper;
      try {
        uriMapper = UriMapperServiceFactory.getInstance();
        rid = uriMapper.getRIDFromGuidRID(RID.getRID(rid)).getPath();
      } catch(WcmException e) {
      }
    }
    

    IResourceFactory resourceFactory = ResourceFactory.getInstance();
    IResourceContext ctx =  ResourceContext.getInstance(user);
  //  IResourceContext ctx = resourceFactory.getServiceContext("cmadmin_service");
    String msg = "";
    RID r = RID.getRID(rid);
    msg = msg + "THE rid: " + r.getPath() + "// ";
    msg = msg + "context: " + ctx.toString() + "// ";
    
    IResource resource = null;
	try {
		resource = ResourceFactory.getInstance().getResource(r, ctx);
	} catch (Exception e) {
		
		throw new Exception("Exception getting resource " + rid + " is null. Data: " + msg);
	}
    if (resource == null) {
      throw new Exception("Resource with RID " + rid + " is null. Data: " + msg);
    }
    return resource;
  }

  /**
   * 
   * @param rid
   * @return
   */
  public static IResource getNullableResource(String rid) {
    IUser user;
    try {
      user = UMFactory.getUserFactory().getUserByLogonID("cmadmin_service");
    } catch (UMException e) {
      return null;
    }

    return getNullableResource(rid, user);
  }

  public static IResource getNullableResource(String rid, IUser user) {
    if (rid == null) {
      return null;
    }

    if (rid.startsWith("/irj/go/km/docs/")) {
      rid = rid.replaceFirst("/irj/go/km/docs", "");
    }

    if (rid.startsWith("/guid/")) {
      IUriMapperService uriMapper;
      try {
        uriMapper = UriMapperServiceFactory.getInstance();
        rid = uriMapper.getRIDFromGuidRID(RID.getRID(rid)).getPath();
      } catch(WcmException e) {
      }
    }

    IResourceContext ctx = ResourceContext.getInstance(user);

    IResource resource = null;
    try {
      resource = ResourceFactory.getInstance().getResource(RID.getRID(rid), ctx);
    } catch (ResourceException e) {
    }

    return resource;
  }

  /**
   * 
   * @param kmFolderName
   * @param file
   * @param overwrite
   * @param user
   * @return
   * @throws Exception
   */
	public static String writeKmResource(String kmFolderName, FileItem file, boolean overwrite, IUser user) throws Exception {
		try {

			if (file == null) {
				throw new Exception("No File given can not upload anything!");
			}

			// prepare kmFolder string
			kmFolderName = StringUtils.removeEnd(kmFolderName, "/");

			// init KM resourcecontext and -factory
			ResourceContext resourceCtx = getResourceContext(user);
			IResourceFactory resourceFactory = ResourceFactory.getInstance();

			// check if file exists: if yes -> overwrite file, if not -> create
			// file
			RID rid = RID.getRID(kmFolderName + "/" + file.getName());
			IResource fileResource;
			if (!resourceFactory.checkExistence(rid, resourceCtx)) {
				RID collectionRid = RID.getRID(kmFolderName);
				ICollection collection = (ICollection) ResourceFactory.getInstance().getResource(collectionRid, resourceCtx);
				fileResource = collection.createResource(file.getName(), null, null);
			} else {
				if (overwrite) {
					fileResource = (IResource) resourceFactory.getResource(rid, resourceCtx);
				} else {
					throw new Exception("File already exists! Aborting since overwriting is not allowed!");
				}
			}

			// create content using an input stream
			ByteArrayInputStream in = new ByteArrayInputStream(file.get());
			Content content = new Content(in, file.getContentType(), -1);

			// update and unlock resource
			fileResource.updateContent(content);

			// return ID of KM resource
			return getIdForResource(fileResource);

		} catch (Exception e) {
			location.errorT("Could not write file to KM: " + kmFolderName + "/" + file.getName() + " - " + e.getMessage());
			throw new Exception(e);
		}
	}
	
	/**
	 * @param kmFilePath
	 * @return
	 * @throws AuthorizationRequiredException
	 * @throws ResourceException
	 * @throws UMException
	 */
	public static IResource readKmResource(String kmFilePath, IUser user) throws AuthorizationRequiredException, ResourceException, UMException,
			NamingException {

		// init KM resourcecontext and -factory
		ResourceContext resourceCtx = getResourceContext(user);
		IResourceFactory resourceFactory = ResourceFactory.getInstance();

		// get or create KM resource
		RID rid = RID.getRID(kmFilePath);

		if (resourceFactory.checkExistence(rid, resourceCtx)) {
			return resourceFactory.getResource(rid, resourceCtx);
		} else {
			location.errorT("Could not read from KM resource: KM file does not exist - " + kmFilePath);
		}
		return null;
	}


	/**
	 * @param path
	 * @return
	 * @throws MHPException
	 */
	public static String createKmFolder(String path, IUser user) throws Exception {
		try {
			// init KM resourcecontext and -factory
			ResourceContext resourceCtx = getResourceContext(user);
			IResourceFactory resourceFactory = ResourceFactory.getInstance();

			path = StringUtils.removeEnd(path, "/");
			String parentFolderPath = path.substring(0, path.lastIndexOf("/"));
			String folderName = path.substring(path.lastIndexOf("/") + 1);

			// check if resource exists
			RID rid = RID.getRID(path);
			if (!resourceFactory.checkExistence(rid, resourceCtx)) {
				RID parentFolderRID = RID.getRID(parentFolderPath);
				if (!resourceFactory.checkExistence(parentFolderRID, resourceCtx)) {
					throw new Exception("KM Parent folder " + parentFolderPath + " does not exist!!");
				}

				IResource parentFolderResource = resourceFactory.getResource(parentFolderRID, resourceCtx);
				if (!parentFolderResource.isCollection()) {
				}
				ICollection parentFolderCollection = (ICollection) parentFolderResource;
				ICollection folderCollection = parentFolderCollection.createCollection(folderName, null);
				return folderCollection.getRID().getPath();

			}

			return rid.getPath();
		} catch (Exception e) {
			location.errorT("Could not create KM resource " + path + " - " + e.getMessage());
			throw new Exception(e);
		}
	}	
	
	/**
	 * @param path
	 * @throws MHPException
	 */
	public static void deleteResourceFromKM(String path, IUser user) throws Exception {
		try {
			// init KM resourcecontext and -factory
			ResourceContext resourceCtx = getResourceContext(user);
			IResourceFactory resourceFactory = ResourceFactory.getInstance();

			// if resource exists, delete it
			RID rid = RID.getRID(path);
			if (resourceFactory.checkExistence(rid, resourceCtx)) {
				IResource res = resourceFactory.getResource(rid, resourceCtx);
				res.delete();

			}
		} catch (Exception e) {
			location.errorT("Could not delete KM resource " + path + " - " + e.getMessage());
			throw new Exception(e);
		}
	}
	
	/**
	 * Parse a text file from KM line by line
	 * @param resource
	 * @return
	 */
	public static List<String> parseTxtFile(IResource resource){
		List<String> list = new ArrayList<String>();
		try {
			InputStreamReader is = new InputStreamReader(resource.getContent().getInputStream());
			BufferedReader br = new BufferedReader(is);		 
	        String line;
	        while((line = br.readLine()) != null) {
	             list.add(line);
	        }
		}
        catch (FileNotFoundException e) {
        	location.errorT("could not find the specified file " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			location.errorT("The BufferedReader could nod read the lines " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			location.errorT("Could not read the resource context " + e.getMessage());
			e.printStackTrace();
		}
		
		return list;
	}
	
	/**
	 * 
	 * @param logonID cmadmin_service
	 * @return
	 * @throws Exception
	 */
	private static IUser getServiceUser(String logonID) throws Exception {

		try {
			return UMFactory.getUserFactory().getUserByLogonID(logonID);
		} catch (UMException e) {
			location.errorT("Error getting service user : " + e.getMessage());
			throw new Exception(e);
		}
	}
}
