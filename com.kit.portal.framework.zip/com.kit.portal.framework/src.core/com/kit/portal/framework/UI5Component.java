package com.kit.portal.framework;

import javax.servlet.http.HttpSession;

import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IEvent;
import com.sapportals.portal.prt.resource.IResource;

public class UI5Component extends AbstractPortalComponent {

	protected void doBeforeContent(IPortalComponentRequest request, IEvent event) {
		HttpSession session = request.getServletRequest().getSession();
		session.setAttribute("com.sap.portal.themes.lafservice.requiredThemeParts", "");
	}

	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		response.write("Der Kunde ist Kaiser!");
		EnhancedPortalResponse epr = new EnhancedPortalResponse(request);
		epr.setDocTypeToHtml5();
		epr.setTitle("UI5");
		epr.removeBodyClass();
		response.include(request, request.getResource(IResource.STATIC_PAGE, "webapp/fragment.html"));
	}

}
