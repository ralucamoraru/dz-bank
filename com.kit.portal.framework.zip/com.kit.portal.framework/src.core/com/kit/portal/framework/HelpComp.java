package com.kit.portal.framework;

import javax.servlet.http.HttpServletResponse;

import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;


public class HelpComp extends AbstractPortalComponent
{

	public static final String REQUEST_OBJECT_ID_PARAM = "objectID";
	
    public HelpComp()
    {
    }

    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response)
    {		
    	
    	HttpServletResponse servletResponse = request.getServletResponse(true);
		servletResponse.setContentType("application/json");
		servletResponse.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP																								// 1.1.
		servletResponse.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		servletResponse.setDateHeader("Expires", 0); // Proxies.
		
    	//response.write("<script>alert(\"iView ID from HelpComp: \");</script>");
    	String objectID = request.getParameter(REQUEST_OBJECT_ID_PARAM);
    	//response.write("<script>alert(\"iView ID from HelpComp: \"" + objectID + ");</script>");
    	IPortalComponentContext componentContext = request.getComponentContext(objectID); //"pcd:com.sap.portal.system/pcc/regionalization/com.sap.portal.pcc/StagingAreaId/Home_0/Home_0/00-EmptyRegion_en/00-EmptyRegion_en/1439988276"
    	IPortalComponentProfile profile = componentContext.getProfile();
    	String helpURL = profile.getAttributeValue("com.sap.portal.iview.HelpURL");
    	//response.write("<script>alert(\"help URL from HelpComp: \"" + helpURL + ");</script>");
    	response.write("{\"success\" : true, \"url\" : \"" + helpURL + "\"}");
    }
    		   
}