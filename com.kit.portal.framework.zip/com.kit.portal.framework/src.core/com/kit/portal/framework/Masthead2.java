package com.kit.portal.framework;

 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.NoSuchAttributeException;

import com.kit.portal.utils.KMUtils;
import com.sap.security.api.IGroup;
import com.sap.security.api.IGroupFactory;
import com.sap.security.api.IRole;
import com.sap.security.api.IRoleFactory;
import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.navigation.INavigationConstants;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.session.IUserContext;
import com.sapportals.portal.prt.util.StringUtils;


public class Masthead2 extends AbstractPortalComponent
{
	
	public static String WGZ_ESS_ROLE_ID	= "ROLE.PCD_ROLE_PERSISTENCE.IZh766obr9M5hDAFgtVlaS279mw=";
	public static String WGZ_MSS_ROLE_ID	= "ROLE.PCD_ROLE_PERSISTENCE.5QaAShTwblZFdGM1K52cE9aaLCs=";
	public static String DZB_ESS_ROLE_ID	= "ROLE.PCD_ROLE_PERSISTENCE.j+kgNhH+nZlTcQiDDozsNHRfOZI=";
	public static String DZB_MSS_ROLE_ID	= "ROLE.PCD_ROLE_PERSISTENCE.fnyBj1lvggvNhf4OTr/fUlGRI0M=";
	public static String PCD_INVISIBLE = "com.sapportals.portal.navigation.Invisible";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		IPortalComponentContext myContext = request.getComponentContext();
		IPortalComponentProfile profile = myContext.getProfile();
		String parameter = profile.getProperty("p1");
		EnhancedPortalResponse ehp = new EnhancedPortalResponse(request);
		//do something
		ehp.setDocTypeToHtml40Strict();
		NavigationNodes init = this.getInitialNodes(request);
		// all necessary rendering is done in the JSP
		request.getServletRequest().getSession().setAttribute("objectID", "");
	//	this.checkWGZUser(request, response);
		response.include(request, request.getResource(IResource.JSP, "jsp/Masthead2.jsp"));
			
	}
	
	private NavigationNodes getInitialNodes(IPortalComponentRequest request) {
		INavigationService service = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		NavigationNodes initialNodes = null;
		
		try {
			initialNodes = service.getInitialNodes(this.getEnvironment(request));
		} catch (NamingException ne) {
			//loc.errorT("Error getting initial nodes! " + LoggingUtils.getErrorLog(ne));
		}
		return initialNodes;
	}
	
	public Hashtable getEnvironment(IPortalComponentRequest request) {
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
				NavigationEventsHelperService.KEY);
		Hashtable environment = navHelperService.getEnvironment(request);

		return environment;
	}
	
	private void checkNavNodes(IPortalComponentRequest request, IPortalComponentResponse response, NavigationNodes navigationNodes, int level) {
		if (navigationNodes == null) {
			return;
		}
		NavigationNodes children;
		Iterator it = navigationNodes.iterator();
		INavigationNode navigationNode;
		String name; // navigation node full path name
		String title; // navigation node title

		while (it.hasNext()) {
			navigationNode = (INavigationNode) it.next();
			title = navigationNode.getTitle(request.getLocale());
			name = StringUtils.escapeToJS(navigationNode.getName());
			try {
				String invisible = navigationNode.getAttributeValue(PCD_INVISIBLE).toString();
				response.write("<script>console.log(\"Node: " + name + " >> "+invisible+"////\");</script>");
				if(name.equalsIgnoreCase(this.WGZ_ESS_ROLE_ID) && !this.checkWGZUser(request, response) && invisible.equalsIgnoreCase("false")){
					//navigationNode.
				}
			} catch (NoSuchAttributeException e) {
				response.write("<script>console.log(\"Node: " + name + " >> ERROR////\");</script>");
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				//windowFeatures = (String) navigationNode.getAttributeValue("com.sapportals.portal.navigation.WinFeatures");

			// Get children nodes and call renderNavNodes recursively
//			try {
//				children = navigationNode.getChildren();
//				renderNavNodes(request, response, children, level + 1);
//			} catch (NamingException ne) {
//				//loc.errorT(LoggingUtils.getErrorLog(ne));
//			}
		}
	}
	


	public static NavigationNodes getPathNodes(IPortalComponentRequest request) {
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);

		List list = helperService.getNavNodesListForPath(request, INavigationConstants.NAVIGATION_CONTEXT_ATTR);
		NavigationNodes nodes = new NavigationNodes();
		for (Iterator it = list.iterator(); it.hasNext();) {
			nodes.add(it.next());
		}

		return nodes;
	}
	
	private boolean checkWGZUser(IPortalComponentRequest request, IPortalComponentResponse response){
    	try {
    		com.sapportals.wcm.repository.IResource resource = KMUtils.getResource("/documents/DZ BANK/WGZ/WGZ_Mitarbeiter.txt");//"/guid/70ed50ff-2511-3410-3f81-a66777522c0e"); //"/documents/DZ%20BANK/WGZ/WGZ_Mitarbeiter.txt");

			if(resource != null){
				List<String> list = KMUtils.parseTxtFile(resource);
				for (int i = 0; i < list.size(); i++) {
					String str = list.get(i);
		   			IUserContext userContext = request.getUser();
	    			String userID = userContext.getName(); 
	    		//	userContext.g
	    			if(userID.equalsIgnoreCase(str)){
	    				 response.write("<script>console.log(\"Das ist ein WGZ Benutzer. ESS und MSS Rollen werden ge�ndert!! \");</script>");
	    				 return true;
	    				 //		 this.switchWGZRoles(true, userContext, request, response);
	    			}
				}
			}
		} catch (Exception e) {
			response.write("<div> error getting resource " + e.getMessage() + " </div>");
			e.printStackTrace();
		}
    	return false;
	}
	
	private void switchWGZRoles(boolean isWGZ, IUserContext userContext, IPortalComponentRequest request, IPortalComponentResponse response){
	
		if (userContext != null) { 
			IUserMaint mutUser = null;
			try {
				String userID = userContext.getUniqueID();
				IRoleFactory rfact = UMFactory.getRoleFactory();
				IGroupFactory gfact= UMFactory.getGroupFactory();
				mutUser = UMFactory.getUserFactory().getMutableUser(userID);
				Iterator rit = mutUser.getRoles(true);	
				while (rit.hasNext()) {
					IRole object = (IRole) rit.next();
					
				}
				String groupName = "GRUP.R3_ROLE_DS.DZ:HCM:ESS-MITARBEITER";
				IGroup group = gfact.getGroup(groupName);
				
				//make sure the ESS Role role is not given to any group > will be assigned dynamically 
				 String[] groups = rfact.getGroupsOfRole(DZB_ESS_ROLE_ID, true);
				 for (int i = 0; i < groups.length; i++) {
					String gr = groups[i];
					rfact.removeGroupFromRole(gr, DZB_ESS_ROLE_ID);	
				}
				//make sure the WGZ ESS Role role is not given to any group > will be assigned dynamically 
				 String[] groupsWGZ = rfact.getGroupsOfRole(WGZ_ESS_ROLE_ID, true);
				 for (int i = 0; i < groupsWGZ.length; i++) {
					String gr = groupsWGZ[i];
					rfact.removeGroupFromRole(gr, WGZ_ESS_ROLE_ID);	
				}				 
				
				boolean userInGroup = mutUser.isMemberOfGroup(groupName, true);
				boolean userWGZRole = mutUser.isMemberOfRole(WGZ_ESS_ROLE_ID, true);
				boolean userDZBRole = mutUser.isMemberOfRole(DZB_ESS_ROLE_ID, true);
				if(isWGZ && userInGroup && !userWGZRole && !userDZBRole){
					rfact.addUserToRole(userID, WGZ_ESS_ROLE_ID);	
				} 
				else if (isWGZ && userInGroup && !userWGZRole && userDZBRole){
					  rfact.removeUserFromRole(userID, DZB_ESS_ROLE_ID);
					  rfact.addUserToRole(userID, WGZ_ESS_ROLE_ID);	
				}
				else if (!isWGZ && userInGroup && !userWGZRole && !userDZBRole){
					rfact.addUserToRole(userID, DZB_ESS_ROLE_ID);	
				}
				else if (!isWGZ && userInGroup && userWGZRole && !userDZBRole){
					  rfact.removeUserFromRole(userID, WGZ_ESS_ROLE_ID);
					  rfact.addUserToRole(userID, DZB_ESS_ROLE_ID);	
				}
//				while(rit.hasNext() && userInGroup){
//					 String roleName = (String) rit.next();
//					  IRole role = null;
//					  try {
//						  rfact.addGroupToRole(groupName,  WGZ_ESS_ROLE_ID);
//						  role = rfact.getRole(roleName);
//						  if(role.getUniqueID().equalsIgnoreCase(DZB_ESS_ROLE_ID)){
//							 
//							  rfact.removeUserFromRole(userID, roleName);
//							  rfact.addUserToRole(userID, WGZ_ESS_ROLE_ID);					
//							  response.write("<script>console.log(\"Role switched.\");</script>");
//						  }							  
//					//	  response.write("<script>console.log(\"Role "+  role.getDisplayName() +" ID: "+  role.getUniqueID() +"\");</script>");
//						  } catch (UMException e) {
//						  response.write("error: " + e.getLocalizedMessage());
//					  }
//				}
				mutUser.save();
				mutUser.commit();
				
			} catch (UMException e1) {
				mutUser.rollback();
			} catch (Exception e2) {
				mutUser.rollback();
			}
		}
	}

}