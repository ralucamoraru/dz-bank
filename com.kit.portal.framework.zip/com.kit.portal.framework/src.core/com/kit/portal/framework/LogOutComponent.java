package com.kit.portal.framework;

import com.sap.security.api.UMFactory;
import com.sapportals.portal.navigation.INavigationGenerator;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IEvent;
import com.sapportals.portal.prt.runtime.PortalRuntime;

public class LogOutComponent extends AbstractPortalComponent
{

    public LogOutComponent()
    {
    }

    public void doOnNodeReady(IPortalComponentRequest iportalcomponentrequest, IEvent ievent)
    {
        String s = UMFactory.getProperties().get("ume.logoff.redirect.url");
        boolean flag = UMFactory.getProperties().getBoolean("ume.logoff.redirect.silent", false);
        if(s != null && !s.equals("") && !flag)
        {
            iportalcomponentrequest.redirect(s);
        } else
        {
            INavigationGenerator inavigationgenerator = (INavigationGenerator)PortalRuntime.getRuntimeResources().getService("com.sap.portal.navigation.service.navigation");
            String s1 = inavigationgenerator.getPortalURL(iportalcomponentrequest, null);
            iportalcomponentrequest.redirect(s1);
        }
    }

    public void doContent(IPortalComponentRequest iportalcomponentrequest, IPortalComponentResponse iportalcomponentresponse)
    {
    }
}