package com.kit.portal.framework;
 
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.NamingException;

import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;



public class Sitemap extends AbstractPortalComponent
{
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
				
		// all necessary rendering is done in the JSP
		response.include(request, request.getResource(IResource.JSP, "jsp/sitemap.jsp"));
	//	response.include(request, request.getResource(IResource.CSS, "../irj/go/km/docs/documents/style.css"));		
	}
	
	
//	public NavigationNodes getSortedNavigation (IPortalComponentRequest request){
//		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
//		Hashtable environment = helperService.getEnvironment(request);
//		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
//		
//		NavigationNodes leafNodes = new NavigationNodes();
//		try {
//			NavigationNodes initialNodes = navService.getInitialNodes(environment);
//			this.recurseNavNodes(initialNodes, 0, leafNodes);
//			//leafNodes = this.sortNodes(leafNodes, request.getLocale());
////			Iterator it = nodeList.iterator();
////			while (it.hasNext()){
////				INavigationNode node = (INavigationNode)it.next();
////				node.getTitle(request.getLocale());
////				
////			}
//			
//			
//		} catch (NamingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return leafNodes;
//	}
	
/*	public String getParentRoles (IPortalComponentRequest request, INavigationNode node){
		String parentRole = ""; 
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		Hashtable environment = helperService.getEnvironment(request);
		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);

		try {
			INavigationNode pNode = node;
			INavigationNode pSubNode = node;
			NavigationNodes initialNodes = navService.getInitialNodes(environment);		
			while (!initialNodes.contains(pNode)){
				String parent = navService.getNavNodeParentName(environment, node.getName()); 
				pNode = navService.getNode(environment, parent);
				pSubNode = node;
				node = pNode;
			}
			parentRole = pNode.getTitle(request.getLocale()) + " > "+ pSubNode.getTitle(request.getLocale());
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return parentRole;
	}*/
	
//	
//	public NavigationNodes sortNodes(NavigationNodes list, Locale locale){
//		final Locale l = locale; 
//		if (!list.isEmpty() && list != null) {
//		    Collections.sort(list, new Comparator<INavigationNode>() {
//		        @Override
//		        public int compare(final INavigationNode node1, INavigationNode node2) {
//		            //You should ensure that list doesn't contain null values!
//		            return node1.getTitle(l).compareTo(node2.getTitle(l));
//		        }
//		       });
//		   }
//		return list;
//		
//	}
//	
//	 private void recurseNavNodes(NavigationNodes navigationNodes, int level, NavigationNodes leafNodes) 
//	 {
//	   if (navigationNodes == null) 
//		   return;
//	   Iterator it = navigationNodes.iterator();
//	   INavigationNode navigationNode;
//
//	   while (it.hasNext()) {
//	    navigationNode = (INavigationNode) it.next();
//	    try {
//		    // Get children nodes and call recurseNavNodes recursively
//		    if(navigationNode.hasChildren())
//		    {		
//			    recurseNavNodes(navigationNode.getChildren(), level + 1, leafNodes);
//		    }else
//		    {
//		    	//leaf node > put it in the list
//		    	leafNodes.add(navigationNode);
//		    }
//	    } catch (NamingException ne) {	
//		    ne.printStackTrace();
//		  }
//
//	   }
//
//	 }
//	
	
}