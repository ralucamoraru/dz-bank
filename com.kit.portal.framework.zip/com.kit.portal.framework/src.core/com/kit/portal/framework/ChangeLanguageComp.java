package com.kit.portal.framework;

import java.util.Locale;

import javax.servlet.http.HttpSession;

import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.session.IUserContext;

/**
 * 
 * @author ralucamoraru@gmail.com
 *
 */
public class ChangeLanguageComp extends AbstractPortalComponent
{

    public ChangeLanguageComp()
    {
    }

    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response)
    {		
    		// read new locale from parameter "locale"
    		String language = "en";
    		String currLanguage = request.getLocale().getLanguage();

    		
    		if (currLanguage.equals("de"))
    			language = "en";
    		else if (currLanguage.equals("en"))	
    			language = "de";
    		String country = "";
    		if (language == null)
    			language = "en";
    		if (language != null && !language.equals("")) {
    			IUserContext userContext = request.getUser();
    			String userID = userContext.getUniqueID();
    			Locale newLocale = new Locale(language, country);

    			if (userID != null && !newLocale.equals(request.getLocale())) {
    				// currently set locale and the given locale differ, set new locale 
    				IUserMaint mutUser = null;
    				try {
    					mutUser = UMFactory.getUserFactory().getMutableUser(userID);
    					mutUser.setLocale(newLocale);
    					mutUser.save();
    					mutUser.commit();
    					
    				} catch (UMException e1) {
    					mutUser.rollback();
    				} catch (Exception e2) {
    					mutUser.rollback();
    				}
    			}
    		}
    		HttpSession session = request.getServletRequest().getSession();
    		if (session.getAttribute("switch") == null || session.getAttribute("switch").toString().equalsIgnoreCase("true")){
    			session.setAttribute("switch", "false");
    		}
    	response.include(request, request.getResource(IResource.JSP, "jsp/ChangeLanguageComp.jsp"));	
    }
    		   
}