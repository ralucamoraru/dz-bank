package com.kit.portal.framework;
 
import java.util.List;

import com.kit.portal.utils.KMUtils;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.wcm.repository.IResource;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class TestComp extends AbstractPortalComponent
{
    /**
     * 
     */
    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) 
    {     	
    	
    	try {
			IResource resource = KMUtils.getResource("/documents/DZ BANK/WGZ/WGZ_Mitarbeiter.txt");//"/guid/70ed50ff-2511-3410-3f81-a66777522c0e"); //"/documents/DZ%20BANK/WGZ/WGZ_Mitarbeiter.txt");
			if(resource == null)
				response.write("<div> Resource is null </div>");
			else{
				List<String> list = KMUtils.parseTxtFile(resource);
				for (int i = 0; i < list.size(); i++) {
					String str = list.get(i);
					response.write("<div> User: " + str + " </div>");
				}
			}
		} catch (Exception e) {
			response.write("<div> error getting resource " + e.getMessage() + " </div>");
			e.printStackTrace();
		}

    }
   	 
 	
}