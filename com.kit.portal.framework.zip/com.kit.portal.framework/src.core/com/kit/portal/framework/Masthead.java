package com.kit.portal.framework;

 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.naming.directory.NoSuchAttributeException;

import com.kit.portal.utils.KMUtils;
import com.sap.security.api.IGroup;
import com.sap.security.api.IGroupFactory;
import com.sap.security.api.IRole;
import com.sap.security.api.IRoleFactory;
import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapconsulting.portal.utils.html.elements.HtmlFactory;
import com.sapportals.portal.navigation.INavigationConstants;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.session.IUserContext;
import com.sapportals.portal.prt.util.StringUtils;


public class Masthead extends AbstractPortalComponent
{
	
	public static String PCD_INVISIBLE = "com.sapportals.portal.navigation.Invisible";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {

		EnhancedPortalResponse epResponse = new EnhancedPortalResponse(request);
		// <!doctype html>
		epResponse.setDocTypeToHtml5();
		String browserDocumentMode = "ie=edge,chrome=1";
		request.getServletResponse(false).addHeader("X-UA-Compatible", browserDocumentMode);		
		// <meta http-equiv='x-ua-compatible' content='ie=edge,chrome=1'>
		epResponse.include(HtmlFactory.createHttpEquivMeta("X-UA-Compatible", browserDocumentMode));
		// <meta charset='utf-8'>
		epResponse.include(HtmlFactory.createCharsetMeta("UTF-8"));			

		// all necessary rendering is done in the JSP
		request.getServletRequest().getSession().setAttribute("objectID", "");
		response.include(request, request.getResource(IResource.JSP, "jsp/Masthead.jsp"));
			
	}
	
	private NavigationNodes getInitialNodes(IPortalComponentRequest request) {
		INavigationService service = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		NavigationNodes initialNodes = null;
		
		try {
			initialNodes = service.getInitialNodes(this.getEnvironment(request));
		} catch (NamingException ne) {
			//loc.errorT("Error getting initial nodes! " + LoggingUtils.getErrorLog(ne));
		}
		return initialNodes;
	}
	
	public Hashtable getEnvironment(IPortalComponentRequest request) {
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(
				NavigationEventsHelperService.KEY);
		Hashtable environment = navHelperService.getEnvironment(request);

		return environment;
	}
	
	

}