package com.kit.portal.framework;

import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.service.laf.ILAFService;

public class LogoffConfirmMsg extends AbstractPortalComponent
{

    public LogoffConfirmMsg()
    {
    }

    public void doContent(IPortalComponentRequest iportalcomponentrequest, IPortalComponentResponse iportalcomponentresponse)
    {
        ILAFService ilafservice = (ILAFService)PortalRuntime.getRuntimeResources().getService("com.sap.portal.themes.lafservice.laf");
        ilafservice.includeThemePartInResponse("ctrl", iportalcomponentrequest, iportalcomponentresponse);
        com.sapportals.portal.prt.resource.IResource iresource = iportalcomponentrequest.getResource("jsp", "jsp/LogoffConfirmMsg.jsp");
        iportalcomponentresponse.include(iportalcomponentrequest, iresource);
    }
}