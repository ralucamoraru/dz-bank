package com.kit.portal.framework;


import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;

public class PageLayout extends AbstractPortalComponent {
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		//response.include(request, request.getResource(IResource.SCRIPT, "scripts/utils.js"));
		// all necessary rendering is done in the JSP
		response.include(request, request.getResource(IResource.JSP, "jsp/framework.jsp"));
		//this.resizeIFrameEPCM(request, response);
	}
	
	private void resizeIFrameEPCM(IPortalComponentRequest request, IPortalComponentResponse response){
		response.write("<script type='text/javascript'>");
		response.write("resizeContent();");
	//	response.write("workArea.resizeIframe();");
	//	response.write("EPCM.subscribeEvent('urn:com.sapportals.portal:browser','resize',workArea.resizeIframe);");
	//	response.write("EPCM.subscribeEvent('urn:com.sapportals.portal:browser','load',workArea.resizeIframe);");
		response.write("</script>");
	}
}

