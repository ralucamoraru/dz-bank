package com.kit.portal.framework;

import java.util.Locale;

import javax.servlet.http.HttpSession;

import com.sap.engine.interfaces.webservices.uddi.UserAccount;
import com.sap.security.api.IUserAccount;
import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.session.IUserContext;

/**
 * 
 * @author ralucamoraru@gmail.com
 *
 */
public class ChangePasswordComp extends AbstractPortalComponent
{
	  public static final String REQUEST_OLD_PW_PARAM = "oldPW";
	  public static final String REQUEST_NEW_PW_PARAM = "newPW";

    public ChangePasswordComp()
    {
    }

    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response)
    {		    		
		String oldPW = request.getParameter(REQUEST_OLD_PW_PARAM);
		String newPW = request.getParameter(REQUEST_NEW_PW_PARAM);
    	IUserContext userContext = request.getUser();
		String userID = userContext.getUniqueID();

		if (userID != null) {
			IUserAccount mutUserAcct = null;
			try {
				IUserAccount userAcct = UMFactory.getUserAccountFactory().getUserAccountByLogonId(userID);
				mutUserAcct = UMFactory.getUserAccountFactory().getMutableUserAccount(userAcct.getUniqueID());
		
				boolean isValid = userAcct.checkPassword(oldPW);
				if (isValid){
					mutUserAcct.setPassword(newPW);
					userAcct.save();
					userAcct.commit();
				}				
			} catch (UMException e1) {
				mutUserAcct.rollback();
			} catch (Exception e2) {
				mutUserAcct.rollback();
			}
		}
    		
    		HttpSession session = request.getServletRequest().getSession();
    		if (session.getAttribute("switchPW") == null || session.getAttribute("switchPW").toString().equalsIgnoreCase("true")){
    			session.setAttribute("switchPW", "false");
    		}
    	response.include(request, request.getResource(IResource.JSP, "jsp/ChangePasswordComp.jsp"));	
    }
    		   
}