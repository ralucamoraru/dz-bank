package com.kit.portal.response;

import com.sapportals.portal.prt.util.html.IHtmlUniqueObject;

public interface IHtmlUniqueElement extends IHtmlUniqueObject
{

}
