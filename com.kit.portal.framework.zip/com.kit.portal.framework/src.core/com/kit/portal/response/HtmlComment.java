package com.kit.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlComment extends HtmlVoidElement implements IHtmlDeferrable
{
	protected String	comment;

	public HtmlComment(String comment)
	{
		this.comment = comment;
	}

	@Override
	public void output(StringBuffer strbuf)
	{
		if (this.isNewLine) {
			strbuf.append("\n");
		}
		strbuf.append("<!-- ");
		strbuf.append(this.comment);
		strbuf.append(" -->");
	}

	@Override
	public void output(Writer writer)
	{
		try {
			if (this.isNewLine) {
				writer.write("\n");
			}
			writer.write("<!-- ");
			writer.write(this.comment);
			writer.write(" -->");
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getComment()
	{
		return this.comment;
	}

	public HtmlComment setComment(String comment)
	{
		this.comment = comment;
		return this;
	}

}
