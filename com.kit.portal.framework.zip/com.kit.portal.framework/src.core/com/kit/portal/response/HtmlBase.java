package com.kit.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlBase extends HtmlVoidElement
{

	protected String	href;
	protected String	target;

	public HtmlBase()
	{
		setTag("base");
	}

	public HtmlBase(String href, String target)
	{
		setTag("base");
		this.href = href;
		this.target = target;
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.href != null) {
			strbuf.append(" href=\"");
			strbuf.append(this.href);
			strbuf.append("\"");
		}
		if (this.target != null) {
			strbuf.append(" target=\"");
			strbuf.append(this.target);
			strbuf.append("\"");
		}
	}

	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (this.href != null) {
				writer.write(" href=\"");
				writer.write(this.href);
				writer.write("\"");
			}
			if (this.target != null) {
				writer.write(" target=\"");
				writer.write(this.target);
				writer.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getHref()
	{
		return this.href;
	}

	public HtmlBase setHref(String href)
	{
		this.href = href;
		return this;
	}

	public String getTarget()
	{
		return this.target;
	}

	public HtmlBase setTarget(String target)
	{
		this.target = target;
		return this;
	}

}
