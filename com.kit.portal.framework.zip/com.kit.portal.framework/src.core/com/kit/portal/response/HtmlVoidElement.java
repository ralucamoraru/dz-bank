package com.kit.portal.response;

import java.io.IOException;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;
import com.sapportals.portal.prt.util.html.HtmlSinglePartElement;

public class HtmlVoidElement extends HtmlSinglePartElement implements IHtmlElement
{
	protected boolean	isNewLine			= false;
	protected boolean	isXHTMLCompliant	= false;

	public void output(StringBuffer strbuf)
	{
		if (this.isNewLine) {
			strbuf.append("\n");
		}
		strbuf.append("<");
		strbuf.append(getTag());
		outputAttributes(strbuf);
		if (isXHTMLCompliant()) {
			strbuf.append("/>");
		} else {
			strbuf.append(">");
		}
	}

	public void output(Writer writer)
	{
		try {
			if (this.isNewLine) {
				writer.write("\n");
			}
			writer.write("<");
			writer.write(getTag());
			outputAttributes(writer);
			if (isXHTMLCompliant()) {
				writer.write("/>");
			} else {
				writer.write(">");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public HtmlVoidElement setNewLine(boolean isNewLine)
	{
		this.isNewLine = isNewLine;
		return this;
	}

	public boolean isNewLine()
	{
		return this.isNewLine;
	}

	public HtmlVoidElement setXHTMLCompliant(boolean isXHTMLCompliant)
	{
		this.isXHTMLCompliant = isXHTMLCompliant;
		return this;
	}

	public boolean isXHTMLCompliant()
	{
		return this.isXHTMLCompliant || super.isThreadXHTMLCompliant();
	}

}
