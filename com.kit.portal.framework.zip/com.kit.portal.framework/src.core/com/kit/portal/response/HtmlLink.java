package com.kit.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlLink extends HtmlVoidElement implements IHtmlUniqueElement
{

	protected String	rel;
	protected String	href;
	protected String	type;
	protected String	media;

	public HtmlLink(String rel, String href, String type, String media)
	{
		setTag("link");
		this.rel = rel;
		this.href = href;
		this.type = type;
		this.media = media;
	}

	@Override
	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.rel != null) {
			strbuf.append(" rel=\"");
			strbuf.append(this.rel);
			strbuf.append("\"");
		}
		if (this.href != null) {
			strbuf.append(" href=\"");
			strbuf.append(this.href);
			strbuf.append("\"");
		}
		if (this.type != null) {
			strbuf.append(" type=\"");
			strbuf.append(this.type);
			strbuf.append("\"");
		}
		if (this.media != null) {
			strbuf.append(" media=\"");
			strbuf.append(this.media);
			strbuf.append("\"");
		}
	}

	@Override
	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (this.rel != null) {
				writer.write(" rel=\"");
				writer.write(this.rel);
				writer.write("\"");
			}
			if (this.href != null) {
				writer.write(" href=\"");
				writer.write(this.href);
				writer.write("\"");
			}
			if (this.type != null) {
				writer.write(" type=\"");
				writer.write(this.type);
				writer.write("\"");
			}
			if (this.media != null) {
				writer.write(" media=\"");
				writer.write(this.media);
				writer.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getUniqueId()
	{
		return this.href;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	public void getUniqueHtmlCode(Writer out)
	{
		output(out);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter out)
	{
		output(out);
	}

	public String getRel()
	{
		return this.rel;
	}

	public HtmlLink setRel(String rel)
	{
		this.rel = rel;
		return this;
	}

	public String getHref()
	{
		return this.href;
	}

	public HtmlLink setHref(String href)
	{
		this.href = href;
		return this;
	}

	public String getType()
	{
		return this.type;
	}

	public HtmlLink setType(String type)
	{
		this.type = type;
		return this;
	}

	public String getMedia()
	{
		return this.media;
	}

	public HtmlLink setMedia(String media)
	{
		this.media = media;
		return this;
	}
}
