package com.kit.portal.response;

import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.util.html.IHtmlOutputable;
import com.sapportals.portal.prt.util.html.IHtmlUniqueObject;

public class HtmlUniqueElementWrapper implements IHtmlUniqueElement
{

	IHtmlOutputable	element;

	public HtmlUniqueElementWrapper(IHtmlOutputable element)
	{
		this.element = element;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public String getUniqueId()
	{
		// if the wrapped element itself is of type IHtmlUniqueObject, then pass its unique ID
		if (this.element instanceof IHtmlUniqueObject) {
			return ((IHtmlUniqueObject) element).getUniqueId();
		} else {
			// otherwise take the HTML output as a unique ID (fallback)
			return element.toString();
		}
	}

	public void destroy()
	{
		this.element.destroy();
	}

	public int getElementCount()
	{
		return this.element.getElementCount();
	}

	public void output(StringBuffer strbuf)
	{
		this.element.output(strbuf);
	}

	@Deprecated
	public void output(PrintWriter writer)
	{
		this.element.output(writer);
	}

	public void output(Writer writer)
	{
		this.element.output(writer);
	}
}
