package com.kit.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlScript extends HtmlNormalElement implements IHtmlUniqueElement, IHtmlDeferrable
{

	protected String	uniqueId;
	protected String	src;
	protected String	type;
	protected boolean	isDeferred;

	public HtmlScript()
	{
		setTag("script");
	}

	public HtmlScript(String src, String type)
	{
		setTag("script");
		setSrc(src);
		setType(type);
	}

	public HtmlScript(String src, String type, boolean isDeferred)
	{
		setTag("script");
		setSrc(src);
		setType(type);
		setDeferred(isDeferred);
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (isXHTMLCompliant() && this.type != null) {
			this.type = "text/javascript";
		}

		if (this.src != null) {
			strbuf.append(" src=\"").append(this.src).append("\"");
		}
		if (this.type != null) {
			strbuf.append(" type=\"").append(this.type).append("\"");
		}
		if (this.isDeferred == true) {
			strbuf.append(" defer=\"defer\"");
		}
	}

	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (isXHTMLCompliant() && this.type != null) {
				this.type = "text/javascript";
			}

			if (this.src != null) {
				writer.write(" src=\"");
				writer.write(this.src);
				writer.write("\"");
			}
			if (this.type != null) {
				writer.write(" type=\"");
				writer.write(this.type);
				writer.write("\"");
			}
			if (this.isDeferred == true) {
				writer.write(" defer=\"defer\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public String getSrc()
	{
		return this.src;
	}

	public HtmlScript setSrc(String src)
	{
		this.src = src;
		this.uniqueId = this.src;
		return this;
	}

	public String getType()
	{
		return this.type;
	}

	public HtmlScript setType(String type)
	{
		this.type = type;
		return this;
	}

	public boolean getDeferred()
	{
		return this.isDeferred;
	}

	public HtmlScript setDeferred(boolean isDeferred)
	{
		this.isDeferred = isDeferred;
		return this;
	}
}
