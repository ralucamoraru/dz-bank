package com.kit.portal.response;




import org.apache.commons.lang.StringUtils;

import com.sapportals.portal.prt.util.html.HtmlImage;



public class HtmlFactory
{

	public static HtmlBase createBase(String href, String target)
	{
		HtmlBase htmlBase = new HtmlBase(href, target);
		return htmlBase;
	}

	public static HtmlMeta createMeta(String name, String content)
	{
		HtmlMeta htmlMeta = new HtmlMeta(name, content);
		return htmlMeta;
	}

	public static HtmlHttpEquivMeta createHttpEquivMeta(String httpEquiv, String content)
	{
		HtmlHttpEquivMeta htmlHttpEquivMeta = new HtmlHttpEquivMeta(httpEquiv, content);
		return htmlHttpEquivMeta;
	}

	public static HtmlCharsetMeta createCharsetMeta(String charset)
	{
		HtmlCharsetMeta htmlCharsetMeta = new HtmlCharsetMeta(charset);
		return htmlCharsetMeta;
	}

	public static HtmlLink createLink(String rel, String href, String type, String media)
	{
		HtmlLink htmlLink = new HtmlLink(rel, href, type, media);
		return htmlLink;
	}

	public static HtmlStyle createStyle(String type, String media, String content)
	{
		HtmlStyle htmlStyle = new HtmlStyle(type, media, content);
		return htmlStyle;
	}

	public static HtmlScript createScript(String src, String type)
	{
		HtmlScript htmlScript = new HtmlScript(src, type);
		return htmlScript;
	}

	public static HtmlScript createInlineScript(String script, String type)
	{
		HtmlScript htmlScript = new HtmlScript(null, type);
		htmlScript.addElement(script);
		htmlScript.setUniqueId(script);
		return htmlScript;
	}

	public static HtmlComment createComment(String comment)
	{
		HtmlComment htmlComment = new HtmlComment(comment);
		return htmlComment;
	}

	public static HtmlConditionalComment createConditionalComment(String condition, boolean isDownlevelRevealed, IHtmlElement... elements)
	{
		HtmlConditionalComment htmlConditionalComment = new HtmlConditionalComment(condition, isDownlevelRevealed);
		for (IHtmlElement element : elements) {
			htmlConditionalComment.addElement(element);
		}
		return htmlConditionalComment;
	}

	public static HtmlScript createSAPUI5Config(String theme, String themeRoot, String libs, String language, String preloadMode, boolean debug, boolean trace)
	{
		return createInlineScript("window[\"sap-ui-config\"] = {" + "themeRoots : {}, theme : \"" + theme + "\",   " + (preloadMode!=null?"preload : \"" + preloadMode + "\",":"")  + (StringUtils.isNotBlank(libs)?"libs : \"" + libs + "\"," : "")
									+ (language != null ? "language : \"" + language + "\"," : "") + "debug : " + debug + "," + "trace : " + trace + "};" +
											(StringUtils.isNotBlank(themeRoot)?("window[\"sap-ui-config\"].themeRoots[\""+ theme +"\"]=\"" + themeRoot + "\";"):""), "text/javascript");
	}

	public static HTMLSAPUI5Bootstrap createSAPUI5Bootstrap(boolean debug, boolean enableCacheBuster)
	{
		HTMLSAPUI5Bootstrap bootstrap;
		if (debug) {
			bootstrap = new HTMLSAPUI5Bootstrap("/sapui5/resources/sap-ui-core-dbg.js");
		} else {
			
			if (enableCacheBuster) {
				bootstrap = new HTMLSAPUI5Bootstrap("/sapui5/resources/sap-ui-cachebuster/sap-ui-core.js");
			}else {
				bootstrap = new HTMLSAPUI5Bootstrap("/sapui5/resources/sap-ui-core.js");	
			}
			
		}
		return bootstrap;
	}

	public static HTMLSAPUI5Bootstrap createSAPUI5BootstrapFromHANA(boolean debug)
	{
		HTMLSAPUI5Bootstrap bootstrap;
		if (debug) {
			bootstrap = new HTMLSAPUI5Bootstrap("https://sapui5.netweaver.ondemand.com/resources/sap-ui-core-dbg.js");
		} else {
			bootstrap = new HTMLSAPUI5Bootstrap("https://sapui5.netweaver.ondemand.com/resources/sap-ui-core.js");
		}
		return bootstrap;
	}
	
	public static HTMLSAPUI5Bootstrap createSAPUI5BootstrapFromBackend(boolean debug, boolean enableCacheBuster)
	{
		HTMLSAPUI5Bootstrap bootstrap;
		if (debug) {
			bootstrap = new HTMLSAPUI5Bootstrap("https://dkassaphrt.dzbank.vrnet:44320/sap/bc/ui5_ui5/sap/ztestui5/resources/sap-ui-core-dbg.js");
		}  else {
			
			if (enableCacheBuster) {
				bootstrap = new HTMLSAPUI5Bootstrap("https://dkassaphrt.dzbank.vrnet:44320/sap/bc/ui5_ui5/sap/ztestui5/resources/sap-ui-cachebuster/sap-ui-core.js");
			}else {
				bootstrap = new HTMLSAPUI5Bootstrap("https://dkassaphrt.dzbank.vrnet:44320/sap/bc/ui5_ui5/sap/ztestui5/resources/sap-ui-core.js");	
			}
			
		}
		return bootstrap;
	}
	
	public static HTMLDivElement createLoadingAnimationDIV() {
		HTMLDivElement div  = new HTMLDivElement("MHPLoadingImageDIV");
		
		HtmlImage img = new HtmlImage("/com.sap.portal.design.urdesigndata/themes/portal/sap_tradeshow_plus/common/loading/lsloading_ani.gif");
		img.setID("MHPLoadingImage");
//		img.setWidth("49");
//		img.setHeight("49");
		
		div.addElement(img);
		return div;
		
	}

}
