package com.kit.portal.response;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

import com.sapportals.portal.prt.runtime.PortalRuntimeException;

public class HtmlCharsetMeta extends HtmlVoidElement implements IHtmlUniqueElement
{

	protected String	charset	= null;
	protected String	uniqueId;

	public HtmlCharsetMeta(String charset)
	{
		setTag("meta");

		this.charset = charset;
		setUniqueId(charset);
	}

	public void outputAttributes(StringBuffer strbuf)
	{
		super.outputAttributes(strbuf);

		if (this.charset != null) {
			strbuf.append(" charset=\"");
			strbuf.append(this.charset);
			strbuf.append("\"");
		}
		requireClosingTag(true);
	}

	public void outputAttributes(Writer writer)
	{
		super.outputAttributes(writer);

		try {
			if (this.charset != null) {
				writer.write(" charset=\"");
				writer.write(this.charset);
				writer.write("\"");
			}
		} catch (IOException e) {
			throw new PortalRuntimeException(e);
		}
		requireClosingTag(true);
	}

	public String getUniqueId()
	{
		return this.uniqueId;
	}

	public void setUniqueId(String uniqueId)
	{
		this.uniqueId = uniqueId;
	}

	public void getUniqueHtmlCode(StringBuffer strbuf)
	{
		output(strbuf);
	}

	@Deprecated
	public void getUniqueHtmlCode(PrintWriter writer)
	{
		output(writer);
	}

	public void getUniqueHtmlCode(Writer writer)
	{
		output(writer);
	}

	public HtmlCharsetMeta setCharset(String charset)
	{
		this.charset = charset;
		return this;
	}

	public String getCharset()
	{
		return this.charset;
	}
}
