package com.dzbank.portal.mss.team;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;
import javax.servlet.http.Cookie;

import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.component.IPortalComponentURI;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class OrganisationProfile extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";
	  private final String FUNCTION_ATTRIBUTE_NAME = "Name";
	  
	  private final String BACKEND_SYSTEM_ALIAS = "SAP_ECC_HumanResources";
	  private final String FUNCTION_NAME = "ZMSS_WDA_TV_SHP_O";
	  private final String FUNCTION_OUT_ORGINFO = "ORGINFO_TABLE";

	  private final String INPUT_NAME1 = "OBJID";	
	  private final String INPUT_NAME2 = "OTYPE";	
	  public static final String REQUEST_OBJECT_ID_PARAM = "objectID";
	  public static final String REQUEST_OBJECT_TYPE_PARAM = "objectType";
	  
	  final String REPORT_COMP_ROOT = "com.dzbank.portal.mss.report.";
	  final String MSS_REP_DIENSTJUBILAEN_COMP	= "MSSReportDienstjubilaen";
	  String[] reports = {"MSSReportAnwesenheit", "MSSReportAbwKont", "MSSReportVerstoese", "MSSReportDienstjubilaen", "MSSReportEinAustritte", "MSSReportBirthday", "MSSReportComp", "MSSReportHaendler",
			  			"MSSReportKappung", "MSSReportMutterschutz", "MSSReportVollmacht", "MSSReportZeitMeldung"};
	  String[] reportsOData = {"ZODATA_ANAB_SRV", "ZODATA_AKTG_SRV", "ZODATA_AZGV_SRV","ZODATA_DJUB_SRV", "ZODATA_EATR_SRV", "ZODATA_GEBT_SRV", "ZODATA_GHLT_SRV",  "ZODATA_MRSK_SRV",
	  			"ZODATA_KAPP_SRV", "ZODATA_MSEZ_SRV", "ZODATA_VMCT_SRV", "ZODATA_ZMLD_SRV"};
	  private final String ui5ReportComp = "com.dzbank.portal.ui5.ui5ReportTemplate";
	
	  private ResourceBundle nls;	
	  public IRecordSet data;

	
	public OrganisationProfile(){    
		this.data = null;
	}
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		//response.write("<script>alert(\"Test\");</script>");

		String objectID = request.getParameter(REQUEST_OBJECT_ID_PARAM);
		String objectType = request.getParameter(REQUEST_OBJECT_TYPE_PARAM);
		request.getServletRequest().getSession().setAttribute("objectID", objectID);
		request.getServletRequest().getSession().setAttribute("objectType", objectType);
		Cookie[] cookies =  request.getServletRequest().getCookies();
		for (int i = 0; i < cookies.length; i++) {
			Cookie c = cookies[i];
			if (c.getName().equalsIgnoreCase("PortalAlias"))
				c.setValue("portal/dzbank");
		}		
		//IRFCCallerService rfcService = (IRFCCallerService)PortalRuntime.getRuntimeResources().getService(IRFCCallerService.KEY);
		Object orgInfoResult = this.doRFCCallKurzProfil(request, FUNCTION_NAME, FUNCTION_OUT_ORGINFO, objectID, objectType);	
		//response.write("<script>alert(\"First param: "+objectID+" second param: "+objectType+"\");</script>");
		// href=\"#\" onclick=\"javascript:getOrgProfile('"+rootUnit.getID()+"');return false;\" // <a href=\""+this.GetReportURL(request) +"\">

		//response.write("<script>alert(\"" + orgInfoResult.toString() + "\");</script>");
		if(orgInfoResult instanceof LinkedHashMap){
			LinkedHashMap list = (LinkedHashMap)orgInfoResult;
			if (!list.isEmpty()){
				String objID = list.get("OBJID").toString();
				String pictureURL = list.get("PICTURE_URL").toString();
				String orgShort = list.get("ORG_KUERZEL").toString();
				String orgName = list.get("ORG_LANGTEXT").toString();
				String costCenter = list.get("KOSTL").toString();
				String leiter1 = list.get("ORG_LEITER1").toString();
				String leiter2 = list.get("ORG_LEITER2").toString();
				String leiter3 = list.get("ORG_LEITER3").toString();
				String leiter4 = list.get("ORG_LEITER4").toString();
				String planstelle = list.get("ORG_PLANSTELLEN").toString();
				String mitarbeiter = list.get("ORG_MITARBEITER").toString();
				String vakanzen = list.get("ORG_VAKANZEN").toString();
				String anwesend = list.get("ORG_ANWESEND").toString();
				//response.write("<div");
				//response.write("<div class=\"content_menue clearfix orga\">");
				//response.write("<div");
				//response.write("<h4>Ausführen: </h4>");
				
				response.write("<script>console.log(\"" + this.GetUI5ReportURL(request) + "\");</script>");
				response.write("<form id='reportForm' name='reportForm' target='_blank' method='POST' action='");
				response.write(this.GetUI5ReportURL(request));
				response.write("' style='height:0;width:0;overflow:hidden;position:absolute;top:-999em'>");				
				response.write("<input type='hidden' id='report-odata' name='report-odata'>");
				response.write("<input type='hidden' id='report-orgid' name='report-orgid'>");
				response.write("<input type='hidden' id='report-etype' name='report-etype'>");
				response.write("<input type='hidden' id='report-eset' name='report-eset'>");
				response.write("</form>");	
				

				response.write("<ul><li>");
				response.write("<h4>" + getNLSString(request, "TEAM_BERICHT") + ": </h4>");
				response.write("</li>");
				response.write("<li>");

				
				response.write("<select name=\"filter\" style=\"width:200px;\" onchange=\"filterReport(this, '"+ objectID +"', 'ZODATA_GEBT_SRV', 'MSS', 'MSSSet');\">");
				for (int i = 0; i < reports.length; i++) {
					response.write("<option value=\""+reportsOData[i]+"\">" + this.getNLSString(request, reports[i]) + "</option>");
				}
				
				response.write("</select>");
				
				response.write("</li></ul>");
				response.write("<br class=\"clear\" />");
				//response.write("</div>");
				//response.write("</div>");
				response.write("<h2>" + getNLSString(request, "TEAM_ORGA_PROFIL") + ": "+ orgName +"</h2>");	
				response.write("<div class=\"wrapper_inner clearfix\">");
				response.write("<h3>" + getNLSString(request, "TEAM_ORGA_DATEN") + "</h3>");
				response.write("<table width=\"805px\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">");
				response.write("<tr>");
				response.write("<td class=\"first\">");
				response.write("<img src=\"" + pictureURL + "\"/></td>");
				response.write("<td class=\"second second_orga\">");
				response.write("<p><strong> " + getNLSString(request, "TEAM_ORGA") + ": </strong> " + orgName + "</p>");
				response.write("<p><strong> " + getNLSString(request, "TEAM_KURZEL") + ": </strong> " + orgShort + "</p>");
				response.write("<p><strong> " + getNLSString(request, "TEAM_KS") + ": </strong> " + costCenter + "</p>");
				response.write("<p><strong> " + getNLSString(request, "TEAM_FK") + ": </strong> " + leiter1 + "</p>");	
				if(!leiter2.equals("") && leiter2!=null)
					response.write("<p><strong> " + getNLSString(request, "TEAM_ZWEITE_FK") + ": </strong> " + leiter2 + "</p>");
				if(!leiter2.equals("") && leiter3!=null)
					response.write("<p><strong> " + getNLSString(request, "TEAM_DRITTE_FK") + ": </strong> " + leiter3 + "</p>");
				if(!leiter2.equals("") && leiter4!=null)
					response.write("<p><strong> " + getNLSString(request, "TEAM_VIERTE_FK") + ": </strong> " + leiter4 + "</p>");
			//	response.write("<p><strong> Organisation ID: </strong> " + objID + "</p>");	
				response.write("<br />");
			//	response.write("<p><strong> " + getNLSString(request, "TEAM_PLAN") + ": </strong> " + planstelle + "</p>");
				response.write("<p><strong> " + getNLSString(request, "TEAM_MITARBEITER") + ": </strong> " + mitarbeiter + "</p>");
			//	response.write("<p><strong> " + getNLSString(request, "TEAM_VAKANZEN") + ": </strong> " + vakanzen + "</p>");
				response.write("<p><strong> " + getNLSString(request, "TEAM_ANWESEND") + ": </strong> " + anwesend + "</p>");
				response.write("</td>");
				response.write("</tr>");	
				response.write("</table>");
				response.write("</div>");
			}
			else{
				//response.write("<script>alert(\""+orgInfoResult.toString()+ "for the ID: "+objectID+"\");</script>");
				response.write("<p>Could not retrieve any organisational info from the backend system.</p>");
			}

		}

	}
	
	private String GetReportURL(IPortalComponentRequest request, String report)
	{
	    String componentName = REPORT_COMP_ROOT + report;
	    IPortalComponentURI msgURI = request.createPortalComponentURI();
	    msgURI.setContextName(componentName);
	    return msgURI.toString();
	}
	
	private String GetUI5ReportURL(IPortalComponentRequest request)
	{
	    String componentName = ui5ReportComp;
	    IPortalComponentURI msgURI = request.createPortalComponentURI();
	    msgURI.setContextName(componentName);
	    return msgURI.toString();
	}
	
	private IConnection getConnection(IPortalComponentRequest request) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		//String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}
	
	private String getNLSString(IPortalComponentRequest request, String resource_key) {
		try {
			ResourceBundle bundle = request.getResourceBundle();
			if (bundle != null) {
				return bundle.getString(resource_key);
			}
			return resource_key;
		} catch (MissingResourceException e) {
			return resource_key;
		}
	}
	
	public Object doRFCCallKurzProfil(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType) {
		IInteraction ix = null;
		IConnection connection = null;
		String ret = "Return: ";
		 Object rs = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				ret = ret + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			   
			    try {
			        Object result = output.get(rfcOutput);
			        if (result == null) {
			            rs = new String(" ");	
			          //  retValue = retValue + " result null";
			        } else if (result instanceof IRecordSet) {
			            //rs = (IRecordSet) result;
			            rs = this.getContent((IRecordSet) result);
			           // this.data = (IRecordSet) result;
			            ret = ret + "record set";// this.readRecordsSet();
			        }
			        else {
			            rs = result.toString();
			          //  retValue = retValue + "got result: "+result.toString();
			        }
			    } 
			    catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    connection.close();
			    return rs;

			}
		} catch (ConnectorException e) {
			ret = ret + "OrganisationProfile: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "OrganisationProfile: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "OrganisationProfile: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "OrganisationProfile: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "OrganisationProfile: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "OrganisationProfile: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return rs;
		
	}
	
	public LinkedHashMap getContent(IRecordSet recordSet) {
		String result = "";
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = recordSet.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 recordSet.beforeFirst();
			//go though each record
			while (recordSet.next()){
				for (int j = 0; j < cols.length; j++) {
					recordsMap.put(cols[j], recordSet.getString(cols[j]));
				}
			}
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			result = result + "exception";
			e.printStackTrace();
		}
		return recordsMap;
	}

}