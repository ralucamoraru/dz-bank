package com.dzbank.portal.mss.team.model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

import com.sapportals.portal.prt.component.IPortalComponentResponse;

@SuppressWarnings("serial")
public class UnitDTO implements Serializable, Comparable<UnitDTO> {
	private String ID;
	private String name;
	private String parentID;
	private boolean isRoot;
	private String ebene;
	private TreeSet<EmployeeDTO> employees = new TreeSet<EmployeeDTO>();
	private TreeSet<UnitDTO> units = new TreeSet<UnitDTO>();
	public Set<ActionDTO> actions = new LinkedHashSet<ActionDTO>();
	
	public UnitDTO() {
 
	}

	public UnitDTO(String ID, String name, String parentID) {
		this.ID = ID;
		this.name = name;
		this.parentID = parentID;
	}
	
	public UnitDTO getUnitForID (String ID){
		boolean found = false;
		if (this.getID().equalsIgnoreCase(ID))
			return this;
		else{
		    Iterator iter = this.units.iterator();
		    while (iter.hasNext()) {
		    	UnitDTO object = (UnitDTO) iter.next();
		    	UnitDTO res = object.getUnitForID(ID);
		    	if(res != null)
		    		return res;
		    	//	return object;					 
		    }
		}		
		return null;
	}
	
	public EmployeeDTO getEmployeeForID (String ID){
		boolean found = false;
		TreeSet<EmployeeDTO> employees = this.getEmployees();
		Iterator iter = employees.iterator();
		while(iter.hasNext()){
			EmployeeDTO emp = (EmployeeDTO)iter.next();
			if (emp.getID().equals(ID))
				return emp;
		}
		TreeSet<UnitDTO> units = this.getUnits();
		Iterator iter2 = units.iterator();
		while(iter2.hasNext()){
			UnitDTO unit = (UnitDTO)iter2.next();
			EmployeeDTO res = unit.getEmployeeForID(ID);
			if (res!=null)
				return res;
		}
		return null;
	}

	public String getID() {
		return this.ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}
	
	public String getEbene() {
		return this.ebene;
	}

	public void setEbene(String ebene) {
		this.ebene = ebene;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentID() {
		return this.parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}

	public TreeSet<EmployeeDTO> getEmployees() {
		return this.employees;
	}
	
	public TreeSet<EmployeeDTO> getManagers() {
		TreeSet<EmployeeDTO> managers = new TreeSet<EmployeeDTO>();
		Iterator iter = this.employees.iterator();
		while (iter.hasNext()) {
			EmployeeDTO object = (EmployeeDTO) iter.next();
	    	if(object.isManager()){
	    		managers.add(object);
	    	}
		}
		return managers;
	}

	public TreeSet<UnitDTO> getUnits() {
		return this.units;
	}
	
	public void setEmployees(TreeSet<EmployeeDTO> employees) {
		this.employees = employees;
	}

	public void addEmployee(EmployeeDTO employee, IPortalComponentResponse response) {
	    boolean toAdd = true;
	    Iterator iter = this.employees.iterator();
	    while (iter.hasNext()) {
	    	EmployeeDTO object = (EmployeeDTO) iter.next();
	    	if(object.getID().equals(employee.getID())){
	    		toAdd = false; 
	    	}					 
	    }
	    if (toAdd){
	    	boolean x = this.employees.add(employee);
	    }
	}

	public void addUnit(UnitDTO unit) {
	    boolean toAdd = true;
	    Iterator iter = this.units.iterator();
	    while (iter.hasNext()) {
	    	UnitDTO object = (UnitDTO) iter.next();
	    	if(object.getID().equals(unit.getID())){
	    		toAdd = false; 
	    	}					 
	    }
	    if (toAdd)
		this.units.add(unit);
	}	
	
	public boolean isRoot() {
		return this.isRoot;
	}

	public void setIsRoot(boolean isRoot) {
		this.isRoot = isRoot;
	}	
	
	public Set<ActionDTO> getActions() {
		return this.actions;
	}

	public void setActions(Set<ActionDTO> actions) {
		this.actions = actions;
	}
	
	@Override
	public int compareTo(UnitDTO o) {
		if(this.ID.equals("00049750") || this.name.equalsIgnoreCase("Dezernat Wolfgang Kirsch"))
			return -1;
		else if (o.ID.equals("00049750") || o.name.equalsIgnoreCase("Dezernat Wolfgang Kirsch"))
			return 1;
		int x =  this.ID.compareTo(o.ID);
		int y = this.name.compareTo(o.name);
		if( y != 0)
			return y;
		else
			return x;
	}



}
