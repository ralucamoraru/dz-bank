package com.dzbank.portal.mss.team;
 
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.dzbank.portal.mss.team.model.EmployeeDTO;
import com.dzbank.portal.mss.team.model.TreeDTO;
import com.dzbank.portal.mss.team.model.UnitDTO;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class TestComp extends AbstractPortalComponent
{
    public final String BACKEND_SYSTEM_ALIAS = "XPORT_SAPUI_LAYER";
    public final String USER_GET_DETAIL_FUNCTION = "/BSHB2B/CA_US_USER_GET_DETCUS1";
    public final String USER_GET_DETAIL_RESULT = "ET_USER2CUSTOMER1";
    public final String USER_INPUT_PARAM_NAME = "IV_UNAME";
    
   
    /**
     * 
     */
    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) 
    {     	
    	try {	
    		String retVal = "Return";
//    		response.write("<div> TREE </div>");	   
//    		TeamView team = new TeamView();
//    		retVal = retVal + team.getContent(request, response);
//    		TreeDTO tree = team.readTree(response);
//    		TreeSet<UnitDTO> roots = tree.getRootUnits();
//    	    Iterator iter = roots.iterator();
//    	    int rootNb = 1;
//    	    while (iter.hasNext()) {
//    	    	UnitDTO root = (UnitDTO) iter.next();
//    	    	this.recurseTree(root, response, 1);
//    	    	rootNb++;
//    	    }
    		response.write("<div> FINISHED RECURSION </div>");	
 /*   		
    		response.write("<div> Level 1: "+root.getName() + root.getID()+"</div>");
    		Set<UnitDTO> units = root.getUnits();
    		Set<EmployeeDTO> employees = root.getEmployees();
    		response.write("<div> Level 1 Employees </div>");
    		Iterator iter = employees.iterator();
    		while (iter.hasNext()){
    			EmployeeDTO emp = (EmployeeDTO)iter.next();
    			response.write("<div> "+emp.getName() + emp.getID()+"</div>");
    		}
    		response.write("<div> Level 1 Units </div>");
    		Iterator iter2 = units.iterator();
    		while (iter2.hasNext()){
    			UnitDTO unit = (UnitDTO)iter2.next();
    			response.write("<div> Level 2: UNIT: "+unit.getName() + unit.getID()+"</div>");
    			Set<EmployeeDTO> employees2 = unit.getEmployees();
        		response.write("<div> Level 2 Employees </div>");
        		Iterator iter3 = employees2.iterator();
        		while (iter3.hasNext()){
        			EmployeeDTO emp = (EmployeeDTO)iter3.next();
        			response.write("<div> "+emp.getName() + emp.getID()+"</div>");
        		}
        		Set<UnitDTO> units2 = unit.getUnits();
        		Iterator iter4 = units2.iterator();
        		while (iter4.hasNext()){
        			UnitDTO un = (UnitDTO)iter4.next();
        			response.write("<div> Level 3: UNIT: "+un.getName() + un.getID()+"</div>");
            		response.write("<div> Employees </div>");
            		Set<EmployeeDTO> employees3 = un.getEmployees();
            		Iterator iter5 = employees3.iterator();
            		while (iter5.hasNext()){
            			EmployeeDTO emp = (EmployeeDTO)iter5.next();
            			response.write("<div> "+emp.getName() + emp.getID()+"</div>");
            		}
        		}
    		}
    		
    		EmployeeDTO testEmp = root.getEmployeeForID("00004005");
    		response.write("<div> Test EmployyforID: "+testEmp.getName() + testEmp.getID()+"</div>");
*/
    		
    	} catch (Exception e) {
	    
    	}
     	
    }
   	
 	public void recurseTree(UnitDTO rootUnit, IPortalComponentResponse response, int count){
 		//int count = 1;
 		response.write("<div> Level "+ count +" - Unit: "+rootUnit.getName()+", "+rootUnit.getID() +" </div>");
		Set<EmployeeDTO> employees = rootUnit.getEmployees();
		response.write("<div> Level "+ count +" - Employees: </div>");
		Iterator iter = employees.iterator();
		while (iter.hasNext()){
			EmployeeDTO emp = (EmployeeDTO)iter.next();
			response.write("<div> "+emp.getName() + emp.getID()+"</div>");
		}
		
		Set<UnitDTO> units = rootUnit.getUnits();
		if(!units.isEmpty()){
			Iterator iter2 = units.iterator();
			while (iter2.hasNext()){
				UnitDTO unit = (UnitDTO)iter2.next();
				response.write("<div> Call reccursion for: "+unit.getName() + unit.getID()+"</div>");
				this.recurseTree(unit, response, count + 1);
			}
		}
 		
 	}
}