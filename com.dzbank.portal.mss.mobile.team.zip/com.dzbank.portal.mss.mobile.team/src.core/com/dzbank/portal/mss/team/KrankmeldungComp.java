package com.dzbank.portal.mss.team;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;
import javax.servlet.http.HttpServletResponse;

import com.dzbank.portal.mss.mobile.team.IRFCCallerService;
import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.navigation.INavigationGenerator;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class KrankmeldungComp extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";
	  private final String FUNCTION_ATTRIBUTE_NAME = "Name";
	  
	  private final String BACKEND_SYSTEM_ALIAS = "SAP_ECC_HumanResources";
	  private final String FUNCTION_NAME = "ZMSS_WDA_TV_ACT_KRANKMELD";
	  private final String FUNCTION_OUT_DATA = "ORGDATA_TABLE";
	  private final String FUNCTION_OUT_ACTIONS = "ACTION_TABLE";
	  private final String FUNCTION_OUT_PROFIL = "SHORT_TABLE";

	  private final String INPUT_NAME1 = "OBJID";	
	  private final String INPUT_NAME2 = "OTYPE";
	  private final String INPUT_VALUE = "TEAM_STD";	
	  public static final String REQUEST_OBJECT_ID_PARAM = "objectID";
	  public static final String REQUEST_OBJECT_TYPE_PARAM = "objectType";
	private ResourceBundle nls;
	public IRecordSet data;
	
	public KrankmeldungComp(){    
		this.data = null;
	}
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		//response.write("<script>alert(\"Test\");</script>");
		String objectID = request.getParameter(REQUEST_OBJECT_ID_PARAM);
		String objectType = request.getParameter(REQUEST_OBJECT_TYPE_PARAM);
		
		HttpServletResponse servletResponse = request.getServletResponse(true);
		servletResponse.setContentType("application/json");
		servletResponse.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP																								// 1.1.
		servletResponse.setHeader("Pragma", "no-cache"); // HTTP 1.0.
		servletResponse.setDateHeader("Expires", 0); // Proxies.

		INavigationGenerator navigationService = (INavigationGenerator)PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		String portalURL = navigationService.getPortalURL(request, null) + "/dzbank";
		
		IRFCCallerService rfcService = (IRFCCallerService)PortalRuntime.getRuntimeResources().getService(IRFCCallerService.KEY);
		Object res = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME, "VALUES_TABLE", objectID, objectType);				
		String obnParam = "";
		String obnOperation = "";
		String obnObject = "";
		String obnSystem = "";
		if (res instanceof IRecordSet){
			IRecordSet obnRes = (IRecordSet)res;
			try {
				obnRes.beforeFirst();
				while (obnRes.next()){
					obnParam = obnRes.getString("PARAM");
					obnOperation = obnRes.getString("BO_ACTIVITY");
					obnObject = obnRes.getString("BUSINESS_OBJECT");
					obnSystem = obnRes.getString("SYSTEM_ALIAS");
				}
			} catch (ConnectorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		String obn = portalURL + "?NavMode=10&NavigationTarget=OBN://" + "BOTechnicalName=" + obnObject + "/" + "BOSystemAlias=" + obnSystem + "/" + "Operation=" + obnOperation  + "&" + obnParam; //EMP_PROFIL_OBN_URL
		response.write("{\"success\" : true, \"url\" : \"" + res.toString() + "\", \"obn\" : \"" + obn + "\"}");
	}
	
	
	public void getContent(IPortalComponentRequest request, String objType, String objID){
		IInteraction ix = null;
		IConnection connection = null;
		String ret = "in method, ";
		try {
			connection = getConnection(request);
			if (connection != null)
			{
				
				// Get the Interaction interface for executing the command
			    ix = connection.createInteractionEx();
			    // Get interaction spec and set the name of the command to run
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    // Put Function Name into interaction Properties.
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, FUNCTION_NAME);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    ret = ret + "got connection, ";
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    try {
			    	ret = ret + "got a result, ";
			    	Object result = output.get(FUNCTION_OUT_DATA);
			        if (result == null) {
			        	ret = ret + "is NULL, ";
			        	this.data = null;
			        } else if (result instanceof IRecordSet) {
			        	ret = ret + "is recordSet, ";
			            this.data = (IRecordSet) result;
			        }
			    } catch (Exception ex) {
			    	ret = ret + "inner exception, " + ex.getMessage();
			    	ex.printStackTrace();
			    }
			    connection.close();
			} 
		} catch (ConnectorException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (UMException e) {
			e.printStackTrace();

		} catch (ResourceException e) {
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
				}

			} catch (ResourceException e) {
				e.printStackTrace();
			}
		}		
	
	}
	
	/**
	 * 
	 * @return
	 */
	public String[] getColNames(){
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	
	/**
	 * 
	 * @return
	 */
	public String[] getColLabels(){
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 
			 for (int i = 0; i < nbCol; i++) {
				 cols[i] = columns.getColumnLabel(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	/**
	 * 
	 * @param d
	 * @return
	 */
	private String formatDate(String d){
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateInString = d; 
		try {	 
			Date date = oldFormat.parse(d);	 
			dateInString = formatter.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}	
	
	public LinkedHashMap readRecordsSet() {
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];		
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			this.data.beforeFirst();
			int count = 0;
			//go though each record
			while (this.data.next()){
				//for one record, go through each
				LinkedHashMap aRecordMap = new LinkedHashMap();
				for (int j = 0; j < cols.length; j++) {
					if (cols[j].equals("GBDAT") || cols[j].equals("GBDATAKT")){
					
						String str = this.data.getString(cols[j]);
						aRecordMap.put(cols[j], this.formatDate(str));
					}else {
						aRecordMap.put(cols[j], this.data.getString(cols[j]));							
					}
				}
				
				recordsMap.put(count, aRecordMap);
				count++;
			}
		} catch (ConnectorException e) {
			e.printStackTrace();
		}

		return recordsMap;
	}

	/**
	 * 
	 * @param recordsMap
	 */
	private void iterateRecordsMap(LinkedHashMap recordsMap){
		Iterator entries = recordsMap.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();
		  Object value = thisEntry.getValue();
		}
	}
	
	/**
	 * 
	 * @param input
	 * @return
	 */
	public LinkedHashMap removeMANDT(LinkedHashMap input){
		String key = "MANDT";
		if (input.containsKey(key))
			input.remove(key);
		return input;
	}
	
	/**
	 * 
	 * @param map
	 * @return
	 */
	private HashMap testIterator(HashMap map){
		Iterator entries = map.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();

		  Object value = thisEntry.getValue();
		 // HashMap aRecordMap = (HashMap)value;
		  String[] array = (String[])value;
		  for (int i = 0; i < array.length; i++) {
			String s = array[i];
		}
		}
		return map;
	}
	
	
	private String formatBigDecimal(double bd){
		//NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		String pattern = "###,###.##";
		//DecimalFormat df = (DecimalFormat)nf;
		DecimalFormat df = new DecimalFormat(pattern);
	    df.setMinimumFractionDigits(2);
	    df.setMaximumFractionDigits(2);
		String res = df.format(bd);
		return res;
	}

	
	/*
	 * Getting the connector gateway service
	 */
	private IConnection getConnection(IPortalComponentRequest request) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}
	
}