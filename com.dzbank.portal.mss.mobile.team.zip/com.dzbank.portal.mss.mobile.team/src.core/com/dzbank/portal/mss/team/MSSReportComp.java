package com.dzbank.portal.mss.team;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.ResourceBundle;
import java.util.Map.Entry;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;

import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class MSSReportComp extends AbstractPortalComponent{
	
	private ResourceBundle nls;
	public IRecordSet data;
	public IRecordSet filter;	
	
	public MSSReportComp(){    
		this.data = null;
		this.filter = null;
	}
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		response.include(request, request.getResource(IResource.JSP, "jsp/MSSReportComp.jsp"));		
		
	}
	
	public Object getContent(IPortalComponentRequest request, IPortalComponentResponse response){
		String retValue = "begining ";
		try {
			IConnection connection = getConnection(request, response);
			if (connection != null)
			{
				retValue = retValue + "got connection ";
				// Get the Interaction interface for executing the command
			    IInteraction ix = connection.createInteractionEx();
			    // Get interaction spec and set the name of the command to run
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    // the well known example BAPI SALESORDER
			    String functionName = "ZFB_GET_GEHALTSLISTE";
			    // Put Function Name into interaction Properties.
			    ixspec.setPropertyValue("Name", functionName);
			    // return structure
			    String function_out = "MSS_GL_TAB";
			    String filter_out = "HIERARCHIE_TAB";
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord("input");
			    // put function input parameters
			    input.put("ORG_VIEW", new String(""));
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    Object rs = null;
			    Object filter_rs = null;
			    try {
			    	//get the complete result set
			        Object result = output.get(function_out);
			        if (result == null) {
			            rs = new String(" ");			 
			        } else if (result instanceof IRecordSet) {
			            rs = (IRecordSet) result;
			            this.data = (IRecordSet) result;
			            retValue = retValue + this.readRecordsSet();
			        }
			        // result object returned
			        else {
			            rs = result.toString();
			            retValue = retValue + "got result: "+result.toString();
			        }
			        
			        //get the filter values
			        Object filterValues = output.get(filter_out);
			        if (filterValues == null) {
			        	filter_rs = new String(" ");			 
			        } else if (filterValues instanceof IRecordSet) {
			        	filter_rs = (IRecordSet) filterValues;
			            this.filter = (IRecordSet) filterValues;
			            retValue = retValue + this.readRecordsSet();
			        }
			        // result object returned
			        else {
			        	filter_rs = filterValues.toString();
			            retValue = retValue + "got result: "+filterValues.toString();
			        }

			    } catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    connection.close();
			    return rs;

			}else 
				return "Connection is null"; 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ResourceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retValue;
	}

	public String[] getColNames(){
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	
	public String[] getColLabels(){
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 
			 for (int i = 0; i < nbCol; i++) {
				 cols[i] = columns.getColumnLabel(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	
	public LinkedList readFilterValues(){
		String val = "Values: "; 
		LinkedList l = new LinkedList();		
		try {
			 IRecordMetaData columns = this.filter.retrieveMetaData();
			 String colName = columns.getColumnName(0);		

			 this.filter.beforeFirst();
			 while (this.filter.next()){
				//for one record, go through each
				val = val + this.filter.getString(colName) + "; ";
				l.add(this.filter.getString(colName));
			}

		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}
	
	public LinkedHashMap readRecordsSet() {
		String result = "";
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];
			 String[] record = new String [nbCol];			
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
				result = result + columns.getColumnName(i) + "; ";
			}
			this.data.beforeFirst();
			int count = 0;
			//go though each record
			while (this.data.next()){
				//for one record, go through each
				LinkedHashMap aRecordMap = new LinkedHashMap();
				String[] aRecord = new String[cols.length];
				String paNr = this.data.getString("PERSNO");
				String jahr = this.data.getString("PERIODE");
				//double nb = this.data.getDouble("GRUNDGEHALT");
				for (int j = 0; j < cols.length; j++) {
					if (cols[j].equals("GRUNDGEHALT") || cols[j].equals("ZIELBONUS") || cols[j].equals("BONUSZAHLUNG") || cols[j].equals("GESAMTBEZUEGE") || cols[j].equals("LETZTER_ERH_BETRAG")){
						double nb = this.data.getDouble(cols[j]);
						aRecordMap.put(cols[j], this.formatBigDecimal(nb));
					}else if (cols[j].equals("LETZTE_ERHOEHUNG")){
						String str = this.data.getString(cols[j]);
						aRecordMap.put(cols[j], this.formatDate(str));
					}else {
						aRecordMap.put(cols[j], this.data.getString(cols[j]));	
						
						aRecord[j] =  this.data.getString(cols[j]);					
						result = result + this.data.getString(cols[j]).toString() + "; ";
					}
					
				//	}
				}
				
				recordsMap.put(count, aRecordMap);
				count++;
				result = result + " // ";
			}
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			result = result + "exception";
			e.printStackTrace();
		}
		Iterator entries = recordsMap.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();
		  Object value = thisEntry.getValue();
		}
		return recordsMap;
	}
	
	public LinkedHashMap removeMANDT(LinkedHashMap input){
		String key = "MANDT";
		if (input.containsKey(key))
			input.remove(key);
		return input;
	}
	private HashMap testIterator(HashMap map){
		Iterator entries = map.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();

		  Object value = thisEntry.getValue();
		 // HashMap aRecordMap = (HashMap)value;
		  String[] array = (String[])value;
		  for (int i = 0; i < array.length; i++) {
			String s = array[i];
		}
		}
		return map;
	}
	
	
	public String formatBigDecimal(double bd){
		//NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		String pattern = "###,###.##";
		//DecimalFormat df = (DecimalFormat)nf;
		DecimalFormat df = new DecimalFormat(pattern);
	    df.setMinimumFractionDigits(2);
	    df.setMaximumFractionDigits(2);
		String res = df.format(bd);
		return res;
	}

	public String formatDate(String d){
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateInString = d; 
		try {	 
			Date date = oldFormat.parse(d);	 
			dateInString = formatter.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}
	
	/*
	 * Getting the connector gateway service
	 */
	private IConnection getConnection(IPortalComponentRequest request, IPortalComponentResponse response) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}
	
	
	/**
	 * Portal Component rendering method - all rendering is done in JSP
   
    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response)
    {
		response.include(request, request.getResource(IResource.JSP, "jsp/poSperreAdmin.jsp"));

		/* 		   
			String BOURL = "http://S91823.mobi.mobicorp.ch:8080/BOE/OpenDocument/opendoc/openDocument.jsp?iDocID=AY.Ik8KvAhtEgaXVOU5uf58&sIDType=CUID";
			String URLiViewID = "portal_content/ch.mobi.mobi/bo/markt_mgmt/param_head"; //pcd:portal_content/ch.mobi.mobi/bo/markt_mgmt/param_head/dynamic_report
			String myURL = URLEncoder.encode(BOURL);
		
			response.write("<A HREF=\"Redirect Link\"  onclick=\"return EPCM.doNavigate('ROLES://" + URLiViewID + "?forcedURL="+ myURL+"')\">Forced URL</A>");
			response.write("<br>");
			response.write("<A HREF=\"Original URL\"  onclick=\"return EPCM.doNavigate('ROLES://" + URLiViewID+ "')" + "\">Original URL</A>");
		
    }
*/ 
}