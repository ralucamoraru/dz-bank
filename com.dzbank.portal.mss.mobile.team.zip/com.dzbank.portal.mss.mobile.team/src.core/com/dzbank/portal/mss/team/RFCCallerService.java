package com.dzbank.portal.mss.team;
 
  import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;

import com.dzbank.portal.mss.mobile.team.IRFCCallerService;
import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.service.IServiceContext;

  public class RFCCallerService implements IRFCCallerService{

  private IServiceContext mm_serviceContext;
  
  private final String INPUT_ATTRIBUTE = "input";
  private final String FUNCTION_ATTRIBUTE_NAME = "Name";
  
  private final String BACKEND_SYSTEM_ALIAS = "SAP_ECC_HumanResources";
 // private final String FUNCTION_NAME = "ZFB_GET_ABWKONTLISTE";
  private final String FUNCTION_OUT = "VALUES_TABLE";
  private final String INPUT_NAME1 = "OBJID";	
  private final String INPUT_NAME2 = "OTYPE";
  
  private IRecordSet data;

  

  /**
  * Generic init method of the service. Will be called by the portal runtime.
  * @param serviceContext
  */
  public void init(IServiceContext serviceContext)
  {
    mm_serviceContext = serviceContext;
  }

  /**
  * This method is called after all services in the portal runtime
  * have already been initialized.
  */
  public void afterInit()
  {
  }

  /**
  * configure the service
  * @param configuration
  * @deprecated
  */
  public void configure(com.sapportals.portal.prt.service.IServiceConfiguration configuration)
  {
  }

  /**
  * This method is called by the portal runtime
  * when the service is destroyed.
  */
  public void destroy()
  {

  }

  /**
  * This method is called by the portal runtime
  * when the service is released.
  * @deprecated
  */
  public void release()
  {
  }

  /**
  * @return the context of the service, which was previously set
  * by the portal runtime
  */
  public IServiceContext getContext()
  {
    return mm_serviceContext;
  }

  /**
  * This method should return a string that is unique to this service amongst all
  * other services deployed in the portal runtime.
  * @return a unique key of the service
  */
  public String getKey()
  {
    return KEY;
  }
  
  
	/*
	 * Getting the connector gateway service
	 */
	private IConnection getConnection(IPortalComponentRequest request) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		//String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}

	@Override
	public Object doRFCCallKurzProfil(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType) {
		IInteraction ix = null;
		IConnection connection = null;
		String ret = "Return: ";
		 Object rs = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				ret = ret + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			   
			    try {
			        Object result = output.get(rfcOutput);
			        if (result == null) {
			            rs = new String(" ");	
			          //  retValue = retValue + " result null";
			        } else if (result instanceof IRecordSet) {
			            //rs = (IRecordSet) result;
			            rs = this.getContent((IRecordSet) result);
			           // this.data = (IRecordSet) result;
			            ret = ret + "record set";// this.readRecordsSet();
			        }
			        else {
			            rs = result.toString();
			          //  retValue = retValue + "got result: "+result.toString();
			        }
			    } 
			    catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    connection.close();
			    return rs;

			}
		} catch (ConnectorException e) {
			ret = ret + "RFCCallerService: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "RFCCallerService: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "RFCCallerService: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "RFCCallerService: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return rs;
		
	}
	
	@Override
	public Object doRFCCallEmpProfile(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType) {
		IInteraction ix = null;
		IConnection connection = null;
		String ret = "Return: ";
		 Object rs = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				ret = ret + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    IRecordSet data;
			    //OBN
			    try {
			        Object result = output.get("OBN_TABLE");
			        if (result == null) {
			        	rs = null;
			        } else if (result instanceof IRecordSet) {
			            rs = (IRecordSet) result;
			        }

			    } catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    //END OBN
//			    if(output instanceof MappedRecord){
//			    	MappedRecord result = (MappedRecord)output;
//					Iterator entries = result.entrySet().iterator();
//					while (entries.hasNext()) {
//					  Entry thisEntry = (Entry) entries.next();
//					  Object key = thisEntry.getKey();
//					  Object value = thisEntry.getValue();
//					  if(key.toString().equalsIgnoreCase("URL"))
//						  rs = value;
//					}
//			    }
//			    ret = ret + "OUTPUT: " + output.toString();
			    connection.close();
			    return rs;

			}
		} catch (ConnectorException e) {
			ret = ret + "RFCCallerService: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "RFCCallerService: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "RFCCallerService: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "RFCCallerService: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return ret;
		
	}
	
	@Override
	public Object doRFCCallCompProfile(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType) {
		IInteraction ix = null;
		IConnection connection = null;

		String ret = "Return: ";
		 Object rs = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				ret = ret + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    //OBN
			    try {
			        Object result = output.get("OBN_TABLE");
			        if (result == null) {
			        	rs = null;
			        } else if (result instanceof IRecordSet) {
			            rs = (IRecordSet) result;
			        }

			    } catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    //END OBN
//			    if(output instanceof MappedRecord){
//			    	MappedRecord result = (MappedRecord)output;
//					Iterator entries = result.entrySet().iterator();
//					while (entries.hasNext()) {
//					  Entry thisEntry = (Entry) entries.next();
//					  Object key = thisEntry.getKey();
//					  Object value = thisEntry.getValue();
//					  if(key.toString().equalsIgnoreCase("URL"))
//						  rs = value;
//					}
//			    }
			   // rs = output.toString(); 
			    ret = ret + "OUTPUT: " + output.toString();
			    connection.close();
			    return rs;

			}
		} catch (ConnectorException e) {
			ret = ret + "RFCCallerService: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "RFCCallerService: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "RFCCallerService: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "RFCCallerService: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return ret;
		
	}	
	
	@Override
	public String[] getColLables() {
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 
			 for (int i = 0; i < nbCol; i++) {
				 cols[i] = columns.getColumnLabel(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}

	@Override
	public String[] getColNames() {
		String[] cols = null;  
		try {
			IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}

	@Override
	public LinkedHashMap getContent(IRecordSet recordSet) {
		String result = "";
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = recordSet.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 recordSet.beforeFirst();
			//go though each record
			while (recordSet.next()){
				for (int j = 0; j < cols.length; j++) {
					recordsMap.put(cols[j], recordSet.getString(cols[j]));
				}
			}
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			result = result + "exception";
			e.printStackTrace();
		}
		return recordsMap;
	}

	
	@Override
	public LinkedHashMap getMapRecordSet() {
		String result = "";
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = this.data.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];
			 String[] record = new String [nbCol];			
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
				result = result + columns.getColumnName(i) + "; ";
			}
			this.data.beforeFirst();
			int count = 0;
			//go though each record
			while (this.data.next()){
				//for one record, go through each
				LinkedHashMap aRecordMap = new LinkedHashMap();
				//String[] aRecord = new String[cols.length];
				//String paNr = this.data.getString("PERSNO");
				//String jahr = this.data.getString("PERIODE");
				//double nb = this.data.getDouble("GRUNDGEHALT");
				for (int j = 0; j < cols.length; j++) {
					if (cols[j].equals("BEGIN_DATE") || cols[j].equals("END_DATE")|| cols[j].equals("DEDUCT_BEGIN")|| cols[j].equals("DEDUCT_END")){
					
						String str = this.data.getString(cols[j]);
						aRecordMap.put(cols[j], this.formatDate(str));
					}else {
						aRecordMap.put(cols[j], this.data.getString(cols[j]));	
						
						//aRecord[j] =  this.data.getString(cols[j]);					
						result = result + this.data.getString(cols[j]).toString() + "; ";
					}
				}
				
				recordsMap.put(count, aRecordMap);
				count++;
				result = result + " // ";
			}
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			result = result + "exception";
			e.printStackTrace();
		}
		Iterator entries = recordsMap.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();
		  Object value = thisEntry.getValue();
		}
		return recordsMap;
	}

	private String formatDate(String d){
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateInString = d; 
		try {	 
			Date date = oldFormat.parse(d);	 
			dateInString = formatter.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}
	
	/**
	 * Basic method - not used
	 */
	public void doRFCCall(IPortalComponentRequest request, String rfcFunction, String rfcInput, String rfcOutput) {
		IInteraction ix = null;
		IConnection connection = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				//retValue = retValue + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, new String(""));
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    Object rs = null;
			    try {
			        Object result = output.get(rfcOutput);
			        if (result == null) {
			            rs = new String(" ");	
			          //  retValue = retValue + " result null";
			        } else if (result instanceof IRecordSet) {
			            rs = (IRecordSet) result;
			            this.data = (IRecordSet) result;
			          //  retValue = retValue + "record set";// this.readRecordsSet();
			        }
			        // result object returned
			        else {
			            rs = result.toString();
			          //  retValue = retValue + "got result: "+result.toString();
			        }
			    } catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    connection.close();
			  //  return rs;

			}
		} catch (ConnectorException e) {
			//ret = ret + "RFCCallerService: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			//ret = ret + "RFCCallerService: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			//ret = ret + "RFCCallerService: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			//ret = ret + "RFCCallerService: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
				//	ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				//ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
				//	ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
			//	ret = ret + "RFCCallerService: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
	//	return retValue;
	}	
}
