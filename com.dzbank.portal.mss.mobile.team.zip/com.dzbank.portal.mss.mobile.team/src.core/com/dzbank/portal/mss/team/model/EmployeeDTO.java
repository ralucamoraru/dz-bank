package com.dzbank.portal.mss.team.model;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.Set;

@SuppressWarnings("serial")
public class EmployeeDTO implements Serializable, Comparable<EmployeeDTO> {
	private String ID;
	private String name;
	private String paNumber;
	private String parentID;
	private boolean isManager;
	private String ebene;
	public Set<ActionDTO> actions = new LinkedHashSet<ActionDTO>();
	
	public EmployeeDTO() {
 
	}

	public EmployeeDTO(String id, String name, String parentID, boolean isManager) {
		this.ID = id;
		this.name = name;
		this.parentID = parentID;
		this.isManager = isManager;
	}

	public String getEbene() {
		return this.ebene;
	}

	public void setEbene(String ebene) {
		if(this.isManager)
			this.ebene = ebene;
		else
			this.ebene = "";
	}
	
	public String getID() {
		return this.ID;
	}

	public void setID(String id) {
		this.ID = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentID() {
		return this.parentID;
	}

	public void setParentID(String parentID) {
		this.parentID = parentID;
	}

	public String getPANumber() {
		return this.paNumber;
	}

	public void setPANumber(String paNumber) {
		this.paNumber = paNumber;
	}	
	
	public boolean isManager() {
		return this.isManager;
	}

	public void setIsManager(boolean isManager) {
		this.isManager = isManager;
	}	
	
	public Set<ActionDTO> getActions() {
		return this.actions;
	}

	public void setActions(Set<ActionDTO> actions) {
		this.actions = actions;
	}
		
	@Override
	public int compareTo(EmployeeDTO o) {
		int x =  this.ID.compareTo(o.ID);
		int y = this.name.compareTo(o.name);
		if( y != 0)
			return y;
		else
			return x;
	}

}
