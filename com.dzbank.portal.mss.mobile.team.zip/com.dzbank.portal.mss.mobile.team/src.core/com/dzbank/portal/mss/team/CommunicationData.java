package com.dzbank.portal.mss.team;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;

import com.dzbank.portal.mss.mobile.team.IRFCCallerService;
import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class CommunicationData extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";
	  private final String FUNCTION_ATTRIBUTE_NAME = "Name";
	  
	  private final String BACKEND_SYSTEM_ALIAS = "SAP_ECC_HumanResources";
	  private final String FUNCTION_NAME = "ZMSS_WDA_TV_SHP_P";
	  private final String FUNCTION_OUT_PERSINFO = "PERSINFO_TABLE";
	  private final String FUNCTION_OUT_COMMUNI = "COMMUNI_TABLE";
	  private final String FUNCTION_OUT_NOTFALL = "NOTFALL_TABLE";
	  
	  private final String FUNCTION_NAME_EMP_PROFIL = "ZMSS_WDA_TV_ACT_PERPROFIL";
	  private final String FUNCTION_NAME_COMP_PROFIL = "ZMSS_WDA_TV_ACT_VGPROFIL";
	  private final String FUNCTION_NAME_ZEITNACHWEIS = "ZMSS_WDA_TV_ACT_ZEITNACHW";
	  private final String FUNCTION_NAME_ZEITKONTO = "ZMSS_WDA_TV_ACT_ZEITKONTO";
	  private final String FUNCTION_NAME_KRANKMELDUNG = "ZMSS_WDA_TV_ACT_KRANKMELD";
	  
	  private final String INPUT_NAME1 = "OBJID";	
	  private final String INPUT_NAME2 = "OTYPE";
	  private final String INPUT_VALUE = "TEAM_STD";	
	  public static final String REQUEST_OBJECT_ID_PARAM = "objectID";
	  public static final String REQUEST_OBJECT_TYPE_PARAM = "objectType";
	private ResourceBundle nls;
	//public IRecordSet data;
	
	
	public CommunicationData(){    
		
	}
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		//response.write("<script>alert(\"Test\");</script>");
		String objectID = request.getParameter(REQUEST_OBJECT_ID_PARAM);
		String objectType = request.getParameter(REQUEST_OBJECT_TYPE_PARAM);
		request.getServletRequest().getSession().setAttribute("objectID", objectID);
		request.getServletRequest().getSession().setAttribute("objectType", objectType);
		
	//	IRFCCallerService rfcService = (IRFCCallerService)PortalRuntime.getRuntimeResources().getService(IRFCCallerService.KEY);
		Object persInfoResult = this.doRFCCallKurzProfil(request, FUNCTION_NAME, FUNCTION_OUT_PERSINFO, objectID, objectType);	
		Object communiResult = this.doRFCCallKurzProfil(request, FUNCTION_NAME, FUNCTION_OUT_COMMUNI, objectID, objectType);	
		Object notfallResult = this.doRFCCallKurzProfil(request, FUNCTION_NAME, FUNCTION_OUT_NOTFALL, objectID, objectType);	

		IRFCCallerService rfcService = (IRFCCallerService)PortalRuntime.getRuntimeResources().getService(IRFCCallerService.KEY);
		Object empProfileURL = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME_EMP_PROFIL, "VALUES_TABLE", objectID, objectType);	
		Object compProfileURL = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME_COMP_PROFIL, "VALUES_TABLE", objectID, objectType);
		Object zeitnachweisURL = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME_ZEITNACHWEIS, "VALUES_TABLE", objectID, objectType);
		Object zeitkontoURL = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME_ZEITKONTO, "VALUES_TABLE", objectID, objectType);
		Object krankmeldungURL = rfcService.doRFCCallEmpProfile(request, FUNCTION_NAME_KRANKMELDUNG, "VALUES_TABLE", objectID, objectType);
		response.write("<ul>");
		response.write("<li><a id=\"empProfile\" href=\"#\" target=\"_blank\" onclick=\"javascript:getEmpProfilURL('" +  objectID + "');return false;\">" + getNLSString(request, "TEAM_MITARBEITERPROFIL") + "</a></li>"); //"+res.toString()+"
		response.write("<li><a id=\"compProfile\" href=\"#\" target=\"_blank\" onclick=\"javascript:getCompensationURL('" +  objectID + "');return false;\">" + getNLSString(request, "TEAM_VERGPROFIL") + "</a></li>"); //" + compProfileURL.toString() + "
		response.write("<li><a id=\"zeitnachweis\" href=\"#\" target=\"_blank\" onclick=\"javascript:getZeitnachweisURL('" +  objectID + "');return false;\">" + getNLSString(request, "TEAM_ZEITNACHWEIS") + "</a></li>");
		response.write("<li><a id=\"zeitkonto\" href=\"#\" target=\"_blank\" onclick=\"javascript:getZeitkontoURL('" +  objectID + "');return false;\">" + getNLSString(request, "TEAM_ZEITKONTO") + "</a></li>");
		response.write("<li><a id=\"krankmeldung\" href=\"#\" target=\"_blank\" onclick=\"javascript:getKrankmeldungURL('" +  objectID + "');return false;\">" + getNLSString(request, "TEAM_KRANKMELD") + "</a></li>");
		response.write("</ul>");
		response.write("<br class=\"clear\" />");

		if(persInfoResult instanceof LinkedHashMap){
			LinkedHashMap records = (LinkedHashMap)persInfoResult;	
			LinkedHashMap list = (LinkedHashMap)records.get(0);

			String pictureURL = list.get("PICTURE_URL").toString();
			String persNo = list.get("PERSNO").toString();
			String title = list.get("TITEL").toString();
			String firstName = list.get("VORNA").toString();
			String lastName = list.get("NACHN").toString();
			String birthday = this.formatDate(list.get("GBDAT").toString());

			response.write("<h2>"+ getNLSString(request, "TEAM_KURZPROFIL") + ": " + firstName + " " + lastName + "</h2>");
			response.write("<div class=\"wrapper_inner clearfix\">");
			response.write("<h3>" + getNLSString(request, "TEAM_PERS_DATA") + "</h3>");
			response.write("<table width=\"805px\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\">");
			response.write("<tr>");
			response.write("<td class=\"first\">");
			response.write("<img src=\"" + pictureURL + "\"/></td>");
			response.write("<td class=\"second\">");
			response.write("<p><strong>" + getNLSString(request, "TEAM_TITEL") + ": </strong>" + title + "</p>");
			response.write("<p><strong>" + getNLSString(request, "TEAM_NAME") + ": </strong>" + firstName + " " + lastName + "</p>");
			response.write("<p><strong>" + getNLSString(request, "TEAM_PA_NR") + ": </strong>" + persNo + "</p>");
			response.write("<p><strong>" + getNLSString(request, "TEAM_GEB_DAT") + ": </strong>" + birthday + "</p>");	
			response.write("</td>");
			
		} else{
			response.write("<p>Could not retrieve any personal info from the backend system.</p>");
		}
		
		if(communiResult instanceof LinkedHashMap){
			LinkedHashMap records = (LinkedHashMap)communiResult;	
			LinkedHashMap list = (LinkedHashMap)records.get(0);
			if (!list.isEmpty()){
				String uname = list.get("UNAME").toString();
				String phone = list.get("TELEFON").toString();
				String mobil = list.get("MOBIL").toString();
				String email = list.get("EMAIL").toString();
				String emailPrivat = list.get("PRIVATE_EMAIL").toString();
				String workplace = list.get("WORKPLACE").toString();
				String bafinID = list.get("BAFINID").toString();
				
				response.write("<td class=\"third\">");	
				//response.write("<h5>Kommunikationsdaten</h5>");	
				response.write("<p><strong>" + getNLSString(request, "TEAM_BENUTZER_ID") + ": </strong> " + uname + "</p>");
				response.write("<p><strong>" + getNLSString(request, "TEAM_EMAIL") + ": </strong> " + email + "</p>");
				//response.write("<p><strong>Private E-Mail: </strong> " + emailPrivat + "</p>");
				response.write("<p><strong>" + getNLSString(request, "TEAM_TELEFON") + ": </strong> " + phone + "</p>");
				response.write("<p><strong>" + getNLSString(request, "TEAM_MOBIL") + ": </strong> " + mobil + "</p>");
				response.write("<p><strong>" + getNLSString(request, "TEAM_ARBEITSPLATZ") + ": </strong> " + workplace + "</p>");
				response.write("<p><strong>BAFIN ID: </strong> " + bafinID + "</p>");	
				response.write("</td>");
			}
			else{
				response.write("<td class=\"third\">");	
				response.write("<p><strong>" + getNLSString(request, "TEAM_KOMMUNIKATION") + "</strong></p>");	
				response.write("<p>Could not retrieve any communication data from the backend system.</p>");
				response.write("</td>");	
			}
			
		}
		
		response.write("</tr>");	
		response.write("</table>");
		response.write("</div>");
		
		if(notfallResult instanceof LinkedHashMap){
			LinkedHashMap records = (LinkedHashMap)notfallResult;				
			String lastName = "N/A";
			String firstName = "N/A";
			String street = "N/A";
			String plz = "N/A";
			String city = "N/A";
			String country = "N/A";
			String phone = "N/A";
			String handy = "N/A";
			if (!records.isEmpty()){
				for (int i = 0; i < records.size(); i++) {
					LinkedHashMap list = (LinkedHashMap)records.get(i);			
					if (list.containsKey("NACHN"))
						lastName = list.get("NACHN").toString();
					if (list.containsKey("VORNA"))
						firstName = list.get("VORNA").toString();
					if (list.containsKey("STRAS"))
						street = list.get("STRAS").toString();
					if (list.containsKey("PSTLZ"))
						plz = list.get("PSTLZ").toString();
					if (list.containsKey("ORT01"))
						city = list.get("ORT01").toString();
					if (list.containsKey("LAND_TEXT"))
						country = list.get("LAND_TEXT").toString();
					if (list.containsKey("TELEFON"))
						phone = list.get("TELEFON").toString();
					if (list.containsKey("MOBIL"))
						handy = list.get("MOBIL").toString();
					response.write("<div class=\"wrapper_inner notfalladressen clearfix\">");
					response.write("<h3>" + getNLSString(request, "TEAM_NOTFALL_DATEN") + "</h3>");
					response.write("<div class=\"clearfix\">");
					response.write("<div class=\"notfalladresse\">");
					int j = i+1;
					response.write("<h5><strong>" + getNLSString(request, "TEAM_NOT_KONTAKT") + " "+j+"</strong></h5>");
					response.write("<p><strong>" + getNLSString(request, "TEAM_NAME") + ": </strong> "  + firstName + " " + lastName + "</p>");
					response.write("<p><strong>" + getNLSString(request, "TEAM_TELEFON") + ": </strong> " + phone + "</p>");
					//response.write("<p><strong>" + getNLSString(request, "TEAM_MOBIL") + ": </strong> " + handy + "</p>");
					response.write("<p><strong>" + getNLSString(request, "TEAM_STREET") + ": </strong> " + street + "</p>");
					response.write("<p><strong>" + getNLSString(request, "TEAM_PLZ") + ": </strong> " + plz + ", " + city + "</p>");
					response.write("<p><strong>" + getNLSString(request, "TEAM_LAND") + ": </strong> " + country + "</p>");
					response.write("</div>");
					response.write("</div>");
					response.write("</div>");
				}
			}else{
				response.write("<div class=\"wrapper_inner clearfix\">");
				response.write("<h3>" + getNLSString(request, "TEAM_NOTFALL_DATEN") + "</h3>");	
				response.write("<div class=\"clearfix\">");
				response.write("<div class=\"notfalladresse\">");
				response.write("<p>" + getNLSString(request, "TEAM_ERROR_NO_DATA") + "</p>");
				response.write("</div>");
				response.write("</div>");
				response.write("</div>");
			}
		} 
		else{
			response.write("<div class=\"wrapper_inner clearfix\">");	
			response.write("<p><strong>Notfalldaten</strong></p>");	
			response.write("<p>Could not retrieve any emergency contact from the backend system.</p>");		
			response.write("</div>");	
		}	
		
	}
	
	private IConnection getConnection(IPortalComponentRequest request) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		//String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}
	
	public Object doRFCCallKurzProfil(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType) {
		IInteraction ix = null;
		IConnection connection = null;
		String ret = "Return: ";
		 Object rs = null;
		try {
			connection = this.getConnection(request);
			if (connection != null)
			{
				ret = ret + "got connection ";
			    ix = connection.createInteractionEx();
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, rfcFunction);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME1, objID);
			    input.put(INPUT_NAME2, objType);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			   
			    try {
			        Object result = output.get(rfcOutput);
			        if (result == null) {
			            rs = new String(" ");	
			          //  retValue = retValue + " result null";
			        } else if (result instanceof IRecordSet) {
			            //rs = (IRecordSet) result;
			            rs = this.getContent((IRecordSet) result);
			           // this.data = (IRecordSet) result;
			            ret = ret + "record set";// this.readRecordsSet();
			        }
			        else {
			            rs = result.toString();
			          //  retValue = retValue + "got result: "+result.toString();
			        }
			    } 
			    catch (Exception ex) {
			    	ex.printStackTrace();
			    }
			    connection.close();
			    return rs;

			}
		} catch (ConnectorException e) {
			ret = ret + "ShortProfile: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "ShortProfile: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "ShortProfile: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "ShortProfile: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "ShortProfile: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "ShortProfile: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return rs;
		
	}
	
	public LinkedHashMap getContent(IRecordSet recordSet) {
		String result = "";
		LinkedHashMap recordsMap = new LinkedHashMap();
		try {
			 IRecordMetaData columns = recordSet.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 String[] cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 recordSet.beforeFirst();
			 int count = 0;
			//go though each record
			while (recordSet.next()){
				LinkedHashMap aRecordMap = new LinkedHashMap();
				for (int j = 0; j < cols.length; j++) {
					aRecordMap.put(cols[j], recordSet.getString(cols[j]));
				}
				recordsMap.put(count, aRecordMap);
				count++;
			}
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			result = result + "exception";
			e.printStackTrace();
		}
	//	if(recordsMap.size() >1)
			return recordsMap;
	//	else
	//		return (LinkedHashMap)recordsMap.get(0);
	}

	private String formatDate(String d){
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateInString = d; 
		try {	 
			Date date = oldFormat.parse(d);	 
			dateInString = formatter.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}
	
	private String getNLSString(IPortalComponentRequest request, String resource_key) {
		try {
			ResourceBundle bundle = request.getResourceBundle();
			if (bundle != null) {
				return bundle.getString(resource_key);
			}
			return resource_key;
		} catch (MissingResourceException e) {
			return resource_key;
		}
	}
}