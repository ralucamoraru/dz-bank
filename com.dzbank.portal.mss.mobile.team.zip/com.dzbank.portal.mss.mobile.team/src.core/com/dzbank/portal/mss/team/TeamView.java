package com.dzbank.portal.mss.team;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeSet;
import java.util.Map.Entry;

import javax.resource.ResourceException;
import javax.resource.cci.MappedRecord;
import javax.resource.cci.RecordFactory;

import com.dzbank.portal.mss.team.model.ActionDTO;
import com.dzbank.portal.mss.team.model.EmployeeDTO;
import com.dzbank.portal.mss.team.model.TreeDTO;
import com.dzbank.portal.mss.team.model.UnitDTO;
import com.sap.security.api.IPrincipal;
import com.sap.security.api.UMException;
import com.sapportals.connector.ConnectorException;
import com.sapportals.connector.connection.IConnection;
import com.sapportals.connector.execution.functions.IInteraction;
import com.sapportals.connector.execution.functions.IInteractionSpec;
import com.sapportals.connector.execution.structures.IRecordMetaData;
import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.ivs.cg.ConnectionProperties;
import com.sapportals.portal.ivs.cg.IConnectorGatewayService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class TeamView extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";
	  private final String FUNCTION_ATTRIBUTE_NAME = "Name";
	  
	  private final String BACKEND_SYSTEM_ALIAS = "SAP_ECC_HumanResources";
	  private final String FUNCTION_NAME = "ZFB_GET_TEAMVIEW_DATA";
	  private final String FUNCTION_OUT_DATA = "ORGDATA_TABLE";
	  private final String FUNCTION_OUT_ACTIONS = "ACTION_TABLE";
	  private final String FUNCTION_OUT_PROFIL = "SHORT_TABLE";

	  private final String INPUT_NAME = "MODE";	
	  private final String INPUT_VALUE = "TEAM_STD";	
	
	private ResourceBundle nls;
//	public IRecordSet data;
	public IRecordSet actionsData;
	public TreeDTO tree;
	public Set<ActionDTO> employeeActions = new LinkedHashSet<ActionDTO>();
	public Set<ActionDTO> unitActions = new LinkedHashSet<ActionDTO>();
	
	public TeamView(){    
//		this.data = null;
		this.actionsData = null;
		this.tree = null;
	}
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		response.include(request, request.getResource(IResource.JSP, "jsp/TeamView.jsp"));	
		
		IRecordSet daten = this.getContent(request, response);
		
    	IPortalComponentContext componentContext = request.getComponentContext(); //"pcd:com.sap.portal.system/pcc/regionalization/com.sap.portal.pcc/StagingAreaId/Home_0/Home_0/00-EmptyRegion_en/00-EmptyRegion_en/1439988276"
    	IPortalComponentProfile profile = componentContext.getProfile();
    	String tbd = componentContext.getComponentName();
    	String helpURL = profile.getAttributeValue("com.sap.portal.iview.HelpURL");
		response.write("<table class=\"tray\"><tbody>");
		response.write("<tr><td>");
		response.write("<h3 class=\"iViewTray\">" + getNLSString(request, "TEAM_VIEW") + "</h3></td>");	
		response.write("<td align=\"right\">");					
		response.write("<a class=\"helpLink\" href=\"#\" target=\"_blank\" onclick=\"javascript:getTutorialURL('" +  helpURL + "');return false;\">" + getNLSString(request, "TEAM_HELP") + "</a>"); 
		response.write("</td></tr></tbody></table>");
		
		if (this.actionsData != null)
			this.readActions(response, daten);
		if (daten != null){
			TreeDTO tree = this.readTree(response, daten);
			TreeSet<UnitDTO> roots = tree.getRootUnits();
			//response.write("<h3 class=\"team\">Teamsicht</h3>");
			response.write("<div class=\"sidenav\">");
			response.write("<ul class=\"dropdown\">");
		    Iterator iter = roots.iterator();
		    int rootNb = 1;
		    while (iter.hasNext()) {
		    	UnitDTO root = (UnitDTO) iter.next();
		    	this.recurseTree(root, response, 1, rootNb);
		    	rootNb++;
		    }
			response.write("</ul></div>"); 

			response.write("<div class=\"subcontent\">");
			response.write("<div id=\"short_profile\"></div>");
			response.write("<div id=\"div1\"></div>");
			response.write("</div>");
		}
		else{
			response.write("<div style='min-height: 80px;'>Keine Daten verf�gbar.<div>");
		}	
	}
	
 	public void recurseTree(UnitDTO rootUnit, IPortalComponentResponse response, int count, int rootNb){
 		//int count = 1;
 		String unitID = rootUnit.getID();
 		String unitName = rootUnit.getName();
 		String ebene = rootUnit.getEbene();
// 		if(ebene.equalsIgnoreCase("AL"))
// 			response.write("<li id=\""+unitID+"\" class=\"sidenav_AL\">");
// 		else if(ebene.equalsIgnoreCase("BL"))
// 			response.write("<li id=\""+unitID+"\" class=\"sidenav_BL\">");
// 		else if(ebene.equalsIgnoreCase("GL"))
// 			response.write("<li id=\""+unitID+"\" class=\"sidenav_GL\">");
//		else if(ebene.equalsIgnoreCase("VS"))
// 			response.write("<li id=\""+unitID+"\" class=\"sidenav_VL\">");
//		else
			response.write("<li id=\""+unitID+"\">");
 		if(rootUnit.isRoot())
 	 		response.write("<a class=\"arrow\" id=\"root"+rootNb+"\" onclick=\"javascript:getRootOrgProfile('"+rootUnit.getID()+"');return false;\">" + rootUnit.getName() + " </a>"); //+unitID+
 		else
 			response.write("<a class=\"arrow\" onclick=\"javascript:getOrgProfile('"+rootUnit.getID()+"');return false;\">" + rootUnit.getName() + " </a>"); //+unitID+
 		response.write("<ul>");
 		TreeSet<EmployeeDTO> employees = rootUnit.getEmployees();
		Iterator iter = employees.iterator();
		TreeSet<EmployeeDTO> managers = rootUnit.getManagers();
		if(!managers.isEmpty()){
			Iterator iterM = managers.iterator();
			while (iterM.hasNext()){
				EmployeeDTO emp = (EmployeeDTO)iterM.next();
				response.write("<li id=\""+emp.getID()+"\"><a class=\"\" onclick=\"javascript:getShortProfile('" +  emp.getID() + "');return false;\">" + emp.getName() + " | " + emp.getEbene() + "</a></li> ");
			}
		}
		while (iter.hasNext()){
			EmployeeDTO emp = (EmployeeDTO)iter.next();
			if (!emp.isManager())
				response.write("<li id=\""+emp.getID()+"\"><a class=\"\" onclick=\"javascript:getShortProfile('" +  emp.getID() + "');return false;\">" + emp.getName() + "</a></li> ");
		}
		
		TreeSet<UnitDTO> units = rootUnit.getUnits();
		if(!units.isEmpty()){
			Iterator iter2 = units.iterator();
			while (iter2.hasNext()){
				UnitDTO unit = (UnitDTO)iter2.next();
				this.recurseTree(unit, response, count + 1, rootNb);
			}
		}
		response.write("</ul></li>");
 	}
	
	public IRecordSet getContent(IPortalComponentRequest request, IPortalComponentResponse response){
		IInteraction ix = null;
		IConnection connection = null;
		IRecordSet daten = null;
		String ret = "in method, ";
		try {
			connection = getConnection(request, response);
			if (connection != null)
			{
				
				// Get the Interaction interface for executing the command
			    ix = connection.createInteractionEx();
			    // Get interaction spec and set the name of the command to run
			    IInteractionSpec ixspec = ix.getInteractionSpec();
			    // Put Function Name into interaction Properties.
			    ixspec.setPropertyValue(FUNCTION_ATTRIBUTE_NAME, FUNCTION_NAME);
			    // return structure
			    RecordFactory rf = ix.getRecordFactory();
			    ret = ret + "got connection, ";
			    MappedRecord input = rf.createMappedRecord(INPUT_ATTRIBUTE);
			    // put function input parameters
			    input.put(INPUT_NAME, INPUT_VALUE);
			    MappedRecord output = (MappedRecord) ix.execute(ixspec, input);
			    try {
			    	ret = ret + "got a result, ";
			    	//response.write("<script>alert(\"Connection is opened!!!"+connection.toString()+"\");</script>");
			    	Object result = output.get(FUNCTION_OUT_DATA);
			        if (result == null) {
			        	ret = ret + "is NULL, ";
			        	//this.data = null;
			        } else if (result instanceof IRecordSet) {
			        	ret = ret + "is recordSet, ";
			          //  this.data = (IRecordSet) result;
			            daten = (IRecordSet) result;
			        }
			        
			        //get actions 
			        ret = ret + "got actions list, ";
			    	Object actionsResult = output.get(FUNCTION_OUT_ACTIONS);
			        if (actionsResult == null) {
			        	ret = ret + "Actions is NULL, ";
			        	this.actionsData = null;
			        } else if (actionsResult instanceof IRecordSet) {
			        	ret = ret + "Actions is recordSet, ";
			            this.actionsData = (IRecordSet) actionsResult;
			        }			    	
			    } catch (Exception ex) {
			    	ret = ret + "inner exception, " + ex.getMessage();
			    	ex.printStackTrace();
			    }
			    connection.close();
			} 
		} catch (ConnectorException e) {
			ret = ret + "TeamView: ConnectorException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (IOException e) {
			ret = ret + "TeamView: IOException occured: " + e.getMessage();
			e.printStackTrace();
		} catch (UMException e) {
			ret = ret + "TeamView: UMException occured: " + e.getMessage();
			e.printStackTrace();

		} catch (ResourceException e) {
			ret = ret + "TeamView: ResourceException occured: " + e.getMessage();
			e.printStackTrace();

		} finally {
			try {
				if (ix != null) {
					ix.close();
					ret = ret + "interraction cloase ";
				}
			} catch (Exception e) {
				ret = ret + "TeamView: Error Closing interaction! ";
				e.printStackTrace();
			}
			try {
				if (connection != null) {
					connection.close();
					ret = ret + "Connection closed!";
				}

			} catch (ResourceException e) {
				ret = ret + "TeamView: Error Closing interaction! ";
				e.printStackTrace();
			}
		}		
		return daten;
	}

	/**
	 * 
	 * @return
	 */
	public String[] getColNames(IRecordSet daten){
		String[] cols = null;  
		try {
			IRecordMetaData columns = daten.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 for (int i = 0; i < nbCol; i++) {
				cols[i] = columns.getColumnName(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	
	/**
	 * 
	 * @return
	 */
	public String[] getColLabels(IRecordSet daten){
		String[] cols = null;  
		try {
			IRecordMetaData columns = daten.retrieveMetaData();
			 int nbCol = columns.getColumnCount();
			 cols = new String [nbCol];
			 
			 for (int i = 0; i < nbCol; i++) {
				 cols[i] = columns.getColumnLabel(i);
			}
			 
		} catch (ConnectorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cols;
	}
	/**
	 * 
	 * @param d
	 * @return
	 */
	private String formatDate(String d){
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		SimpleDateFormat oldFormat = new SimpleDateFormat("yyyy-MM-dd");
		String dateInString = d; 
		try {	 
			Date date = oldFormat.parse(d);	 
			dateInString = formatter.format(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateInString;
	}	
	

	public TreeDTO readTree(IPortalComponentResponse response, IRecordSet daten) {
		TreeDTO tree = new TreeDTO();
		try {
			 //*** Call for Tree Structure ***//
			if (daten == null){
				//response.write("<script>alert(\"ACHTUNG!! Das Backend liefert eine leere Datenstruktur!!\");</script>");
				return tree;
			}else{					
				daten.beforeFirst();
				int count = 0;
				while (daten.next()){
					String name = daten.getString("NODE_TEXT");
					String objID = daten.getString("OBJID");
					String objType = daten.getString("OTYPE");
					String parentObjID = daten.getString("OBJID_PARENT");
					String ebene = daten.getString("EBENE_BEZEICHNUNG");
					boolean isManager = daten.getString("MANAGER").equalsIgnoreCase("X");
					int level = daten.getInt("EBENE");
					if (objType.equalsIgnoreCase("o"))
					{						
						//response.write("<script>alert(\"New unit: " + name + ", " + objID +"\");</script>");
						UnitDTO unit = new UnitDTO(objID, name, parentObjID);
						unit.setEbene(ebene);
						unit.setActions(this.unitActions);
						if (level == 1){
							unit.setIsRoot(true);
							tree.addUnit(unit);
							//tree.setRootUnit(unit);
						}else if(level >1){
							unit.setIsRoot(false);
							//UnitDTO root = tree.getRootUnit();
							TreeSet<UnitDTO> rootUnits = tree.getRootUnits();
							Iterator iter = rootUnits.iterator();
							boolean found = false;
						    while (iter.hasNext() && !found) {
						    	UnitDTO object = (UnitDTO) iter.next();
						    	UnitDTO parent = object.getUnitForID(parentObjID);
						    	if(parent!=null){
						    		found = true;
						    		parent.addUnit(unit);
						    	}
						    }
						}	
					}else if (objType.equalsIgnoreCase("p")){
						EmployeeDTO employee = new EmployeeDTO(objID, name, parentObjID, isManager);
						employee.setEbene(ebene);
						employee.setActions(this.employeeActions);					
						TreeSet<UnitDTO> rootUnits = tree.getRootUnits();
						Iterator iter = rootUnits.iterator();
						boolean found = false;
					    while (iter.hasNext() && !found) {
					    	UnitDTO object = (UnitDTO) iter.next();
					    	UnitDTO parent = object.getUnitForID(parentObjID);
					    	if(parent != null){
					    		found = true;
					    		parent.addEmployee(employee, response);
					    	}
					    }						
						//UnitDTO root = tree.getRootUnit();
						//UnitDTO parent = root.getUnitForID(parentObjID);
						//parent.addEmployee(employee);
					}
				}
					this.tree = tree;
			}	
		} catch (ConnectorException e) {
			e.printStackTrace();
		}

		return tree;
	}	
	

	public void readActions(IPortalComponentResponse response, IRecordSet daten) {
		TreeDTO tree = new TreeDTO();
		try {
			if (daten == null){
				response.write("<script>alert(\"ACHTUNG!! Das Backend liefert eine leere Datenstruktur!!\");</script>");
				return;
			}else{	
				 //*** Call for Tree Structure ***//
				this.actionsData.beforeFirst();
				int count = 0;
				while (this.actionsData.next()){
					String ID = this.actionsData.getString("BUTTON_ID");
					String fb = this.actionsData.getString("FUNKTIONSBAUSTEIN");
					String text = this.actionsData.getString("BUTTON_TEXT");
					String objType = this.actionsData.getString("OTYPE");
					String actionType = this.actionsData.getString("ACTION_TYPE");
					ActionDTO action = new ActionDTO(ID, text, fb, objType, actionType);
					if (objType.equalsIgnoreCase("o")){
						//response.write("<script>alert(\"New unit: " + name + ", " + objID +"\");</script>");
						this.unitActions.add(action);
					}else if (objType.equalsIgnoreCase("p")){
						this.employeeActions.add(action);
						}	
				}
			}
		} catch (ConnectorException e) {
			e.printStackTrace();
		}
	}	
	
	/**
	 * 
	 * @param recordsMap
	 */
	private void iterateRecordsMap(LinkedHashMap recordsMap){
		Iterator entries = recordsMap.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();
		  Object value = thisEntry.getValue();
		}
	}
	
	/**
	 * 
	 * @param input
	 * @return
	 */
	public LinkedHashMap removeMANDT(LinkedHashMap input){
		String key = "MANDT";
		if (input.containsKey(key))
			input.remove(key);
		return input;
	}
	
	/**
	 * 
	 * @param map
	 * @return
	 */
	private HashMap testIterator(HashMap map){
		Iterator entries = map.entrySet().iterator();
		while (entries.hasNext()) {
		  Entry thisEntry = (Entry) entries.next();
		  Object key = thisEntry.getKey();

		  Object value = thisEntry.getValue();
		 // HashMap aRecordMap = (HashMap)value;
		  String[] array = (String[])value;
		  for (int i = 0; i < array.length; i++) {
			String s = array[i];
		}
		}
		return map;
	}
	
	
	private String formatBigDecimal(double bd){
		//NumberFormat nf = NumberFormat.getNumberInstance(Locale.GERMAN);
		String pattern = "###,###.##";
		//DecimalFormat df = (DecimalFormat)nf;
		DecimalFormat df = new DecimalFormat(pattern);
	    df.setMinimumFractionDigits(2);
	    df.setMaximumFractionDigits(2);
		String res = df.format(bd);
		return res;
	}

	
	/*
	 * Getting the connector gateway service
	 */
	private IConnection getConnection(IPortalComponentRequest request, IPortalComponentResponse response) throws ConnectorException, IOException, UMException
	{
		IConnectorGatewayService cgService = (IConnectorGatewayService)PortalRuntime.getRuntimeResources().getService(IConnectorGatewayService.KEY); 
		ConnectionProperties prop = new ConnectionProperties(request.getLocale(), (IPrincipal) request.getUser());
		if (cgService == null) 
		{
			return null;
			//writeJsonResponse(request, "");
		}
		//Get the system alias from the configurable Portal component property
		String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		IConnection conn = null;
		conn = cgService.getConnection(BACKEND_SYSTEM_ALIAS, prop);
		
		return conn;
	}
	
	private String getNLSString(IPortalComponentRequest request, String resource_key) {
		try {
			ResourceBundle bundle = request.getResourceBundle();
			if (bundle != null) {
				return bundle.getString(resource_key);
			}
			return resource_key;
		} catch (MissingResourceException e) {
			return resource_key;
		}
	}
}