package com.dzbank.portal.mss.team.model;

import java.io.Serializable;
import java.util.Iterator;
import java.util.TreeSet;

@SuppressWarnings("serial")
public class TreeDTO implements Serializable {
//	private UnitDTO unit = new UnitDTO();
	private TreeSet<UnitDTO> units = new TreeSet<UnitDTO>();
	
	public TreeDTO() {
 
	}

/*	public UnitDTO getRootUnit() {
		return this.unit;
	}

	public void setRootUnit(UnitDTO unit) {
		this.unit = unit;
	}*/
	
	public TreeSet<UnitDTO> getRootUnits() {
		return this.units;
	}
	
	public void setRootUnits(TreeSet<UnitDTO> units) {
		this.units = units;
	}
	
	public void addUnit(UnitDTO unit) {
	    boolean toAdd = true;
	    Iterator iter = this.units.iterator();
	    while (iter.hasNext()) {
	    	UnitDTO object = (UnitDTO) iter.next();
	    	if(object.getID().equals(unit.getID())){
	    		toAdd = false; 
	    	}					 
	    }
	    if (toAdd)
	    	this.units.add(unit);
	}	

}
