package com.dzbank.portal.mss.team.model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ActionDTO implements Serializable, Comparable<ActionDTO> {
	private String ID;
	private String text;
	private String fb;
	private String objectType; //P für Person oder O für Organisation
	private String actionType; //R für Report, U für URL, O für OBN
	
	
	public ActionDTO() {
 
	}

	public ActionDTO(String id, String text, String fb, String objectType, String actionType) {
		this.ID = id;
		this.fb = fb;
		this.text = text;
		this.objectType = objectType;
		this.actionType = actionType;
	}



	public String getID() {
		return this.ID;
	}

	public void setID(String id) {
		this.ID = id;
	}

	public String getFB() {
		return this.fb;
	}

	public void setFB(String fb) {
		this.fb = fb;
	}

	public String getText() {
		return this.text;
	}
	
	public void setText(String text) {
		this.text = text;
	}
	
	public String getObjectType() {
		return this.objectType;
	}
	
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	
	public String getActionType() {
		return this.actionType;
	}
	
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
		
	@Override
	public int compareTo(ActionDTO o) {
	return this.ID.compareTo(o.ID);
	}

}
