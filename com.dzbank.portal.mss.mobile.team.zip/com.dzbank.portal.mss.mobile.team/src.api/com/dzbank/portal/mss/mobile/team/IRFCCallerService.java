package com.dzbank.portal.mss.mobile.team;
 

import java.util.LinkedHashMap;

import com.sapportals.connector.execution.structures.IRecordSet;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.service.IService;

public interface IRFCCallerService extends IService
{
    public static final String KEY = "com.dzbank.portal.mss.team.RFCCallerService";

    public void doRFCCall(IPortalComponentRequest request, String rfcFunction, String rfcInput, String rfcOutput);
    
    public Object doRFCCallKurzProfil(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType);
    
    public Object doRFCCallEmpProfile(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType);
    
    public Object doRFCCallCompProfile(IPortalComponentRequest request, String rfcFunction, String rfcOutput, String objID, String objType);
    
    public LinkedHashMap getContent(IRecordSet recordSet);
            
    public LinkedHashMap getMapRecordSet();
        
    public String[] getColNames();
    
    public String[] getColLables();
    
}

