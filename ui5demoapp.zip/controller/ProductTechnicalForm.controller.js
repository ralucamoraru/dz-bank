sap.ui.define([
	"sap/ui/demoapps/rta/freestyle/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("sap.ui.demoapps.rta.freestyle.controller.ProductTechnicalForm", {

	});
});
