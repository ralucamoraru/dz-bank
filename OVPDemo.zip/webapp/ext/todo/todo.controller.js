(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("demo.ovp.BusinessOverview.ext.todo.todo", {

		onInit: function () {

		},

		onAfterRendering: function () {

		},

		onExit: function () {

		}

	});
})();