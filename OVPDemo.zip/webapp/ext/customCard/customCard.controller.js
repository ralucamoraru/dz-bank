(function () {
	"use strict";

	/* controller for custom card  */

	sap.ui.controller("demo.ovp.BusinessOverview.ext.customCard.customCard", {

		onInit: function () {

		},

		onAfterRendering: function () {

		},

		onExit: function () {

		}

	});
})();