package com.uit.portal.support;

import java.util.Hashtable;

import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sap.portal.resource.repository.IResourceRepositoryService;
import com.sap.portal.resource.repository.exceptions.InvalidResourcePathException;
import com.sap.portal.resource.repository.exceptions.ResourceNotFoundException;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class NeuPageOpener extends AbstractPortalComponent{

	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		//response.include(request, request.getResource(IResource.JSP, "jsp/SysMsg.jsp"));	
		IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		
		String portalPath = aliasHelper.getPath(request);		
		
		Hashtable environment = helperService.getEnvironment(request);
		
		String iviewURL = request.getComponentContext().getProfile().getProperty("com.uit.portal.URL");
		String htmlPath = portalPath + iviewURL;
		response.write("<script>console.log(\"System Nachrichten... \");</script>");
		response.write("<script>console.log(\"Resource: " + htmlPath + "\"); </script>");
		response.write("<script>window.open('"+ htmlPath +"', \"_blank\", \"toolbar=no, scrollbars=yes, resizable=yes, top=100, left=100, width=1000, height=1000\");</script>");

	}
	
 
}