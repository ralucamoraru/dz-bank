package com.uit.portal.idprovider;
 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.NamingException;

import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sap.portal.resource.repository.IResourceRepositoryService;
import com.sap.portal.resource.repository.exceptions.InvalidResourcePathException;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;


/**
 * 
 * @author Raluca Moraru
 * ralucamoraru@gmail.com / +49 176 64718145
 *
 */

public class IDProviderComp extends AbstractPortalComponent
{
	public String portalPath = "";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		response.include(request, request.getResource(IResource.CSS, "css/uit.css"));
		String user = request.getUser().getName();
		response.write("<div class='wpc_area'><div class='wpc_info_box'><h2>Mit dieser GenoID sind Sie angemeldet</h2><p><strong>Geno ID: </strong>" + user+ "</p></div></div>");
	}

}