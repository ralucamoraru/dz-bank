<?php
// http_response_code(500);
// sleep(2);
// usleep(500000);// microseconds = 1000 milliseconds = 1000000 seconds
header('Content-type: text/json');
$callback = $_GET['callback'];
if ($callback) echo $callback . "(";
?>{
  "term": "<%=@$_GET['term']%>",
  "index": "typeahead",
  "hits": 3,
  "performance": 231,
  "results": [ "c++", "java", "php", "coldfusion", "javascript", "asp", "ruby", "swift", "swing", "kajar", "mojave" ]
}<?php
if ($callback) echo ")";
?>
