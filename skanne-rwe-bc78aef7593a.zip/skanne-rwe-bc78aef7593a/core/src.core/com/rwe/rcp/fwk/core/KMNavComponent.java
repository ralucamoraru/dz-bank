package com.rwe.rcp.fwk.core;

import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResourceInformation;
import com.sapportals.wcm.WcmException;
import com.sapportals.wcm.repository.*;
import com.sapportals.wcm.service.urimapper.IUriMapperService;
import com.sapportals.wcm.service.urimapper.UriMapperServiceFactory;
import com.sapportals.wcm.util.uri.RID;
import de.neuland.jade4j.template.FileTemplateLoader;
import de.neuland.jade4j.template.JadeTemplate;
import de.neuland.jade4j.template.TemplateLoader;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.*;

public class KMNavComponent extends AbstractFrameworkComponent {

  final static HashMap<String, String> TYPES = new HashMap<String, String>();
  static {
    TYPES.put(".pdf", "pdf");
    TYPES.put(".ppt", "ppt");
    TYPES.put(".pptx", "ppt");
    TYPES.put(".doc", "doc");
    TYPES.put(".docx", "doc");
    TYPES.put(".xls", "xls");
    TYPES.put(".xlsx", "xls");
    TYPES.put("", "unknown");
  }

  @Override
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
    writeBody(request, response);
  }

  @Override
  public JSONObject getModel(IPortalComponentRequest request) {
    return null;
  }

  public static JSONObject getKMNav(IPortalComponentRequest request, String startRid, String currentRid) {
    JSONObject jsonKMNav = new JSONObject();
    try {
      if (currentRid == null) {
        currentRid = startRid;
      }

      IResourceContext ctx = ResourceContext.getInstance(request.getUser());
      IResource startResource = getResource(startRid, ctx);
      IResource currentResource = getResource(currentRid, ctx);

      jsonKMNav.put("startRid", startRid);
      jsonKMNav.put("currentRid", currentRid);

      if (currentResource.isCollection()) {
        ICollection collection = (ICollection) currentResource;
        IResourceList children = collection.getChildren();
        if (children != null) {
          SimpleDateFormat ddMMyyyy = new SimpleDateFormat("dd.MM.yyyy");
          SimpleDateFormat hhmmss = new SimpleDateFormat("hh:mm:ss");

          JSONArray jsonResources = new JSONArray();
          for (IResourceListIterator it = children.listIterator(); it.hasNext();) {
            JSONObject jsonResource = new JSONObject();

            IResource childResource = it.next();
            String rid = childResource.getRID().getPath();
            int dotPos = rid.lastIndexOf(".");

            jsonResource.put("rid", rid);
            jsonResource.put("displayName", childResource.getDisplayName(true));

            if (childResource.isCollection()) {
              jsonResource.put("isCollection", true);
            } else {
              String type = TYPES.get(dotPos > -1 ? rid.substring(dotPos) : "");
              if (type == null) {
                type = "unknown";
              }
              jsonResource.put("type", type);

              long size = childResource.getContent().getContentLength();
              jsonResource.put("fileSize", getSize(size));
              jsonResource.put("fileSizeOrder", size);
            }

            Date lastModified = childResource.getLastModified();
            jsonResource.put("lastModifiedDate", ddMMyyyy.format(lastModified));
            jsonResource.put("lastModifiedTime", hhmmss.format(lastModified));
            jsonResource.put("lastModifiedOrder", lastModified.getTime());

            jsonResources.add(jsonResource);
          }
          jsonKMNav.put("list", jsonResources);
        }

        new InputStreamReader(currentResource.getContent().getInputStream(), "UTF-8");

        JSONArray jsonResources = new JSONArray();
        if (!startRid.equals(currentRid) && currentRid.indexOf(startRid) > -1) {
          do {
            if (currentResource != null) {
              JSONObject jsonResource = new JSONObject();

              String rid = currentResource.getRID().getPath();
              jsonResource.put("rid", rid);
              jsonResource.put("displayName", currentResource.getDisplayName(true));
              if (rid.equals(startRid)) {
                jsonResource.put("isStart", true);
              }

              jsonResources.add(0, jsonResource);

              currentResource = currentResource.getParentCollection();
            }
          } while (currentResource != null && !startResource.equals(currentResource));
        }

        JSONObject jsonResource = new JSONObject();
        jsonResource.put("rid", startRid);
        jsonResource.put("displayName", startResource.getDisplayName(true));
        jsonResource.put("isStart", true);
        jsonResources.add(0, jsonResource);

        jsonResource = (JSONObject) jsonResources.get(jsonResources.size() - 1);
        jsonResource.put("css", "is-last");

        jsonKMNav.put("path", jsonResources);
      }
    } catch (Exception e) {
      jsonKMNav.put("exception", e.getLocalizedMessage());
    }
    return jsonKMNav;
  }


  void writeBody(IPortalComponentRequest request, IPortalComponentResponse response) {
    long start = System.currentTimeMillis();

    TemplateLoader loader = new FileTemplateLoader(getFilePath(request, "jade/"), "UTF-8");
    JADE_CONFIGURATION.setTemplateLoader(loader);

    try {
      JadeTemplate template = JADE_CONFIGURATION.getTemplate(getTemplate(request));
      String startRid = request.getParameter("startRid");
      String currentRid = request.getParameter("currentRid");

      JSONObject model = getKMNav(request, startRid, currentRid);
      model.put("isStandalone", true);
      putResourceBundle(request.getLocale(), model);

      Writer writer = request.getServletResponse(true).getWriter();

      JADE_CONFIGURATION.renderTemplate(template, model, writer);
      long stop = System.currentTimeMillis();
      writer.write("<!-- " + (stop - start) + "ms -->");
    } catch (IOException e) {
      response.write("Error: " + e.getMessage());
    }
  }

  public String getTemplate(IPortalComponentRequest request) {
    return "_kmnav.jade";
  }

  private String getFilePath(IPortalComponentRequest request, String fileName) {
    com.sapportals.portal.prt.resource.IResource resource = request.getResource(com.sapportals.portal.prt.resource.IResource.STATIC_PAGE, fileName);
    IResourceInformation resourceInformation = resource.getResourceInformation();
    String source = resourceInformation.getSource();
    return source.replaceFirst("\\.html$", "");
  }

  private static String getSize(long size) {
    double kilo = size / 1000;
    if (kilo <= 0) return size + " bytes";
    double mega = size / 1000 / 1000;
    if (mega <= 0) return Math.round(kilo) + " KB";
    double giga = size / 1000 / 1000 / 1000;
    if (giga <= 0) return Math.round(mega) + " MB";
    double tera = size / 1000 / 1000 / 1000 / 1000;
    if (tera <= 0) return Math.round(giga) + " GB";
    return Math.round(tera) + " TB";
  }


  private static IResource getResource(String rid, IResourceContext ctx) throws Exception, ResourceException {
    if (rid == null) {
      throw new Exception("RID is not specified.");
    }

    if (rid.startsWith("/irj/go/km/docs/")) {
      rid = rid.replaceFirst("/irj/go/km/docs", "");
    }

    if (rid.startsWith("/guid/")) {
      IUriMapperService uriMapper;
      try {
        uriMapper = UriMapperServiceFactory.getInstance();
        rid = uriMapper.getRIDFromGuidRID(RID.getRID(rid)).getPath();
      } catch(WcmException e) {
      }
    }

    IResource resource = ResourceFactory.getInstance().getResource(RID.getRID(rid), ctx);
    if (resource == null) {
      throw new Exception("Resource with RID " + rid + " is null.");
    }
    return resource;
  }

  public void putResourceBundle(Locale locale, JSONObject model) {
    ResourceBundle resourceBundle = ResourceBundle.getBundle("rb", locale);
    JSONObject rb = new JSONObject();
    Set<String> keySet = resourceBundle.keySet();
    for (String key : keySet) {
      String value = resourceBundle.getString(key);
      rb.put(key, value);
    }
    model.put("rb", rb);
  }
}
