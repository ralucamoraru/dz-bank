package com.rwe.rcp.fwk.core.utils;

import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IComponentNode;
import com.sapportals.portal.prt.pom.INode;
import com.sapportals.portal.prt.pom.INodeList;
import com.sapportals.portal.prt.pom.IPortalNode;

public class PRTUtils {


	public static void addChildNode(IPortalComponentRequest request, String launchURL, String groupName) {
		INode node = request.getNode();
		if (node != null) {
			IPortalNode portalNode = node.getPortalNode();

			IPortalComponentContext componentContext = request.getComponentContext(launchURL);
			if (componentContext != null) {
				IComponentNode contentAreaNode = portalNode.createComponentNode(groupName, componentContext);
				node.addChildNode(contentAreaNode);
			}
		}
	}

	public static void includeChildNodes(IPortalComponentRequest request, IPortalComponentResponse response, String groupName) {
		INode node = request.getNode();
		INodeList contentAreaNodes = node.getChildNodesByName(groupName);
		if (contentAreaNodes != null) {
			for (int i = 0; i < contentAreaNodes.getLength(); i++) {
				response.include(request, contentAreaNodes.item(i));
			}
		}
	}
}
