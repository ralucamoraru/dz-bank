package com.rwe.rcp.fwk.core.utils;

import com.sapportals.wcm.repository.IResource;
import com.sapportals.wcm.util.content.IContent;
import de.neuland.jade4j.template.TemplateLoader;

import java.io.*;
import java.util.Locale;

/**
 * Created by d037963 on 11/05/16.
 */
public class KMReaderTemplateLoader implements TemplateLoader {
  private String baseRID = "";
  private Locale locale = Locale.ENGLISH;

  public KMReaderTemplateLoader(String baseRID, Locale locale) {
    this.baseRID = baseRID;
    this.locale = locale;
  }

  public long getLastModified(String name) throws IOException {
    IResource resource = getResource(name);
    return resource.getLastModified().getTime();
  }

  public Reader getReader(String name) throws IOException {
    try {
      IResource resource = getResource(name);
      return new InputStreamReader(resource.getContent().getInputStream(), "UTF-8");
    } catch (Exception e) {
      return new StringReader("<!-- A reader for [" + name + "] cannot be initialized. -->");
    }
  }

  private IResource getResource(String name) {
    int dotPos = name.lastIndexOf(".");
    String localeName = name.substring(0, dotPos) + '_' + this.locale.toString() + name.substring(dotPos);
    IResource resource = KMUtils.getNullableResource(this.baseRID + localeName);
    if (resource == null && this.locale.getCountry() != null) {
      localeName = name.substring(0, dotPos) + '_' + this.locale.getLanguage() + name.substring(dotPos);
      resource = KMUtils.getNullableResource(this.baseRID + localeName);
    }
    if (resource == null) {
      resource = KMUtils.getNullableResource(this.baseRID + name);
    }
    return resource;
  }
}
