package com.rwe.rcp.fwk.core.utils;

import com.sap.security.api.IUser;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapportals.wcm.WcmException;
import com.sapportals.wcm.repository.*;
import com.sapportals.wcm.service.urimapper.IUriMapperService;
import com.sapportals.wcm.service.urimapper.UriMapperServiceFactory;
import com.sapportals.wcm.util.uri.RID;

/**
 * Created by d037963 on 11/05/16.
 */
public class KMUtils {

  public static IResource getResource(String rid) throws Exception {
    IUser user = UMFactory.getUserFactory().getUserByLogonID("cmadmin_service");

    return getResource(rid, user);
  }

  public static IResource getResource(String rid, IUser user) throws Exception {
    if (rid == null) {
      throw new Exception("RID is not specified.");
    }

    if (rid.startsWith("/irj/go/km/docs/")) {
      rid = rid.replaceFirst("/irj/go/km/docs", "");
    }

    if (rid.startsWith("/guid/")) {
      IUriMapperService uriMapper;
      try {
        uriMapper = UriMapperServiceFactory.getInstance();
        rid = uriMapper.getRIDFromGuidRID(RID.getRID(rid)).getPath();
      } catch(WcmException e) {
      }
    }

    IResourceContext ctx = ResourceContext.getInstance(user);

    IResource resource = ResourceFactory.getInstance().getResource(RID.getRID(rid), ctx);
    if (resource == null) {
      throw new Exception("Resource with RID " + rid + " is null.");
    }
    return resource;
  }

  public static IResource getNullableResource(String rid) {
    IUser user;
    try {
      user = UMFactory.getUserFactory().getUserByLogonID("cmadmin_service");
    } catch (UMException e) {
      return null;
    }

    return getNullableResource(rid, user);
  }

  public static IResource getNullableResource(String rid, IUser user) {
    if (rid == null) {
      return null;
    }

    if (rid.startsWith("/irj/go/km/docs/")) {
      rid = rid.replaceFirst("/irj/go/km/docs", "");
    }

    if (rid.startsWith("/guid/")) {
      IUriMapperService uriMapper;
      try {
        uriMapper = UriMapperServiceFactory.getInstance();
        rid = uriMapper.getRIDFromGuidRID(RID.getRID(rid)).getPath();
      } catch(WcmException e) {
      }
    }

    IResourceContext ctx = ResourceContext.getInstance(user);

    IResource resource = null;
    try {
      resource = ResourceFactory.getInstance().getResource(RID.getRID(rid), ctx);
    } catch (ResourceException e) {
    }

    return resource;
  }

}
