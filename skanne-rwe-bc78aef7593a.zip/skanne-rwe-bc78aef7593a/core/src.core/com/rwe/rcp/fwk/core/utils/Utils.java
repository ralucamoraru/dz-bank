package com.rwe.rcp.fwk.core.utils;

import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;

import javax.servlet.http.Cookie;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLDecoder;

/**
 * This class is to be used as a static class only. The reason being is the
 * versioning of resources like stylesheets and Javascript files, such that we
 * can always be sure that the end user loads the correct version of the
 * corresponding file, even if there is an older version in the user's browser
 * cache.
 *
 * @author Sven Kannengiesser (SAP)
 * @version 2008-01-29-16-40
 */
public class Utils {

	/**
	 * Retrieves the cookie with the given name from the request.
	 *
	 * @param request
	 *            The current request.
	 * @param name
	 *            The cookie's name.
	 * @return the cookie's value, or null if not found for 'name'.
	 */
	public static String getCookie(IPortalComponentRequest request, String name) {
		Cookie[] cookies = request.getServletRequest().getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				Cookie cookie = cookies[i];
				String n = cookie.getName();
				if (n.equals(name)) {
					String v = cookie.getValue();
					if (v != null) {
						return URLDecoder.decode(v);
					}
				}
			}
		}
		return null;
	}

	/**
	 * Returns <i>true</i> or <i>false</i> depending on the value of the
	 * property with the given key.
	 *
	 * @param profile
	 *            The profile that contains the property.
	 * @param key
	 *            The property's key.
	 * @return <i>true</i> if the property's value is equal to "true".
	 */
	public static boolean isEnabled(IPortalComponentProfile profile, String key) {
		if (profile == null)
			return false;
		String prop = profile.getProperty(key);
		return Boolean.valueOf(prop).booleanValue();
	}

	/**
	 * Returns the value of the property with the given key. If the profile or
	 * the value is null, an empty String is returned.
	 *
	 * @param profile
	 *            The profile that contains the property.
	 * @param key
	 *            The property's key.
	 * @return the property value
	 */
	public static String getProperty(IPortalComponentProfile profile, String key) {
		if (profile == null)
			return "";
		String prop = profile.getProperty(key);
		return prop == null ? "" : prop;
	}


	public static String getPageNotFoundText(String portalPath, String theText) {
		return java.text.MessageFormat.format(theText, new Object[] { portalPath }).toString();
	}


	public static String getStackTrace(Throwable e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}

}
