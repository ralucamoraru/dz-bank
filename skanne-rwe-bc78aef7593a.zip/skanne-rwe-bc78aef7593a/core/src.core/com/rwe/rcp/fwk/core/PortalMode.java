package com.rwe.rcp.fwk.core;

public enum PortalMode {

	auto, legacy, html5;

}
