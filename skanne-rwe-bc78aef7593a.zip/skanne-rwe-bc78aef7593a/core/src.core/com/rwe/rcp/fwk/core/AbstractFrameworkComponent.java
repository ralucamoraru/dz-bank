package com.rwe.rcp.fwk.core;

import com.sap.security.api.IUserMaint;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IEvent;
import com.sapportals.portal.prt.util.AbstractURI;
import de.neuland.jade4j.JadeConfiguration;
import de.neuland.jade4j.filter.MarkdownFilter;
import de.neuland.jade4j.template.FileTemplateLoader;
import de.neuland.jade4j.template.JadeTemplate;
import de.neuland.jade4j.template.TemplateLoader;
import org.json.simple.JSONObject;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.Writer;
import java.util.Locale;

public abstract class AbstractFrameworkComponent extends AbstractPortalComponent {
  final static String MIMES_APP = "com.rwe.rcp.fwk.mimes";

  final static JadeConfiguration JADE_CONFIGURATION = new JadeConfiguration();
  static {
    JADE_CONFIGURATION.setCaching(true);
    JADE_CONFIGURATION.setPrettyPrint(true);  // TODO change to false before go-live
    JADE_CONFIGURATION.setFilter("markdown", new MarkdownFilter());
  }

  protected void doBeforeContent(IPortalComponentRequest request, IEvent event) {
    // remove global style sheets from request
    HttpSession session = request.getServletRequest().getSession();
    session.setAttribute("com.sap.portal.themes.lafservice.requiredThemeParts", "");
  }

  protected void doOnNodeReady(IPortalComponentRequest request, IEvent event) {
    Config cfg = Config.getInstance(request);

    if (checkLanguage(request, cfg)) {
      // the language check ended with a redirect, >> exit
      return;
    }
  }

  private boolean checkLanguage(IPortalComponentRequest request, Config cfg) {
    if (!cfg.isAnonymousUser()) {
      // authenticated user --> if an authenticated user lacks a user language,
      String lang = request.getParameter("lang");
      String qlParam = request.getParameter("QuickLink");

      if (lang != null) {
        try {
          IUserMaint userMaint = UMFactory.getUserFactory().getMutableUser(request.getUser().getUniqueID());
          Locale locale = new Locale(lang);
          userMaint.setLocale(locale);
          userMaint.save();
          userMaint.commit();
          try {

            String path = cfg.getPortalPath() + (qlParam == null ? "" : '/' + qlParam);
            String qs = request.getServletRequest().getQueryString();
            if (qs != null) {
              AbstractURI uri = new AbstractURI(path + "?" + qs.replaceAll(":", "%3A"));
              uri.removeParameter("lang");
              uri.removeParameter("QuickLink");
              request.getServletResponse(true).sendRedirect(uri.toString());
            } else {
              request.getServletResponse(true).sendRedirect(path);
            }
          } catch (IOException e) {
          }
          return true;
        } catch (UMException e) {
        }
      } else {
        return false;
      }
    }
    return false;
  }

  public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
//    response.write(getKMTempl(request, cfg.getLaunchedNode()));
    Config cfg = Config.getInstance(request);

    String webResourcePath = request.getWebResourcePath(MIMES_APP) + '/';

    // Set IE Edge Mode
    request.getServletResponse(false).setHeader("X-UA-Compatible", "IE=Edge");

    EnhancedPortalResponse epResponse = EnhancedPortalResponse.getInstance(request, true, false);

    // <!doctype html>
    epResponse.setDocTypeToHtml5();

    // <title>
    epResponse.setTitle(cfg.getPageTitle() + " | RWE Corporate Portal");

    // <meta charset='utf-8'>
    epResponse.includeCharsetMeta("UTF-8");

    // <meta name='viewport' content='width=device-width, initial-scale=1, user-scalable=0'>
    epResponse.includeMeta("viewport", "width=device-width, initial-scale=1, user-scalable=1");

    // <link rel='shortcut icon' href='img/favicon.png'>
    epResponse.includeLink("shortcut icon", webResourcePath + "img/rwe.ico", null, null);

    epResponse.includeStyleResource(MIMES_APP, "css/fwk.css");

    epResponse.addHtmlAttribute("id", "fwk");
    epResponse.addHtmlAttribute("class", "is-closed-panel");
    epResponse.removeBodyClass();
    epResponse.setBodyId("body");

    writeBody(request, response);

    JSONObject jsonFWK = new JSONObject();
    jsonFWK.put("locale", request.getLocale().getLanguage());
    jsonFWK.put("webResourcePath", '/' + MIMES_APP + '/');
    jsonFWK.put("contentAreaPath", "/irj/go/portal/prtroot/com.sap.portal.navigation.contentarea.default");
    jsonFWK.put("portalPath", cfg.getPortalPath());
    jsonFWK.put("navigationTarget", cfg.getLaunchedNode().getHashedName());
    String pageDescription = cfg.getPageDescription();
    if (cfg.isKMTempl() && pageDescription != null && !pageDescription.trim().isEmpty()) {
      jsonFWK.put("pageTitle", pageDescription);
    } else {
      jsonFWK.put("pageTitle", cfg.getPageTitle());
    }

    response.write("<script>FWK=" + jsonFWK.toJSONString() + "</script>");

    epResponse.deferScriptResource(MIMES_APP, "js/fwk.js");

    epResponse.deferComment("sven://kannengiesser");
  }

  void writeBody(IPortalComponentRequest request, IPortalComponentResponse response) {
    long start0 = System.currentTimeMillis();
    Config cfg = Config.getInstance(request);

    long start1 = System.currentTimeMillis();
    TemplateLoader loader = new FileTemplateLoader(cfg.getJadePath(), "UTF-8");
    JADE_CONFIGURATION.setTemplateLoader(loader);
    long stop1 = System.currentTimeMillis();

    try {
      long start2 = System.currentTimeMillis();
      JadeTemplate template = JADE_CONFIGURATION.getTemplate("body.jade");
      long stop2 = System.currentTimeMillis();

      long start3 = System.currentTimeMillis();
      JSONObject model = getModel(request);
      long stop3 = System.currentTimeMillis();

      Writer writer = response.getWriter();

      long start4 = System.currentTimeMillis();
      JADE_CONFIGURATION.renderTemplate(template, model, writer);

      long stop0 = System.currentTimeMillis();
      writer.write("\n\n<!-- " +
        "\nloader:   " + (stop1 - start1) + "ms" +
        "\ntemplate: " + (stop2 - start2) + "ms" +
        "\nmodel:    " + (stop3 - start3) + "ms" +
        "\nrender:   " + (stop0 - start4) + "ms" +
        "\nTOTAL:    " + (stop0 - start0) + "ms" +
        "\n-->\n\n");
    } catch (IOException e) {
      e.printStackTrace();
      response.write("Error: " + e.getMessage());
    }
  }

  public abstract JSONObject getModel(IPortalComponentRequest request);
}
