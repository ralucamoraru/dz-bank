package com.rwe.rcp.fwk.core;

import com.rwe.rcp.fwk.core.utils.PRTUtils;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.pom.IEvent;
import com.sapportals.portal.prt.runtime.PortalRuntime;

public class ContentComponent extends AbstractPortalComponent {

	@Override
	protected void doOnNodeReady(IPortalComponentRequest request, IEvent event) {
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		INavigationNode launchedNode = helperService.getCurrentLaunchNavNode(request);
		if (launchedNode != null) {
			String launchURL = launchedNode.getLaunchURL();
			if (launchURL != null && launchURL.startsWith("pcd:")) {
				PRTUtils.addChildNode(request, launchURL, "contentArea");
			}
		}
	}

	@Override
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		PRTUtils.includeChildNodes(request, response, "contentArea");
	}
}
