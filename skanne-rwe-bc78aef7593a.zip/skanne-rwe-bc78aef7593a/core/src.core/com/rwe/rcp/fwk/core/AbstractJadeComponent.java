package com.rwe.rcp.fwk.core;

import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentContext;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.resource.IResourceInformation;
import de.neuland.jade4j.Jade4J;
import de.neuland.jade4j.JadeConfiguration;
import de.neuland.jade4j.template.FileTemplateLoader;
import de.neuland.jade4j.template.JadeTemplate;
import de.neuland.jade4j.template.TemplateLoader;
import org.json.simple.JSONObject;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@SuppressWarnings("unchecked")
public abstract class AbstractJadeComponent extends AbstractPortalComponent {
  final static boolean PRETTY_PRINT = true;

  public final void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
    long start = System.currentTimeMillis();

    JadeConfiguration config = new JadeConfiguration();
    config.setTemplateLoader(getTemplateLoader(request));
    config.setPrettyPrint(PRETTY_PRINT);

    HttpServletResponse servletResponse = request.getServletResponse(true);
    try {
      JadeTemplate template = config.getTemplate(getTemplateName(request));
      JSONObject model = getEnhancedModel(request);

      PrintWriter writer = servletResponse.getWriter();
      Jade4J.render(template, model, writer);
      long stop = System.currentTimeMillis();
      writer.write("<!-- " + (stop - start) + "ms -->");
    } catch (IOException e) {
      e.printStackTrace();
      response.write("Error: " + e.getMessage());
    }
  }

  public final void doJson(IPortalComponentRequest request, IPortalComponentResponse response) {
    JSONObject model = getEnhancedModel(request);
    HttpServletResponse servletResponse = request.getServletResponse(true);
    try {
      PrintWriter writer = servletResponse.getWriter();
      servletResponse.addHeader("Content-Type", "application/json");
      model.writeJSONString(writer);
    } catch (IOException e) {
      e.printStackTrace();
      response.write("Error: " + e.getMessage());
    }
  }

  public abstract JSONObject getModel(IPortalComponentRequest request);

  private JSONObject getEnhancedModel(IPortalComponentRequest request) {
    JSONObject model = getModel(request);
    if (model == null) {
      model = new JSONObject();
    }

    IPortalComponentContext componentContext = request.getComponentContext();
    String applicationName = componentContext.getApplicationName();
    String title = componentContext.getProfile().getProperty("Title");
    if (title == null) {
      title = componentContext.getComponentName().substring(applicationName.length() + 1);
    }

    model.put("_title", title);
    model.put("_mimesPath", '/' + applicationName + '/');

    return model;
  }

  public String getTemplateName(IPortalComponentRequest request) {
    IPortalComponentContext componentContext = request.getComponentContext();
    String applicationName = componentContext.getApplicationName();
    String componentName = componentContext.getComponentName();
    return componentName.substring(applicationName.length() + 1);
  }

  public TemplateLoader getTemplateLoader(IPortalComponentRequest request) {
    return new FileTemplateLoader(getJadeFilePath(request, "jade/"), "UTF-8");
  }

  private String getJadeFilePath(IPortalComponentRequest request, String jadeFileName) {
    IResource resource = request.getResource(IResource.STATIC_PAGE, jadeFileName);
    IResourceInformation resourceInformation = resource.getResourceInformation();
    String source = resourceInformation.getSource();
    return source.replaceFirst("\\.html$", "");
  }

}
