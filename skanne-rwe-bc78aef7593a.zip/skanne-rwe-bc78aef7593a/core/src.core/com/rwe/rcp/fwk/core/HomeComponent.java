package com.rwe.rcp.fwk.core;

import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;

public class HomeComponent extends AbstractPortalComponent {

	@Override
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		// Note: Left blank on purpose!
	}

}
