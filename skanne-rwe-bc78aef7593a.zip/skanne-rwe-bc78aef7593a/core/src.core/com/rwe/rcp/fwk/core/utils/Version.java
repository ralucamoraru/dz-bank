package com.rwe.rcp.fwk.core.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

/**
 * This class is to be used as a static class only. The reason being is the versioning of resources like stylesheets and Javascript files,
 * such that we can always be sure that the end user loads the correct version of the corresponding file, even if there is an older version in
 * the user's browser cache.
 *
 * @author Sven Kannengiesser (SAP)
 * @version 2008-01-29-16-40
 */
public class Version {

	/**
	 * Please change this value with each change of any MIME resource of this portal archive!
	 *
	 * Tip: keep both this value and the 'Implementation-Version' from the METAINF.MF file in sync.
	 */
//	public static final String TIMESTAMP_STR = "2008-01-30-10-24";
	public static String TIMESTAMP_STR = new SimpleDateFormat("yyyy-MM-dd-HH-mm").format(new Date());
	static {
		String cn = (Version.class).getName().replace('.', '/') + ".class";
		String jar = (Version.class).getClassLoader().getResource(cn).toString();
		String version = null;
		if (jar.startsWith("jar:file:")) {
			int n = 9;
			if (jar.startsWith("jar:file:/") && jar.charAt(11) == ':')
				n = 10;
			String jarFilePath = jar.substring(n, jar.indexOf("!"));

			String path = jarFilePath;
			int privateLibPos = jarFilePath.lastIndexOf("/private/lib/");
			int libPos = jarFilePath.lastIndexOf("/lib/");
			if (privateLibPos > -1) {
				path = path.substring(0, privateLibPos);
			} else {
				path = path.substring(0, libPos);
			}
			path = path.concat("/META-INF/MANIFEST.MF");
			try {
				File file = new File(path);

				if (file != null) {
					InputStream is = new FileInputStream(file);
					Manifest mf = new Manifest(is);
					if (mf != null) {
						Attributes attr = mf.getMainAttributes();
						if (attr != null) {
							version = attr.getValue("Implementation-Version");
							if (version != null) {
								TIMESTAMP_STR = version;
							}
						}
					}
				}
			} catch (IOException e) {
			}
		}
	}

	/**
	 * Usage example: request.getResource(IResource.CSS, "mimes/cp.css?"+Version.TIMESTAMP)
	 */
	public static int TIMESTAMP = Math.abs(TIMESTAMP_STR.hashCode());
}
