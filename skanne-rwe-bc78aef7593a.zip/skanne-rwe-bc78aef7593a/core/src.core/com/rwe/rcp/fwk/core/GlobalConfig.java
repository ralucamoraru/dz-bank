package com.rwe.rcp.fwk.core;

public class GlobalConfig {

	private static GlobalConfig thiz = new GlobalConfig();
	private PortalMode mode = PortalMode.auto;
	private boolean force = false;

	private GlobalConfig() {
	}

	public static GlobalConfig getInstance() {
		return thiz;
	}

	public PortalMode getMode() {
		return mode;
	}

	public void setMode(PortalMode mode, boolean force) {
		if (force) {
			this.mode = mode;
			this.force = force;
		} else if (!thiz.force) {
			this.mode = mode;
		}
	}

	public boolean isForce() {
		return force;
	}

}
