package com.rwe.rcp.fwk.core;

public class PortalModeType {





}
