/**
 *
 */
package com.rwe.rcp.fwk.core;

import com.rwe.rcp.fwk.core.utils.NavNode;
import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.resource.IResourceInformation;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.portal.prt.session.IUserContext;

import javax.servlet.http.HttpServletRequest;
import java.util.Hashtable;
import java.util.Locale;


/**
 * @author D037963
 */
public class Config {
  private boolean isNoDesktop = false;
  private boolean isHome = false;
  private boolean isKMNav = false;
  private boolean isKMTempl = false;
  private boolean isAnonymousUser = false;
  private boolean isHtml5Fwk = true;
  @SuppressWarnings("rawtypes")
  private Hashtable environment = null;
  private INavigationNode selectedNode;
  private INavigationNode launchedNode;
  private INavigationNode contextNode;
  private INavigationNode personalizePortalNode;
  private NavigationNodes pathNodes;
  private NavigationNodes initialNodes;
  private String launchURL;
  private String navPath;
  private String portalPath;
  private String mimesPath;
  private String jsonPath;
  private String jadePath;
  private String pageTitle;
  private String pageDescription;
  private String codeLink;
  private String startRid;
  private String currentRid;
  private String navPanelStatus;
  private String firstName = "";
  private String lastName = "";
  private String[] supportedLanguages;
  private Locale locale;
  boolean isDebug = false;

  public Config(IPortalComponentRequest request) {
    Boolean fwkDebug = (Boolean) request.getComponentSession().getValue("fwkDebug");
    if (fwkDebug == null) {
      fwkDebug = Boolean.FALSE;
    }
    String fwkDebugParam = request.getParameter("fwkDebug");
    if (fwkDebugParam != null) {
      if (fwkDebugParam.equals("off") || fwkDebugParam.equals("false") || fwkDebugParam.equals("0")) {
        request.getComponentSession().removeValue("fwkDebug");
        fwkDebug = Boolean.FALSE;
      } else {
        request.getComponentSession().putValue("fwkDebug", Boolean.TRUE);
        fwkDebug = Boolean.TRUE;
      }
    }
    isDebug = fwkDebug.booleanValue();

    NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
    INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);

    environment = navHelperService.getEnvironment(request);

    isAnonymousUser = navHelperService.isAnonymousUser(request);
    if (!isAnonymousUser) {
      IUserContext user = request.getUser();
      firstName = user.getFirstName();
      lastName = user.getLastName();
    }

    selectedNode = navHelperService.getCurrentNavNode(request);
    contextNode = navHelperService.getCurrentContextNavNode(request);
    launchedNode = navHelperService.getCurrentLaunchNavNode(request);
    personalizePortalNode = navHelperService.getPersonalizePortalNode(request);
    pathNodes = NavNode.getPathNodes(request);
    initialNodes = navHelperService.getRealInitialNodes(request);

    HttpServletRequest servletRequest = request.getServletRequest();
    IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
    portalPath = aliasHelper.getPath(request).replaceFirst("\\\\/$", "");
//		isHtml5Fwk = portalPath.endsWith("/html5");
    portalPath = portalPath.replaceFirst("/login$", "").replaceFirst("/html5$", "");

    String requestUri = servletRequest.getRequestURI();
    if (!requestUri.endsWith("portallauncher.default")) {
      portalPath = requestUri;
      isNoDesktop = true;
    }

    String queryString = servletRequest.getQueryString();
    navPath = servletRequest.getRequestURL() + (queryString != null && !queryString.isEmpty() ? '?' + queryString : "");

    String webResourcePath = request.getWebResourcePath();
    mimesPath = webResourcePath + "/";

    jsonPath = getFilePath(request, "json/");
    jadePath = getFilePath(request, "jade/");

    locale = request.getLocale();
    String supportedLanguagesProp = request.getComponentContext().getProfile().getProperty("com.rwe.rcp.fwk.SupportedLanguages");
    if (supportedLanguagesProp != null) {
      supportedLanguages = supportedLanguagesProp.split(",");
    }

    if (launchedNode != null) {
      launchURL = launchedNode.getLaunchURL();

      if (NavNode.isInvisible(launchedNode)) {
        pageTitle = selectedNode.getTitle(locale);
        pageDescription = selectedNode.getDescription(locale);
      } else {
        pageTitle = launchedNode.getTitle(locale);
        pageDescription = launchedNode.getDescription(locale);
      }

      codeLink = (String) NavNode.getAttributeValue(launchedNode, "CodeLink");
      if (codeLink == null) {
        codeLink = "";
      }

      if (codeLink.equals("com.rwe.rcp.fwk.core.home")) {
        isHome = true;
      } else if (codeLink.equals("com.rwe.rcp.fwk.core.kmnav")) {
        isKMNav = true;
      } else if (codeLink.equals("com.rwe.rcp.fwk.core.kmtempl")) {
        isKMTempl = true;
      }

      String startRidParam = request.getParameter("startRid");
      if (startRidParam != null) {
        isKMNav = true;
        startRid = startRidParam;
        currentRid = request.getParameter("currentRid");
      } else if (isKMNav) {
        startRid = (String) NavNode.getAttributeValue(launchedNode, "com.rwe.rcp.fwk.StartRID");
        currentRid = (String) NavNode.getAttributeValue(launchedNode, "com.rwe.rcp.fwk.CurrentRID");
      }
      if (currentRid != null && currentRid.trim().isEmpty()) {
        currentRid = null;
      }

      navPanelStatus = (String) NavNode.getAttributeValue(launchedNode, "com.sap.portal.reserved.iview.NavPanelStatus");
    }
  }

  /**
   * Create and hang a Config object to the request.
   *
   * @param request
   * @return
   */
  public static Config getInstance(IPortalComponentRequest request) {
    HttpServletRequest servletRequest = request.getServletRequest();
    Config cfg = (Config) servletRequest.getAttribute("cfg");
    if (cfg == null) {
      cfg = new Config(request);
      servletRequest.setAttribute("cfg", cfg);
    }
    return cfg;
  }

  private String getFilePath(IPortalComponentRequest request, String fileName) {
    IResource resource = request.getResource(IResource.STATIC_PAGE, fileName);
    IResourceInformation resourceInformation = resource.getResourceInformation();
    String source = resourceInformation.getSource();
    return source.replaceFirst("\\.html$", "");
  }

  @SuppressWarnings("rawtypes")
  public Hashtable getEnvironment() {
    return environment;
  }

  public boolean isHome() {
    return isHome;
  }

  public boolean isKMNav() {
    return isKMNav;
  }

  public boolean isKMTempl() {
    return isKMTempl;
  }

  public boolean isAnonymousUser() {
    return isAnonymousUser;
  }

  public boolean isNoDesktop() {
    return isNoDesktop;
  }

  public boolean isHtml5Fwk() {
    return isHtml5Fwk;
  }

  public INavigationNode getSelectedNode() {
    return selectedNode;
  }

  public INavigationNode getLaunchedNode() {
    return launchedNode;
  }

  public INavigationNode getContextNode() {
    return contextNode;
  }

  public INavigationNode getPersonalizePortalNode() {
    return personalizePortalNode;
  }

  public NavigationNodes getPathNodes() {
    return pathNodes;
  }

  public NavigationNodes getInitialNodes() {
    return initialNodes;
  }

  public String getLaunchURL() {
    return launchURL;
  }

  public String getNavPath() {
    return navPath;
  }

  public String getPortalPath() {
    return portalPath;
  }

  public String getMimesPath() {
    return mimesPath;
  }

  public String getJsonPath() {
    return jsonPath;
  }

  public String getJadePath() {
    return jadePath;
  }

  public String getPageTitle() {
    return pageTitle;
  }

  public String getPageDescription() {
    return pageDescription;
  }

  public String getCodeLink() {
    return codeLink;
  }

  public Locale getLocale() {
    return locale;
  }

  public String[] getSupportedLanguages() {
    return supportedLanguages;
  }

  public String getStartRid() {
    return startRid;
  }

  public String getCurrentRid() {
    return currentRid;
  }

  public String getNavPanelStatus() {
    return navPanelStatus;
  }

  public boolean isDebug() {
    return isDebug;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }
}
