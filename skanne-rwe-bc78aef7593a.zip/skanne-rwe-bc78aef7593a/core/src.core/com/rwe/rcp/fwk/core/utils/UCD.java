package com.rwe.rcp.fwk.core.utils;

//import net.sf.json.parser.JSONParser;
//import net.sf.json.parser.ParseException;

//import com.sap.portal.directory.Constants;
//import com.sap.portal.ns.INamespaceDescriptor;
//import com.sap.portal.ns.INamespaceManager;
//import com.sap.portal.pcm.admin.IAdminBase;
//import com.sap.portal.pcm.admin.IAttributeSet;
//import com.sap.portal.pcm.admin.PcmConstants;
//import com.sap.portal.pcm.admin.ValidationException;
//import com.sapportals.portal.pcd.gl.IPcdAttribute;
//import com.sapportals.portal.pcd.gl.IPcdContext;
//import com.sapportals.portal.prt.jndisupport.InitialContext;


public class UCD {
//	private static final String NZ_ATTR_PREFIX = "com.nordzucker";
//	private static final String NZ = "com.nordzucker.employee.portal.framework";
//	private static final String P13N = "p13n";
//	private static final String NZ_P13N = NZ + '/' + P13N;
//
//	public static String getP13nAttribute(IPortalComponentRequest request, String key) {
//		return getP13nAttribute(request, request.getUser(), key);
//	}
//
//	public static String getP13nAttribute(IPortalComponentRequest request, IUser user, String key) {
//		String value = null;
//		try {
//			IAdminBase ucdAdminBase = getUcdAdminBase(request, user, NZ, P13N);
//			IAttributeSet attrSet = (IAttributeSet) ucdAdminBase.getImplementation(IAdminBase.ATTRIBUTE_SET);
//			value = attrSet.getAttribute(NZ_ATTR_PREFIX + '.' + key);
//		} catch (NamingException e) {
//		}
//		return value;
//	}
//
//	public static JSONObject getP13n(IPortalComponentRequest request) {
//		return getP13n(request, request.getUser());
//	}
//
//	public static JSONObject getP13n(IPortalComponentRequest request, IUser user) {
//		JSONObject json = new JSONObject();
//		try {
//			IAdminBase ucdAdminBase = getUcdAdminBase(request, user, NZ, P13N);
//			IAttributeSet attrSet = (IAttributeSet) ucdAdminBase.getImplementation(IAdminBase.ATTRIBUTE_SET);
////			JSONParser jp = new JSONParser();
//
//			Enumeration attributeIds = attrSet.getAttributeIds();
//			while (attributeIds.hasMoreElements()) {
//				String id = (String) attributeIds.nextElement();
//
//				if (id.startsWith(NZ_ATTR_PREFIX)) {
//					String attribute = attrSet.getAttribute(id);
//
////					try {
////						json.put(id.substring(NZ_ATTR_PREFIX.length() + 1), jp.parse(attribute));
////					} catch (ParseException e) {
//						json.put(id.substring(NZ_ATTR_PREFIX.length() + 1), attribute);
////					}
//				}
//			}
//		} catch (NamingException e) {
//		}
//		return json;
//	}
//
//	public static JSONObject setP13n(IPortalComponentRequest request, Map<String, String> attributes) {
//		return setP13n(request, request.getUser(), attributes);
//	}
//
//	public static JSONObject setP13n(IPortalComponentRequest request, IUser user, Map<String, String> attributes) {
//		JSONObject json = new JSONObject();
//		try {
//			IAdminBase ucdAdminBase = getUcdAdminBase(request, user, NZ, P13N);
//			IAttributeSet attrSet = (IAttributeSet) ucdAdminBase.getImplementation(IAdminBase.ATTRIBUTE_SET);
//
//			JSONArray jsonAttrs = new JSONArray();
//
//			for (Iterator<String> iterator = attributes.keySet().iterator(); iterator.hasNext();) {
//				String name = iterator.next();
//				String value = attributes.get(name);
//				attrSet.putAttribute(NZ_ATTR_PREFIX + '.' + name, value);
//				jsonAttrs.add(name);
//			}
//
//			try {
//				attrSet.save();
//			} catch (ValidationException e) {
//				json.put("ValidationException", getStacktraceAsString(e));
//			} catch (IOException e) {
//				json.put("IOException", getStacktraceAsString(e));
//			}
//
//			json.put("success", "true");
//			json.put("savedAttributes", jsonAttrs);
//		} catch (NamingException e) {
//			json.put("NamingException", getStacktraceAsString(e));
//		}
//		return json;
//	}
//
//	private static String getStacktraceAsString(Throwable e) {
//		StringWriter sw = new StringWriter();
//		PrintWriter pw = new PrintWriter(sw);
//		e.printStackTrace(pw);
//		return sw.toString();
//	}
//
//	public static JSONObject getAttributes(IAttributeSet attrSet) {
//		JSONObject json = new JSONObject();
////		JSONParser jp = new JSONParser();
//
//		Enumeration attributeIds = attrSet.getAttributeIds();
//		while (attributeIds.hasMoreElements()) {
//			String id = (String) attributeIds.nextElement();
//			attrSet.getAttribute(id);
//			if (id.startsWith(NZ_ATTR_PREFIX)) {
//				String attribute = attrSet.getAttribute(id);
//
////				try {
////					json.put(id.substring(NZ_ATTR_PREFIX.length() + 1), jp.parse(attribute));
////				} catch (ParseException e) {
//					json.put(id.substring(NZ_ATTR_PREFIX.length() + 1), attribute);
////				}
//			}
//		}
//
//		return json;
//	}
//
//	private static IPcdContext getUcdContext(IPortalComponentRequest request) throws NamingException {
//		Hashtable<Object, Object> env = new Hashtable<Object, Object>();
//		env.put(Context.INITIAL_CONTEXT_FACTORY, IPcdContext.UCD_INITIAL_CONTEXT_FACTORY);
//		env.put(Context.SECURITY_PRINCIPAL, request.getUser());
//		InitialContext ctx = new InitialContext(env);
//		return (IPcdContext) ctx.lookup("");
//	}
//
//	private static IAdminBase getUcdAdminBase(IPortalComponentRequest request, IUser user, String namespace, String name) throws NamingException {
//		if (!exists(request, namespace)) {
//			createNamespace(request, namespace);
//		}
//
//		if (user == null) {
//			user = request.getUser();
//		}
//
//		Hashtable<Object, Object> env = new Hashtable<Object, Object>();
//		env.put(Context.INITIAL_CONTEXT_FACTORY, IPcdContext.UCD_INITIAL_CONTEXT_FACTORY);
//		env.put(Context.SECURITY_PRINCIPAL, user);
//		InitialContext ctx = new InitialContext(env);
//		IPcdContext contextByNamespace = (IPcdContext) ctx.lookup(namespace);
//
//		contextByNamespace.addToEnvironment(PcmConstants.REQUESTED_ASPECT, PcmConstants.ASPECT_ADMINISTRATION);
//		contextByNamespace.addToEnvironment(PcmConstants.APPLY_ASPECTS_TO_CONTEXTS, PcmConstants.APPLY_ASPECTS_TO_CONTEXTS);
//		IAdminBase ucdAdminBase = null;
//		try {
//			ucdAdminBase = (IAdminBase) contextByNamespace.lookup(name);
//		} catch (NamingException e) {
//		}
//		if (ucdAdminBase == null) {
//			try {
//				contextByNamespace.createSubcontext(name);
//				ucdAdminBase = (IAdminBase) contextByNamespace.lookup(name);
//			} catch (NamingException e) {
//			}
//		}
//		return ucdAdminBase;
//	}
//
//	private static boolean exists(IPortalComponentRequest request, String namespace) {
//		try {
//			IPcdContext ucdContext = getUcdContext(request);
//			ucdContext.addToEnvironment(Constants.REQUESTED_ASPECT, IPcdAttribute.ASPECT_EXISTENCE);
//			Boolean exists = (Boolean) ucdContext.lookup(namespace);
//			return exists.booleanValue();
//		} catch (NamingException e) {
//			return false;
//		}
//	}
//
//	private static void createNamespace(IPortalComponentRequest request, String namespace) throws NamingException {
//		IPcdContext ucdContext = getUcdContext(request);
//		INamespaceManager namespaceManager = (INamespaceManager) PortalRuntime.getRuntimeResources().getService(INamespaceManager.KEY);
//		INamespaceDescriptor namespaceDescriptor = (INamespaceDescriptor) namespaceManager.instantiateDescriptor(namespace);
//		ucdContext.bind(namespace, namespaceDescriptor);
//		return;
//	}
}
