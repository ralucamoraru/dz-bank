package com.rwe.rcp.fwk.core;

import com.rwe.rcp.fwk.core.utils.NavNode;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.util.*;

//import com.sap.tc.logging.Location;

public class FrameworkIViewComponent extends AbstractFrameworkComponent {
//	private static Location LOCATION = Location.getLocation(FrameworkIViewComponent.class);

  public JSONObject getModel(IPortalComponentRequest request) {
    long start = System.currentTimeMillis();
    JSONObject model = new JSONObject();

    Config cfg = Config.getInstance(request);
    INavigationNode launchedNode = cfg.getLaunchedNode();

    putUser(cfg, model);
    putLanguages(cfg, model);
    putDockbar(cfg, model);
    putSystems(cfg, model);
    putTln(cfg, model);
    putPath(cfg, model);
    putDtn(cfg, model);
    putResourceBundle(cfg, model);

    model.put("pageTitle", cfg.getPageTitle());
    model.put("portalPath", cfg.getPortalPath());
    model.put("isNoDesktop", cfg.isNoDesktop());
    model.put("contentAreaPath", "/irj/go/portal/prtroot/com.sap.portal.navigation.contentarea.default");
    model.put("navigationTarget", launchedNode.getHashedName());

    if ("1".equals(request.getParameter("NavMode"))) {
      model.put("isContentOnly", true);
    }
    if (cfg.isHome()) {
      model.put("isHome", true);
    } else if (cfg.isKMNav()) {
      model.put("isKMNav", true);
      String startRid = cfg.getStartRid();
      String currentRid = cfg.getCurrentRid();
      model.put("kmnav", KMNavComponent.getKMNav(request, startRid, currentRid));
    } else if (cfg.isKMTempl()) {
      model.put("isKMTempl", true);
      String jadeRid = (String) NavNode.getAttributeValue(launchedNode, "com.rwe.rcp.fwk.JadeRID");
      model.put("kmtempl", KMTemplComponent.getKMTempl(request, jadeRid));
      String cssRid = (String) NavNode.getAttributeValue(launchedNode, "com.rwe.rcp.fwk.CssRID");
      if (cssRid != null) {
        EnhancedPortalResponse epResponse = EnhancedPortalResponse.getInstance(request);
        epResponse.includeLink("stylesheet", "/irj/go/km/docs" + cssRid.trim());
      }
      String pageDescription = cfg.getPageDescription();
      if (pageDescription != null && !pageDescription.trim().isEmpty()) {
        model.put("pageTitle", pageDescription);
      }
    }

    String navPanelStatus = cfg.getNavPanelStatus();
    if ("Close".equals(navPanelStatus)) {
      model.put("isPanelPinned", false);
    } else if ("Always Close".equals(navPanelStatus)) {
      model.put("isNoPanel", true);
    } else {
      model.put("isPanelPinned", true);
    }

    long stop = System.currentTimeMillis();
    model.put("timings", stop - start);
    return model;
  }

  private void putUser(Config cfg, JSONObject model) {
    JSONObject jsonUser = new JSONObject();
    jsonUser.put("firstName", cfg.getFirstName());
    jsonUser.put("lastName", cfg.getLastName());
    model.put("user", jsonUser);
  }

  private void putLanguages(Config cfg, JSONObject model) {
    JSONObject jsonLanguages = new JSONObject();

    Locale sourceLocale = cfg.getLocale();
    JSONObject jsonSource = new JSONObject();
    jsonSource.put("iso3", sourceLocale.getISO3Language());
    jsonSource.put("title", sourceLocale.getDisplayLanguage(sourceLocale));
    jsonLanguages.put("source", jsonSource);
    JSONArray jsonTargets = new JSONArray();

    String[] supportedLanguages = cfg.getSupportedLanguages();
    if (supportedLanguages != null) {
      for (int i = 0; i < supportedLanguages.length; i++) {
        Locale targetLocale = new Locale(supportedLanguages[i]);

        if (targetLocale.equals(sourceLocale)) continue;
        JSONObject jsonTarget = new JSONObject();
        jsonTarget.put("iso3", targetLocale.getISO3Language());
        jsonTarget.put("title", targetLocale.getDisplayLanguage(targetLocale) + " - " + targetLocale.getDisplayLanguage(sourceLocale));
        jsonTarget.put("lang", targetLocale.getLanguage());
        jsonTargets.add(jsonTarget);
      }
    }

    jsonLanguages.put("targets", jsonTargets);
    model.put("languages", jsonLanguages);
  }

  private void putDockbar(Config cfg, JSONObject model) {
    JSONParser jp = new JSONParser();
    try {
      Object jsonDockbar = jp.parse(new FileReader(cfg.getJsonPath() + "dockbar.json"));
      if (jsonDockbar != null) {
        model.put("dockbar", jsonDockbar);
      }
    } catch (IOException e) {
    } catch (ParseException e) {
    }
  }

  private void putSystems(Config cfg, JSONObject model) {
    JSONParser jp = new JSONParser();
    try {
      Object jsonSystems = jp.parse(new FileReader(cfg.getJsonPath() + "systems.json"));
      if (jsonSystems != null) {
        model.put("systems", jsonSystems);
      }
    } catch (IOException e) {
    } catch (ParseException e) {
    }
  }

  private void putTln(Config cfg, JSONObject model) {
    JSONArray jsonTln = new JSONArray();

    NavigationNodes initialNodes = cfg.getInitialNodes();
    NavigationNodes pathNodes = cfg.getPathNodes();
    String portalPath = cfg.getPortalPath();
    Locale locale = cfg.getLocale();
    if (initialNodes != null && initialNodes.size() > 0) {
      for (Iterator<INavigationNode> it = initialNodes.iterator(); it.hasNext(); ) {
        INavigationNode node = it.next();

        String target = node.getHashedName();
        String id = NavNode.getId(node);
        String title = NavNode.getTitle(node, locale);
        boolean isInPath = NavNode.isInPath(node, pathNodes);
        String codeLink = (String) NavNode.getAttributeValue(node, "CodeLink");

        JSONObject jsonNode = new JSONObject();
        jsonNode.put("id", id);
        jsonNode.put("title", title);
        jsonNode.put("href", portalPath + "?DrillDownLevel=3&NavigationTarget=" + target);
        if (isInPath) {
          jsonNode.put("isSelected", isInPath);
        }
        if ("com.rwe.rcp.fwk.core.home".equals(codeLink)) {
          jsonNode.put("isHome", true);
        }
        jsonTln.add(jsonNode);
      }

      model.put("tln", jsonTln);
    }
  }

  private void putPath(Config cfg, JSONObject model) {
    JSONArray jsonPath = new JSONArray();

    NavigationNodes pathNodes = cfg.getPathNodes();
    String portalPath = cfg.getPortalPath();
    Locale locale = cfg.getLocale();

    for (Iterator<INavigationNode> it = pathNodes.iterator(); it.hasNext(); ) {
      INavigationNode node = it.next();

      if (it.hasNext()) { // add all but last one into jsonPath
        String target = node.getHashedName();
        String id = NavNode.getId(node);
        String title = NavNode.getTitle(node, locale);

        JSONObject jsonNode = new JSONObject();
        jsonNode.put("id", id);
        jsonNode.put("title", title);
        jsonNode.put("href", portalPath + "?DrillDownLevel=3&NavigationTarget=" + target);
        jsonPath.add(jsonNode);
      }
    }

    model.put("path", jsonPath);
  }

  private void putDtn(Config cfg, JSONObject model) {
    JSONArray jsonDtn = new JSONArray();

    NavigationNodes pathNodes = cfg.getPathNodes();
    String portalPath = cfg.getPortalPath();
    Locale locale = cfg.getLocale();
    Hashtable environment = cfg.getEnvironment();

    if (!pathNodes.isEmpty()) {
      INavigationNode firstNode = (INavigationNode) pathNodes.get(0);
      putDtnLevel(firstNode, pathNodes, environment, locale, portalPath, jsonDtn);
    }

    model.put("dtn", jsonDtn);
  }

  private void putDtnLevel(INavigationNode startNode, NavigationNodes pathNodes, Hashtable environment, Locale locale, String portalPath, JSONArray list) {
    NavigationNodes childNodes = NavNode.getChildren(startNode, environment);

    for (Iterator<INavigationNode> it = childNodes.iterator(); it.hasNext(); ) {
      INavigationNode node = it.next();

      String target = node.getHashedName();
      String id = NavNode.getId(node);
      String title = NavNode.getTitle(node, locale);
      boolean hasChildren = NavNode.hasChildren(node, environment);
      boolean isInPath = NavNode.isInPath(node, pathNodes);
      boolean isSelected = NavNode.isLastInPath(node, pathNodes);

      JSONObject jsonNode = new JSONObject();
      jsonNode.put("id", id);
      jsonNode.put("title", title);
      jsonNode.put("href", portalPath + "?DrillDownLevel=3&NavigationTarget=" + target);
      if (isInPath) {
        jsonNode.put("isInPath", true);
      }
      if (isSelected) {
        jsonNode.put("isSelected", true);
      }
      int mode = node.getShowType();
      if (mode > 0) {
        jsonNode.put("mode", mode);
        jsonNode.put("target", target);
        jsonNode.put("winName", NavNode.getWindowName(node));
        jsonNode.put("winFeatures", NavNode.getWindowFeatures(node));
      }

      if (hasChildren) {
        JSONArray jsonList = new JSONArray();
        putDtnLevel(node, pathNodes, environment, locale, portalPath, jsonList);
        jsonNode.put("list", jsonList);
      }

      list.add(jsonNode);
    }
  }

  public void putResourceBundle(Config cfg, JSONObject model) {
    ResourceBundle resourceBundle = ResourceBundle.getBundle("rb", cfg.getLocale());
    JSONObject rb = new JSONObject();
    Set<String> keySet = resourceBundle.keySet();
    for (String key : keySet) {
      String value = resourceBundle.getString(key);
      rb.put(key, value);
    }
    model.put("rb", rb);
  }

}
