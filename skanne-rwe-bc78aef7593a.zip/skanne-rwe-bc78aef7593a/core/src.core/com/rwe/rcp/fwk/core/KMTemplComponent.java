package com.rwe.rcp.fwk.core;

import com.rwe.rcp.fwk.core.utils.KMReaderTemplateLoader;
import com.sapconsulting.portal.utils.html.EnhancedPortalResponse;
import com.sapportals.portal.prt.component.IPortalComponentProfile;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import de.neuland.jade4j.filter.MarkdownFilter;
import de.neuland.jade4j.template.JadeTemplate;
import org.json.simple.JSONObject;

import java.io.IOException;
import java.io.StringWriter;

public class KMTemplComponent extends AbstractFrameworkComponent {

  public JSONObject getModel(IPortalComponentRequest request) {
    IPortalComponentProfile profile = request.getComponentContext().getProfile();
    String templateName = profile.getProperty("com.rwe.rcp.fwk.JadeRID");
    String cssRid =  profile.getProperty("com.rwe.rcp.fwk.CssRID");

    JSONObject model = new JSONObject();
    model.put("isNoDesktop", true);
    model.put("isContentOnly", true);
    model.put("isKMTempl", true);
    model.put("kmtempl", KMTemplComponent.getKMTempl(request, templateName));

    if (cssRid != null) {
      EnhancedPortalResponse epResponse = EnhancedPortalResponse.getInstance(request);
      epResponse.includeLink("stylesheet", "/irj/go/km/docs" + cssRid.trim());
    }
    return model;
  }

  public static String getKMTempl(IPortalComponentRequest request, String jadeRid) {
    long start = System.currentTimeMillis();

    String baseRid = jadeRid.substring(0, jadeRid.lastIndexOf("/")+1);
    String name = jadeRid.substring(jadeRid.lastIndexOf("/")+1);

    JADE_CONFIGURATION.setTemplateLoader(new KMReaderTemplateLoader(baseRid, request.getLocale()));

    try {
      JadeTemplate template = JADE_CONFIGURATION.getTemplate(name);

      JSONObject model = new JSONObject();
      model.put("firstName", request.getUser().getFirstName());
      model.put("lastName", request.getUser().getLastName());
      model.put("baseRid", baseRid);
      model.put("basePath", "/irj/go/km/docs" + baseRid);

      StringWriter writer = new StringWriter();

      JADE_CONFIGURATION.renderTemplate(template, model, writer);

      long stop = System.currentTimeMillis();
      writer.write("<!-- " + (stop - start) + "ms -->");

      return writer.toString();
    } catch (IOException e) {
      return "Error: " + e.getMessage();
    }
  }
}
