package com.uit.portal.bereichsseiten;
 
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.NamingException;

import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sap.portal.resource.repository.IResourceRepositoryService;
import com.sap.portal.resource.repository.exceptions.InvalidResourcePathException;
import com.sap.portal.resource.repository.exceptions.ResourceNotFoundException;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;


/**
 * 
 * @author Raluca Moraru
 * ralucamoraru@gmail.com / +49 176 64718145
 *
 */

public class BereichsseiteComp extends AbstractPortalComponent
{
	public String portalPath = "";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		this.portalPath = aliasHelper.getPath(request);
		this.renderArea(request, response);		
	//	this.getContactHTML(request, response);
		//String BACKEND_SYSTEM_ALIAS = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.SystemAlias");
		// all necessary rendering is done in the JSP
		//response.include(request, request.getResource(IResource.JSP, "jsp/sitemap.jsp"));
		response.include(request, request.getResource(IResource.CSS, "css/uit_area.css"));		
	}

	public void renderArea(IPortalComponentRequest request, IPortalComponentResponse response){
		
		IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		
		Hashtable environment = helperService.getEnvironment(request);
		
		INavigationNode node = null;
		try {
			node = helperService.getCurrentLaunchNavNode(request);	
			INavigationNode node1 = helperService.getCurrentNavNode(request);
			INavigationNode node2 = helperService.getCurrentLaunchNavNode(request);
			response.write("<script>console.log(\"///NODE/// Name: "+node.getName()+" NODE 1: "+node1.getName()+" NODE 2: "+node2.getName()+"\");</script>");
			String parentNodeName = navService.getNavNodeParentName(environment, node.getName());
			INavigationNode parentNode = navService.getNode(environment, parentNodeName);
			response.write("<script>console.log(\"///Parent Node/// Name: "+parentNodeName+" and Node Name: "+parentNode.getName()+"\");</script>");
			//get parent Node with merged
			NavigationNodes xNodes = helperService.getNavNodesListForTarget(request, parentNode);
			String pr = "";
			Iterator ix = xNodes.iterator();
			boolean found = false;
			while(ix.hasNext() && !found){
				INavigationNode xn = (INavigationNode)ix.next();
				String xName = xn.getName();
				if(xName.indexOf(parentNodeName) >=0){
					parentNode = navService.getNode(environment, xName);
					found=true;
				}	
			}
			response.write("<script>console.log(\"///AFTER MERGE Parent Node/// Name: "+parentNode.getName()+"\");</script>");
			boolean hasSubareas = this.hasSubareas(parentNode, environment);
			
			//response.write("<div class=\"big_div\" width=\"80%\">");
			response.write("<table width='100%'>");
			
			String areaTitle = node.getTitle(new Locale("de"));
			String areaDescription = node.getDescription(new Locale("de"));
			String icon = request.getComponentContext().getProfile().getProperty("com.uit.portal.areaIcon");
			IResource resource = resourceRepository.getResource(icon, IResource.IMAGE, false);
			String iconPath = resource.getResourceInformation().getURL(request);
			NavigationNodes children = parentNode.getChildrenWithInivisible(environment);
			Iterator iter = children.iterator();
			
			boolean hasLink = this.hasLinks(children, node, environment);
			
			int count = 1;
			boolean initial = false;

			if(hasSubareas && hasLink){
				
				response.write("<tr><td style='vertical-align:top;width:40%;'>");
				response.write("<div class='area'>");
				response.write("<div class='area_img'>");
				response.write("<img src='" + iconPath + "'></img>");
				response.write("</div>");
				response.write("<div class='area_content'>");
				response.write("<h2>" + areaTitle + "</h2>");
				response.write("<p>" + areaDescription + "</p>");
				while(iter.hasNext()){
					INavigationNode kid = (INavigationNode)iter.next();
					String name = kid.getName();	
					
					//render links that are not folders
					if(!name.equalsIgnoreCase(node.getName()) && !kid.hasChildren(environment) && !this.isAreaPage(kid)){
						initial = true;
						response.write("<div class='subarea_content'>");
						response.write("<a href='" + this.getHref(kid, this.portalPath, null, null, null) + "'>" + kid.getTitle(new Locale("de"))+ "</a>");
						response.write("<p>" + kid.getDescription(new Locale("de")) + "</p>");
						response.write("</div>");
					}				
				}
				count++;
				response.write("</div>");
				response.write("</div>");
				response.write("</td>");
			}
			else if(!hasSubareas && hasLink) { 
				response.write("<tr><td style='vertical-align:top;width:80%;'>");
				response.write("<div class='area'>");
				response.write("<div class='area_img'>");
				response.write("<img src='" + iconPath + "'></img>");
				response.write("</div>");
				response.write("<div class='area_content'>");
				response.write("<h3>" + areaTitle + "</h3>");
				//response.write("<p>" + areaDescription + "</p>");
				while(iter.hasNext()){
					INavigationNode kid = (INavigationNode)iter.next();
					String name = kid.getName();	
					
					//render links that are not folders
					if(!name.equalsIgnoreCase(node.getName()) && !kid.hasChildren(environment) && !this.isAreaPage(kid)){
						initial = true;
						response.write("<div class='subarea_content'>");
						response.write("<a href='" + this.getHref(kid, this.portalPath, null, null, null) + "'>" + kid.getTitle(new Locale("de"))+ "</a>");
						response.write("<p>" + kid.getDescription(new Locale("de")) + "</p>");
						response.write("</div>");
					}				
				}
				count++;
				response.write("</div>");
				response.write("</div>");
				response.write("</td>");	
				response.write("<td style='vertical-align:top;width:5%;'></td>");
				response.write("<td style=\"vertical-align:top;\"><div class='contact'>");
				
				IResource contactHtml = this.getContactHTML(request, response);
				String contactAwd = this.getContactAwd(request, response);
				if(contactAwd != null && !contactAwd.equals("")){
					response.write("<iframe width='auto' height='auto' src='"+ contactAwd +"'></iframe>");	
				}else{
					if(contactHtml != null)
						response.include(request, contactHtml);
				}
				response.write("</div></td>");
				response.write("</tr>");	
			}


			if (hasSubareas){
				NavigationNodes subAreas = this.getSubareas(parentNode, environment);
				iter = subAreas.iterator();
				
				while(iter.hasNext()){
					INavigationNode sub = (INavigationNode)iter.next();
					String href = this.getHref(sub, this.portalPath, null, null, null);
					String title = sub.getTitle(new Locale("de"));
					String description = sub.getDescription(new Locale("de"));
					String iconConfig = sub.getAttributeValue("com.uit.portal.areaIcon").toString();
					String urlBereich = sub.getAttributeValue("com.uit.portal.URLBereichsseite").toString();
					String fullUrlBereich = this.portalPath + "?NavigationTarget=" + urlBereich;
					IResource res = resourceRepository.getResource(iconConfig, IResource.IMAGE, false);
					String path = res.getResourceInformation().getURL(request);

					if(count % 2 == 1){
						response.write("<tr><td style='vertical-align:top;width:40%;'>");
						response.write("<div class='area'>");
						response.write("<div class='area_img'>");
						response.write("<img src='" + path + "'></img>");
						response.write("</div>");
						response.write("<div class='area_content'>");
						if(urlBereich != null && !urlBereich.equals("")){
							response.write("<a href='" + fullUrlBereich + "' class='areaLink'><h2>" + title + "</h2></a>");
							
						}
						else
							response.write("<a href='" + href + "' class='areaLink'><h2>" + title + "</h2></a>");
							response.write("<p>" + description + "</p>");
							response.write("</div></div>");
							response.write("</td>");
					}else{
						response.write("<td style='vertical-align:top;width:40%;'>");
						response.write("<div class='area'>");
						response.write("<div class='area_img'>");
						response.write("<img src='" + path + "'></img>");
						response.write("</div>");
						response.write("<div class='area_content'>");
						if(urlBereich != null && !urlBereich.equals("")){
							response.write("<a href='" + fullUrlBereich + "' class='areaLink'><h2>" + title + "</h2></a>");
							response.write("<script>console.log(\"URL Bereich: \"+" + fullUrlBereich + ");</script>");
						}
						else
							response.write("<a href='" + href + "' class='areaLink'><h2>" + title + "</h2></a>");
						response.write("<p>" + description + "</p>");
						response.write("</div></div>");
						response.write("</td>");
						if (count == 2){
							response.write("<td style=\"vertical-align:top;\"><div class='contact'>");
							IResource contactHtml = this.getContactHTML(request, response);
							
							String contactAwd = this.getContactAwd(request, response);
							if(contactAwd != null && !contactAwd.equals("")){
								response.write("<iframe width='auto' height='auto' src='"+ contactAwd +"'></iframe>");		
							}else{
								if(contactHtml != null)
									response.include(request, contactHtml);
							}
							response.write("</div></td>");							
						}
						response.write("</tr>");
					}
					count++;					
				}
				if (count == 2){
					response.write("<td style=\"vertical-align:top;\"><div class='contact'>");
					IResource contactHtml = this.getContactHTML(request, response);
					String contactAwd = this.getContactAwd(request, response);
					if(contactAwd != null && !contactAwd.equals("")){
						response.write("<iframe width='auto' height='auto' src='"+ contactAwd +"'></iframe>");		
					}else{
						if(contactHtml != null)
							response.include(request, contactHtml);
					}
					response.write("</div></td>");		
					response.write("</tr>");
				}
				
			}

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidResourcePathException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		
	}
	
	public boolean hasLinks(NavigationNodes children, INavigationNode node, Hashtable environment){
		boolean hasLinks = false;
		Iterator iter = children.iterator();
		while(iter.hasNext()){
			INavigationNode kid = (INavigationNode)iter.next();
			String name = kid.getName();	
			
			//render links that are not folders
			try {
				if(!name.equalsIgnoreCase(node.getName()) && !kid.hasChildren(environment) && !this.isAreaPage(kid)){	
					hasLinks = true;	
				}
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return hasLinks;
	}
	
	public IResource getContactHTML(IPortalComponentRequest request, IPortalComponentResponse response){
		IResource resource = null;
		//response.write("<script>alert(\"ACHTUNG!!\");</script>");
		IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
		String fileLoc = request.getComponentContext().getProfile().getProperty("com.uit.portal.areaContact");
		try {
			resource = resourceRepository.getResource(fileLoc, IResource.STATIC_PAGE, false);
			//response.include(request, resource);
			
			String content = resource.getResourceInformation().getSource();
			//response.write("we have content: "+content);
		} catch (ResourceNotFoundException e) {
			response.write("Contact error");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvalidResourcePathException e) {
			// TODO Auto-generated catch block
			response.write("Contact error");
			e.printStackTrace();
		}
		
		return resource;
	}
	
	public String getContactAwd(IPortalComponentRequest request, IPortalComponentResponse response){
		String anwendung = request.getComponentContext().getProfile().getProperty("com.uit.portal.areaContactWD");		
		return anwendung;
	}
	
	public String getMergedParentNode(INavigationNode parent, Hashtable environment){
		String ret = "";
		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		try {
			NavigationNodes initialNodes = navService.getInitialNodes(environment);
			Iterator iter = initialNodes.iterator();
			
			while (iter.hasNext()){
				INavigationNode itNode = (INavigationNode)iter.next();
			}
				
			
				
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ret;
	}
	
	public void writeAreaContent(IPortalComponentRequest request, IPortalComponentResponse response){
/*		response.write("<div class='area'>");
		response.write("<div class='area_img'>");
		response.write("<img src='" + iconPath + "'></img>");
		response.write("</div>");
		response.write("<div class='area_content'>");
		response.write("<h2>" + areaTitle + "</h2>");
		response.write("<p>" + areaDescription + "</p>");
		response.write("</div>");
		response.write("</div>");*/
	}
	
	public void writeSubAreaContent(IPortalComponentRequest request, IPortalComponentResponse response){
/*		response.write("<div class='area'>");
		response.write("<div class='area_img'>");
		response.write("<img src='" + iconPath + "'></img>");
		response.write("</div>");
		response.write("<div class='area_content'>");
		response.write("<h2>" + areaTitle + "</h2>");
		response.write("<p>" + areaDescription + "</p>");
		response.write("</div>");
		response.write("</div>");*/
	}	
	
	private boolean hasSubareas(INavigationNode node, Hashtable environment){
		boolean hasSub = false;
		try {
			NavigationNodes children = node.getChildrenWithInivisible(environment);
			Iterator iter = children.iterator();
			
			while(iter.hasNext()){
				INavigationNode kid = (INavigationNode)iter.next();
				if (kid.hasChildren(environment)){
					Iterator it = kid.getChildrenWithInivisible(environment).iterator();
					while (it.hasNext()) {
						INavigationNode subKid = (INavigationNode)it.next();
						
						try {
							String isArea = subKid.getAttributeValue("com.uit.portal.istBereich").toString();
							if (isArea.equalsIgnoreCase("true")){
								hasSub = true;
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						
					}
				}
					
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return hasSub;
		}		
		return hasSub;
	}
	
	private boolean isAreaPage(INavigationNode node){
		boolean result = false;
		try {
			String isArea = node.getAttributeValue("com.uit.portal.istBereich").toString();
			if (isArea.equalsIgnoreCase("true")){
				result = true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
				
		return result;
	}
	
	private NavigationNodes getSubareas(INavigationNode node, Hashtable environment){
		NavigationNodes subAreas = new NavigationNodes();
		try {
			NavigationNodes children = node.getChildrenWithInivisible(environment);
			Iterator iter = children.iterator();
			
			while(iter.hasNext()){
				INavigationNode kid = (INavigationNode)iter.next();
				if (kid.hasChildren(environment)){
					Iterator it = kid.getChildrenWithInivisible(environment).iterator();
					while (it.hasNext()) {
						INavigationNode subKid = (INavigationNode)it.next();
						
						try {
							String isArea = subKid.getAttributeValue("com.uit.portal.istBereich").toString();
							if (isArea.equalsIgnoreCase("true")){
								subAreas.add(subKid);
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						
					}
				}
					
			}
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return subAreas;
		}		
		return subAreas;
	}
	
	private String getHref(INavigationNode node, String portalPath, String quickLink1, String quickLink2, String quickLink3) {
		if (quickLink1 != null) {
			if (quickLink2 == null) {
				return portalPath + '/' + quickLink1;
			} else if (quickLink3 == null) {
				return portalPath + '/' + quickLink1 + '/' + quickLink2;
			} else {
				return portalPath + '/' + quickLink1 + '/' + quickLink2 + '/' + quickLink3;
			}
		}
		return portalPath + "?NavigationTarget=" + node.getHashedName();
	}
}