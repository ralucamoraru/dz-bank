package com.uit.portal.bereichsseiten;
 
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;


/**
 *  
 * @author Raluca Moraru 
 * ralucamoraru@gmail.com / +49 176 64718145
 *
 */
public class TestComp extends AbstractPortalComponent
{
   
    /**
     * 
     */
    public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) 
    {     	
    	try {	    		
    		response.write("<div> Write something in the response. </div>");	  		
    	} catch (Exception e) {
	    
    	}
     	
    }
   	
}