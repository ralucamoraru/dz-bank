'use strict';

module.exports = function(grunt, options){

  return {
      options: {
      banner: '<%= banner %>',
      report: 'min',
      keepSpecialComments: 0
    },
    dist: {
      expand: true,
      cwd: '<%= defaults.tmp %>/styles/',
      src: ['**/*.css'],
      dest: '<%= defaults.tmp %>/styles/'
    }
  }
}