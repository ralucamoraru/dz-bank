'use strict';

module.exports = function(grunt, options){

	return {
    // Test settings
    unit: {
      configFile: 'test/karma.conf.js',
      singleRun: true
    }
  }
}