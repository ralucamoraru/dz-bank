'use strict';

module.exports = function(grunt, options){

  return {
    validation: {
        options: {
            reset: grunt.option('reset') || false,
            stoponerror: false,
            remotePath: 'http://decodize.com/',
            remoteFiles: ['html/moving-from-wordpress-to-octopress/', 'css/site-preloading-methods/']
        },
        files: {
            src: ['<%= defaults.tmp %>/*.html']
        }
    }
  }
}