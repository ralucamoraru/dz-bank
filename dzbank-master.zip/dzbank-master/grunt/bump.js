'use strict';

module.exports = function(grunt, options){

	return {
    options: {
      files: ['package.json'],
      commitMessage: 'Release v%VERSION%',
      commitFiles: ['-a'],
      tagName: 'v%VERSION%',
      pushTo: '<%= pkg.repository.url %>'
    }
	}
}