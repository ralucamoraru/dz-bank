'use strict';

module.exports = function(grunt, options){

  return {
    vendor: {
      src: [

        'bower_components/jquery/dist/jquery.js',
        // 'bower_components/jquery-ui/ui/core.js',
        'bower_components/jquery-ui/ui/widget.js',
        // 'bower_components/jquery-ui/ui/position.js',
        // 'bower_components/jquery-ui/ui/autocomplete.js',
        // 'bower_components/jquery-ui/ui/menu.js',
        // 'bower_components/jquery-ui/ui/effect.js',
        // 'bower_components/jquery-ui/ui/effect-blind.js',
        // 'bower_components/jquery-ui/ui/effect-bounce.js',
        // 'bower_components/jquery-ui/ui/effect-clip.js',
        // 'bower_components/jquery-ui/ui/effect-drop.js',
        // 'bower_components/jquery-ui/ui/effect-explode.js',
        // 'bower_components/jquery-ui/ui/effect-fade.js',
        // 'bower_components/jquery-ui/ui/effect-fold.js',
        // 'bower_components/jquery-ui/ui/effect-highlight.js',
        // 'bower_components/jquery-ui/ui/effect-puff.js',
        // 'bower_components/jquery-ui/ui/effect-pulsate.js',
        // 'bower_components/jquery-ui/ui/effect-scale.js',
        // 'bower_components/jquery-ui/ui/effect-shake.js',
        // 'bower_components/jquery-ui/ui/effect-size.js',
        // 'bower_components/jquery-ui/ui/effect-slide.js',
        // 'bower_components/jquery-ui/ui/effect-transfer.js',

        'bower_components/jquery-throttle-debounce/jquery.ba-throttle-debounce.js',
        'bower_components/matchHeight/jquery.matchHeight.js',
        // 'bower_components/imagesloaded/imagesloaded.pkgd.js',

        // 'bower_components/bootstrap-less/js/affix.js',
        // 'bower_components/bootstrap-less/js/alert.js',
        'bower_components/bootstrap-less/js/button.js',
        'bower_components/bootstrap-less/js/carousel.js',
        'bower_components/bootstrap-less/js/collapse.js',
        'bower_components/bootstrap-less/js/dropdown.js',
        'bower_components/bootstrap-less/js/modal.js',
        'bower_components/bootstrap-less/js/tooltip.js',
        'bower_components/bootstrap-less/js/popover.js',
        // 'bower_components/bootstrap-less/js/scrollspy.js',
        'bower_components/bootstrap-less/js/tab.js',
        'bower_components/bootstrap-less/js/transition.js',

        // 'bower_components/typeahead.js/dist/typeahead.jquery.js',
        'bower_components/jquery-selectboxit/src/javascripts/jquery.selectBoxIt.js',
        'bower_components/autogrow-textarea/jquery.autogrowtextarea.js',
        'bower_components/Chart.js/dist/Chart.bundle.js',
        'bower_components/nouislider/distribute/nouislider.js'
      ],
      dest: '<%= defaults.tmp %>/assets/scripts/vendor.js'
    },
    polyfills: {
      src: [
        // 'bower_components/html5shiv/dist/html5shiv.js',
        // 'bower_components/respond/dest/respond.src.js',
        'bower_components/picturefill/dist/picturefill.js'
      ],
      dest: '<%= defaults.tmp %>/assets/scripts/polyfills.js'
    },
    main: {
      src: [
        'src/assets/scripts/main.js',
        'src/assets/scripts/components/**/*.js',
        'src/assets/scripts/applications/**/*.js',
      ],
      dest: '<%= defaults.tmp %>/assets/scripts/main.js'
    }
  }
}