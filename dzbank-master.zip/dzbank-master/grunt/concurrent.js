// 'use strict';

// module.exports = function(grunt, options){

//   return {
//     target: ['jekyll:server_' + global.globals.site, 'watch'],
//     options: {
//       logConcurrentOutput: true
//     }
//   }
// }