
'use strict';

module.exports = function(grunt, options){

  return {   
    options: {
      browsers: ['last 3 version']
    },
    css: {
      src: [
        '<%= defaults.tmp %>/styles/*.css'
      ]
    }
  }
}