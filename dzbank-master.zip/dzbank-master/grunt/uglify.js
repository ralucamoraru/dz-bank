'use strict';

module.exports = function(grunt, options){
  return {
    options: {
      mangle: false,
      banner: '<%= banner %>',
      stripBanners: true,
      report: 'min'
    },
    dist: {
      files: {
        '<%= defaults.tmp %>/assets/scripts/main.js': '<%= concat.main.dest %>',
        '<%= defaults.tmp %>/assets/scripts/vendor.js': '<%= concat.vendor.dest %>',
        '<%= defaults.tmp %>/assets/scripts/polyfills.js': '<%= concat.polyfills.dest %>'
      }
    }
  }
}