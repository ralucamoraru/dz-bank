'use strict';

module.exports = function(grunt, options){

  return {
    less: {
      files: '<%= defaults.src %>/assets/styles/less/**/*',
      tasks: ['less', 'autoprefixer']
    },
    js: {
      files: [
        '<%= defaults.src %>/assets/scripts/**/*.js'
      ],
      tasks: ['jshint', 'concat']
    },
    ejs: {
        files: [
          '<%= defaults.src %>/ejs/**/*.ejs'
        ],
        tasks: ['ejs:dev']
    },
    images: {
      files: [
        '<%= defaults.src %>/images/**/*',
        '<%= defaults.src %>/assets/images/**/*'
      ],
      tasks: ['copy:images']
    },
    testdata: {
      files: [
        '<%= defaults.src %>/testdata/**/*'
      ],
      tasks: ['copy:testdata']
    },
    api: {
      files: [
        '<%= defaults.src %>/api/**/*'
      ],
      tasks: ['copy:api']
    },
    options: {
      livereload: true
    }
  }
}