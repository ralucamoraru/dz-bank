'use strict';

module.exports = function(grunt, options){

  return {
    server: {
      options: {
        livereload: true,
        port: '<%= defaults.port %>',
        base: '<%= defaults.tmp %>'
      }
    }
  }
}