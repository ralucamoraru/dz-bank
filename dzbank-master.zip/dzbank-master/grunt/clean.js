'use strict';

module.exports = function(grunt, options){


  return {
    dist: {
      src: ['<%= defaults.tmp %>', '<%= defaults.dist %>']
    },
    tmp: {
      src: ['<%= defaults.tmp %>']
    }
  }
}