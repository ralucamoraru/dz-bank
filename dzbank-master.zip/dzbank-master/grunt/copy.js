'use strict';

module.exports = function(grunt, options){

  return {

    configs: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['sftp-config.json','.htaccess'],
      dest: '<%= defaults.tmp %>/'
    },

    robots: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['robots.txt', 'sitemap.xml', 'sitemap-*.xml'],
      dest: '<%= defaults.tmp %>/'
    },

    testdata: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['testdata/**'],
      dest: '<%= defaults.tmp %>/'
    },

    images: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['images/**'],
      dest: '<%= defaults.tmp %>/'
    },

    assets_styles: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['assets/styles/*.css'],
      dest: '<%= defaults.tmp %>/'
    },
    assets_fonts: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['assets/styles/fonts/**'],
      dest: '<%= defaults.tmp %>/'
    },
    assets_images: {
      expand: true,
      cwd: '<%= defaults.src %>/',
      src: ['assets/images/**'],
      dest: '<%= defaults.tmp %>/'
    },

    build: {
      expand: true,
      cwd: '<%= defaults.tmp %>/',
      src: ['**'],
      dest: '<%= defaults.dist %>/'
    }

  }
}