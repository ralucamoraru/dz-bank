'use strict';

module.exports = function(grunt, options){

  return {
    dev: {
      path: '<%= defaults.hostname %>:<%= defaults.port %>/'
    }
  }
}