'use strict';

module.exports = function(grunt, options){

  return {
    options: {
      jshintrc: '.jshintrc'
    },
    gruntfile: {
      src: 'Gruntfile.js'
    },
    src: {
      src: ['src/scripts/*.js', 'src/scripts/components/*/**.js']
    }
  }
}