'use strict';

module.exports = function(grunt, options){


  return {
    dev: {
      src: ['**/*.ejs'],
      cwd: '<%= defaults.src %>/ejs/pages/',
      dest: '<%= defaults.tmp %>/',
      expand: true,
      ext: '.html',
      options: {
        title: 'EJS-locals',
        base_url:'<%= defaults.tmp %>/'
      }
    },
    dist: {
      src: ['**/*.ejs'],
      cwd: '<%= defaults.src %>/ejs/pages/',
      dest: '<%= defaults.dist %>/',
      expand: true,
      ext: '.html',
      options: {
        title: 'EJS-locals',
        base_url:'<%= defaults.dist %>/'
      }
    }
  }
}