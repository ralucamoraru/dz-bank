'use strict';

module.exports = function(grunt, options){

  return {
    images: {
      files: [{
        expand: true,
        cwd: 'src/images',
        src: ['**/*.{png,jpg,jpeg,gif}'],
        dest: 'dist/images'
      }]
    },
    assets: {
      files: [{
        expand: true,
        cwd: 'src/assets/images',
        src: ['**/*.{png,jpg,jpeg,gif}'],
        dest: 'dist/assets/images'
      }]
    }
  }
}