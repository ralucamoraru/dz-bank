'use strict';

module.exports = function(grunt, options){

  return {
    main: {
      options: {
        compress: true,
        report: 'min',
        dumpLineNumbers: 'comments',
      },
      files: {
        '<%= defaults.tmp %>/assets/styles/main.css': '<%= defaults.src %>/assets/styles/less/main.less'
      }
    }
  }
}