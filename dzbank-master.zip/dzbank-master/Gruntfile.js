/**
 * Gruntfile - Setup
 */
var globals           = {};
    globals.defaults  = {
      port: 9000,
      hostname: 'http://127.0.0.1',
      dist: 'dist',
      src: 'src',
      tmp: 'tmp'
    };

module.exports = function(grunt) {
  "use strict";

  require('load-grunt-tasks')(grunt);

  require('time-grunt')(grunt);
                                                                   
  var config = {
    pkg: grunt.file.readJSON('package.json'),
    globals: globals,
    banner: '/*! \n' +
              ' * <%= pkg.clientName %> | <%= pkg.clientProject %>\n' +
              ' * <%= pkg.version %> - <%= grunt.template.today("yyyy-mm-dd, HH:MM:ss") %>\n' +
              ' * (c) <%= grunt.template.today("yyyy") %> <%= pkg.clientName %>\n' +
              ' *\n' +
              ' * <%= pkg.creatorNames %>\n' +
              '*/\n',

    data: {
      defaults: globals.defaults
    }
  };

  global.globals = globals;
  config = require('load-grunt-config')(grunt, config);

  grunt.initConfig(config);

  grunt.registerTask('build', [
    'jshint',
    'clean',
    'less',
    'autoprefixer',
    'concat',
    'copy:configs',
    'copy:robots',
    'copy:images',
    'copy:testdata',
    'copy:assets_images',
    'copy:assets_styles',
    'copy:assets_fonts',
    'ejs:dist',
    'cssmin',
    'uglify',
    // 'validation',
    'copy:build',
    'clean:tmp'
  ]);

  grunt.registerTask('dev', [
    'jshint',
    'clean',
    'less',
    'autoprefixer',
    'concat',
    'copy:configs',
    'copy:robots',
    'copy:images',
    'copy:testdata',
    'copy:assets_images',
    'copy:assets_styles',
    'copy:assets_fonts',
    'ejs:dev',
    'connect:server',
    'open:dev',
    'watch'
  ]);

  grunt.registerTask('default', 'dev');

};
