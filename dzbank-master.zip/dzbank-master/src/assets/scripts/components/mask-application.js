DZBMYHR20.globals.siteheader = {
  'secureText': 'Daten verbergen',
  'unsecureText': 'Daten anzeigen'
}

$(function(){

  /* *********************************************************************** */

  /*
   * Append helper element
   */

  if (!DZBMYHR20.dom.$siteBody.prev('.is-secured-symbol').length) {

    DZBMYHR20.dom.$siteBody.before('<div class="is-secured-symbol"></div>');

  }

  /* *********************************************************************** */

  /*
   * DOM references
   */

  DZBMYHR20.dom.$maskApplicationLink = DZBMYHR20.dom.$siteHeader.find('.maskapplication');

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.functions.maskApplication = function() {

    if (DZBMYHR20.dom.$maskApplicationLink.hasClass('active')) {

      DZBMYHR20.dom.$maskApplicationLink.removeClass('active');
      DZBMYHR20.dom.$maskApplicationLink.find('span').text(DZBMYHR20.globals.siteheader.secureText);
      DZBMYHR20.dom.$siteBody.removeClass('is-secured');

    } else {

      DZBMYHR20.dom.$maskApplicationLink.addClass('active');
      DZBMYHR20.dom.$maskApplicationLink.find('span').text(DZBMYHR20.globals.siteheader.unsecureText);
      DZBMYHR20.dom.$siteBody.addClass('is-secured');

    }

  };

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$maskApplicationLink.on('click', function(event){

    event.preventDefault();

    DZBMYHR20.functions.maskApplication()    

  });

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$window.on('keyup', function(event){
    if (event.ctrlKey && event.keyCode == 27) {
      DZBMYHR20.functions.maskApplication();
    }
  });

});