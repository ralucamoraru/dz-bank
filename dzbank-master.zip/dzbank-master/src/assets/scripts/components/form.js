$(function(){

  /* *********************************************************************** */

  /*
   * SelectBoxIt
   */

  $('select').selectBoxIt();

  $("[data-option-popover]").popover({ trigger: 'hover', container: 'body' });

  /* *********************************************************************** */

  /*
   * Autogrow Textarea
   */

  $('textarea[data-autogrow]').autoGrow();

  /* *********************************************************************** */

});