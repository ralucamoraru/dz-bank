$(function(){

  $('.carousel').carousel();

});