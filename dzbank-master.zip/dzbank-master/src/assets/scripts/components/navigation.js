$(function(){

  /* *********************************************************************** */

  /*
   * Append helper element
   */

  if (!DZBMYHR20.dom.$body.find('.navigation-overlay').length) {

    DZBMYHR20.dom.$body.append('<div class="navigation-overlay"/>');

  }

  /* *********************************************************************** */

  /*
   * DOM references
   */

  DZBMYHR20.dom.$navigationOpener = DZBMYHR20.dom.$siteHeader.find('>button');
  DZBMYHR20.dom.$navigationContainer = DZBMYHR20.dom.$siteHeader.find('nav');
  DZBMYHR20.dom.$navigationOverlay = DZBMYHR20.dom.$body.find('.navigation-overlay');

  DZBMYHR20.dom.$navigationSearchForm = DZBMYHR20.dom.$siteHeader.find('form');

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$navigationOpener.on('click', function(event){

    event.preventDefault();

    DZBMYHR20.dom.$navigationOpener.toggleClass('open');
    DZBMYHR20.dom.$navigationContainer.toggleClass('open');    
    DZBMYHR20.dom.$navigationOverlay.toggleClass('open');

  });

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$navigationContainer.on('click', '.level-1>li>.more', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('open');
    $this.parent().toggleClass('open');
    $this.next().toggleClass('open');

  });

  DZBMYHR20.dom.$navigationContainer.on('click', '.level-2>li>.more', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('open');
    $this.parent().toggleClass('open');
    $this.next().toggleClass('open');

  });

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$window.on('keyup', function(event){
    if (event.keyCode == 27) {
      DZBMYHR20.dom.$navigationContainer.find('.open').removeClass('open');
    }
  });

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$navigationSearchForm.on('submit', function(event){

    event.preventDefault();

  });

  DZBMYHR20.dom.$navigationSearchForm.on('click', 'button', function(event){

    event.preventDefault();

  });

  /* *********************************************************************** */

  /*
   * 
   */

  DZBMYHR20.dom.$siteHeader.on('click', '.view-select>a', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('active');
    $this.next().toggle();

  });
/*
  DZBMYHR20.dom.$siteHeader.on('resize', function(){

    DZBMYHR20.dom.$siteHeader.find('.view-select>ul').css({ 'width': DZBMYHR20.dom.$siteHeader.find('.view-select>a').outerWidth() });

  }).resize();
*/
});