$(function(){

  /* *********************************************************************** */

  /*
   * 
   */

   DZBMYHR20.globals.colors = {
    orange: '#f28200',
    blue: '#0e3c8a',
    gray: '#dfdedd'
   }

  /* *********************************************************************** */

  /*
   * 
   */

  if (DZBMYHR20.device.isPhone) {

    DZBMYHR20.dom.$body.addClass('minimized');

  }

  DZBMYHR20.dom.siteHeaderHeight = 0;

  DZBMYHR20.dom.$window.on('scroll resize', function(event){

    if (!DZBMYHR20.device.isPhone && !DZBMYHR20.device.isTablet) {

      if (DZBMYHR20.dom.siteHeaderHeight == 0) {

        DZBMYHR20.dom.siteHeaderHeight = parseInt(DZBMYHR20.dom.$siteHeader.outerHeight()) - parseInt(DZBMYHR20.dom.$siteHeader.find('>nav').outerHeight());

      }

      var windowScrollTop = parseInt(DZBMYHR20.dom.$window.scrollTop()),
          navigationOffsetTop = parseInt(DZBMYHR20.dom.$siteHeader.find('>nav').offset().top);

      if (!DZBMYHR20.dom.$body.hasClass('minimized')) {

        if (windowScrollTop >= navigationOffsetTop) {

          DZBMYHR20.dom.$body.addClass('minimized');

        }

      } else {

        if (windowScrollTop <= DZBMYHR20.dom.siteHeaderHeight) {

          DZBMYHR20.dom.$body.removeClass('minimized');

        }

      }

    } else {

      DZBMYHR20.dom.$body.removeClass('minimized');

    }

  }).scroll();

});