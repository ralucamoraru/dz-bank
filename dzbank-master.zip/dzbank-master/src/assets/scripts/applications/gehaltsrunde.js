$(function(){

  if ($('#gehaltsrunde').length) {

    $('[data-toggle="popover"]').popover({
      html: true,
      content: $('#popover-content').html()
    });

  }

});