$(function(){

  /* *********************************************************************** */

  /*
   * 
   */

  if ($('#gehaltsrechner').length) {

    /* ********************************************************************* */

    /*
     * Example implementation
     */

    var rangeSlider1 = document.getElementById('slider-range-1');

    noUiSlider.create(rangeSlider1, {
      start: [ 50000 ],
      range: {
        'min': [  0 ],
        'max': [ 60000 ]
      },
      steps: 1000,
      pips: {
        mode: 'values',
        values: [0, 10000, 20000, 30000, 40000, 50000, 60000],
        density: 2
      }
    });

    var rangeSlider2 = document.getElementById('slider-range-2');

    noUiSlider.create(rangeSlider2, {
      start: [ 100 ],
      range: {
        'min': [  0 ],
        'max': [ 100 ]
      },
      steps: 25,
      pips: {
        mode: 'values',
        values: [0, 25, 50, 75, 100],
        density: 25
      }
    });

    /* ********************************************************************* */

    /*
     * Example implementation
     */

    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };
    var randomColorFactor = function() {
        return Math.round(Math.random() * 255);
    };
    var randomColor = function(opacity) {
        return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
    };

    var config = {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                ],
                backgroundColor: [
                    DZBMYHR20.globals.colors.orange,
                    DZBMYHR20.globals.colors.gray
                ]
            }, {
                data: [
                    randomScalingFactor(),
                    randomScalingFactor()
                ],
                backgroundColor: [
                    DZBMYHR20.globals.colors.blue,
                    DZBMYHR20.globals.colors.gray
                ]
            }],
            labels: [
                "",
                ""
            ]
        },
        options: {
            responsive: true,
            legend: {
                position: 'bottom',
            },
            title: {
                display: false,
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById("chart-area").getContext("2d");
        window.myDoughnut = new Chart(ctx, config);
    };

  }

});