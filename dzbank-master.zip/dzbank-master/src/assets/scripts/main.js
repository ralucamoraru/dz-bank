
$(function(){

  /*
   * Configuration
   */

  DZBMYHR20.setup = DZBMYHR20.setup || {};

  DZBMYHR20.setup = {}

  /*
   * Global dom references
   */

  DZBMYHR20.dom = DZBMYHR20.dom || {};

  DZBMYHR20.dom.$window = $(window),
  DZBMYHR20.dom.$document = $(document),
  DZBMYHR20.dom.$body = $('body');

  DZBMYHR20.dom.$siteHeader = $('#site-header'),
  DZBMYHR20.dom.$siteBody = $('#site-body'),
  DZBMYHR20.dom.$siteFooter = $('#site-footer');

  /* *********************************************************************** */

  /*
   * Device and browser settings
   */

  DZBMYHR20.device = DZBMYHR20.device || {};

  /*
   * Detect browser
   */

  DZBMYHR20.device.browser = navigator.userAgent.toLowerCase();

  /*
   * Detect device by Bootstrap grid sizes
   */

  DZBMYHR20.dom.$body
    .append('<div id="breakpoint-desktop" class="visible-md visible-lg" />')
    .append('<div id="breakpoint-tablet" class="visible-sm" />')
    .append('<div id="breakpoint-phone" class="visible-xs" />');

  DZBMYHR20.functions.detectDevice = function(){

    DZBMYHR20.device.wasDesktop = DZBMYHR20.device.isDesktop || false;
    DZBMYHR20.device.wasTablet = DZBMYHR20.device.isTablet || false;
    DZBMYHR20.device.wasPhone = DZBMYHR20.device.isPhone || false;

    DZBMYHR20.device.isDesktop = $('#breakpoint-desktop').is(':visible');
    DZBMYHR20.device.isTablet = $('#breakpoint-tablet').is(':visible');
    DZBMYHR20.device.isPhone = $('#breakpoint-phone').is(':visible');

  }

  /* Trigger DZBMYHR20.functions.detectDevice() */
  DZBMYHR20.functions.detectDevice();

  /* Register DZBMYHR20.functions.detectDevice() on resize */
  DZBMYHR20.dom.$window.on('resize', $.debounce(100, function(event){

    DZBMYHR20.functions.detectDevice();

  }));

});