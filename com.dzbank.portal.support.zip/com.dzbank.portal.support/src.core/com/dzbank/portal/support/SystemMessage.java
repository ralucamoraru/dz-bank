package com.dzbank.portal.support;



import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;

import com.sap.portal.directory.Constants;
import com.sap.portal.pcm.admin.PcmConstants;
import com.sap.portal.pcm.iview.IiView;
import com.sap.security.api.IUser;
import com.sap.security.api.UMException;
import com.sap.security.api.UMFactory;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.pcd.gl.IPcdContext;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
//import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;
import com.sapportals.wcm.repository.Content;
import com.sapportals.wcm.repository.ICollection;
import com.sapportals.wcm.repository.IResource;
import com.sapportals.wcm.repository.IResourceFactory;
import com.sapportals.wcm.repository.ResourceContext;
import com.sapportals.wcm.repository.ResourceException;
import com.sapportals.wcm.repository.ResourceFactory;
import com.sapportals.wcm.util.content.ContentException;
import com.sapportals.wcm.util.uri.RID;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class SystemMessage extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";
	  public static final String REQUEST_BEG_DATE_PARAM = "bDate";
	  public static final String REQUEST_END_DATE_PARAM = "eDate";
	  public static final String REQUEST_NEW_PARAM = "new";
	  public static final String REQUEST_TEXT_PARAM = "text";
	  public static final String REQUEST_TIT_PARAM = "title";
	
	  
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
	//	response.write("<script>alert(\"sys msg\") </script>");
		String begDate = request.getParameter(REQUEST_BEG_DATE_PARAM);
		String endDate = request.getParameter(REQUEST_END_DATE_PARAM);
		String newEntry = request.getParameter(REQUEST_NEW_PARAM);
		String text = request.getParameter(REQUEST_TEXT_PARAM);
		String title = request.getParameter(REQUEST_TIT_PARAM);
		
		if (newEntry!=null && newEntry.equals("true")){
			this.changeiViewAttr(request, response, begDate, endDate);
			String s = this.writeHTML(text, title);
			writeFileIntoKM(s, "index.html", this.getKMAdminUser());
		}else{
			boolean check = this.checkDate(request, response);
			if (check){
			//	IResource res = this.readKmResource("/documents/index.html", request.getUser());
			//	String name = res.getDisplayName();
			//	response.write("<script>alert(\""+name+"\") </script>");
				response.include(request, request.getResource(com.sapportals.portal.prt.resource.IResource.JSP, "jsp/SysMsg.jsp"));	
			}
		}
	}
	
	public IUser getKMAdminUser(){
	    IUser user;
	    try {
	      user = UMFactory.getUserFactory().getUserByLogonID("cmadmin_service");
	    } catch (UMException e) {
	      return null;
	    }
	    return user;
	}
	
	public IUser getPCDAdminUser(){
	    IUser user;
	    try {
	      user = UMFactory.getUserFactory().getUserByLogonID("pcd_service");
	    } catch (UMException e) {
	      return null;
	    }
	    return user;
	}
	
	public void changeiViewAttr(IPortalComponentRequest request, IPortalComponentResponse response, String begDate, String endDate){
		NavigationEventsHelperService navHelperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		Hashtable env = new Hashtable<String, Object>();
		env.put( Context.INITIAL_CONTEXT_FACTORY, IPcdContext.PCD_INITIAL_CONTEXT_FACTORY );
		env.put(Context.SECURITY_PRINCIPAL, request.getUser() );
		env.put(Constants.REQUESTED_ASPECT, PcmConstants.ASPECT_SEMANTICS);
	//	env.put(IPcdContext.PCD_PERSONALIZATION_PRINCIPAL, request.getUser());

		IiView iView = null;
		InitialContext iCtx = null;
		try {
			iCtx = new InitialContext(env);
			Object currentObject = iCtx.lookup("portal_content/dzbank/admin/sysmsg");
			if (currentObject instanceof IiView) {
				iView = (IiView) currentObject; 
				//response.write("<script>alert(\" inside \"); </script>");
			}
		Enumeration enums = iView.getAttributeIds();
		String sDate = iView.getAttribute("com.dzbank.portal.support.StartDate");
		
		iView.putAttribute("com.dzbank.portal.support.StartDate", begDate);
		iView.putAttribute("com.dzbank.portal.support.EndDate", endDate);
		iView.save();
		
		}catch (Exception e) {
			response.write("<script>alert(\" Exception \"); </script>");
		}
	}
 
	public boolean checkDate(IPortalComponentRequest request, IPortalComponentResponse response){
		boolean check = false;
		response.write("<script>console.log(\"In check date method \"); </script>");
		String startDate = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.support.StartDate");
		String endDate = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.support.EndDate");		
		SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		try {
			Date sDate = formatter.parse(startDate);
			Date eDate = formatter.parse(endDate);
			Date date = new Date();
			response.write("<script>console.log(\"Start date: " + sDate.toString() + " end date: " + eDate.toString() + " and current: "+ date.toString() +"\"); </script>");
			if(date.after(sDate) && date.before(eDate))
				check = true;
			response.write("<script>console.log(\"CHECK: "+ check +"\"); </script>");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		return check;
	}
	
	public static IResource readKmResource(String kmFilePath, IUser user) {
		
		try {
			// init KM resourcecontext and -factory
			ResourceContext resourceCtx = ResourceContext.getInstance(user);
			IResourceFactory resourceFactory = ResourceFactory.getInstance();
			
			// get or create KM resource
			RID rid = RID.getRID(kmFilePath);
			
			if (resourceFactory.checkExistence(rid, resourceCtx)) {
			
				return resourceFactory.getResource(rid, resourceCtx);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		return null;
	}
		
	public String writeHTML(String text, String title){
		String html = "<meta charset=\"UTF-8\">";
		html = html + "<style>";
		html = html + ".sys_msg{ color: #707172; font-family: Arial, Verdana, sans-serif; font-size: 14px; padding-top: 5px; padding-bottom: 5px; border-bottom: 1px solid #eee;}";
		html = html + ".sys_msg_title{color: #0e3c8a; font-family: Arial, Verdana, sans-serif; font-size: 14px; text-transform: uppercase; width: 100%; padding-top: 10px; padding-bottom: 5px;}";
		html = html + ".support-box h4 {color: #707172; font-size: 12px; font-weight: bold; margin-bottom: 10px; margin-top: 20px; }";
		html = html + ".support-box p {color: #707172; font-size: 12px; line-height: 1.42em; margin-bottom: 20px; }";
		html = html + "</style>";
		html = html + "<div class=\"sys_msg_title\">";
		html = html + title;
		html = html + "</div>";
		html = html + "<div class='sys_msg' >";
		html = html + text;
		html = html + "</div>";
		html = html + "<div class='support-box'>"; 
		html = html + "<h4>HR DIREKT</h4>";
		html = html + "<p>Telefon: 069 7447-8787<br>Telefax: 069 7447-92307<br>";
		html = html + "<a href='mailto;hrdirekt@dzbank.de'>hrdirekt@dzbank.de</a>";
		html = html + "</p></div>";
        
			
		return html;
	} 
	 
	public static void writeFileIntoKM (String file, String fileName, IUser user) {
			
		InputStream stream = new ByteArrayInputStream(file.getBytes(StandardCharsets.UTF_8));
			RID pathRID = RID.getRID("/documents"); 	
			RID rid = RID.getRID("/documents/" + fileName);
			try {
			
	 
				ResourceContext resourceContext = ResourceContext.getInstance(user);
				
				IResourceFactory resourceFactory = com.sapportals.wcm.repository.ResourceFactory.getInstance();
				
				ICollection collection = (ICollection)resourceFactory.getResource(pathRID, resourceContext);
				String resourceName = fileName;
				Content cont = new Content(stream, "text/html ",-1,null);
				IResource fileResource;
				if (!resourceFactory.checkExistence(rid, resourceContext)) {
					//create a file in above mentioned path in KM
					fileResource = (IResource)collection.createResource(resourceName, null, cont);
				}else{
					//overwrite resource
					fileResource = (IResource) resourceFactory.getResource(rid, resourceContext);
					fileResource.updateContent(cont);
				}
				
			} catch (ResourceException e) {
				e.printStackTrace();
			}  catch (ContentException e) {
				e.printStackTrace();
			}	
		}
	
	
	public static String getIdForResource(IResource res)  {
		if (res == null) {
			return null;
		}
		try {
			RID rid = res.getRID();
			if (rid == null) {
				return null;
			}
			return rid.getPath();
		} catch (ResourceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}