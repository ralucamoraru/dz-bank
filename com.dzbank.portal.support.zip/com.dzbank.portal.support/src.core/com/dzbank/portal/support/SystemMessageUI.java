package com.dzbank.portal.support;

import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class SystemMessageUI extends AbstractPortalComponent{

	  private final String INPUT_ATTRIBUTE = "input";

	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		
			response.include(request, request.getResource(IResource.JSP, "jsp/SysMsgUI.jsp"));	
	
	}
	
	
	
}