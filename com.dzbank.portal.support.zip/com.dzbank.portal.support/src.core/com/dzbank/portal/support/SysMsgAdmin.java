package com.dzbank.portal.support;

import com.sap.portal.resource.repository.IResourceRepositoryService;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.runtime.PortalRuntime;

/**
 *  
 * @author Raluca Moraru / ralucamoraru@gmail.com 
 *
 */
public class SysMsgAdmin extends AbstractPortalComponent{
	
	
	public static final String REQUEST_BEG_DATE_PARAM = "bDate";
	public static final String REQUEST_END_DATE_PARAM = "eDate";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response){
		
		String begDate = request.getParameter(REQUEST_BEG_DATE_PARAM);
		String endDate = request.getParameter(REQUEST_END_DATE_PARAM);
		//response.write("<script>alert(\"Test \");</script>");
	
	}
	
	
	public void updateResource(){
		IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
		
	}
}