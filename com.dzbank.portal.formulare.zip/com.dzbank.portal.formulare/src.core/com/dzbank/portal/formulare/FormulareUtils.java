package com.dzbank.portal.formulare;
 
import java.util.Hashtable;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

import com.sap.portal.navigation.IAliasHelper;
import com.sap.portal.navigation.IAliasService;
import com.sapportals.portal.navigation.INavigationNode;
import com.sapportals.portal.navigation.INavigationService;
import com.sapportals.portal.navigation.NavigationEventsHelperService;
import com.sapportals.portal.navigation.NavigationNodes;
import com.sapportals.portal.prt.component.AbstractPortalComponent;
import com.sapportals.portal.prt.component.IPortalComponentRequest;
import com.sapportals.portal.prt.component.IPortalComponentResponse;
import com.sapportals.portal.prt.resource.IResource;
import com.sapportals.portal.prt.runtime.PortalRuntime;


/**
 * 
 * @author Raluca Moraru
 * ralucamoraru@gmail.com / +49 176 64718145
 *
 */

public class FormulareUtils extends AbstractPortalComponent
{
	public String portalPath = "";
	
	public void doContent(IPortalComponentRequest request, IPortalComponentResponse response) {
		IAliasHelper aliasHelper = (IAliasHelper) PortalRuntime.getRuntimeResources().getService(IAliasService.KEY);
		this.portalPath = aliasHelper.getPath(request);
		
		String colors = request.getComponentContext().getProfile().getProperty("com.dzbank.portal.colors");
	//	response.write("Color Code config: " + colors);
		JSONObject ret = this.getFormsAsJSON(request);	
//		response.write("Response: " + ret.toString());
		response.write("<script>FC=" + ret.toString() + "; alert('" +ret.toString() +"');</script>");
	//	response.write(" FORMULARE: " + ret.toString());
//		try {
	//		response.write("<script>FORMS=" + ret.toString() + ";</script>");
//		} catch (JSONException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		
		response.include(request, request.getResource(IResource.JSP, "jsp/Overview.jsp"));	
		
//	//	response.write(ret.toString());
//		HttpServletResponse servletResponse = request.getServletResponse(true);
//
//		servletResponse.setContentType("text/json");
//
//		servletResponse.setCharacterEncoding("UTF-8");
//		servletResponse.setHeader("Content-Type", "application/json; charset=UTF-8");
//		
//		try {
//			servletResponse.getWriter().write(ret.toString());
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		//JSONObject fwk = cfg.getFwkObject();
		//response.write("<script>FWK=" + fwk.toString(4) + ";</script>");
		//onclick="FWK._preLogout()"
		//FWK.themeRoot
	
	}

	public JSONObject getFormsAsJSON(IPortalComponentRequest request){
		
		//IResourceRepositoryService resourceRepository = (IResourceRepositoryService) PortalRuntime.getRuntimeResources().getService(IResourceRepositoryService.KEY);
		NavigationEventsHelperService helperService = (NavigationEventsHelperService) PortalRuntime.getRuntimeResources().getService(NavigationEventsHelperService.KEY);
		INavigationService navService = (INavigationService) PortalRuntime.getRuntimeResources().getService(INavigationService.KEY);
		
		Hashtable environment = helperService.getEnvironment(request);
		
		JSONObject retJSON = new JSONObject();
		
		INavigationNode node = null;
		try {
			node = helperService.getCurrentLaunchNavNode(request);	
			INavigationNode node1 = helperService.getCurrentNavNode(request);
			
			String parentNodeName = navService.getNavNodeParentName(environment, node.getName());
			INavigationNode parentNode = navService.getNode(environment, parentNodeName);

			//response.write("<script>console.log(\"///NODE/// Name: "+node.getName()+" NODE 1: "+node1.getName()+" NODE 2: "+node2.getName()+"\");</script>");
			//String parentNodeName = navService.getNavNodeParentName(environment, node.getName());
			//INavigationNode parentNode = navService.getNode(environment, parentNodeName);

			NavigationNodes children = parentNode.getChildren(environment);
			Iterator iter = children.iterator();

			
			JSONArray allCats = new JSONArray();
			while(iter.hasNext()){
				INavigationNode category = (INavigationNode)iter.next();
				String url = category.getLaunchURL();	
				String catName = category.getTitle(request.getLocale());
				String description = category.getTitle(request.getLocale());
				
				if(category.hasChildren(environment)){
					JSONObject cat = new JSONObject();
					JSONArray forms = new JSONArray();
					NavigationNodes level3Children = category.getChildren(environment);
					Iterator iter2 = level3Children.iterator();
					
					while (iter2.hasNext()) {
						INavigationNode formular = (INavigationNode)iter2.next();
						String formUrl = formular.getLaunchURL();	
						String formHref = this.getHref(formular, this.portalPath, null, null, null);
						String formName = formular.getTitle(request.getLocale());
						String formDescription = formular.getTitle(request.getLocale());
						JSONObject form = new JSONObject();
						form.put("name", formName);
						form.put("url", formHref);
						form.put("description", formDescription);
						forms.put(form);
					//	response.write("Level 3: " + formName + " URL: " + formHref);
					}
					
					cat.put("Category", category.getTitle(request.getLocale()));
					cat.put("Forms", forms);
					allCats.put(cat); 
				}	
				
			}
			retJSON.put("Formulare", allCats);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
			
		return retJSON;
	}

	
	private String getHref(INavigationNode node, String portalPath, String quickLink1, String quickLink2, String quickLink3) {
		if (quickLink1 != null) {
			if (quickLink2 == null) {
				return portalPath + '/' + quickLink1;
			} else if (quickLink3 == null) {
				return portalPath + '/' + quickLink1 + '/' + quickLink2;
			} else {
				return portalPath + '/' + quickLink1 + '/' + quickLink2 + '/' + quickLink3;
			}
		}
		return portalPath + "?NavigationTarget=" + node.getHashedName();
	}
}