sap.ui.controller("mehrarbeit.antragTable", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf giftbook.smartTable
*/
	onInit: function() {

	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf giftbook.smartTable
*/
	onBeforeRendering: function() {

	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf giftbook.smartTable
*/
	onAfterRendering: function() {
				
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf giftbook.smartTable
*/
	onExit: function() {

	},

	
	editGift: function(){
		//alert("hat funktioniert!");
	},
	
    delEntry: function(id, entry){
    	console.log("delEntry"); 
    	var view = this.getView();
        var dataModel = view.getModel("oData_RU");
        entry[0].Action = "LOESCHEN";
        
        var status = "";
        var result = "";
        
        var oData = {};
        
        oData.Abgestimmt = entry[0].Abgestimmt;
        oData.Aufnr = entry[0].Aufnr;
        oData.AusgleichDatumAb = "";//entry["0"].AusgleichDatumAb;
        oData.AusgleichDatumBis = "";//entry["0"].AusgleichDatumBis;
        oData.AusgleichZeitAb = entry[0].AusgleichZeitAb;
        oData.AusgleichZeitBis = entry[0].AusgleichZeitBis;
        oData.Auswahl = entry[0].Auswahl;
        oData.Begruendung = entry[0].Begruendung;
        oData.BrGenehmAm = "";//entry["0"].BrGenehmAm;
        oData.BrKommentar = entry[0].BrKommentar;
        oData.BrName = entry[0].BrName;
        oData.BrUser = entry[0].BrUser;
        oData.DatumBis = entry[0].DatumBis;
        oData.DatumVon = entry[0].DatumVon;
        oData.EinsatzPunkteBerechnet = entry[0].EinsatzPunkteBerechnet;
        oData.EinsatzPunkteGeplant = entry[0].EinsatzPunkteGeplant;
        oData.FkGenehmAm = "";//entry[0].FkGenehmAm;
        oData.FkKommentar = entry[0].FkKommentar;
        oData.FkName = entry[0].FkName;
        oData.FkUser = entry[0].FkUser;
        oData.Hash = entry[0].Hash;
        oData.Infotyp = entry[0].Infotyp;
        oData.Kostl = entry[0].Kostl;
        oData.Pernr = entry[0].Pernr;
        oData.PsGenehmAm = "";//entry["0"].PsGenehmAm;
        oData.PsGenehmName = entry[0].PsGenehmName;
        oData.PsKommentar = entry[0].PsKommentar;
        oData.PsUser = entry[0].PsUser;
        oData.Seqnr = entry[0].Seqnr;
        oData.SonnFeiertag = entry[0].SonnFeiertag;
        oData.Sprps = entry[0].Sprps;
        oData.Status = entry[0].Status;
        oData.Stunden_beantr = entry[0].Stunden_beantr;
        oData.Subty = entry[0].Subty;
        oData.UhrzeitBis = entry[0].UhrzeitBis;
        oData.UhrzeitVon = entry[0].UhrzeitVon;
        oData.Versl = entry[0].Versl;
        oData.VonAm = entry[0].VonAm;
        oData.VonName = entry[0].VonName;
        oData.VonUm = entry[0].VonUm;
        oData.VonUser = entry[0].VonUser;
        oData.Zguid = entry[0].Zguid;
        
        oData.Action = "LOESCHEN";
        
        try{
        	dataModel.remove(  //"/RUMSet?$filter=Pernr eq '" + persDat_pernr + "'"
        			"/RUMSet(Zguid='"+ id +"')", 
        			
        			oData,
        			{
        				async: false,
        				success: function() {
        					status = "success";
        					console.log("ODATA: Erfolgreich gelöscht...");
        					//		sap.m.MessageBox.success("Erfolgreich gelöscht");
        							//originview.getController().refreshTable();
        				},
        				error: function(){
        					status = "error";
        					console.log("ODATA: error occured when deleting...");
        					//sap.m.MessageBox.error(oError.Message);
        				}		
        			}
        	);  	
        }catch(err){
        	//if(err.message === "S is not a function"){
        		status = "success";
				//sap.m.MessageBox.success("Erfolgreich gelöscht");
				//originView.getController().refreshTable();
        	//}else{
        		//status = "error";
        	//}
        } 
        
        if(status == "success"){
            sap.m.MessageBox.success("Erfolgreich gelöscht!", {
                onClose: function(){
                  console.log("Erfolgreich gelöscht...");
                  location.reload();
                  //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
                }
              });
        }else if (status == "error"){
            sap.m.MessageBox.error("Ein Fehler ist aufgetretten!", {
                onClose: function(){
                  console.log("error occured when deleting...");
                  location.reload();
                  //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
                }
            });
        }
        
    },
    
    stornoEntry: function(id, entry){
    	console.log("stornoEntry"); 
    	var view = this.getView();
        var dataModel = view.getModel("oData_RU");
        entry[0].Action = "STORNIEREN";
        try{
        	dataModel.remove(  //"/RUMSet?$filter=Pernr eq '" + persDat_pernr + "'"
        			"/RUMSet?$filter=Zguid eq '"+ id +"'", 
        			
        			entry,
        			{
        				async: false,
        				success: function() {
        							sap.m.MessageBox.success("Erfolgreich storniert");
        							//originview.getController().refreshTable();
        						},
        				error: function(){
        							sap.m.MessageBox.error(oError.Message);
        						}		
        			}
        	); 
        	
        }catch(err){
        	if(err.message === "S is not a function"){
				sap.m.MessageBox.success("Erfolgreich storniert");
				//originView.getController().refreshTable();
        	}
        }        
    },
 
    abrechnen: function(id, entry){
        var lv_status;
        var lv_response;
    	console.log("abrechnen..."); 
    	var view = this.getView();
        var dataModel = view.getModel("RUM_Antrag");
        
        var oData = {};
        
       // entry[0].Status = "8";
        
        oData.Abgestimmt = entry[0].Abgestimmt;
        oData.Aufnr = entry[0].Aufnr;
        oData.AusgleichDatumAb = entry[0].AusgleichDatumAb;
        oData.AusgleichDatumBis = entry[0].AusgleichDatumBis;
        oData.AusgleichZeitAb = entry[0].AusgleichZeitAb;
        oData.AusgleichZeitBis = entry[0].AusgleichZeitBis;
        oData.Auswahl = entry[0].Auswahl;
        oData.Begruendung = entry[0].Begruendung;
        oData.BrGenehmAm = entry[0].BrGenehmAm;
        oData.BrKommentar = entry[0].BrKommentar;
        oData.BrName = entry[0].BrName;
        oData.BrUser = entry[0].BrUser;
        oData.DatumBis = entry[0].DatumBis;
        oData.DatumVon = entry[0].DatumVon;
        oData.EinsatzPunkteVortag = entry[0].EinsatzPunkteBerechnet;
        oData.EinsatzPunkteForecast = entry[0].EinsatzPunkteGeplant;
        oData.FkGenehmAm = entry[0].FkGenehmAm;
        oData.FkKommentar = entry[0].FkKommentar;
        oData.FkName = entry[0].FkName;
        oData.FkUser = entry[0].FkUser;
        oData.Hash = entry[0].Hash;
        oData.Infotyp = entry[0].Infotyp;
        oData.Kostl = entry[0].Kostl;
        oData.Pernr = entry[0].Pernr;
        oData.PsGenehmAm = entry[0].PsGenehmAm;
        oData.PsGenehmName = entry[0].PsGenehmName;
        oData.PsKommentar = entry[0].PsKommentar;
        oData.PsUser = entry[0].PsUser;
        oData.Seqnr = entry[0].Seqnr;
        oData.SonnFeiertag = entry[0].SonnFeiertag;
        oData.Sprps = entry[0].Sprps;
        oData.Status = entry[0].Status;
        oData.Stunden_beantr = entry[0].Stunden_beantr;
        oData.Subty = entry[0].Subty;
        oData.UhrzeitBis = entry[0].UhrzeitBis;
        oData.UhrzeitVon = entry[0].UhrzeitVon;
        oData.Versl = entry[0].Versl;
        oData.VonAm = entry[0].VonAm;
        oData.VonName = entry[0].VonName;
        oData.VonUm = entry[0].VonUm;
        oData.VonUser = entry[0].VonUser;
        oData.Zguid = entry[0].Zguid;
        
        oData.Action = "ABRECHNEN";
        oData.Stunden_abger = entry[0].Stunden_beantr;
        
        
        
        entry[0].Action = "ABRECHNEN";
    //    entry[0].Stunden_abger = document.getElementById("abr_stunden").value;
        
        //TODO: Gutschrift art - welche oData Feld?!?!?
        
        try{
        	dataModel.update(
        			"/RUMSet(Zguid='" + id + "')", 
        			
        			oData, 
        			{
        				async: false,
        				error: function(response) {
        					lv_status = "error";
        					lv_response = response;
			            },
			            success: function(response, status) {
			            	lv_status = "success";
			            	lv_response = response;
			            	//sap.m.MessageBox.success("Erfolgreich abgerechnet");
			            }
        			});
             	
        }catch(err){
        	if(err.message === "S is not a function"){
				sap.m.MessageBox.success("Erfolgreich abgerechnet");
				//originView.getController().refreshTable();
        	}
        }
        
  	  var text = lv_response.response.body.toString();   
	  parser = new DOMParser();
  	  xmlDoc = parser.parseFromString(text,"text/xml"); 
      if (lv_status === "error"){      	
      	  var msg = "Fehler: " + xmlDoc.getElementsByTagName("errordetail")[0].childNodes[1].textContent;
          sap.m.MessageBox.error(msg, {
              onClose: function(){
                console.log("RESPONSE ON ERROR: " + msg);
                
                location.reload();
                //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
              }
          });
      }
      else if(lv_status != "undefined"){
        if(lv_status === "success"){
          var msg = "Der Rufbereitschaftsantrag von " + entry[0].DatumVon + " bis " + entry[0].DatumVon + " über " + oData.Stunden_abger + " Stunden wurde erfolgreich abgerechnet!";	
          sap.m.MessageBox.success(msg, {
            onClose: function(){
              console.log("erfolgreich abgerechnet...");
              location.reload();
              //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
            }
          });
        } 
      }
    },
    
	refreshTable: function(){
		
		var view = this.getView();
		var model = view.byId("idRandomDataTable").getModel();
		model.refresh();
		
	}
});