sap.ui.jsview("mehrarbeit.antragTable", {

  /** Specifies the Controller belonging to this View. 
  * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
  * @memberOf giftbook.smartTable
  */ 
  getControllerName : function() {
    return "mehrarbeit.antragTable";
  },

  /** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
  * Since the Controller is given to this method, its event handlers can be attached right away. 
  * @memberOf giftbook.smartTable
  */ 
  createContent : function(oController) {
    var content = "";
    var eSet = "RUMSet";
    var oData = "ZUI5_ODATA_RUFB_MEHRA_SRV";


    var url = "/sap/opu/odata/SAP/" + oData; 

    var oDataModel = new sap.ui.model.odata.ODataModel(url, {
      json: true
    });
    oDataModel.headers = {
      AccessControlAllowOrigin: "*"
    };
    oDataModel.attachRequestFailed(function(evt) {
    });

    oDataModel.setHeaders({
      "X-Requested-With": "XMLHttpRequest",
      "Content-Type": "application/atom+xml",
      "DataServiceVersion": "2.0",
      "X-CSRF-Token": "Fetch"
    });
    var oMeta = oDataModel.getServiceMetadata();

    content += "<section id='table-0' class='collapse in mCustomScrollbar' data-mcs-theme='dark' data-mcs-axis='y'>"
    content += "<table class='flex-table'>";
    content += "<thead class='flex-table-thead'>";
    content += "<tr class='flex-table-tr'>";
    content += "<th class='flex-table-th'></th>";
    content += "<th class='flex-table-th'>Art</th>";
    content += "<th class='flex-table-th'>Status</th>";
    content += "<th class='flex-table-th'>Beantragender</th>";
    content += "<th class='flex-table-th'>Beginn</th>";
    content += "<th class='flex-table-th'>Uhrzeit</th>";
    content += "<th class='flex-table-th'>Ende</th>";
    content += "<th class='flex-table-th'>Uhrzeit</th>";
    content += "<th class='flex-table-th'>Stunden</th>";
    content += "<th class='flex-table-th'>Erstellt am</th>";
    content += "<th class='flex-table-th'>Begründung</th>";
    content += "<th class='flex-table-th'></th>";
    content += "</tr>";

//************ Getting the Data for each Entry*********//
    if(existingEntries == null || existingEntries.length == 0) return;
    else{
      var index = 0;
      for (var i = 0; i < existingEntries.length; i++) {
        index++;
        var perNr = existingEntries[i].Pernr;

        var guid = existingEntries[i].Zguid;

        var von = existingEntries[i].VonName;
        if(von == null || von == "")
          von = "nicht vorhanden";

        var begD = existingEntries[i].DatumVon;
        var begDate = new Date (begD);
        begD = begDate.toLocaleDateString();
        begD = this.formatDate(begD);

        var begZ = existingEntries[i].UhrzeitVon;
        begZ = this.getTime(begZ);

        var endD = existingEntries[i].DatumBis;
        var endDate = new Date(endD);
        endD = endDate.toLocaleDateString();
        endD = this.formatDate(endD);

        var endZ = existingEntries[i].UhrzeitBis;
        endZ = this.getTime(endZ);

        var std = existingEntries[i].Stunden_beantr;
        var erstellt = existingEntries[i].VonAm;
        if(erstellt == null || erstellt == ""){
          erstellt = "nicht vorhanden";
        }else{
          var erstelltDate = new Date (erstellt);
          erstellt = erstelltDate.toLocaleDateString();
          erstellt = this.formatDate(erstellt);
        }
        var grund = existingEntries[i].Begruendung;
        if(grund == null || grund == "")
          grund = "nicht vorhanden";

        var approveFkAm = existingEntries[i].FkGenehmAm;
        if(approveFkAm == null || approveFkAm == "")
          approveFkAm = "in Bearbeitung";
        else{
        	var apprD = new Date (approveFkAm);
        	approveFkAm = apprD.toLocaleDateString();
        	approveFkAm = this.formatDate(approveFkAm);
        }

        var approveBrAm = existingEntries[i].BrGenehmAm;
        if(approveBrAm == null || approveBrAm == "")
          approveBrAm = "in Bearbeitung";
        else{
        	var apprBrD = new Date (approveBrAm);
        	approveBrAm = apprBrD.toLocaleDateString();
        	approveBrAm = this.formatDate(approveBrAm);
        }
        
        var approveBr = existingEntries[i].BrName;
        if(approveBr == null || approveBr == "")
          approveBr = "nicht vorhanden";

        var gutschrift = existingEntries[i].Versl;
        if(gutschrift == null || gutschrift == ""){
          gutschrift = "nicht vorhanden";
        }
        else if (gutschrift == "1"){
        	gutschrift = "Geld";
        }
        else if (gutschrift == "2"){
        	gutschrift = "Zeit";
        }
        var approvePsAm = existingEntries[i].PsGenehmAm;
        if(approvePsAm == null || approvePsAm == "")
          approvePsAm = "in Bearbeitung";
        else{
        	var apprPsD = new Date (approvePsAm);
        	approvePsAm = apprPsD.toLocaleDateString();
        	approvePsAm = this.formatDate(approvePsAm);
        }
        
        var approvePs = existingEntries[i].PsGenehmName;
        if(approvePs == null || approvePs == "")
          approvePs = "nicht vorhanden";
        var fkKomment = existingEntries[i].FkKommentar;
        var brKomment = existingEntries[i].BrKommentar;
        var psKomment = existingEntries[i].PsKommentar;

        //art
        var infotyp = existingEntries[i].Infotyp; 
        var art = "";
        if (infotyp == "2004")
          art = "Rufbereitschaft";
        else
          art = "Überstunden"; 

        var soFiNoPS =  existingEntries[i].sofei_no_ps;
        
        var punkte = existingEntries[i].EinsatzPunkteAntrag;

        var status = existingEntries[i].Status;
        var statusEntry = this.getStatusEntry(status);
        var imgPath = statusEntry.Picture;
        var imgText = statusEntry.UIText;
        var statusNb = statusEntry.Status;

        var statusShow =  "<img height='30px' width='30px' src='" + imgPath + "'></img><span> " + imgText + "</span>";

        content += "<tbody id='" + guid + "' class='flex-table-tbody'>";
        content += "<tr class='flex-table-tr'>";
        content += "<td class='flex-table-td nowrap'><a href='#' data-extend='#extensible-row-"+index+"' class='link'><i class='icon icon-arrow-right4'></i><span>öffnen</span></a></td>";
        content += "<td class='flex-table-td'>" + art + "</td>";
        content += "<td class='flex-table-td nowrap'>" + statusShow + "</td>";
        content += "<td class='flex-table-td nowrap'>" + von + "</td>";
        content += "<td class='flex-table-td nowrap'>" + begD + "</td>";
        content += "<td class='flex-table-td nowrap'>" + begZ + "</td>";
        content += "<td class='flex-table-td nowrap'>" + endD + "</td>";
        content += "<td class='flex-table-td nowrap'>" + endZ + "</td>";
        content += "<td class='flex-table-td'>" + std + "</td>";
        content += "<td class='flex-table-td nowrap'>" + erstellt + "</td>";
        content += "<td class='flex-table-td'>" + grund + "</td>";
        content += "<td class='flex-table-td'><a href='#' onclick='copy(\""+ guid +"\")'><img src='styles/images/copy-16.png' title='Antrag kopieren'></img></a></td>";
   //     content += "<td class='flex-table-td'><a href='#' onclick='print(\""+ guid +"\")'><img src='styles/images/inbox-5-16.png' title='Antrag ausdrucken'></img></a></td>";
        content += "</tr>";
        content += "</tbody>";

        //drop-down content
        content += "<tbody id='extensible-row-"+index+"' class='flex-table-tbody flex-table-extensible'>";
        content += "<tr class='flex-table-tr'>";
        content += "<td colspan='16' class='flex-table-td nowrap'>";
        content += "<div class='row'>";
        content += "<div class='col-md-6'>";
        content += "<form class='form_event'>";
        content += "<div class='row'>";
        content += "<div class='col-md-12 col-sm-12'>";
        content += "<h3 class='highlight'>" + art + "</h3>";
        content += "</div>";
        content += "</div>";
        content += "<div class='row'>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Name</label>";
        content += "<input type='text' name='' id='' value='" + persDat_ename + "' disabled='' class='form-control input-xs'>";
        content += "</div>";
        content += "</div>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Führungskraft</label>";
        content += "<input type='text' name='' id='' value='" + persDat_fk + "' disabled='' class='form-control input-xs'>";
        content += "</div>";
        content += "</div>";
        content += "</div>";
        content += "<div class='row'>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Gültig ab</label>";
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<input class='form-control input-xs' type='text' value='"+ begD +"'>";
//        }else{
          content += "<input class='form-control input-xs' type='text' disabled='' value='"+ begD +"'>";
//        }
        content += "</div>";
        content += "</div>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Beginnuhrzeit</label>";
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<input type='text' name='' id='' value="+ begZ +" class='form-control input-xs'>";
//        }else{
          content += "<input type='text' name='' id='' value="+ begZ +" disabled='' class='form-control input-xs'>";
//        }
        content += "</div>";
        content += "</div>";
        content += "</div>";
        content += "<div class='row'>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Gültig bis</label>";
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<input type='text' name='' id='' value="+ endD +" class='form-control input-xs'>";
//        }else{
          content += "<input type='text' name='' id='' value="+ endD +" disabled='' class='form-control input-xs'>";
//        }
        content += "</div>";
        content += "</div>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Endeuhrzeit</label>";
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<input type='text' name='' id='' value="+ endZ +" class='form-control input-xs'>";
//        }else{
          content += "<input type='text' name='' id='' value="+ endZ +" disabled='' class='form-control input-xs'>";
//        }
        content += "</div>";
        content += "</div>";
        content += "</div>";
        content += "<div class='row'>";
        content += "<div class='col-md-6 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Begründung</label>";
        content += "<textarea name='' id='' disabled='' data-autogrow='' class='form-control input-xs'>" + grund + "</textarea>";
        content += "</div>";
        content += "</div>";
        content += "<div class='col-md-3 col-sm-6'>";
        content += "<div class='form-group'>";
        content += "<label for=''>Stunden</label>";
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<input type='text' name='' id='abr_stunden' value="+ std +" class='form-control input-xs'>";
//        }else {
          content += "<input type='text' name='' id='abr_stunden' value="+ std +" disabled='' class='form-control input-xs'>";
//        }
        content += "</div>";
        content += "</div>";
        if(art == "Mehrarbeit" && persDat_ort == "Frankfurt"){
          content += "<div class='col-md-3 col-sm-6'>";
          content += "<div class='form-group'>";
          content += "<label for=''>Art der Gutschrift</label>";
          content += "<input type='text' name='' id='' value="+ gutschrift +" disabled='' class='form-control input-xs'>";
          content += "</div>";
          content += "</div>";
        }
        if(art == "Rufbereitschaft" && persDat_ort == "Frankfurt"){
          content += "<div class='col-md-3 col-sm-6'>";
          content += "<div class='form-group'>";
          content += "<label for=''>Einsatzpunkte</label>";
          content += "<input type='text' name='' id='' value="+ punkte +" disabled='' class='form-control input-xs'>";
          content += "</div>";
          content += "</div>";
        }
        content += "</div>";

        //Abrechnung
//        if (statusNb == "8" && art == "Rufbereitschaft"){
//          content += "<div class='row'>";
//          content += "<div class='col-md-12 col-sm-12'>";
//          content += "<h3 class='highlight'>Abrechnung</h3>";
//          content += "</div>";
//          content += "</div>";
//          content += "<div class='row'>";
//          content += "<div class='col-md-6 col-sm-6'>";
//          content += "<div class='form-group'>";
//          content += "<label for=''>Geleistete Stunden</label>";
//          content += "<input type='text' id='Input_Std_Geleistet' class='form-control input-xs'>";
//          content += "</div>";
//          content += "</div>";
//          content += "<div class='col-md-6 col-sm-6'>";
//          content += "<div class='form-group'>";
//          content += "<label for=''>Bevorzügte Gutschrift</label>";
//          content += "<div class='btn-group bootstrap-select btn-xs'>";
//          content += "<select class='selectpicker'  tabindex='-98'>";
//          content += "<option value='1'>Zeitgutschrift in Langzeitkonto</option>";
//          content += "<option value='2'>Geld Auszahlung</option>";
//          content += "</select>";
//          content += "</div>";
//          content += "</div>";
//          content += "</div>";
//          content += "</div>";
//        }

        //buttons 
        content += "<div class='form-actions'>";
        content += "<button class='secondary'>schliessen</button>";

        
//        var currentDate = new Date();
//        if(endD < currentDate){
//        	
//        }
//        if (statusNb == "3" && art == "Rufbereitschaft"){
//          content += "<button class='primary' onclick='abrechnen(\""+ guid +"\")'><span>Antrag abrechnen</span><i class='icon icon-arrow-right4'></i></button>";
//        }
        if (statusNb === "1"){
          content += "<button class='primary' onclick='deleteEntry(\""+ guid +"\"); return false;'><span>Antrag löschen</span><i class='icon icon-arrow-right4'></i></button>";
        }
        else if (statusNb != "9"){
          content += "<button class='primary' onclick='cancelEntry(\""+ guid +"\"); return false;'><span>Antrag stornieren</span><i class='icon icon-arrow-right4'></i></button>";
        } 


        content += "</div>";

        content += "</form>";
        content += "</div>";

        //Genehmigung
        content += "<div class='col-md-4 col-sm-6'>";
        content += "<h3 class='highlight'>Status</h3>";
        content += "<dl class='dynamic'>";
        content += "<dt>Genehmigung Führungskraft</dt>";
        content += "<dd>" + persDat_fk + "</dd>";
        content += "<dt>Zustimmung Betriebsrat</dt>";
        content += "<dd>" + approveBr + "</dd>";

        if(art == "Überstunden" ){ //&& soFiNoPS != "" && soFiNoPS != null
          content += "<dt>Freigabe Personal</dt>";
          content += "<dd>" + approvePs + "</dd>";
        }else{
          content += "<br/><br/>"; 
        }
        content += "<br/>"; 
        content += "<div><h3 class='highlight'>Kommentar</h3></div>"; 
        content += "<div>" + fkKomment + "</div>";
        content += "<div>" + brKomment + "</div>";
        content += "<div>" + psKomment + "</div>";
        content += "</dl>";
        content += "</div>";
        content += "<div class='col-md-2 col-sm-6'>";
        content += "<h3 class='highlight'>&nbsp;</h3>";
        content += "<dl class='dynamic'>";
        content += "<dt>&nbsp;</dt>";
        content += "<dd>" + approveFkAm + "</dd>";
        content += "<dt>&nbsp;</dt>";
        if(art == "Mehrarbeit"){ // && soFiNoPS != "" && soFiNoPS != null
            content += "<dt>&nbsp;</dt>";
            content += "<dd>" + approvePsAm + "</dd>";
          }        
        content += "<dd>" + approveBrAm + "</dd>";


        content += "<br/>"; 
        content += "</dl>";
        content += "</div>"
        content += "</div>"
        content += "</td>";
        content += "</tr>";
        content += "</tbody>";

        //console.log("INFODYP" + infotyp);
      }
    }
    content += "</thead>";
    content += "</table>";
    content += "</section>";





    var oHTML = new sap.ui.core.HTML("free_html", {});

    oHTML.setContent(content);

  //  console.log("in the new view");
    return oHTML;
  },


  getTime: function(time){
    //PT08H00M00S
    var h = time.substr(2, 2);
    var m = time.substr(5, 2);
    var s = time.substr(8, 2);
    var t = h + ":" + m + ":" + s; 
    //console.log("Time: " + t);
    return t;
  },

  getStatusEntry: function (status){
    var ent = null;
    for (var i = 0; i < stati.results.length; i++) {
      var entry = stati.results[i];
      if (entry.Status == status)
        ent=entry;
    }
    return ent;
  },

  formatDate: function(date){
    var d = "";
        var date_str = date.split('.');
        var yy = date_str[2];
        if(date_str[1].length < 2) mm = "0" + date_str[1]; else mm = date_str[1] ;
        if(date_str[0].length < 2) dd = "0" + date_str[0]; else dd = date_str[0] ;
        d = dd + "." + mm + "." + yy;
        return d;
  }

});