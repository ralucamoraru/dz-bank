sap.ui.jsview("mehrarbeit.mehrfachErfassungMA", {

  /** Specifies the Controller belonging to this View. 
  * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
  * @memberOf giftbook.smartTable
  */ 
  getControllerName : function() {
    return "mehrarbeit.mehrfachErfassungMA";
  },

  /** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
  * Since the Controller is given to this method, its event handlers can be attached right away. 
  * @memberOf giftbook.smartTable
  */ 
  createContent : function(oController) {
    var content = "";
    console.log("IN CREATECONTENT");
  //  var antrag = antragTyp;//this.getController().getAntragTyp();
  //  console.log("ANTRAG: " + antrag);    
    content += "<div class='row'>";
    content += "<div id='flex-table-wrapper' class='container'>";
    content += "<div class='form-group-header'>";
    content += "<header><h3>Mehrarbeit Mehrfacherfassung</h3></header>";
    content += "</div>";
    content += "<form action='' id='mehrfachErfassungMA'>";
    
    content += "<div class='row'>";
    content += "<div class='col-md-12 col-sm-12'>";
    content += "<div class='form-group'>";
    content += "<p><b>Achtung:</b> Mehrarbeit an einem Sonntag oder Feiertag ist nur über einen Einzelantrag in MyHR möglich!</p>";
    content += "</div>";
    content += "</div>";
    content += "</div>";
    
    content += "<div class='row'>";
//    content += "<div class='col-md-2 col-sm-2'>";
//    content += "<div class='form-group'>";
//    content += "<label for=''>Antragsart</label>";
//    content += "<input type='text' id='mass_art_ma' value='Mehrarbeit' disabled='' class='form-control'>";
//    content += "</div>";
//    content += "</div>";
    content += "<div class='col-md-2 col-sm-2'>";
    content += "<div class='form-group'>";
    content += "<label for=''>Name</label>";
    content += "<input type='text' id='mass_name_ma' value='Max Mustermann' disabled='' class='form-control'>";
    content += "</div>";
    content += "</div>";
    content += "<div class='col-md-2 col-sm-2'>";
    content += "<div class='form-group'>";
    content += "<label for=''>Führungskraft</label>";
    content += "<input type='text' id='mass_fk_ma' value='Test Führungskraft' disabled='' class='form-control'>";
    content += "</div>";
    content += "</div>";
    content += "<div class='col-md-2 col-sm-2'>";
    content += "<div class='form-group'>";
    content += "<label for=''>Standort</label>";
    content += "<input type='text' id='mass_ort_ma' value='Frankfurt' disabled='' class='form-control'>";
    content += "</div>";
    content += "</div>";
    content += "<div class='col-md-2 col-sm-2'>";
    content += "<div class='form-group'>";
    content += "<label for=''>Betriebsstätte/Gruppe</label>";
    content += "<input type='text' id='mass_gruppe_ma' value='F/PSAP' disabled='' class='form-control'>";
    content += "</div>";
    content += "</div>";
    content += "<div class='col-md-2 col-sm-2'>";
    content += "<div class='form-group'>";
    content += "<label for=''>Kostenstelle</label>";
    content += "<input type='text' id='mass_ks_ma' value='7709' disabled='' class='form-control'>";
    content += "</div>";
    content += "</div>";
 //   content += "<div class='col-md-2 col-sm-2'>";
 //   content += "<div class='form-group'>";
 //   content += "<label for=''>Art der Gutschrift</label>";
 //   content += "<select class='form-control form-select' id='gutschrift_ma'></select>";
 //   content += "</div>";
 //   content += "</div>";    
    content += "</div>";
    
    
    content += "<section class='collapse in mass-entry-section'>";
    content += "<table class='flex-table' id='massEntryTable_ma'>";
    content += "<thead class='flex-table-thead'>";
    content += "<tr class='flex-table-tr'>";
    content += "<th class='flex-table-th'>Beginn</th>";
    content += "<th class='flex-table-th'>Uhrzeit</th>";
    content += "<th class='flex-table-th'>Ende</th>";
    content += "<th class='flex-table-th'>Uhrzeit</th>";
    content += "<th class='flex-table-th'>Stunden</th>";
    content += "<th class='flex-table-th'>Begründung</th>";
  //  content += "<th class='flex-table-th'id='soFei_th_ma'>Sonntags- und Feiertagsarbeit</th>";
 //   content += "<th class='flex-table-th'>Abweichende Kostenstelle</th>";
    content += "<th class='flex-table-th nowrap'></th>";
    content += "</thead>";
    content += "</tr>";
    
    for (var i = 1; i <= 5; i++) {
    	content += "<tbody class='flex-table-tbody'>";
    	content += "<tr class='flex-table-tr'>";
    	content += "<td class='flex-table-td nowrap'><input id='ma_startDate_"+i+"' value='' placeholder='01.01.2018' class='form-control'></td>";
    	content += "<td class='flex-table-td nowrap'><input id='ma_startTime_"+i+"' value='' placeholder='09:00:00' class='form-control'></td>";
    	content += "<td class='flex-table-td nowrap'><input id='ma_endDate_"+i+"' value='' placeholder='01.01.2017' class='form-control'></td>";
    	content += "<td class='flex-table-td nowrap'><input id='ma_endTime_"+i+"' value='' placeholder='18:00:00' class='form-control'></td>";
    	content += "<td class='flex-table-td nowrap'><input id='ma_hours_"+i+"' value='' placeholder='2.00' class='form-control hours'></td>";    	
    	content += "<td class='flex-table-td nowrap'><input id='ma_reason_"+i+"' value='' placeholder='Begründung' class='form-control'></td>";
    //	content += "<td class='flex-table-td nowrap'><select id='ma_SoFei_"+i+"' class='form-control form-select soFeiDisable'></select></td>";
   // 	content += "<td class='flex-table-td nowrap'><input id='ma_ks_"+i+"' value='' placeholder='Abw. KS' class='form-control'></td>";

    	
    	if (i == 5){
    		content += "<td class='flex-table-td nowrap' style='border-bottom: none;'><a href='#' class='plus' id='ma_addButton_"+i+"' onclick='addRowsMehrfacherfassungMA(" + i + ")'><img src='styles/images/plus-8-24.png' title='Anträge hinzufügen'></img></a></td>";
    	}else{
    		content += "<td class='flex-table-td nowrap' style='border-bottom: none;'></td>";
    	}
    	
    	content += "</tr>";
    	content += "</tbody>";
    }
    
//    content += "</thead>";
    content += "</table>";
    content += "</section>";
    content += "<div class='form-actions'><a href='#' class='secondary' onclick='abortMehrfacherfassungMA(); return false;'><span>Abbrechen</span></a>";
    content += "<button id='submit_ru_save' class='primary'  onclick='sendMassDataMA(); return false;'><span>Beantragen</span><i class='icon-calculator'></i></button>";
    content += "</div>";    
    content += "</form>";


    content += "</div>";
    content += "</div>";
    
    var oHTML = new sap.ui.core.HTML("mehrfach_erfassung_ma", {});
    oHTML.setContent(content);
    return oHTML;
  },  
  
  
  getTime: function(time){
    //PT08H00M00S
    var h = time.substr(2, 2);
    var m = time.substr(5, 2);
    var s = time.substr(8, 2);
    var t = h + ":" + m + ":" + s; 
    return t;
  },

  formatDate: function(date){
    var d = "";
        var date_str = date.split('.');
        var yy = date_str[2];
        if(date_str[1].length < 2) mm = "0" + date_str[1]; else mm = date_str[1] ;
        if(date_str[0].length < 2) dd = "0" + date_str[0]; else dd = date_str[0] ;
        d = dd + "." + mm + "." + yy;
        return d;
  }

});