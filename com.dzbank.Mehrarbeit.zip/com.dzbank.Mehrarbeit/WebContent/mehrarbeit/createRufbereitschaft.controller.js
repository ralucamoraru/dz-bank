sap.ui.controller("mehrarbeit.createRufbereitschaft", {

    viewModus: VIEW_MODUS_CREATE,

    /**
     * Called when a controller is instantiated and its View controls (if
     * available) are already created. Can be used to modify the View before it
     * is displayed, to bind event handlers and do other one-time
     * initialization.
     * 
     * @memberOf giftbook.mainHTML
     */
    onInit: function() {

      },

    onAfterRendering: function() {

        /**
         * Daten laden
         */
        this.setPersData();
  //      this.setSoFeiOptions();

        //this.setFieldsMandatory();
      //  getSelView(1,1);        
    },

    setPersData: function() {
     //   document.getElementById("Input_Pernr").value = persDat_pernr;
        document.getElementById("Input_Name").value = persDat_name;
        document.getElementById("Input_FKName").value = persDat_fk;
        document.getElementById("Input_Gruppe").value = persDat_gruppe;
        document.getElementById("Input_KS").value = persDat_ks;
        document.getElementById("Input_Ort").value = persDat_ort;
        
        //set data in the Date fields
        var date1 = new Date();
        var date2 = new Date();//new Date(Date.now() + 864e5); 
        document.getElementById("input_DatumAb").placeholder = this.getFormatedCurrentDate(date1);
        document.getElementById("input_DatumAb").value = this.getFormatedCurrentDate(date1);
        document.getElementById("input_DatumBis").placeholder = this.getFormatedCurrentDate(date2);
        document.getElementById("input_DatumBis").value = this.getFormatedCurrentDate(date2);
        
        var diff = date2.valueOf() - date1.valueOf();
        var diffInHours = diff/1000/60/60;
        console.log("Auto hours: " + diff + " in hours: " + diffInHours);
        document.getElementById("Input_Stunden").value = diffInHours;
        document.getElementById("Input_Stunden").placeholder = diffInHours;
        
        
    },
    
    refreshHours: function(){
      console.log("Refresh Hours method called...");
      if ($("#input_DatumAb").val() && $("#input_DatumBis").val() && $("#input_ZeitAb").val() && $("#input_ZeitBis").val())
      {
        var date1 = this.getDateFromString($("#input_DatumAb").val().toString(), $("#input_ZeitAb").val().toString());
        var date2 = this.getDateFromString($("#input_DatumBis").val(), $("#input_ZeitBis").val());
        console.log("EXAMPLE: Date: " + $("#input_DatumAb").val() + " Time: " + $("#input_ZeitAb").val());
        console.log("Date 1 " + date1 + " Date 2 " + date2);
        var diff = date2.valueOf() - date1.valueOf();
          var diffInHours = diff/1000/60/60;
          var stdString = diffInHours + ".00";
          document.getElementById("Input_Stunden").value = diffInHours.toFixed(2);
          console.log("Hours..." + diffInHours);
      }
      else{
        console.log("fields not filled...");
      }
    },

    checkFields: function() {

        var checker_tmp = {};
        checker_tmp.result = true;
        checker_tmp.message = "";
        checker_tmp.feldId = "";
        
        if($(".data-required").val() === ""){
          console.log("Return Data required ");
          return checker_tmp;
        }
        
        var begruendung =  document.getElementById("Input_Reason").value;
      //  var so = document.getElementById("so_fei").value;
        if (begruendung === "" || begruendung === " ") {
            checker_tmp.result = false;
            checker_tmp.message = "Geben Sie eine Begründung ein!";
            checker_tmp.fieldId = "Input_Reason";
            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
            return checker_tmp;
        }
        
        var stunden =  document.getElementById("Input_Stunden").value;
        if (stunden === "") {
            checker_tmp.result = false;
            checker_tmp.message = "Geben Sie die Stunden Anzahl ein!";
            checker_tmp.fieldId = "Input_Stunden";
            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
            return checker_tmp; 
        }
        
        var numCheck = $("#Input_Stunden").val().replace(",",".") / 1;
        
        var num = parseFloat($("#Input_Stunden").val().replace(",",".")).toFixed(2);
        if( !isNaN(num) && !isNaN(numCheck)){
          if(num <= 0){
                checker_tmp.result = false;
                checker_tmp.message = "Anzahl muss größer als 0 Stunden sein!";
                checker_tmp.fieldId = "Input_Stunden";
                console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
                return checker_tmp;
          }
          else if (num > 144){
                checker_tmp.result = false;
                checker_tmp.message = "Anzahl darf nicht größer als 144 Stunden sein!";
                checker_tmp.fieldId = "Input_Stunden";
                console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
                return checker_tmp;
          }
        }else{
            checker_tmp.result = false;
            checker_tmp.message = "Bitte geben Sie eine gültige Zahl ein!";
            checker_tmp.fieldId = "Input_Stunden";
            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
            return checker_tmp; 
        }
        
        /* Datum Ab */
        var date_str1 = $("#input_DatumAb").val().split('.');
        var yy = date_str1[2];
        if(date_str1[1].length < 2) mm = "0" + date_str1[1]; else mm = date_str1[1] ;
        if(date_str1[0].length < 2) dd = "0" + date_str1[0]; else dd = date_str1[0] ;
        var dateAbString = yy +"-" + mm + "-" + dd + "T00:00:00";        
        var startDate = new Date(dateAbString);
        
        /* Datum Bis */
        var date_str2 = $("#input_DatumBis").val().split('.');
        var yy = date_str2[2];
        if(date_str2[0].length < 2) dd = "0" + date_str2[0]; else dd = date_str2[0] ;
        if(date_str2[1].length < 2) mm = "0" + date_str2[1]; else mm = date_str2[1] ;
        var dateBisString = yy +"-" + mm + "-" + dd + "T00:00:00";
        var endDate = new Date(dateBisString);
        
        if(startDate > endDate){
            checker_tmp.result = false;
            checker_tmp.message = "Beginn Datum ist größer als Startdatum!";
            checker_tmp.fieldId = "input_DatumAb";
            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
            return checker_tmp;
        }
        var currentDate = new Date();
        if(startDate < currentDate){
            checker_tmp.result = false;
            checker_tmp.message = "Rückwirkende Rufbereitschaft darf nicht beantragt werden!";
            checker_tmp.fieldId = "input_DatumAb";
            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
            return checker_tmp;

        }
        

              
/*         Datum 
        if (document.getElementById("input_datum").value === "") {
            checker_tmp.result = false;
            checker_tmp.message = "Geben Sie ein Datum ein!";
            checker_tmp.fieldId = "input_datum";
            return checker_tmp;
        }
        var d_str = $("#input_datum").val().split('.');
        if(d_str.length != 3){
            checker_tmp.result = false;
            checker_tmp.message = "Datum ung�ltig (g�ltiges Format: tt.mm.jjjj)";
            checker_tmp.fieldId = "input_datum";
            return checker_tmp;
        }else{
          if(d_str[2].toString().length != 4 ){
                checker_tmp.result = false;
                checker_tmp.message = "Datum ung�ltig (g�ltiges Format: tt.mm.jjjj)";
                checker_tmp.fieldId = "input_datum";
                return checker_tmp;
          }
        }
        
        var date_heute = new Date();
        var date_input_jahr = d_str[2];
        var date_input_monat = d_str[1];
        var date_input_tag = d_str[0];
        var date_input = new Date(date_input_jahr+"/"+date_input_monat+"/"+date_input_tag+" "+"00:00:00");
        
        if(date_input > date_heute){
            checker_tmp.result = false;
            checker_tmp.message = "Datum liegt in der Zukunft!";
            checker_tmp.fieldId = "input_datum";
            return checker_tmp;
        }*/
 
        console.log("end checker");
        console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
        return checker_tmp;
    },
    
    resetValuesBack: function(){

    },
       
    
    sendDataRufbereitschaft: function() {
      var lv_status;
      var lv_response;

      console.log("Sending data Rufbereitschaft");
      var controller = this;
      var testMsg = false;
        var checker = this.checkFields();
        if (!checker.result) {
          sap.m.MessageBox.show(checker.message,{
            icon: sap.m.MessageBox.Icon.INFORMATION,
            onClose: function(){
              testMsg = true;
              console.log("closing message...");
        }
          });
        //  getSelView(1,1); 
          $("#"+checker.fieldId).focus();
          console.log("bla bla...");
        } else {

            var datum;
            var oData = {};

            /* Static fields */
            //oData.Art = "Rufbereitschaft";
            oData.Infotyp = "2004";
            oData.Subty = "99";
            oData.Action = "BEANTRAGEN";
            
            /* Fields from User Service */
            oData.Pernr = persDat_pernr;
          //  oData.Name = persDat_name;
            oData.VonUser = persDat_pernr;
            oData.VonName = persDat_name;
            oData.FkUser = persDat_fk_user;
            oData.FkName = persDat_fk;
            oData.Kostl = persDat_ks;
            
            /* Fields from UI */
        //    oData.Aufnr = document.getElementById("Input_AbwKS").value;
            
            oData.Begruendung =  document.getElementById("Input_Reason").value;
//            var sf = document.getElementById("so_fei").value;
//            if ((grund === "" || grund === " ")  && !(sf === "" || sf === " ")){
//            	oData.Begruendung = this.getSoFeiOptionForID();
//            } else{
//            	oData.Begruendung =  grund;
//            }
            
            
            oData.Stunden_beantr =  document.getElementById("Input_Stunden").value;
            
            
            /* Datum Ab */
            var date_str1 = $("#input_DatumAb").val().split('.');
            var yy = date_str1[2];
            if(date_str1[1].length < 2) mm = "0" + date_str1[1]; else mm = date_str1[1] ;
            if(date_str1[0].length < 2) dd = "0" + date_str1[0]; else dd = date_str1[0] ;
            oData.DatumVon = yy +"-" + mm + "-" + dd + "T00:00:00";
            console.log("DATUMMMM: " + oData.DatumVon);
            /* Uhrzeit Ab */
            var time_str1 = $("#input_ZeitAb").val();
            oData.UhrzeitVon = this.formatTime(time_str1);;
            
            /* Datum Bis */
            var date_str2 = $("#input_DatumBis").val().split('.');
            var yy = date_str2[2];
            if(date_str2[0].length < 2) dd = "0" + date_str2[0]; else dd = date_str2[0] ;
            if(date_str2[1].length < 2) mm = "0" + date_str2[1]; else mm = date_str2[1] ;
            oData.DatumBis = yy +"-" + mm + "-" + dd + "T00:00:00";
            
            /* Uhrzeit Bis */
            var time_str2 = $("#input_ZeitBis").val();
            oData.UhrzeitBis = this.formatTime(time_str2);            
            
            
            /* aktuelles Datum und Uhrzeit */                     
            var currDate = new Date(); 
            var time = currDate.toLocaleTimeString();
            var currDateString = currDate.toISOString();            
            currDateString = currDateString.substr(0, currDateString.indexOf('.')); 
            oData.VonAm = currDateString;
          //  oData.VonUm = this.formatTime(time);

     //       oData.SonnFeiertag = document.getElementById("so_fei").value;
            
           // console.log(odata);
            
            var view = this.getView();
            var dataModdel = view.getModel("oData_RU");

          dataModdel.create("/RUMSet", oData, {
            async: false,
            error: function(response) {
            	console.log("ERRORRRRRRR....");            
            	lv_status = "error";
            	lv_response = response;
              },
              success: function(response, status) {
                lv_status = status;
                lv_response = response;
                console.log("Rufbereitschaft gespeichert mit Status: " + lv_status.statusText);

              }

          }); 

          if (lv_status === "error"){  
        	  var text = lv_response.response.body.toString();   
        	  parser = new DOMParser();
          	  xmlDoc = parser.parseFromString(text,"text/xml"); 
          	  var msg = "Fehler: " + xmlDoc.getElementsByTagName("errordetail")[0].childNodes[1].textContent;
              sap.m.MessageBox.error(msg, {
                  onClose: function(){
                    console.log("error occured...");
                    console.log("RESPONSE ON ERROR: " + msg);
                    
                    location.reload();
                    //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
                  }
              });
          }
          else if(lv_status != "undefined"){
            if(lv_status.statusText === "Created"){
              var sapMsg = lv_status.headers['sap-message'];
              if(sapMsg && sapMsg != "undefined" && sapMsg != ""){
            	  var text = sapMsg.toString();
	          	  parser = new DOMParser();
	          	  xmlDoc = parser.parseFromString(text,"text/xml"); 
	          	  var typ = xmlDoc.getElementsByTagName("severity")[0].textContent;
	          	  if (typ == "warning" ){
	              	  var msg = xmlDoc.getElementsByTagName("details")[0].childNodes[0].getElementsByTagName("message").textContent;
	                  sap.m.MessageBox.success("Gespeichert mit der Warnung: " + msg, {
	                    onClose: function(){
	                      console.log("save rufbereitschaft on close - warining...");
	                      location.reload();
	                      //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
	                    }
	                  });          	           	  
	              }
	          	  else{
	          		sap.m.MessageBox.success("Erfolgreich gespeichert!", {
	                  onClose: function(){
	                    console.log("save rufbereitschaft on close - erfolg...");
	                    location.reload();
	                    //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
	                  }
	                });          		  
	          	  }
              }else{
          		sap.m.MessageBox.success("Erfolgreich gespeichert!", {
	                  onClose: function(){
	                    console.log("save rufbereitschaft on close - erfolg...");
	                    location.reload();
	                    //sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
	                  }
	            });    
              }
            } 
          }
          
//          // RESET DATA
          controller. resetDataRufbereitschaft();
//          location.reload();
            getSelView(1,"leer");
           } 

    }, 
    
    parseResponse: function(text){
    	console.log("in parser...");

    },
    
    copyRufbereitschaft: function(id, entry){
      console.log("COPY Rufbereitschaft Methode!");
      getSelView(1,1);
      var grund = entry["0"].Begruendung;
      document.getElementById("Input_Reason").value = entry["0"].Begruendung;
      document.getElementById("Input_AbwKS").value = entry["0"].Aufnr;
      document.getElementById("Input_Stunden").value = entry["0"].Stunden_beantr;

    var begD = entry["0"].DatumVon;
    var begDate = new Date (begD);
    begD = begDate.toLocaleDateString();
    begD = this.formatDate(begD);

    var begZ = entry["0"].UhrzeitVon;
    begZ = this.getTime(begZ);

    var endD = entry["0"].DatumBis;
    var endDate = new Date(endD);
    endD = endDate.toLocaleDateString();
    endD = this.formatDate(endD);

    var endZ = entry["0"].UhrzeitBis;
    endZ = this.getTime(endZ);

//      document.getElementById("input_DatumAb").value = begD.toString();
//      document.getElementById("input_ZeitAb").value = begZ.toString();
//      document.getElementById("input_DatumBis").value = endD.toString();
//      document.getElementById("input_ZeitBis").value = endZ.toString();

      document.getElementById("input_DatumAb").value = entry["0"].DatumVon;
      document.getElementById("input_ZeitAb").value = entry["0"].UhrzeitVon;
      document.getElementById("input_DatumBis").value = entry["0"].DatumBis;
      document.getElementById("input_ZeitBis").value = entry["0"].UhrzeitBis;

      
      //document.getElementById("so_fei").value = entry["0"].SonnFeiertag;
      //var objSelect = document.getElementById("so_fei");

//      $("#so_fei").val(entry["0"].SonnFeiertag).trigger('change');


    },
    
  getTime: function(time){
    //PT08H00M00S
    var h = time.substr(2, 2);
    var m = time.substr(5, 2);
    var s = time.substr(8, 2);
    var t = h + ":" + m + ":" + s; 
    console.log("Time: " + t);
    return t;
  },

  formatDate: function(date){
    var d = "";
        var date_str = date.split('.');
        var yy = date_str[2];
        if(date_str[1].length < 2) mm = "0" + date_str[1]; else mm = date_str[1] ;
        if(date_str[0].length < 2) dd = "0" + date_str[0]; else dd = date_str[0] ;
        d = dd + "." + mm + "." + yy;
        return d;
  },

  getDateFromString: function(date, time){
	  console.log("getDateFromString METHOD: " + date);
        var date_str = date.split('.');
        var yy = date_str[2];
      
        if(date_str[0].length < 2) dd = "0" + date_str[0]; else dd = date_str[0] ;
        if(date_str[1].length < 2) mm = "0" + date_str[1]; else mm = date_str[1] ;

        var time_str = time.split(':');
        if(time_str[0].length < 2) std = "0" + time_str[0]; else std = time_str[0] ;
        if(time_str[1].length < 2) min = "0" + time_str[1]; else min = time_str[1] ;
        if(time_str[2].length < 2) sec = "0" + time_str[2]; else sec = time_str[2] ;
        var retTime = "T" + std +":" + min + ":" + sec;   
        
        var dateString = yy +"-" + mm + "-" + dd + retTime;
        console.log("getDateFromString ENDDATE: " + dateString);
  //      SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-ddTHH:mm:ssZ");
    //    var endDate = outputFormat.format(dateString);
        var endDate = Date.parse(dateString.toString());
        console.log("getDateFromString ENDDATE AFTER: " + endDate.toString());
        return endDate;
  },

  getFormatedCurrentDate: function(dateToFormat){
    var dd = dateToFormat.getDate();
    var mm = dateToFormat.getMonth()+1; //January is 0!
    var yyyy = dateToFormat.getFullYear();

    if(dd<10){
        dd='0'+dd;
    } 

    if(mm<10){
        mm='0'+mm;
    } 

    var dateToFormat = dd+'.'+mm+'.'+yyyy;
    return dateToFormat;
  },
    
    setSoFeiOptions: function(){
      var options = soFeiOptions;
      var soFeiSelect = document.getElementById("so_fei");

      for (var i = 0; i < options.results.length; i++) {

        var optID = options.results[i].Sofei;
        var optText = options.results[i].Sofet;


            newOption = document.createElement("option");
            newOption.text = optText;
            newOption.value = optID;
            newOption.setAttribute("id", "selectSoFie_" + i);
            
            soFeiSelect.add(newOption);
      }
    },
    
    getSoFeiOptionForID: function(){
    	console.log("in getSoFeiOptionForID...");
        var options = soFeiOptions;
        var soFeiID = document.getElementById("so_fei").value;
        console.log("ID..." + soFeiID);
        var res = "N/A";
        for (var i = 0; i < options.results.length; i++) {

          var optID = options.results[i].Sofei;
          var optText = options.results[i].Sofet;
          if (optID === soFeiID) {
        	  res = optText;
          }
        }
        console.log("Res..." + res);
        return res;
      },
    
    formatTime: function(time){
      var retTime = "";
      var time_str = time.split(':');
        if(time_str[0].length < 2) std = "0" + time_str[0]; else std = time_str[0] ;
        if(time_str[1].length < 2) min = "0" + time_str[1]; else min = time_str[1] ;
        if(time_str[2].length < 2) sec = "0" + time_str[2]; else sec = time_str[2] ;
        retTime = "PT" + std +"H" + min + "M" + sec + "S";      
        return retTime;
    },
    
    resetDataRufbereitschaft: function() {
        var oData = {};
        console.log("reset data rufbereitschaft...");

        $("#Input_AbwKS").val("");
        $("#Input_Reason").val("");
        $("#Input_Stunden").val("");
        $("#input_DatumAb").val("");
        $("#input_ZeitAb").val("");
        $("#input_DatumBis").val("");
        $("#input_ZeitBis").val("");
        $("#so_fei").val("0").trigger('change');
     //   $("#so_fei").prop("selectedIndex",0).trigger('change');
    },
        
    toogleFieldsReadOnly: function(readOnly) {

        console.log("toogleFieldsReadOnly ...");

    },

    parseDateToString: function(jsonDate) {
        var date = new Date(jsonDate.toString());
        var tag = date.getDate();
        var monat = date.getMonth() + 1;
        var jahr = date.getFullYear();
        if (tag.toString().length < 2) tag = "0" + tag;
        if (monat.toString().length < 2) monat = "0" + monat;
        return tag + "." + monat + "." + jahr;
    }

});