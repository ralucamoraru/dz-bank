sap.ui.controller("mehrarbeit.mehrfachErfassungMA", {


    /**
     * Called when a controller is instantiated and its View controls (if
     * available) are already created. Can be used to modify the View before it
     * is displayed, to bind event handlers and do other one-time
     * initialization.
     * 
     * @memberOf 
     */
    onInit: function() {

    	},

    onAfterRendering: function() {
    	    	
        /**
         * Daten laden
         */
        this.setPersData();
  //      this.setSoFeiOptions(5);
 //       this.setGutschriftOptions();
    	this.setDatePicker(5);
    },

    setPersData: function() {
     //   document.getElementById("Input_Pernr").value = persDat_pernr;
    	
        document.getElementById("mass_name_ma").value = persDat_ename;
        document.getElementById("mass_fk_ma").value = persDat_fk;
        document.getElementById("mass_gruppe_ma").value = persDat_gruppe;
        document.getElementById("mass_ks_ma").value = persDat_ks;
        document.getElementById("mass_ort_ma").value = persDat_ort;
        
    },
    
    setGutschriftOptions: function(){
        var gutschriftSelect = document.getElementById("gutschrift_ma");
        var optGeld =  document.createElement("option");
        optGeld.text = "Geld";
        optGeld.value = "1";
        optGeld.setAttribute("id", "selectGutschrift_ma_1");
        gutschriftSelect.add(optGeld);
        var optZeit =  document.createElement("option");
        optZeit.text = "Zeit";
        optZeit.value = "2";
        optZeit.setAttribute("id", "selectGutschrift_ma_2");
        gutschriftSelect.add(optZeit);   

      },
      
      setDatePicker: function(nbRows){
    	  for (var i = 1; i <= nbRows; i++) {
	  		$( "#ma_startDate_"+i ).datepicker({ dateFormat: 'dd.mm.yy' });
			$( "#ma_endDate_"+i ).datepicker({ dateFormat: 'dd.mm.yy' });
			$( "#ma_startTime_"+i ).timepicker({ 'scrollDefault': 'now', 'timeFormat': 'H:i:s'});
			$( "#ma_endTime_"+i ).timepicker({ 'scrollDefault': 'now', 'timeFormat': 'H:i:s'});    	
    	  }
      },

    
    refreshHoursMehrfachMA: function(i){
        console.log("Refresh Hours method called for index: " + i);
        if ($("#ma_startDate_"+i).val() && $("#ma_endDate_"+i).val() && $("#ma_startTime_"+i).val() && $("#ma_endTime_"+i).val())
        {
          var date1 = this.getDateFromString($("#ma_startDate_"+i).val(), $("#ma_startTime_"+i).val());
          var date2 = this.getDateFromString($("#ma_endDate_"+i).val(), $("#ma_endTime_"+i).val());
          console.log("Date 1 " + date1 + " Date 2 " + date2);
          var diff = date2.valueOf() - date1.valueOf();
            var diffInHours = diff/1000/60/60;
            var stdString = diffInHours + ".00";
            document.getElementById("ma_hours_"+i).value = diffInHours.toFixed(2);
            console.log("Hours..." + diffInHours.toFixed(2));
            console.log("Hours in field..." + document.getElementById("ma_hours_"+i).value);
        }
        else{
          console.log("fields not filled...");
        }
      },

    
    addRowsMehrfacherfassungMA: function(position){
      content = "";
      if (position < 20){
	      for (var i = position + 1; i <= position + 5; i++) {
	      	content += "<tbody class='flex-table-tbody'>";
	      	content += "<tr class='flex-table-tr'>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_startDate_"+i+"' value='' placeholder='01.01.2018' class='form-control' ></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_startTime_"+i+"' value='' placeholder='09:00:00' class='form-control' ></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_endDate_"+i+"' value='' placeholder='01.01.2017' class='form-control' ></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_endTime_"+i+"' value='' placeholder='18:00:00' class='form-control' ></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_hours_"+i+"' value='' placeholder='2.00' class='form-control' ></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_reason_"+i+"' value='' placeholder='Begründung' class='form-control'></td>";
	     // 	content += "<td class='flex-table-td nowrap'><select id='ma_SoFei_"+i+"' class='form-control form-select'></select></td>";
	      	content += "<td class='flex-table-td nowrap'><input id='ma_ks_"+i+"' value='' placeholder='Abw. KS' class='form-control'></td>";
	      	if (i == position + 5 && position < 15){
	      		content += "<td class='flex-table-td nowrap' style='border-bottom: none;'><a href='#' class='plus' id='ma_addButton_"+i+"' onclick='addRowsMehrfacherfassungMA(" + i + ")'><img src='styles/images/plus-8-24.png' title='Anträge hinzufügen'></img></a></td>";
	      	}else{
	      		content += "<td class='flex-table-td nowrap' style='border-bottom: none;'></td>";
	      	}
	      	
	      	content += "</tr>";
	      	content += "</tbody>";
	      }
	      $('#massEntryTable_ma').append(content);
	      $("#ma_addButton_"+position).hide();	
	      this.setSoFeiOptions(position + 5);  
	      this.setDatePicker(position + 5);
	      $('select').addClass('selectpicker');
	      $('.selectpicker').selectpicker();
//	      this.setAntragTyp(position+5, 1);

      }else{
          sap.m.MessageBox.error("Sie können maximal 20 Anträge erfassen!", {
              onClose: function(){
                console.log("Maximale Anzahl der Anträge erreicht...");
              }
          }); 
      }
    },  
    
    checkFields: function() {

        var checker_tmp = {};
        checker_tmp.result = true;
        checker_tmp.message = "";
        checker_tmp.feldId = "";
        
        if($(".data-required").val() === ""){
        	console.log("Return Data required ");
        	return checker_tmp;
        }
        var i = 1;
		while (i <=20 && $("#ma_startDate_"+i).length > 0) {
			if (document.getElementById("ma_hours_"+i).value != null && document.getElementById("ma_hours_"+i).value != ""){
		        var begruendung =  document.getElementById("ma_reason_"+i).value;
		        if (begruendung === "" || begruendung === " ") {
		            checker_tmp.result = false;
		            checker_tmp.message = "Geben Sie eine Begründung ein!";
		            checker_tmp.fieldId = "ma_reason_"+i;
		            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
		            return checker_tmp;
		        }
		        
		        var stunden =  document.getElementById("ma_hours_"+i).value;
		        if (stunden === "") {
		            checker_tmp.result = false;
		            checker_tmp.message = "Geben Sie die Stunden Anzahl ein!";
		            checker_tmp.fieldId = "ma_hours_"+i;
		            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
		            return checker_tmp; 
		        }
		        
		        var numCheck = $("#ma_hours_"+i).val();//.replace(",",".") / 1;
		        
		        var num = parseFloat($("#ma_hours_"+i).val()); //.replace(",",".")).toFixed(2);
		        
		        if( !isNaN(num) && !isNaN(numCheck)){
		        	if(num <= 0){
		                checker_tmp.result = false;
		                checker_tmp.message = "Der eingegebene Stunden Anzahl muss größer als 0 sein!";
		                checker_tmp.fieldId = "ma_hours_"+i;
		                console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
		                return checker_tmp;
		        	}
		        }else{
		            checker_tmp.result = false;
		            checker_tmp.message = "Bitte geben Sie eine gültige Zahl ein!";
		            checker_tmp.fieldId = "ma_hours_"+i;
		            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
		            return checker_tmp; 
		        }
		        
		        /* Datum Ab */
		        var date_str1 = $("#ma_startDate_"+i).val().split('.');
		        var yy = date_str1[2];
		        if(date_str1[1].length < 2) mm = "0" + date_str1[1]; else mm = date_str1[1] ;
		        if(date_str1[0].length < 2) dd = "0" + date_str1[0]; else dd = date_str1[0] ;
		        var dateAbString = yy +"-" + mm + "-" + dd + "T00:00:00";        
		        var startDate = new Date(dateAbString);
		        
		        /* Datum Bis */
		        var date_str2 = $("#ma_endDate_"+i).val().split('.');
		        var yy = date_str2[2];
		        if(date_str2[0].length < 2) dd = "0" + date_str2[0]; else dd = date_str2[0] ;
		        if(date_str2[1].length < 2) mm = "0" + date_str2[1]; else mm = date_str2[1] ;
		        var dateBisString = yy +"-" + mm + "-" + dd + "T00:00:00";
		        var endDate = new Date(dateBisString);
		        
		        if(startDate > endDate){
		            checker_tmp.result = false;
		            checker_tmp.message = "Beginn Datum ist größer als Startdatum!";
		            checker_tmp.fieldId = "#ma_startDate_"+i;
		            console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
		            return checker_tmp;	
		        }
		        
			}
			i++;
		}

        console.log("end checker");
        console.log("CHECKER msg: " + checker_tmp.message + "field" + checker_tmp.feldId);
        return checker_tmp;
    },
    
    resetValuesBack: function(){
    	
    },
       
    
    sendMassDataMA: function() {
    	var lv_status = [];
    	var lv_response = [];

    	console.log("Sending data Mehrfacherfassung");
    	var controller = this;
    	
        var checker = this.checkFields();
        if (!checker.result) {
        	
        } else {

          nbCreated = 0;
           var i = 1;
           var msg = "";
           while (i <=20 && $("#ma_startDate_"+i).length > 0) {
				if (document.getElementById("ma_hours_"+i).value != null && document.getElementById("ma_hours_"+i).value != ""){
					var datum;
		            var oData = {};
		
		            
		            /* Static fields */
		            //oData.Art = "Rufbereitschaft";
		            if (antragTyp == 1){
		            	//RUFBEREITSCHAFT
		            	console.log("//RUFBEREITSCHAFT//");
		                oData.Infotyp = "2004";
		                oData.Subty = "99";
		            	
		            }else if (antragTyp == 2){
		            	//RUFBEREITSCHAFT
		            	console.log("//MEHRARBEIT//");
			            oData.Infotyp = "2007";
			            oData.Subty = "01";
		            }
		            

		            oData.Action = "BEANTRAGEN";
		            oData.Status = "1";
		            /* Fields from User Service */
		            oData.Pernr = persDat_pernr;
		          //  oData.Name = persDat_name;
		            oData.VonUser = persDat_pernr;
		            oData.VonName = persDat_name;
		            oData.FkUser = persDat_fk_user;
		            oData.FkName = persDat_fk;
		            oData.Kostl = persDat_ks;
		            
		            /* Fields from UI */
		     //       oData.Aufnr = document.getElementById("ma_ks_"+i).value;
		            oData.Begruendung =  document.getElementById("ma_reason_"+i).value;
		            oData.Stunden_beantr =  document.getElementById("ma_hours_"+i).value;
		            
		            
		            /* Datum Ab */
		            var date_str1 = $("#ma_startDate_"+i).val().split('.');
		            var yy = date_str1[2];
		            if(date_str1[1].length < 2) mm = "0" + date_str1[1]; else mm = date_str1[1] ;
		            if(date_str1[0].length < 2) dd = "0" + date_str1[0]; else dd = date_str1[0] ;
		            oData.DatumVon = yy +"-" + mm + "-" + dd + "T00:00:00";
		            
		            /* Uhrzeit Ab */
		            var time_str1 = $("#ma_startTime_"+i).val();
		            oData.UhrzeitVon = this.formatTime(time_str1);
		            
		            /* Datum Bis */
		            var date_str2 = $("#ma_endDate_"+i).val().split('.');
		            var yy = date_str2[2];
		            if(date_str2[0].length < 2) dd = "0" + date_str2[0]; else dd = date_str2[0] ;
		            if(date_str2[1].length < 2) mm = "0" + date_str2[1]; else mm = date_str2[1] ;
		            oData.DatumBis = yy +"-" + mm + "-" + dd + "T00:00:00";
		            
		            /* Uhrzeit Bis */
		            var time_str2 = $("#ma_endTime_"+i).val();
		            oData.UhrzeitBis = this.formatTime(time_str2);            
		            
		            
		            /* aktuelles Datum und Uhrzeit */                     
		            var currDate = new Date(); 
		            var time = currDate.toLocaleTimeString();
		            var currDateString = currDate.toISOString();            
		            currDateString = currDateString.substr(0, currDateString.indexOf('.')); 
		            oData.VonAm = currDateString;
		            //oData.VonUm = this.formatTime(time);
		
		            oData.Versl = "1"; //document.getElementById("gutschrift_ma").value;
		            oData.SonnFeiertag = "0";//document.getElementById("ma_SoFei_"+i).value;
		            
		            var view = this.getView();
		            var dataModdel = view.getModel("oData_RU");
		            console.log("Mehrfacherfassung " + i+ " before create!");
		            dataModdel.create("/RUMSet", oData, {
		             //   async: false,
		            	error: function(response) {
		            		lv_status[i] = "error";
		            		lv_response[i] = response;
		                },
		                success: function(response, status) {
		                	console.log("Mehrfacherfassung " + i+ " gespeichert!");
		                	lv_status[i] = status;
		                	lv_response[i] = response;
		                	nbCreated++;
		                	//sap.m.MessageBox.success("Erfolgreich gespeichert - Mehrfacherfassung.");
		                }
		
		            }); 
		            
		            if (lv_status[i] === "error"){ 
			        	  console.log("error occured in Antrag: " + lv_response);
				      	  var text = lv_response[i].response.body.toString();   
				    	  parser = new DOMParser();
				      	  xmlDoc = parser.parseFromString(text,"text/xml"); 
			          	  msg = msg + "Fehler im Antrag Nr. " + i + ": " + xmlDoc.getElementsByTagName("errordetail")[0].childNodes[1].textContent;

			          }
			          else if(lv_status[i] != "undefined"){
			            if(lv_status[i].statusText === "Created"){
			              msg = msg + "Antrag Nr. " + i + " wurde erfolgreich gespeichert!\r\n";	

			            } 
			          }		            
		          
				}
				i++;
			}

				console.log("MESSAGE: "+msg);
			//	sap.m.MessageBox.success(msg);
				sap.m.MessageBox.show(msg, {
					actions: sap.m.MessageBox.Action.OK,  
					initialFocus: sap.m.MessageBox.Action.OK,
	        		onClose: function(oAction){		        			
	        			console.log("save rufbereitschaft on close...");	
	        			location.reload();
	        			//sap.ui.getCore().byId("antragtableJS").getModel().refresh(true);
					}
	        	});


       } 

    }, 
    
    
//    setSoFeiOptions: function(rowNb){
//    	var options = soFeiOptions;
//    	
//    	j = 1;
//    	while (j <=rowNb) {
//    		
//	    	var soFeiSelect = document.getElementById("ma_SoFei_"+j);	    	
//	    	for (var i = 0; i < options.results.length; i++) {
//	    		
//	    		var optID = options.results[i].Sofei;
//	    		var optText = options.results[i].Sofet;
//	    		
//	    		//console.log("Options: " + optID + " / " + optText);
//	    		
//	            newOption = document.createElement("option");
//	            newOption.text = optText;
//	            newOption.value = optID;
//	            newOption.setAttribute("id", "ma_selSoFie_" + j+"_"+i);
//	            
//	            soFeiSelect.add(newOption);    		
//	    	}
//	    	j++;
//    	}
//    },
    
    formatTime: function(time){
    	var retTime = "";
    	var time_str = time.split(':');
        if(time_str[0].length < 2) std = "0" + time_str[0]; else std = time_str[0] ;
        if(time_str[1].length < 2) min = "0" + time_str[1]; else min = time_str[1] ;
        if(time_str[2].length < 2) sec = "0" + time_str[2]; else sec = time_str[2] ;
        retTime = "PT" + std +"H" + min + "M" + sec + "S";      
        return retTime;
    },
    
    resetDataMehrfacherfassungMA: function() {
        var i = 1;
		while (i <=5) {
			$("#ma_startDate_"+i).val("");
			$("#ma_startTime_"+i).val("");
			$("#ma_endDate_"+i).val("");
			$("#ma_endTime_"+i).val("");
			$("#ma_reason_"+i).val("");
			$("#ma_hours_"+i).val("");
			$("#ma_ks_"+i).val("");
			//$("#ma_SoFei_"+i).val("0").trigger('change');
			i++;
		}
        console.log("reset data Mehrfacherfassung...");
    },
        
    toogleFieldsReadOnly: function(readOnly) {

        console.log("toogleFieldsReadOnly ...");

    },
    
    getDateFromString: function(date, time){
        var date_str = date.split('.');
        var yy = date_str[2];
        if(date_str[0].length < 2) dd = "0" + date_str[0]; else dd = date_str[0] ;
        if(date_str[1].length < 2) mm = "0" + date_str[1]; else mm = date_str[1] ;

        var time_str = time.split(':');
        if(time_str[0].length < 2) std = "0" + time_str[0]; else std = time_str[0] ;
        if(time_str[1].length < 2) min = "0" + time_str[1]; else min = time_str[1] ;
        if(time_str[2].length < 2) sec = "0" + time_str[2]; else sec = time_str[2] ;
        var retTime = "T" + std +":" + min + ":" + sec;   
        
        var dateString = yy +"-" + mm + "-" + dd + retTime;
        var endDate = new Date(dateString);
        return endDate;
    },
  
    parseDateToString: function(jsonDate) {
        var date = new Date(jsonDate.toString());
        var tag = date.getDate();
        var monat = date.getMonth() + 1;
        var jahr = date.getFullYear();
        if (tag.toString().length < 2) tag = "0" + tag;
        if (monat.toString().length < 2) monat = "0" + monat;
        return tag + "." + monat + "." + jahr;
    }
    
});