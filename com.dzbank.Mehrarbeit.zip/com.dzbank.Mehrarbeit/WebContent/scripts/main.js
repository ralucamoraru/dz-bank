
$(function(){

  /*
   * Configuration
   */

  DZBMYHR20.setup = DZBMYHR20.setup || {};

  DZBMYHR20.setup = {}

  /*
   * Global dom references
   */

  DZBMYHR20.dom = DZBMYHR20.dom || {};

  DZBMYHR20.dom.$window = $(window),
  DZBMYHR20.dom.$document = $(document),
  DZBMYHR20.dom.$body = $('body');

  DZBMYHR20.dom.$siteHeader = $('#site-header'),
  DZBMYHR20.dom.$siteBody = $('#site-body'),
  DZBMYHR20.dom.$siteFooter = $('#site-footer');

  /* *********************************************************************** */

  /*
   * Device and browser settings
   */

  DZBMYHR20.device = DZBMYHR20.device || {};

  /*
   * Detect browser
   */

  DZBMYHR20.device.browser = navigator.userAgent.toLowerCase();

  /*
   * Detect device by Bootstrap grid sizes
   */

  DZBMYHR20.dom.$body
    .append('<div id="breakpoint-desktop" class="visible-md visible-lg" />')
    .append('<div id="breakpoint-tablet" class="visible-sm" />')
    .append('<div id="breakpoint-phone" class="visible-xs" />');

  DZBMYHR20.functions.detectDevice = function(){

    DZBMYHR20.device.wasDesktop = DZBMYHR20.device.isDesktop || false;
    DZBMYHR20.device.wasTablet = DZBMYHR20.device.isTablet || false;
    DZBMYHR20.device.wasPhone = DZBMYHR20.device.isPhone || false;

    DZBMYHR20.device.isDesktop = $('#breakpoint-desktop').is(':visible');
    DZBMYHR20.device.isTablet = $('#breakpoint-tablet').is(':visible');
    DZBMYHR20.device.isPhone = $('#breakpoint-phone').is(':visible');

  }

  /* Trigger DZBMYHR20.functions.detectDevice() */
  DZBMYHR20.functions.detectDevice();

  /* Register DZBMYHR20.functions.detectDevice() on resize */
  DZBMYHR20.dom.$window.on('resize', $.debounce(100, function(event){

    DZBMYHR20.functions.detectDevice();

  }));

});
$(function(){

  /* *********************************************************************** */

  /**
   *
   */

  DZBMYHR20.functions.setDynamicDataLists = function(){

    $('dl.dynamic').each(function(){

      var $dl = $(this);

      $dl.removeClass('horizontal vertical');

      if ($dl.outerWidth() <= 400) {

        $dl.addClass('vertical');

      } else {

        $dl.addClass('horizontal');

      }

      $dl.find('dt,dd').each(function(){

        $(this).css({ 'height': 'auto' });

      });

      if ($dl.hasClass('horizontal')) {

        $dl.find('dt').each(function(){

          var $dt = $(this),
              $dd = $dt.next('dd');

          var dt_height = $dt.outerHeight(),
              dd_height = $dd.outerHeight();

          if (dt_height >= dd_height) {

            $dd.css({ 'height': dt_height });

          } else if (dd_height >= dt_height) {

            $dt.css({ 'height': dd_height });

          }

        });

      }

    });

  }

  /* Trigger DZBMYHR20.functions.setDynamicDataLists() */
  DZBMYHR20.functions.setDynamicDataLists();

  /* Register DZBMYHR20.functions.setDynamicDataLists() on resize */
  DZBMYHR20.dom.$window.on('resize', $.debounce(100, function(event){

    DZBMYHR20.functions.setDynamicDataLists();

  }));

  /* *********************************************************************** */

});

$(function(){

  /* *********************************************************************** */

  /**
   * Bootstrap select
   */

  $('select').addClass('selectpicker');

  $('.selectpicker').selectpicker();

  // $("[data-option-popover]").popover({ trigger: 'hover', container: 'body' });

  /* *********************************************************************** */

  /*
   * Bootstrap switch
   */

  $('[data-switch]').bootstrapSwitch();

  /* *********************************************************************** */

  /*
   * Autogrow Textarea
   */

  $('textarea[data-autogrow]').autoGrow();

  /* *********************************************************************** */

});

$(function(){

  /* *********************************************************************** */

  /*
   * Tooltips
   */

  $('[data-toggle="tooltip"]').tooltip({
    container: 'body'
  });

  /* *********************************************************************** */

});
$(function(){

  $('.carousel').carousel();

});
$(function(){

  /* *********************************************************************** */

  /*
   *
   */

   DZBMYHR20.globals.colors = {
    orange: '#f28200',
    blue: '#0e3c8a',
    gray: '#dfdedd'
   }

  /* *********************************************************************** */

  /*
   *
   */

  if (DZBMYHR20.device.isPhone) {

    DZBMYHR20.dom.$body.addClass('minimized');

  }

  DZBMYHR20.dom.siteHeaderHeight = 0;

/* DZBMYHR20.dom.$window.on('scroll resize', function(event){

    if (!DZBMYHR20.device.isPhone && !DZBMYHR20.device.isTablet) {

      if (DZBMYHR20.dom.siteHeaderHeight === 0) {

        DZBMYHR20.dom.siteHeaderHeight = parseInt(DZBMYHR20.dom.$siteHeader.outerHeight()) - parseInt(DZBMYHR20.dom.$siteHeader.find('>nav').outerHeight());

      }

      var windowScrollTop = parseInt(DZBMYHR20.dom.$window.scrollTop()),
          navigationOffsetTop = parseInt(DZBMYHR20.dom.$siteHeader.find('>nav').offset().top);

      if (!DZBMYHR20.dom.$body.hasClass('minimized')) {

        if (windowScrollTop >= navigationOffsetTop) {

          DZBMYHR20.dom.$body.addClass('minimized');

        }

      } else {

        if (windowScrollTop <= DZBMYHR20.dom.siteHeaderHeight) {

          DZBMYHR20.dom.$body.removeClass('minimized');

        }

      }

    } else {

      DZBMYHR20.dom.$body.removeClass('minimized');

    }

  }).scroll();
*/

});

$(function(){

  /* *********************************************************************** */

  /*
   * Colossal link
   */

  $('.colossal-link-container').on('click', 'a.expander', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.parent().toggleClass('active');

    $this.toggleClass('active');

  });

  /* *********************************************************************** */

});

DZBMYHR20.globals.siteheader = {
  'secureText': 'Daten verbergen',
  'unsecureText': 'Daten anzeigen'
}

$(function(){

  /* *********************************************************************** */

  /*
   * Append helper element
   */

  if (!DZBMYHR20.dom.$siteBody.prev('.is-secured-symbol').length) {

    DZBMYHR20.dom.$siteBody.before('<div class="is-secured-symbol"></div>');

  }

  /* *********************************************************************** */

  /*
   * DOM references
   */

  DZBMYHR20.dom.$maskApplicationLink = DZBMYHR20.dom.$siteHeader.find('.maskapplication');

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.functions.maskApplication = function() {

    if (DZBMYHR20.dom.$maskApplicationLink.hasClass('active')) {

      DZBMYHR20.dom.$maskApplicationLink.removeClass('active');
      DZBMYHR20.dom.$maskApplicationLink.find('span').text(DZBMYHR20.globals.siteheader.secureText);
      DZBMYHR20.dom.$siteBody.removeClass('is-secured');

    } else {

      DZBMYHR20.dom.$maskApplicationLink.addClass('active');
      DZBMYHR20.dom.$maskApplicationLink.find('span').text(DZBMYHR20.globals.siteheader.unsecureText);
      DZBMYHR20.dom.$siteBody.addClass('is-secured');

    }

  };

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$maskApplicationLink.on('click', function(event){

    event.preventDefault();

    DZBMYHR20.functions.maskApplication()

  });

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$window.on('keyup', function(event){
    if (event.ctrlKey && event.keyCode === 27) {
      DZBMYHR20.functions.maskApplication();
    }
  });

});

$(function(){

  /* *********************************************************************** */

  /*
   * Append helper element
   */

  if (!DZBMYHR20.dom.$body.find('.navigation-overlay').length) {

    DZBMYHR20.dom.$body.append('<div class="navigation-overlay"/>');

  }

  /* *********************************************************************** */

  /*
   * DOM references
   */

  DZBMYHR20.dom.$navigationOpener = DZBMYHR20.dom.$siteHeader.find('>button');
  DZBMYHR20.dom.$navigationContainer = DZBMYHR20.dom.$siteHeader.find('nav');
  DZBMYHR20.dom.$navigationOverlay = DZBMYHR20.dom.$body.find('.navigation-overlay');

  DZBMYHR20.dom.$navigationSearchForm = DZBMYHR20.dom.$siteHeader.find('form');

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$navigationOpener.on('click', function(event){

    event.preventDefault();

    DZBMYHR20.dom.$navigationOpener.toggleClass('open');
    DZBMYHR20.dom.$navigationContainer.toggleClass('open');
    DZBMYHR20.dom.$navigationOverlay.toggleClass('open');

  });

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$navigationContainer.on('click', '.level-1>li>.more', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('open');
    $this.parent().toggleClass('open');
    $this.next().toggleClass('open');

  });

  DZBMYHR20.dom.$navigationContainer.on('click', '.level-2>li>.more', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('open');
    $this.parent().toggleClass('open');
    $this.next().toggleClass('open');

  });

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$window.on('keyup', function(event){
    if (event.keyCode === 27) {
      DZBMYHR20.dom.$navigationContainer.find('.open').removeClass('open');
    }
  });

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$navigationSearchForm.on('submit', function(event){

    event.preventDefault();

  });

  DZBMYHR20.dom.$navigationSearchForm.on('click', 'button', function(event){

    event.preventDefault();

  });
  
  $('#mehrarbeit').on('submit', function(event){

	    event.preventDefault();

	  });

  $('#mehrarbeit').on('click', 'button', function(event){

	    event.preventDefault();

	  });
  
  $('#mehrfachErfassung').on('submit', function(event){

	    event.preventDefault();

	  });

  $('#mehrfachErfassung').on('click', 'button', function(event){

	    event.preventDefault();

	  });
  
  $('.form_event').on('submit', function(event){

	    event.preventDefault();

	  });

  $('.form_event').on('click', 'button', function(event){

	    event.preventDefault();

	  });

  /* *********************************************************************** */

  /*
   *
   */

  DZBMYHR20.dom.$siteHeader.on('click', '.view-select>a', function(event){

    event.preventDefault();

    var $this = $(this);

    $this.toggleClass('active');
    $this.next().toggle();

  });
/*
  DZBMYHR20.dom.$siteHeader.on('resize', function(){

    DZBMYHR20.dom.$siteHeader.find('.view-select>ul').css({ 'width': DZBMYHR20.dom.$siteHeader.find('.view-select>a').outerWidth() });

  }).resize();
*/
});

$(function(){

  /* *********************************************************************** */

  /**
   *
   */

  DZBMYHR20.functions.setFlexTableExpanderHeight = function(){

    $('.flex-table').each(function(){

      var $table = $(this);

      $table.find('th.flex-table-group-expander').each(function(){

        var $th = $(this),
            $a = $th.find('a'),
            $span = $a.find('span');

        var height = ($table.outerHeight());

        $a.css({ 'height': height });
        $span.css({ 'width': (height + 24) }).data('height', height);

      });

    });

  }

  /* Trigger DZBMYHR20.functions.setFlexTableExpanderHeight() */
  DZBMYHR20.functions.setFlexTableExpanderHeight();

  /* Register DZBMYHR20.functions.setFlexTableExpanderHeight() on resize */
  DZBMYHR20.dom.$window.on('resize', $.debounce(100, function(event){

    DZBMYHR20.functions.setFlexTableExpanderHeight();

  }));

  /* *********************************************************************** */

  /**
   *
   */

  $('th.flex-table-group-expander').on('click', 'a', function(event){

    event.preventDefault();

    var $this = $(this),
        $table = $this.parents('table');

    if ($this.data('group-expander-data-registered')) {

      if ($this.hasClass('is-visible')) {

        $this.removeClass('is-visible');

        $('th[data-group-expander="' + $this.data('group-expander') + '"]', $table).hide();
        $('td[data-group-expander="' + $this.data('group-expander') + '"]', $table).hide();

      } else {

        $this.addClass('is-visible');

        $('th[data-group-expander="' + $this.data('group-expander') + '"]', $table).show();
        $('td[data-group-expander="' + $this.data('group-expander') + '"]', $table).show();

      }

    } else {

      $.ajax({
        type: 'GET',
        dataTyp: 'json',
        url: $this.data('group-expander-data'),
      })
      .fail(function(jqXHR, textStatus){

        console.log(jqXHR, textStatus);

      })
      .done(function(json){

        $this.data('group-expander-data-registered', true);
        $this.addClass('is-visible');

        var $theadHook = $('th[data-group-expander-hook="' + $this.data('group-expander') + '"]', $table);

        $theadHook.after(json.thead);

        for (var i = 0; i < json.tbody.length; i++) {

          $tbody = $table.find('tbody:not(".flex-table-extensible"):eq(' + i + ')');
          $tbodyHook = $('td[data-group-expander-hook="' + $this.data('group-expander') + '"]', $tbody);

          $tbodyHook.after(json.tbody[i]);

        }

      });

    }

  });

  /* *********************************************************************** */

  /**
   *
   */

  $('a[data-extend]').on('click', function(event) {

    event.preventDefault();
    console.log("calling method");
    var $this = $(this);

    $($this.data('extend')).toggleClass('in');

    $this.parents('.flex-table-tbody').toggleClass('extended');

    $this.toggleClass('extended');

    DZBMYHR20.functions.setFlexTableExpanderHeight();

      if ($this.hasClass('extended')) {
        expandScrollHeigt();

      }else{

        reduceScrollHeigt();

      }
  });

  /* *********************************************************************** */

  /**
   *
   */

  DZBMYHR20.functions.setFlexTableSplitRowHeight = function(){


    $('.flex-table').each(function(){

      var $table = $(this);

      $table.find('td.split-row').each(function(){

        var $td = $(this);

        var height = ($td.height() / 2);

        $td.find('span.split-row').each(function(){

          $(this).css({ 'height': height });

        });

      });

    });


  }

  /* Trigger DZBMYHR20.functions.setFlexTableSplitRowHeight() */
  DZBMYHR20.functions.setFlexTableSplitRowHeight();

  /* Register DZBMYHR20.functions.setFlexTableSplitRowHeight() on resize */
  DZBMYHR20.dom.$window.on('resize', $.debounce(100, function(event){

    DZBMYHR20.functions.setFlexTableSplitRowHeight();

  }));

  /* *********************************************************************** */

});

$(function(){

  /* *********************************************************************** */

  /*
   *
   */

  if ($('#gehaltsrechner').length) {

    /* ********************************************************************* */

    /*
     * Example implementation
     */

    var rangeSlider1 = document.getElementById('slider-range-1');

    noUiSlider.create(rangeSlider1, {
      start: [ 50000 ],
      range: {
        'min': [  0 ],
        'max': [ 60000 ]
      },
      steps: 1000,
      pips: {
        mode: 'values',
        values: [0, 10000, 20000, 30000, 40000, 50000, 60000],
        density: 2
      }
    });

    var rangeSlider2 = document.getElementById('slider-range-2');

    noUiSlider.create(rangeSlider2, {
      start: [ 100 ],
      range: {
        'min': [  0 ],
        'max': [ 100 ]
      },
      steps: 25,
      pips: {
        mode: 'values',
        values: [0, 25, 50, 75, 100],
        density: 25
      }
    });

    /* ********************************************************************* */

    /*
     * Example implementation
     */

    var randomScalingFactor = function() {
        return Math.round(Math.random() * 100);
    };
    var randomColorFactor = function() {
        return Math.round(Math.random() * 255);
    };
    var randomColor = function(opacity) {
        return 'rgba(' + randomColorFactor() + ',' + randomColorFactor() + ',' + randomColorFactor() + ',' + (opacity || '.3') + ')';
    };

    var config = {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [
                    randomScalingFactor(),
                    randomScalingFactor(),
                ],
                backgroundColor: [
                    DZBMYHR20.globals.colors.orange,
                    DZBMYHR20.globals.colors.gray
                ]
            }, {
                data: [
                    randomScalingFactor(),
                    randomScalingFactor()
                ],
                backgroundColor: [
                    DZBMYHR20.globals.colors.blue,
                    DZBMYHR20.globals.colors.gray
                ]
            }],
            labels: [
                "Gehalt",
                "Arbeitszeit"
            ]
        },
        options: {
            responsive: true,
            legend: {
                position: 'bottom',
            },
            title: {
                display: false,
            }
        }
    };

    window.onload = function() {
        var ctx = document.getElementById("chart-area").getContext("2d");
        window.myDoughnut = new Chart(ctx, config);
    };

  }

});
$(function(){

  if ($('#gehaltsrunde').length) {

    $('[data-toggle="popover"]').popover({
      html: true,
      content: $('#popover-content').html()
    });

  }

});
$(function(){

  /* *********************************************************************** */

  /*
   *
   */

  if ($('#verguetungsplanung').length) {

    /* ********************************************************************* */

    /*
     * Example implementation
     */

    $('input[name="fullscreen"]').on('switchChange.bootstrapSwitch', function(event, state) {

      $('#flex-table-wrapper').toggleClass('container container-fluid');

      DZBMYHR20.dom.$window.trigger('resize');

    });


    /* ********************************************************************* */

    /*
     * Example implementation
     */

    $('input[name="editing"]').on('switchChange.bootstrapSwitch', function(event, state) {

      $('#flex-table-filter-inf').slideToggle();

    });

    /* ********************************************************************* */

  }
  
  /*
   * RM: RUM Anwendung Schnellerfassung
   */
	$('input[name="massentry"]').on('switchChange.bootstrapSwitch', function(event, state) {
	
	$('#flex-entry-table').toggleClass('hide-all');
	if (antragTyp == 1)
		$('#mass-entry-table-rb').toggleClass('hide-all');
	else if (antragTyp == 2)
	//	$('#mass-entry-table-ma').toggleClass('hide-all');
	console.log("Antrag Typ: " + antragTyp);
	/*  DZBMYHR20.dom.$window.trigger('resize');*/
	});

});

/*
 * ************************ Raluca: Mehrarbeit / Rufbereitschaft **************************************
 */
  function expandScrollHeigt(){
    var $ext = $('.mCustomScrollbar').find('tbody.flex-table-extensible');
    var $add_height = $('.mCustomScrollbar').height() + $ext.height();
    $('.mCustomScrollbar').css({ 'height': $add_height });
  }

  function reduceScrollHeigt(){
    var $ext = $('.mCustomScrollbar').find('tbody.flex-table-extensible');
    var $add_height = $('.mCustomScrollbar').height() - $ext.height();
    $('.mCustomScrollbar').css({ 'height': $add_height });
  }

function changeAntrag(){
	 console.log("...antrag select");  
	 if( $('#antrag_select').val() == "1"){
	   $('#self_row_1').show();
	   $('#self_row_2').show();
	   $('#other_row_1').hide();
	   $('#other_row_2').hide();
	 }else{
	   $('#self_row_1').hide();
	   $('#self_row_2').hide();
	   $('#other_row_1').show();
	   $('#other_row_2').show();
	 }
}

