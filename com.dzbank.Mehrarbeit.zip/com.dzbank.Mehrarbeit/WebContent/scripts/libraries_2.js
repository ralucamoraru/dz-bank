//
//var oDataFile = new sap.ui.model.odata.ODataModel(url, {
//    json : false
//  // disableHeadRequestForToken: true
//  // tokenHandling: false
//  });
//
//  oDataFile.headers = {[
//                        AccessControlAllowOrigin : "*",
//                        X-CSRF-Token : "Fetch"
//                        ]
//
//  };
//
//  oDataFile.setHeaders({
//    "X-Requested-With" : "XMLHttpRequest",
//    "Content-Type" : "application/atom+xml",
//    "DataServiceVersion" : "2.0"
//
//  });
//  
//  oDataFile.attachMetadataLoaded(null, function() {
//      var oMeta = this.getServiceMetadata();
//    }, null);
//  
//  oDataFile.read("/Gifts?$filter=Pernr eq '"+persDat_pernr+"'",{
//	  success: function(odata,response){
//		  header_xcsrf_token = response.headers['x-csrf-token'];
//	  },
//	  error: function(response){
//		  alert("nix da");
//	  }
//  });
//
