/* ========================================================================
 * Bootstrap: affix.js v3.3.6
 * http://getbootstrap.com/javascript/#affix
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */
+ function($) {
    'use strict';

    // AFFIX CLASS DEFINITION
    // ======================

    var Affix = function(element, options) {
        this.options = $.extend({}, Affix.DEFAULTS, options)

        this.$target = $(this.options.target)
            .on('scroll.bs.affix.data-api', $.proxy(this.checkPosition, this))
            .on('click.bs.affix.data-api', $.proxy(this.checkPositionWithEventLoop, this))

        this.$element = $(element)
        this.affixed = null
        this.unpin = null
        this.pinnedOffset = null

        this.checkPosition()
    };

    Affix.VERSION = '3.3.6'

    Affix.RESET = 'affix affix-top affix-bottom'

    Affix.DEFAULTS = {
        offset: 0,
        target: window
    }

    Affix.prototype.getState = function(scrollHeight, height, offsetTop, offsetBottom) {
        var scrollTop = this.$target.scrollTop()
        var position = this.$element.offset()
        var targetHeight = this.$target.height()

        if (offsetTop != null && this.affixed == 'top') return scrollTop < offsetTop ? 'top' : false

        if (this.affixed == 'bottom') {
            if (offsetTop != null) return (scrollTop + this.unpin <= position.top) ? false : 'bottom'
            return (scrollTop + targetHeight <= scrollHeight - offsetBottom) ? false : 'bottom'
        }

        var initializing = this.affixed == null
        var colliderTop = initializing ? scrollTop : position.top
        var colliderHeight = initializing ? targetHeight : height

        if (offsetTop != null && scrollTop <= offsetTop) return 'top'
        if (offsetBottom != null && (colliderTop + colliderHeight >= scrollHeight - offsetBottom)) return 'bottom'

        return false
    };

    Affix.prototype.getPinnedOffset = function() {
        if (this.pinnedOffset) return this.pinnedOffset
        this.$element.removeClass(Affix.RESET).addClass('affix')
        var scrollTop = this.$target.scrollTop()
        var position = this.$element.offset()
        return (this.pinnedOffset = position.top - scrollTop)
    };

    Affix.prototype.checkPositionWithEventLoop = function() {
        setTimeout($.proxy(this.checkPosition, this), 1)
    };

    Affix.prototype.checkPosition = function() {
        if (!this.$element.is(':visible')) return

        var height = this.$element.height()
        var offset = this.options.offset
        var offsetTop = offset.top
        var offsetBottom = offset.bottom
        var scrollHeight = Math.max($(document).height(), $(document.body).height())

        if (typeof offset != 'object') offsetBottom = offsetTop = offset
        if (typeof offsetTop == 'function') offsetTop = offset.top(this.$element)
        if (typeof offsetBottom == 'function') offsetBottom = offset.bottom(this.$element)

        var affix = this.getState(scrollHeight, height, offsetTop, offsetBottom)

        if (this.affixed != affix) {
            if (this.unpin != null) this.$element.css('top', '')

            var affixType = 'affix' + (affix ? '-' + affix : '')
            var e = $.Event(affixType + '.bs.affix')

            this.$element.trigger(e)

            if (e.isDefaultPrevented()) return

            this.affixed = affix
            this.unpin = affix == 'bottom' ? this.getPinnedOffset() : null

            this.$element
                .removeClass(Affix.RESET)
                .addClass(affixType)
                .trigger(affixType.replace('affix', 'affixed') + '.bs.affix')
        }

        if (affix == 'bottom') {
            this.$element.offset({
                top: scrollHeight - height - offsetBottom
            })
        }
    };


    // AFFIX PLUGIN DEFINITION
    // =======================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.affix')
            var options = typeof option == 'object' && option

            if (!data) $this.data('bs.affix', (data = new Affix(this, options)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.affix

    $.fn.affix = Plugin
    $.fn.affix.Constructor = Affix


    // AFFIX NO CONFLICT
    // =================

    $.fn.affix.noConflict = function() {
        $.fn.affix = old
        return this
    };


    // AFFIX DATA-API
    // ==============

    $(window).on('load', function() {
        $('[data-spy="affix"]').each(function() {
            var $spy = $(this)
            var data = $spy.data()

            data.offset = data.offset || {}

            if (data.offsetBottom != null) data.offset.bottom = data.offsetBottom
            if (data.offsetTop != null) data.offset.top = data.offsetTop

            Plugin.call($spy, data)
        })
    })

}(jQuery);

/* ========================================================================
 * Bootstrap: alert.js v3.3.6
 * http://getbootstrap.com/javascript/#alerts
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // ALERT CLASS DEFINITION
    // ======================

    var dismiss = '[data-dismiss="alert"]'
    var Alert = function(el) {
        $(el).on('click', dismiss, this.close)
    }

    Alert.VERSION = '3.3.6'

    Alert.TRANSITION_DURATION = 150

    Alert.prototype.close = function(e) {
        var $this = $(this)
        var selector = $this.attr('data-target')

        if (!selector) {
            selector = $this.attr('href')
            selector = selector && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
        }

        var $parent = $(selector)

        if (e) e.preventDefault()

        if (!$parent.length) {
            $parent = $this.closest('.alert')
        }

        $parent.trigger(e = $.Event('close.bs.alert'))

        if (e.isDefaultPrevented()) return

        $parent.removeClass('in')

        function removeElement() {
            // detach from parent, fire event then clean up data
            $parent.detach().trigger('closed.bs.alert').remove()
        }

        $.support.transition && $parent.hasClass('fade') ?
            $parent
            .one('bsTransitionEnd', removeElement)
            .emulateTransitionEnd(Alert.TRANSITION_DURATION) :
            removeElement()
    }


    // ALERT PLUGIN DEFINITION
    // =======================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.alert')

            if (!data) $this.data('bs.alert', (data = new Alert(this)))
            if (typeof option == 'string') data[option].call($this)
        })
    }

    var old = $.fn.alert

    $.fn.alert = Plugin
    $.fn.alert.Constructor = Alert


    // ALERT NO CONFLICT
    // =================

    $.fn.alert.noConflict = function() {
        $.fn.alert = old
        return this
    }


    // ALERT DATA-API
    // ==============

    $(document).on('click.bs.alert.data-api', dismiss, Alert.prototype.close)

}(jQuery);

/* ========================================================================
 * Bootstrap: button.js v3.3.6
 * http://getbootstrap.com/javascript/#buttons
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // BUTTON PUBLIC CLASS DEFINITION
    // ==============================

    var Button = function(element, options) {
        this.$element = $(element)
        this.options = $.extend({}, Button.DEFAULTS, options)
        this.isLoading = false
    }

    Button.VERSION = '3.3.6'

    Button.DEFAULTS = {
        loadingText: 'loading...'
    }

    Button.prototype.setState = function(state) {
        var d = 'disabled'
        var $el = this.$element
        var val = $el.is('input') ? 'val' : 'html'
        var data = $el.data()

        state += 'Text'

        if (data.resetText == null) $el.data('resetText', $el[val]())

        // push to event loop to allow forms to submit
        setTimeout($.proxy(function() {
            $el[val](data[state] == null ? this.options[state] : data[state])

            if (state == 'loadingText') {
                this.isLoading = true
                $el.addClass(d).attr(d, d)
            } else if (this.isLoading) {
                this.isLoading = false
                $el.removeClass(d).removeAttr(d)
            }
        }, this), 0)
    }

    Button.prototype.toggle = function() {
        var changed = true
        var $parent = this.$element.closest('[data-toggle="buttons"]')

        if ($parent.length) {
            var $input = this.$element.find('input')
            if ($input.prop('type') == 'radio') {
                if ($input.prop('checked')) changed = false
                $parent.find('.active').removeClass('active')
                this.$element.addClass('active')
            } else if ($input.prop('type') == 'checkbox') {
                if (($input.prop('checked')) !== this.$element.hasClass('active')) changed = false
                this.$element.toggleClass('active')
            }
            $input.prop('checked', this.$element.hasClass('active'))
            if (changed) $input.trigger('change')
        } else {
            this.$element.attr('aria-pressed', !this.$element.hasClass('active'))
            this.$element.toggleClass('active')
        }
    }


    // BUTTON PLUGIN DEFINITION
    // ========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.button')
            var options = typeof option == 'object' && option

            if (!data) $this.data('bs.button', (data = new Button(this, options)))

            if (option == 'toggle') data.toggle()
            else if (option) data.setState(option)
        })
    }

    var old = $.fn.button

    $.fn.button = Plugin
    $.fn.button.Constructor = Button


    // BUTTON NO CONFLICT
    // ==================

    $.fn.button.noConflict = function() {
        $.fn.button = old
        return this
    }


    // BUTTON DATA-API
    // ===============

    $(document)
        .on('click.bs.button.data-api', '[data-toggle^="button"]', function(e) {
            var $btn = $(e.target)
            if (!$btn.hasClass('btn')) $btn = $btn.closest('.btn')
            Plugin.call($btn, 'toggle')
            if (!($(e.target).is('input[type="radio"]') || $(e.target).is('input[type="checkbox"]'))) e.preventDefault()
        })
        .on('focus.bs.button.data-api blur.bs.button.data-api', '[data-toggle^="button"]', function(e) {
            $(e.target).closest('.btn').toggleClass('focus', /^focus(in)?$/.test(e.type))
        })

}(jQuery);

/* ========================================================================
 * Bootstrap: carousel.js v3.3.6
 * http://getbootstrap.com/javascript/#carousel
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // CAROUSEL CLASS DEFINITION
    // =========================

    var Carousel = function(element, options) {
        this.$element = $(element)
        this.$indicators = this.$element.find('.carousel-indicators')
        this.options = options
        this.paused = null
        this.sliding = null
        this.interval = null
        this.$active = null
        this.$items = null

        this.options.keyboard && this.$element.on('keydown.bs.carousel', $.proxy(this.keydown, this))

        this.options.pause == 'hover' && !('ontouchstart' in document.documentElement) && this.$element
            .on('mouseenter.bs.carousel', $.proxy(this.pause, this))
            .on('mouseleave.bs.carousel', $.proxy(this.cycle, this))
    }

    Carousel.VERSION = '3.3.6'

    Carousel.TRANSITION_DURATION = 600

    Carousel.DEFAULTS = {
        interval: 5000,
        pause: 'hover',
        wrap: true,
        keyboard: true
    }

    Carousel.prototype.keydown = function(e) {
        if (/input|textarea/i.test(e.target.tagName)) return
        switch (e.which) {
            case 37:
                this.prev();
                break
            case 39:
                this.next();
                break
            default:
                return
        }

        e.preventDefault()
    }

    Carousel.prototype.cycle = function(e) {
        e || (this.paused = false)

        this.interval && clearInterval(this.interval)

        this.options.interval &&
            !this.paused &&
            (this.interval = setInterval($.proxy(this.next, this), this.options.interval))

        return this
    }

    Carousel.prototype.getItemIndex = function(item) {
        this.$items = item.parent().children('.item')
        return this.$items.index(item || this.$active)
    }

    Carousel.prototype.getItemForDirection = function(direction, active) {
        var activeIndex = this.getItemIndex(active)
        var willWrap = (direction == 'prev' && activeIndex === 0) ||
            (direction == 'next' && activeIndex == (this.$items.length - 1))
        if (willWrap && !this.options.wrap) return active
        var delta = direction == 'prev' ? -1 : 1
        var itemIndex = (activeIndex + delta) % this.$items.length
        return this.$items.eq(itemIndex)
    }

    Carousel.prototype.to = function(pos) {
        var that = this
        var activeIndex = this.getItemIndex(this.$active = this.$element.find('.item.active'))

        if (pos > (this.$items.length - 1) || pos < 0) return

        if (this.sliding) return this.$element.one('slid.bs.carousel', function() {
                that.to(pos)
            }) // yes, "slid"
        if (activeIndex == pos) return this.pause().cycle()

        return this.slide(pos > activeIndex ? 'next' : 'prev', this.$items.eq(pos))
    }

    Carousel.prototype.pause = function(e) {
        e || (this.paused = true)

        if (this.$element.find('.next, .prev').length && $.support.transition) {
            this.$element.trigger($.support.transition.end)
            this.cycle(true)
        }

        this.interval = clearInterval(this.interval)

        return this
    }

    Carousel.prototype.next = function() {
        if (this.sliding) return
        return this.slide('next')
    }

    Carousel.prototype.prev = function() {
        if (this.sliding) return
        return this.slide('prev')
    }

    Carousel.prototype.slide = function(type, next) {
        var $active = this.$element.find('.item.active')
        var $next = next || this.getItemForDirection(type, $active)
        var isCycling = this.interval
        var direction = type == 'next' ? 'left' : 'right'
        var that = this

        if ($next.hasClass('active')) return (this.sliding = false)

        var relatedTarget = $next[0]
        var slideEvent = $.Event('slide.bs.carousel', {
            relatedTarget: relatedTarget,
            direction: direction
        })
        this.$element.trigger(slideEvent)
        if (slideEvent.isDefaultPrevented()) return

        this.sliding = true

        isCycling && this.pause()

        if (this.$indicators.length) {
            this.$indicators.find('.active').removeClass('active')
            var $nextIndicator = $(this.$indicators.children()[this.getItemIndex($next)])
            $nextIndicator && $nextIndicator.addClass('active')
        }

        var slidEvent = $.Event('slid.bs.carousel', {
                relatedTarget: relatedTarget,
                direction: direction
            }) // yes, "slid"
        if ($.support.transition && this.$element.hasClass('slide')) {
            $next.addClass(type)
            $next[0].offsetWidth // force reflow
            $active.addClass(direction)
            $next.addClass(direction)
            $active
                .one('bsTransitionEnd', function() {
                    $next.removeClass([type, direction].join(' ')).addClass('active')
                    $active.removeClass(['active', direction].join(' '))
                    that.sliding = false
                    setTimeout(function() {
                        that.$element.trigger(slidEvent)
                    }, 0)
                })
                .emulateTransitionEnd(Carousel.TRANSITION_DURATION)
        } else {
            $active.removeClass('active')
            $next.addClass('active')
            this.sliding = false
            this.$element.trigger(slidEvent)
        }

        isCycling && this.cycle()

        return this
    }


    // CAROUSEL PLUGIN DEFINITION
    // ==========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.carousel')
            var options = $.extend({}, Carousel.DEFAULTS, $this.data(), typeof option == 'object' && option)
            var action = typeof option == 'string' ? option : options.slide

            if (!data) $this.data('bs.carousel', (data = new Carousel(this, options)))
            if (typeof option == 'number') data.to(option)
            else if (action) data[action]()
            else if (options.interval) data.pause().cycle()
        })
    }

    var old = $.fn.carousel

    $.fn.carousel = Plugin
    $.fn.carousel.Constructor = Carousel


    // CAROUSEL NO CONFLICT
    // ====================

    $.fn.carousel.noConflict = function() {
        $.fn.carousel = old
        return this
    }


    // CAROUSEL DATA-API
    // =================

    var clickHandler = function(e) {
        var href
        var $this = $(this)
        var $target = $($this.attr('data-target') || (href = $this.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, '')) // strip for ie7
        if (!$target.hasClass('carousel')) return
        var options = $.extend({}, $target.data(), $this.data())
        var slideIndex = $this.attr('data-slide-to')
        if (slideIndex) options.interval = false

        Plugin.call($target, options)

        if (slideIndex) {
            $target.data('bs.carousel').to(slideIndex)
        }

        e.preventDefault()
    }

    $(document)
        .on('click.bs.carousel.data-api', '[data-slide]', clickHandler)
        .on('click.bs.carousel.data-api', '[data-slide-to]', clickHandler)

    $(window).on('load', function() {
        $('[data-ride="carousel"]').each(function() {
            var $carousel = $(this)
            Plugin.call($carousel, $carousel.data())
        })
    })

}(jQuery);

/* ========================================================================
 * Bootstrap: collapse.js v3.3.6
 * http://getbootstrap.com/javascript/#collapse
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // COLLAPSE PUBLIC CLASS DEFINITION
    // ================================

    var Collapse = function(element, options) {
        this.$element = $(element)
        this.options = $.extend({}, Collapse.DEFAULTS, options)
        this.$trigger = $('[data-toggle="collapse"][href="#' + element.id + '"],' +
            '[data-toggle="collapse"][data-target="#' + element.id + '"]')
        this.transitioning = null

        if (this.options.parent) {
            this.$parent = this.getParent()
        } else {
            this.addAriaAndCollapsedClass(this.$element, this.$trigger)
        }

        if (this.options.toggle) this.toggle()
    }

    Collapse.VERSION = '3.3.6'

    Collapse.TRANSITION_DURATION = 350

    Collapse.DEFAULTS = {
        toggle: true
    }

    Collapse.prototype.dimension = function() {
        var hasWidth = this.$element.hasClass('width')
        return hasWidth ? 'width' : 'height'
    }

    Collapse.prototype.show = function() {
        if (this.transitioning || this.$element.hasClass('in')) return

        var activesData
        var actives = this.$parent && this.$parent.children('.panel').children('.in, .collapsing')

        if (actives && actives.length) {
            activesData = actives.data('bs.collapse')
            if (activesData && activesData.transitioning) return
        }

        var startEvent = $.Event('show.bs.collapse')
        this.$element.trigger(startEvent)
        if (startEvent.isDefaultPrevented()) return

        if (actives && actives.length) {
            Plugin.call(actives, 'hide')
            activesData || actives.data('bs.collapse', null)
        }

        var dimension = this.dimension()

        this.$element
            .removeClass('collapse')
            .addClass('collapsing')[dimension](0)
            .attr('aria-expanded', true)

        this.$trigger
            .removeClass('collapsed')
            .attr('aria-expanded', true)

        this.transitioning = 1

        var complete = function() {
            this.$element
                .removeClass('collapsing')
                .addClass('collapse in')[dimension]('')
            this.transitioning = 0
            this.$element
                .trigger('shown.bs.collapse')
        }

        if (!$.support.transition) return complete.call(this)

        var scrollSize = $.camelCase(['scroll', dimension].join('-'))

        this.$element
            .one('bsTransitionEnd', $.proxy(complete, this))
            .emulateTransitionEnd(Collapse.TRANSITION_DURATION)[dimension](this.$element[0][scrollSize])
    }

    Collapse.prototype.hide = function() {
        if (this.transitioning || !this.$element.hasClass('in')) return

        var startEvent = $.Event('hide.bs.collapse')
        this.$element.trigger(startEvent)
        if (startEvent.isDefaultPrevented()) return

        var dimension = this.dimension()

        this.$element[dimension](this.$element[dimension]())[0].offsetHeight

        this.$element
            .addClass('collapsing')
            .removeClass('collapse in')
            .attr('aria-expanded', false)

        this.$trigger
            .addClass('collapsed')
            .attr('aria-expanded', false)

        this.transitioning = 1

        var complete = function() {
            this.transitioning = 0
            this.$element
                .removeClass('collapsing')
                .addClass('collapse')
                .trigger('hidden.bs.collapse')
        }

        if (!$.support.transition) return complete.call(this)

        this.$element[dimension](0)
            .one('bsTransitionEnd', $.proxy(complete, this))
            .emulateTransitionEnd(Collapse.TRANSITION_DURATION)
    }

    Collapse.prototype.toggle = function() {
        this[this.$element.hasClass('in') ? 'hide' : 'show']()
    }

    Collapse.prototype.getParent = function() {
        return $(this.options.parent)
            .find('[data-toggle="collapse"][data-parent="' + this.options.parent + '"]')
            .each($.proxy(function(i, element) {
                var $element = $(element)
                this.addAriaAndCollapsedClass(getTargetFromTrigger($element), $element)
            }, this))
            .end()
    }

    Collapse.prototype.addAriaAndCollapsedClass = function($element, $trigger) {
        var isOpen = $element.hasClass('in')

        $element.attr('aria-expanded', isOpen)
        $trigger
            .toggleClass('collapsed', !isOpen)
            .attr('aria-expanded', isOpen)
    }

    function getTargetFromTrigger($trigger) {
        var href
        var target = $trigger.attr('data-target') ||
            (href = $trigger.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, '') // strip for ie7

        return $(target)
    }


    // COLLAPSE PLUGIN DEFINITION
    // ==========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.collapse')
            var options = $.extend({}, Collapse.DEFAULTS, $this.data(), typeof option == 'object' && option)

            if (!data && options.toggle && /show|hide/.test(option)) options.toggle = false
            if (!data) $this.data('bs.collapse', (data = new Collapse(this, options)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.collapse

    $.fn.collapse = Plugin
    $.fn.collapse.Constructor = Collapse


    // COLLAPSE NO CONFLICT
    // ====================

    $.fn.collapse.noConflict = function() {
        $.fn.collapse = old
        return this
    }


    // COLLAPSE DATA-API
    // =================

    $(document).on('click.bs.collapse.data-api', '[data-toggle="collapse"]', function(e) {
        var $this = $(this)

        if (!$this.attr('data-target')) e.preventDefault()

        var $target = getTargetFromTrigger($this)
        var data = $target.data('bs.collapse')
        var option = data ? 'toggle' : $this.data()

        Plugin.call($target, option)
    })

}(jQuery);

/* ========================================================================
 * Bootstrap: dropdown.js v3.3.6
 * http://getbootstrap.com/javascript/#dropdowns
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // DROPDOWN CLASS DEFINITION
    // =========================

    var backdrop = '.dropdown-backdrop'
    var toggle = '[data-toggle="dropdown"]'
    var Dropdown = function(element) {
        $(element).on('click.bs.dropdown', this.toggle)
    }

    Dropdown.VERSION = '3.3.6'

    function getParent($this) {
        var selector = $this.attr('data-target')

        if (!selector) {
            selector = $this.attr('href')
            selector = selector && /#[A-Za-z]/.test(selector) && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
        }

        var $parent = selector && $(selector)

        return $parent && $parent.length ? $parent : $this.parent()
    }

    function clearMenus(e) {
        if (e && e.which === 3) return
        $(backdrop).remove()
        $(toggle).each(function() {
            var $this = $(this)
            var $parent = getParent($this)
            var relatedTarget = {
                relatedTarget: this
            }

            if (!$parent.hasClass('open')) return

            if (e && e.type == 'click' && /input|textarea/i.test(e.target.tagName) && $.contains($parent[0], e.target)) return

            $parent.trigger(e = $.Event('hide.bs.dropdown', relatedTarget))

            if (e.isDefaultPrevented()) return

            $this.attr('aria-expanded', 'false')
            $parent.removeClass('open').trigger($.Event('hidden.bs.dropdown', relatedTarget))
        })
    }

    Dropdown.prototype.toggle = function(e) {
        var $this = $(this)

        if ($this.is('.disabled, :disabled')) return

        var $parent = getParent($this)
        var isActive = $parent.hasClass('open')

        clearMenus()

        if (!isActive) {
            if ('ontouchstart' in document.documentElement && !$parent.closest('.navbar-nav').length) {
                // if mobile we use a backdrop because click events don't delegate
                $(document.createElement('div'))
                    .addClass('dropdown-backdrop')
                    .insertAfter($(this))
                    .on('click', clearMenus)
            }

            var relatedTarget = {
                relatedTarget: this
            }
            $parent.trigger(e = $.Event('show.bs.dropdown', relatedTarget))

            if (e.isDefaultPrevented()) return

            $this
                .trigger('focus')
                .attr('aria-expanded', 'true')

            $parent
                .toggleClass('open')
                .trigger($.Event('shown.bs.dropdown', relatedTarget))
        }

        return false
    }

    Dropdown.prototype.keydown = function(e) {
        if (!/(38|40|27|32)/.test(e.which) || /input|textarea/i.test(e.target.tagName)) return

        var $this = $(this)

        e.preventDefault()
        e.stopPropagation()

        if ($this.is('.disabled, :disabled')) return

        var $parent = getParent($this)
        var isActive = $parent.hasClass('open')

        if (!isActive && e.which != 27 || isActive && e.which == 27) {
            if (e.which == 27) $parent.find(toggle).trigger('focus')
            return $this.trigger('click')
        }

        var desc = ' li:not(.disabled):visible a'
        var $items = $parent.find('.dropdown-menu' + desc)

        if (!$items.length) return

        var index = $items.index(e.target)

        if (e.which == 38 && index > 0) index-- // up
            if (e.which == 40 && index < $items.length - 1) index++ // down
                if (!~index) index = 0

        $items.eq(index).trigger('focus')
    }


    // DROPDOWN PLUGIN DEFINITION
    // ==========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.dropdown')

            if (!data) $this.data('bs.dropdown', (data = new Dropdown(this)))
            if (typeof option == 'string') data[option].call($this)
        })
    }

    var old = $.fn.dropdown

    $.fn.dropdown = Plugin
    $.fn.dropdown.Constructor = Dropdown


    // DROPDOWN NO CONFLICT
    // ====================

    $.fn.dropdown.noConflict = function() {
        $.fn.dropdown = old
        return this
    }


    // APPLY TO STANDARD DROPDOWN ELEMENTS
    // ===================================

    $(document)
        .on('click.bs.dropdown.data-api', clearMenus)
        .on('click.bs.dropdown.data-api', '.dropdown form', function(e) {
            e.stopPropagation()
        })
        .on('click.bs.dropdown.data-api', toggle, Dropdown.prototype.toggle)
        .on('keydown.bs.dropdown.data-api', toggle, Dropdown.prototype.keydown)
        .on('keydown.bs.dropdown.data-api', '.dropdown-menu', Dropdown.prototype.keydown)

}(jQuery);

/* ========================================================================
 * Bootstrap: modal.js v3.3.6
 * http://getbootstrap.com/javascript/#modals
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // MODAL CLASS DEFINITION
    // ======================

    var Modal = function(element, options) {
        this.options = options
        this.$body = $(document.body)
        this.$element = $(element)
        this.$dialog = this.$element.find('.modal-dialog')
        this.$backdrop = null
        this.isShown = null
        this.originalBodyPad = null
        this.scrollbarWidth = 0
        this.ignoreBackdropClick = false

        if (this.options.remote) {
            this.$element
                .find('.modal-content')
                .load(this.options.remote, $.proxy(function() {
                    this.$element.trigger('loaded.bs.modal')
                }, this))
        }
    }

    Modal.VERSION = '3.3.6'

    Modal.TRANSITION_DURATION = 300
    Modal.BACKDROP_TRANSITION_DURATION = 150

    Modal.DEFAULTS = {
        backdrop: true,
        keyboard: true,
        show: true
    }

    Modal.prototype.toggle = function(_relatedTarget) {
        return this.isShown ? this.hide() : this.show(_relatedTarget)
    }

    Modal.prototype.show = function(_relatedTarget) {
        var that = this
        var e = $.Event('show.bs.modal', {
            relatedTarget: _relatedTarget
        })

        this.$element.trigger(e)

        if (this.isShown || e.isDefaultPrevented()) return

        this.isShown = true

        this.checkScrollbar()
        this.setScrollbar()
        this.$body.addClass('modal-open')

        this.escape()
        this.resize()

        this.$element.on('click.dismiss.bs.modal', '[data-dismiss="modal"]', $.proxy(this.hide, this))

        this.$dialog.on('mousedown.dismiss.bs.modal', function() {
            that.$element.one('mouseup.dismiss.bs.modal', function(e) {
                if ($(e.target).is(that.$element)) that.ignoreBackdropClick = true
            })
        })

        this.backdrop(function() {
            var transition = $.support.transition && that.$element.hasClass('fade')

            if (!that.$element.parent().length) {
                that.$element.appendTo(that.$body) // don't move modals dom position
            }

            that.$element
                .show()
                .scrollTop(0)

            that.adjustDialog()

            if (transition) {
                that.$element[0].offsetWidth // force reflow
            }

            that.$element.addClass('in')

            that.enforceFocus()

            var e = $.Event('shown.bs.modal', {
                relatedTarget: _relatedTarget
            })

            transition ?
                that.$dialog // wait for modal to slide in
                .one('bsTransitionEnd', function() {
                    that.$element.trigger('focus').trigger(e)
                })
                .emulateTransitionEnd(Modal.TRANSITION_DURATION) :
                that.$element.trigger('focus').trigger(e)
        })
    }

    Modal.prototype.hide = function(e) {
        if (e) e.preventDefault()

        e = $.Event('hide.bs.modal')

        this.$element.trigger(e)

        if (!this.isShown || e.isDefaultPrevented()) return

        this.isShown = false

        this.escape()
        this.resize()

        $(document).off('focusin.bs.modal')

        this.$element
            .removeClass('in')
            .off('click.dismiss.bs.modal')
            .off('mouseup.dismiss.bs.modal')

        this.$dialog.off('mousedown.dismiss.bs.modal')

        $.support.transition && this.$element.hasClass('fade') ?
            this.$element
            .one('bsTransitionEnd', $.proxy(this.hideModal, this))
            .emulateTransitionEnd(Modal.TRANSITION_DURATION) :
            this.hideModal()
    }

    Modal.prototype.enforceFocus = function() {
        $(document)
            .off('focusin.bs.modal') // guard against infinite focus loop
            .on('focusin.bs.modal', $.proxy(function(e) {
                if (this.$element[0] !== e.target && !this.$element.has(e.target).length) {
                    this.$element.trigger('focus')
                }
            }, this))
    }

    Modal.prototype.escape = function() {
        if (this.isShown && this.options.keyboard) {
            this.$element.on('keydown.dismiss.bs.modal', $.proxy(function(e) {
                e.which == 27 && this.hide()
            }, this))
        } else if (!this.isShown) {
            this.$element.off('keydown.dismiss.bs.modal')
        }
    }

    Modal.prototype.resize = function() {
        if (this.isShown) {
            $(window).on('resize.bs.modal', $.proxy(this.handleUpdate, this))
        } else {
            $(window).off('resize.bs.modal')
        }
    }

    Modal.prototype.hideModal = function() {
        var that = this
        this.$element.hide()
        this.backdrop(function() {
            that.$body.removeClass('modal-open')
            that.resetAdjustments()
            that.resetScrollbar()
            that.$element.trigger('hidden.bs.modal')
        })
    }

    Modal.prototype.removeBackdrop = function() {
        this.$backdrop && this.$backdrop.remove()
        this.$backdrop = null
    }

    Modal.prototype.backdrop = function(callback) {
        var that = this
        var animate = this.$element.hasClass('fade') ? 'fade' : ''

        if (this.isShown && this.options.backdrop) {
            var doAnimate = $.support.transition && animate

            this.$backdrop = $(document.createElement('div'))
                .addClass('modal-backdrop ' + animate)
                .appendTo(this.$body)

            this.$element.on('click.dismiss.bs.modal', $.proxy(function(e) {
                if (this.ignoreBackdropClick) {
                    this.ignoreBackdropClick = false
                    return
                }
                if (e.target !== e.currentTarget) return
                this.options.backdrop == 'static' ?
                    this.$element[0].focus() :
                    this.hide()
            }, this))

            if (doAnimate) this.$backdrop[0].offsetWidth // force reflow

            this.$backdrop.addClass('in')

            if (!callback) return

            doAnimate ?
                this.$backdrop
                .one('bsTransitionEnd', callback)
                .emulateTransitionEnd(Modal.BACKDROP_TRANSITION_DURATION) :
                callback()

        } else if (!this.isShown && this.$backdrop) {
            this.$backdrop.removeClass('in')

            var callbackRemove = function() {
                that.removeBackdrop()
                callback && callback()
            }
            $.support.transition && this.$element.hasClass('fade') ?
                this.$backdrop
                .one('bsTransitionEnd', callbackRemove)
                .emulateTransitionEnd(Modal.BACKDROP_TRANSITION_DURATION) :
                callbackRemove()

        } else if (callback) {
            callback()
        }
    }

    // these following methods are used to handle overflowing modals

    Modal.prototype.handleUpdate = function() {
        this.adjustDialog()
    }

    Modal.prototype.adjustDialog = function() {
        var modalIsOverflowing = this.$element[0].scrollHeight > document.documentElement.clientHeight

        this.$element.css({
            paddingLeft: !this.bodyIsOverflowing && modalIsOverflowing ? this.scrollbarWidth : '',
            paddingRight: this.bodyIsOverflowing && !modalIsOverflowing ? this.scrollbarWidth : ''
        })
    }

    Modal.prototype.resetAdjustments = function() {
        this.$element.css({
            paddingLeft: '',
            paddingRight: ''
        })
    }

    Modal.prototype.checkScrollbar = function() {
        var fullWindowWidth = window.innerWidth
        if (!fullWindowWidth) { // workaround for missing window.innerWidth in IE8
            var documentElementRect = document.documentElement.getBoundingClientRect()
            fullWindowWidth = documentElementRect.right - Math.abs(documentElementRect.left)
        }
        this.bodyIsOverflowing = document.body.clientWidth < fullWindowWidth
        this.scrollbarWidth = this.measureScrollbar()
    }

    Modal.prototype.setScrollbar = function() {
        var bodyPad = parseInt((this.$body.css('padding-right') || 0), 10)
        this.originalBodyPad = document.body.style.paddingRight || ''
        if (this.bodyIsOverflowing) this.$body.css('padding-right', bodyPad + this.scrollbarWidth)
    }

    Modal.prototype.resetScrollbar = function() {
        this.$body.css('padding-right', this.originalBodyPad)
    }

    Modal.prototype.measureScrollbar = function() { // thx walsh
        var scrollDiv = document.createElement('div')
        scrollDiv.className = 'modal-scrollbar-measure'
        this.$body.append(scrollDiv)
        var scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth
        this.$body[0].removeChild(scrollDiv)
        return scrollbarWidth
    }


    // MODAL PLUGIN DEFINITION
    // =======================

    function Plugin(option, _relatedTarget) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.modal')
            var options = $.extend({}, Modal.DEFAULTS, $this.data(), typeof option == 'object' && option)

            if (!data) $this.data('bs.modal', (data = new Modal(this, options)))
            if (typeof option == 'string') data[option](_relatedTarget)
            else if (options.show) data.show(_relatedTarget)
        })
    }

    var old = $.fn.modal

    $.fn.modal = Plugin
    $.fn.modal.Constructor = Modal


    // MODAL NO CONFLICT
    // =================

    $.fn.modal.noConflict = function() {
        $.fn.modal = old
        return this
    }


    // MODAL DATA-API
    // ==============

    $(document).on('click.bs.modal.data-api', '[data-toggle="modal"]', function(e) {
        var $this = $(this)
        var href = $this.attr('href')
        var $target = $($this.attr('data-target') || (href && href.replace(/.*(?=#[^\s]+$)/, ''))) // strip for ie7
        var option = $target.data('bs.modal') ? 'toggle' : $.extend({
            remote: !/#/.test(href) && href
        }, $target.data(), $this.data())

        if ($this.is('a')) e.preventDefault()

        $target.one('show.bs.modal', function(showEvent) {
            if (showEvent.isDefaultPrevented()) return // only register focus restorer if modal will actually get shown
            $target.one('hidden.bs.modal', function() {
                $this.is(':visible') && $this.trigger('focus')
            })
        })
        Plugin.call($target, option, this)
    })

}(jQuery);

/* ========================================================================
 * Bootstrap: tooltip.js v3.3.6
 * http://getbootstrap.com/javascript/#tooltip
 * Inspired by the original jQuery.tipsy by Jason Frame
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // TOOLTIP PUBLIC CLASS DEFINITION
    // ===============================

    var Tooltip = function(element, options) {
        this.type = null
        this.options = null
        this.enabled = null
        this.timeout = null
        this.hoverState = null
        this.$element = null
        this.inState = null

        this.init('tooltip', element, options)
    }

    Tooltip.VERSION = '3.3.6'

    Tooltip.TRANSITION_DURATION = 150

    Tooltip.DEFAULTS = {
        animation: true,
        placement: 'top',
        selector: false,
        template: '<div class="tooltip" role="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
        trigger: 'hover focus',
        title: '',
        delay: 0,
        html: false,
        container: false,
        viewport: {
            selector: 'body',
            padding: 0
        }
    }

    Tooltip.prototype.init = function(type, element, options) {
        this.enabled = true
        this.type = type
        this.$element = $(element)
        this.options = this.getOptions(options)
        this.$viewport = this.options.viewport && $($.isFunction(this.options.viewport) ? this.options.viewport.call(this, this.$element) : (this.options.viewport.selector || this.options.viewport))
        this.inState = {
            click: false,
            hover: false,
            focus: false
        }

        if (this.$element[0] instanceof document.constructor && !this.options.selector) {
            throw new Error('`selector` option must be specified when initializing ' + this.type + ' on the window.document object!')
        }

        var triggers = this.options.trigger.split(' ')

        for (var i = triggers.length; i--;) {
            var trigger = triggers[i]

            if (trigger == 'click') {
                this.$element.on('click.' + this.type, this.options.selector, $.proxy(this.toggle, this))
            } else if (trigger != 'manual') {
                var eventIn = trigger == 'hover' ? 'mouseenter' : 'focusin'
                var eventOut = trigger == 'hover' ? 'mouseleave' : 'focusout'

                this.$element.on(eventIn + '.' + this.type, this.options.selector, $.proxy(this.enter, this))
                this.$element.on(eventOut + '.' + this.type, this.options.selector, $.proxy(this.leave, this))
            }
        }

        this.options.selector ?
            (this._options = $.extend({}, this.options, {
                trigger: 'manual',
                selector: ''
            })) :
            this.fixTitle()
    }

    Tooltip.prototype.getDefaults = function() {
        return Tooltip.DEFAULTS
    }

    Tooltip.prototype.getOptions = function(options) {
        options = $.extend({}, this.getDefaults(), this.$element.data(), options)

        if (options.delay && typeof options.delay == 'number') {
            options.delay = {
                show: options.delay,
                hide: options.delay
            }
        }

        return options
    }

    Tooltip.prototype.getDelegateOptions = function() {
        var options = {}
        var defaults = this.getDefaults()

        this._options && $.each(this._options, function(key, value) {
            if (defaults[key] != value) options[key] = value
        })

        return options
    }

    Tooltip.prototype.enter = function(obj) {
        var self = obj instanceof this.constructor ?
            obj : $(obj.currentTarget).data('bs.' + this.type)

        if (!self) {
            self = new this.constructor(obj.currentTarget, this.getDelegateOptions())
            $(obj.currentTarget).data('bs.' + this.type, self)
        }

        if (obj instanceof $.Event) {
            self.inState[obj.type == 'focusin' ? 'focus' : 'hover'] = true
        }

        if (self.tip().hasClass('in') || self.hoverState == 'in') {
            self.hoverState = 'in'
            return
        }

        clearTimeout(self.timeout)

        self.hoverState = 'in'

        if (!self.options.delay || !self.options.delay.show) return self.show()

        self.timeout = setTimeout(function() {
            if (self.hoverState == 'in') self.show()
        }, self.options.delay.show)
    }

    Tooltip.prototype.isInStateTrue = function() {
        for (var key in this.inState) {
            if (this.inState[key]) return true
        }

        return false
    }

    Tooltip.prototype.leave = function(obj) {
        var self = obj instanceof this.constructor ?
            obj : $(obj.currentTarget).data('bs.' + this.type)

        if (!self) {
            self = new this.constructor(obj.currentTarget, this.getDelegateOptions())
            $(obj.currentTarget).data('bs.' + this.type, self)
        }

        if (obj instanceof $.Event) {
            self.inState[obj.type == 'focusout' ? 'focus' : 'hover'] = false
        }

        if (self.isInStateTrue()) return

        clearTimeout(self.timeout)

        self.hoverState = 'out'

        if (!self.options.delay || !self.options.delay.hide) return self.hide()

        self.timeout = setTimeout(function() {
            if (self.hoverState == 'out') self.hide()
        }, self.options.delay.hide)
    }

    Tooltip.prototype.show = function() {
        var e = $.Event('show.bs.' + this.type)

        if (this.hasContent() && this.enabled) {
            this.$element.trigger(e)

            var inDom = $.contains(this.$element[0].ownerDocument.documentElement, this.$element[0])
            if (e.isDefaultPrevented() || !inDom) return
            var that = this

            var $tip = this.tip()

            var tipId = this.getUID(this.type)

            this.setContent()
            $tip.attr('id', tipId)
            this.$element.attr('aria-describedby', tipId)

            if (this.options.animation) $tip.addClass('fade')

            var placement = typeof this.options.placement == 'function' ?
                this.options.placement.call(this, $tip[0], this.$element[0]) :
                this.options.placement

            var autoToken = /\s?auto?\s?/i
            var autoPlace = autoToken.test(placement)
            if (autoPlace) placement = placement.replace(autoToken, '') || 'top'

            $tip
                .detach()
                .css({
                    top: 0,
                    left: 0,
                    display: 'block'
                })
                .addClass(placement)
                .data('bs.' + this.type, this)

            this.options.container ? $tip.appendTo(this.options.container) : $tip.insertAfter(this.$element)
            this.$element.trigger('inserted.bs.' + this.type)

            var pos = this.getPosition()
            var actualWidth = $tip[0].offsetWidth
            var actualHeight = $tip[0].offsetHeight

            if (autoPlace) {
                var orgPlacement = placement
                var viewportDim = this.getPosition(this.$viewport)

                placement = placement == 'bottom' && pos.bottom + actualHeight > viewportDim.bottom ? 'top' :
                    placement == 'top' && pos.top - actualHeight < viewportDim.top ? 'bottom' :
                    placement == 'right' && pos.right + actualWidth > viewportDim.width ? 'left' :
                    placement == 'left' && pos.left - actualWidth < viewportDim.left ? 'right' :
                    placement

                $tip
                    .removeClass(orgPlacement)
                    .addClass(placement)
            }

            var calculatedOffset = this.getCalculatedOffset(placement, pos, actualWidth, actualHeight)

            this.applyPlacement(calculatedOffset, placement)

            var complete = function() {
                var prevHoverState = that.hoverState
                that.$element.trigger('shown.bs.' + that.type)
                that.hoverState = null

                if (prevHoverState == 'out') that.leave(that)
            }

            $.support.transition && this.$tip.hasClass('fade') ?
                $tip
                .one('bsTransitionEnd', complete)
                .emulateTransitionEnd(Tooltip.TRANSITION_DURATION) :
                complete()
        }
    }

    Tooltip.prototype.applyPlacement = function(offset, placement) {
        var $tip = this.tip()
        var width = $tip[0].offsetWidth
        var height = $tip[0].offsetHeight

        // manually read margins because getBoundingClientRect includes difference
        var marginTop = parseInt($tip.css('margin-top'), 10)
        var marginLeft = parseInt($tip.css('margin-left'), 10)

        // we must check for NaN for ie 8/9
        if (isNaN(marginTop)) marginTop = 0
        if (isNaN(marginLeft)) marginLeft = 0

        offset.top += marginTop
        offset.left += marginLeft

        // $.fn.offset doesn't round pixel values
        // so we use setOffset directly with our own function B-0
        $.offset.setOffset($tip[0], $.extend({
            using: function(props) {
                $tip.css({
                    top: Math.round(props.top),
                    left: Math.round(props.left)
                })
            }
        }, offset), 0)

        $tip.addClass('in')

        // check to see if placing tip in new offset caused the tip to resize itself
        var actualWidth = $tip[0].offsetWidth
        var actualHeight = $tip[0].offsetHeight

        if (placement == 'top' && actualHeight != height) {
            offset.top = offset.top + height - actualHeight
        }

        var delta = this.getViewportAdjustedDelta(placement, offset, actualWidth, actualHeight)

        if (delta.left) offset.left += delta.left
        else offset.top += delta.top

        var isVertical = /top|bottom/.test(placement)
        var arrowDelta = isVertical ? delta.left * 2 - width + actualWidth : delta.top * 2 - height + actualHeight
        var arrowOffsetPosition = isVertical ? 'offsetWidth' : 'offsetHeight'

        $tip.offset(offset)
        this.replaceArrow(arrowDelta, $tip[0][arrowOffsetPosition], isVertical)
    }

    Tooltip.prototype.replaceArrow = function(delta, dimension, isVertical) {
        this.arrow()
            .css(isVertical ? 'left' : 'top', 50 * (1 - delta / dimension) + '%')
            .css(isVertical ? 'top' : 'left', '')
    }

    Tooltip.prototype.setContent = function() {
        var $tip = this.tip()
        var title = this.getTitle()

        $tip.find('.tooltip-inner')[this.options.html ? 'html' : 'text'](title)
        $tip.removeClass('fade in top bottom left right')
    }

    Tooltip.prototype.hide = function(callback) {
        var that = this
        var $tip = $(this.$tip)
        var e = $.Event('hide.bs.' + this.type)

        function complete() {
            if (that.hoverState != 'in') $tip.detach()
            that.$element
                .removeAttr('aria-describedby')
                .trigger('hidden.bs.' + that.type)
            callback && callback()
        }

        this.$element.trigger(e)

        if (e.isDefaultPrevented()) return

        $tip.removeClass('in')

        $.support.transition && $tip.hasClass('fade') ?
            $tip
            .one('bsTransitionEnd', complete)
            .emulateTransitionEnd(Tooltip.TRANSITION_DURATION) :
            complete()

        this.hoverState = null

        return this
    }

    Tooltip.prototype.fixTitle = function() {
        var $e = this.$element
        if ($e.attr('title') || typeof $e.attr('data-original-title') != 'string') {
            $e.attr('data-original-title', $e.attr('title') || '').attr('title', '')
        }
    }

    Tooltip.prototype.hasContent = function() {
        return this.getTitle()
    }

    Tooltip.prototype.getPosition = function($element) {
        $element = $element || this.$element

        var el = $element[0]
        var isBody = el.tagName == 'BODY'

        var elRect = el.getBoundingClientRect()
        if (elRect.width == null) {
            // width and height are missing in IE8, so compute them manually; see https://github.com/twbs/bootstrap/issues/14093
            elRect = $.extend({}, elRect, {
                width: elRect.right - elRect.left,
                height: elRect.bottom - elRect.top
            })
        }
        var elOffset = isBody ? {
            top: 0,
            left: 0
        } : $element.offset()
        var scroll = {
            scroll: isBody ? document.documentElement.scrollTop || document.body.scrollTop : $element.scrollTop()
        }
        var outerDims = isBody ? {
            width: $(window).width(),
            height: $(window).height()
        } : null

        return $.extend({}, elRect, scroll, outerDims, elOffset)
    }

    Tooltip.prototype.getCalculatedOffset = function(placement, pos, actualWidth, actualHeight) {
        return placement == 'bottom' ? {
                top: pos.top + pos.height,
                left: pos.left + pos.width / 2 - actualWidth / 2
            } :
            placement == 'top' ? {
                top: pos.top - actualHeight,
                left: pos.left + pos.width / 2 - actualWidth / 2
            } :
            placement == 'left' ? {
                top: pos.top + pos.height / 2 - actualHeight / 2,
                left: pos.left - actualWidth
            } :
            /* placement == 'right' */
            {
                top: pos.top + pos.height / 2 - actualHeight / 2,
                left: pos.left + pos.width
            }

    }

    Tooltip.prototype.getViewportAdjustedDelta = function(placement, pos, actualWidth, actualHeight) {
        var delta = {
            top: 0,
            left: 0
        }
        if (!this.$viewport) return delta

        var viewportPadding = this.options.viewport && this.options.viewport.padding || 0
        var viewportDimensions = this.getPosition(this.$viewport)

        if (/right|left/.test(placement)) {
            var topEdgeOffset = pos.top - viewportPadding - viewportDimensions.scroll
            var bottomEdgeOffset = pos.top + viewportPadding - viewportDimensions.scroll + actualHeight
            if (topEdgeOffset < viewportDimensions.top) { // top overflow
                delta.top = viewportDimensions.top - topEdgeOffset
            } else if (bottomEdgeOffset > viewportDimensions.top + viewportDimensions.height) { // bottom overflow
                delta.top = viewportDimensions.top + viewportDimensions.height - bottomEdgeOffset
            }
        } else {
            var leftEdgeOffset = pos.left - viewportPadding
            var rightEdgeOffset = pos.left + viewportPadding + actualWidth
            if (leftEdgeOffset < viewportDimensions.left) { // left overflow
                delta.left = viewportDimensions.left - leftEdgeOffset
            } else if (rightEdgeOffset > viewportDimensions.right) { // right overflow
                delta.left = viewportDimensions.left + viewportDimensions.width - rightEdgeOffset
            }
        }

        return delta
    }

    Tooltip.prototype.getTitle = function() {
        var title
        var $e = this.$element
        var o = this.options

        title = $e.attr('data-original-title') ||
            (typeof o.title == 'function' ? o.title.call($e[0]) : o.title)

        return title
    }

    Tooltip.prototype.getUID = function(prefix) {
        do prefix += ~~(Math.random() * 1000000)
        while (document.getElementById(prefix))
        return prefix
    }

    Tooltip.prototype.tip = function() {
        if (!this.$tip) {
            this.$tip = $(this.options.template)
            if (this.$tip.length != 1) {
                throw new Error(this.type + ' `template` option must consist of exactly 1 top-level element!')
            }
        }
        return this.$tip
    }

    Tooltip.prototype.arrow = function() {
        return (this.$arrow = this.$arrow || this.tip().find('.tooltip-arrow'))
    }

    Tooltip.prototype.enable = function() {
        this.enabled = true
    }

    Tooltip.prototype.disable = function() {
        this.enabled = false
    }

    Tooltip.prototype.toggleEnabled = function() {
        this.enabled = !this.enabled
    }

    Tooltip.prototype.toggle = function(e) {
        var self = this
        if (e) {
            self = $(e.currentTarget).data('bs.' + this.type)
            if (!self) {
                self = new this.constructor(e.currentTarget, this.getDelegateOptions())
                $(e.currentTarget).data('bs.' + this.type, self)
            }
        }

        if (e) {
            self.inState.click = !self.inState.click
            if (self.isInStateTrue()) self.enter(self)
            else self.leave(self)
        } else {
            self.tip().hasClass('in') ? self.leave(self) : self.enter(self)
        }
    }

    Tooltip.prototype.destroy = function() {
        var that = this
        clearTimeout(this.timeout)
        this.hide(function() {
            that.$element.off('.' + that.type).removeData('bs.' + that.type)
            if (that.$tip) {
                that.$tip.detach()
            }
            that.$tip = null
            that.$arrow = null
            that.$viewport = null
        })
    }


    // TOOLTIP PLUGIN DEFINITION
    // =========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.tooltip')
            var options = typeof option == 'object' && option

            if (!data && /destroy|hide/.test(option)) return
            if (!data) $this.data('bs.tooltip', (data = new Tooltip(this, options)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.tooltip

    $.fn.tooltip = Plugin
    $.fn.tooltip.Constructor = Tooltip


    // TOOLTIP NO CONFLICT
    // ===================

    $.fn.tooltip.noConflict = function() {
        $.fn.tooltip = old
        return this
    }

}(jQuery);

/* ========================================================================
 * Bootstrap: popover.js v3.3.6
 * http://getbootstrap.com/javascript/#popovers
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // POPOVER PUBLIC CLASS DEFINITION
    // ===============================

    var Popover = function(element, options) {
        this.init('popover', element, options)
    }

    if (!$.fn.tooltip) throw new Error('Popover requires tooltip.js')

    Popover.VERSION = '3.3.6'

    Popover.DEFAULTS = $.extend({}, $.fn.tooltip.Constructor.DEFAULTS, {
        placement: 'right',
        trigger: 'click',
        content: '',
        template: '<div class="popover" role="tooltip"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
    })


    // NOTE: POPOVER EXTENDS tooltip.js
    // ================================

    Popover.prototype = $.extend({}, $.fn.tooltip.Constructor.prototype)

    Popover.prototype.constructor = Popover

    Popover.prototype.getDefaults = function() {
        return Popover.DEFAULTS
    }

    Popover.prototype.setContent = function() {
        var $tip = this.tip()
        var title = this.getTitle()
        var content = this.getContent()

        $tip.find('.popover-title')[this.options.html ? 'html' : 'text'](title)
        $tip.find('.popover-content').children().detach().end()[ // we use append for html objects to maintain js events
            this.options.html ? (typeof content == 'string' ? 'html' : 'append') : 'text'
        ](content)

        $tip.removeClass('fade top bottom left right in')

        // IE8 doesn't accept hiding via the `:empty` pseudo selector, we have to do
        // this manually by checking the contents.
        if (!$tip.find('.popover-title').html()) $tip.find('.popover-title').hide()
    }

    Popover.prototype.hasContent = function() {
        return this.getTitle() || this.getContent()
    }

    Popover.prototype.getContent = function() {
        var $e = this.$element
        var o = this.options

        return $e.attr('data-content') ||
            (typeof o.content == 'function' ?
                o.content.call($e[0]) :
                o.content)
    }

    Popover.prototype.arrow = function() {
        return (this.$arrow = this.$arrow || this.tip().find('.arrow'))
    }


    // POPOVER PLUGIN DEFINITION
    // =========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.popover')
            var options = typeof option == 'object' && option

            if (!data && /destroy|hide/.test(option)) return
            if (!data) $this.data('bs.popover', (data = new Popover(this, options)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.popover

    $.fn.popover = Plugin
    $.fn.popover.Constructor = Popover


    // POPOVER NO CONFLICT
    // ===================

    $.fn.popover.noConflict = function() {
        $.fn.popover = old
        return this
    }

}(jQuery);

/* ========================================================================
 * Bootstrap: scrollspy.js v3.3.6
 * http://getbootstrap.com/javascript/#scrollspy
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // SCROLLSPY CLASS DEFINITION
    // ==========================

    function ScrollSpy(element, options) {
        this.$body = $(document.body)
        this.$scrollElement = $(element).is(document.body) ? $(window) : $(element)
        this.options = $.extend({}, ScrollSpy.DEFAULTS, options)
        this.selector = (this.options.target || '') + ' .nav li > a'
        this.offsets = []
        this.targets = []
        this.activeTarget = null
        this.scrollHeight = 0

        this.$scrollElement.on('scroll.bs.scrollspy', $.proxy(this.process, this))
        this.refresh()
        this.process()
    }

    ScrollSpy.VERSION = '3.3.6'

    ScrollSpy.DEFAULTS = {
        offset: 10
    }

    ScrollSpy.prototype.getScrollHeight = function() {
        return this.$scrollElement[0].scrollHeight || Math.max(this.$body[0].scrollHeight, document.documentElement.scrollHeight)
    }

    ScrollSpy.prototype.refresh = function() {
        var that = this
        var offsetMethod = 'offset'
        var offsetBase = 0

        this.offsets = []
        this.targets = []
        this.scrollHeight = this.getScrollHeight()

        if (!$.isWindow(this.$scrollElement[0])) {
            offsetMethod = 'position'
            offsetBase = this.$scrollElement.scrollTop()
        }

        this.$body
            .find(this.selector)
            .map(function() {
                var $el = $(this)
                var href = $el.data('target') || $el.attr('href')
                var $href = /^#./.test(href) && $(href)

                return ($href &&
                    $href.length &&
                    $href.is(':visible') &&
                    [
                        [$href[offsetMethod]().top + offsetBase, href]
                    ]) || null
            })
            .sort(function(a, b) {
                return a[0] - b[0]
            })
            .each(function() {
                that.offsets.push(this[0])
                that.targets.push(this[1])
            })
    }

    ScrollSpy.prototype.process = function() {
        var scrollTop = this.$scrollElement.scrollTop() + this.options.offset
        var scrollHeight = this.getScrollHeight()
        var maxScroll = this.options.offset + scrollHeight - this.$scrollElement.height()
        var offsets = this.offsets
        var targets = this.targets
        var activeTarget = this.activeTarget
        var i

        if (this.scrollHeight != scrollHeight) {
            this.refresh()
        }

        if (scrollTop >= maxScroll) {
            return activeTarget != (i = targets[targets.length - 1]) && this.activate(i)
        }

        if (activeTarget && scrollTop < offsets[0]) {
            this.activeTarget = null
            return this.clear()
        }

        for (i = offsets.length; i--;) {
            activeTarget != targets[i] &&
                scrollTop >= offsets[i] &&
                (offsets[i + 1] === undefined || scrollTop < offsets[i + 1]) &&
                this.activate(targets[i])
        }
    }

    ScrollSpy.prototype.activate = function(target) {
        this.activeTarget = target

        this.clear()

        var selector = this.selector +
            '[data-target="' + target + '"],' +
            this.selector + '[href="' + target + '"]'

        var active = $(selector)
            .parents('li')
            .addClass('active')

        if (active.parent('.dropdown-menu').length) {
            active = active
                .closest('li.dropdown')
                .addClass('active')
        }

        active.trigger('activate.bs.scrollspy')
    }

    ScrollSpy.prototype.clear = function() {
        $(this.selector)
            .parentsUntil(this.options.target, '.active')
            .removeClass('active')
    }


    // SCROLLSPY PLUGIN DEFINITION
    // ===========================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.scrollspy')
            var options = typeof option == 'object' && option

            if (!data) $this.data('bs.scrollspy', (data = new ScrollSpy(this, options)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.scrollspy

    $.fn.scrollspy = Plugin
    $.fn.scrollspy.Constructor = ScrollSpy


    // SCROLLSPY NO CONFLICT
    // =====================

    $.fn.scrollspy.noConflict = function() {
        $.fn.scrollspy = old
        return this
    }


    // SCROLLSPY DATA-API
    // ==================

    $(window).on('load.bs.scrollspy.data-api', function() {
        $('[data-spy="scroll"]').each(function() {
            var $spy = $(this)
            Plugin.call($spy, $spy.data())
        })
    })

}(jQuery);

/* ========================================================================
 * Bootstrap: tab.js v3.3.6
 * http://getbootstrap.com/javascript/#tabs
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // TAB CLASS DEFINITION
    // ====================

    var Tab = function(element) {
        // jscs:disable requireDollarBeforejQueryAssignment
        this.element = $(element)
            // jscs:enable requireDollarBeforejQueryAssignment
    }

    Tab.VERSION = '3.3.6'

    Tab.TRANSITION_DURATION = 150

    Tab.prototype.show = function() {
        var $this = this.element
        var $ul = $this.closest('ul:not(.dropdown-menu)')
        var selector = $this.data('target')

        if (!selector) {
            selector = $this.attr('href')
            selector = selector && selector.replace(/.*(?=#[^\s]*$)/, '') // strip for ie7
        }

        if ($this.parent('li').hasClass('active')) return

        var $previous = $ul.find('.active:last a')
        var hideEvent = $.Event('hide.bs.tab', {
            relatedTarget: $this[0]
        })
        var showEvent = $.Event('show.bs.tab', {
            relatedTarget: $previous[0]
        })

        $previous.trigger(hideEvent)
        $this.trigger(showEvent)

        if (showEvent.isDefaultPrevented() || hideEvent.isDefaultPrevented()) return

        var $target = $(selector)

        this.activate($this.closest('li'), $ul)
        this.activate($target, $target.parent(), function() {
            $previous.trigger({
                type: 'hidden.bs.tab',
                relatedTarget: $this[0]
            })
            $this.trigger({
                type: 'shown.bs.tab',
                relatedTarget: $previous[0]
            })
        })
    }

    Tab.prototype.activate = function(element, container, callback) {
        var $active = container.find('> .active')
        var transition = callback &&
            $.support.transition &&
            ($active.length && $active.hasClass('fade') || !!container.find('> .fade').length)

        function next() {
            $active
                .removeClass('active')
                .find('> .dropdown-menu > .active')
                .removeClass('active')
                .end()
                .find('[data-toggle="tab"]')
                .attr('aria-expanded', false)

            element
                .addClass('active')
                .find('[data-toggle="tab"]')
                .attr('aria-expanded', true)

            if (transition) {
                element[0].offsetWidth // reflow for transition
                element.addClass('in')
            } else {
                element.removeClass('fade')
            }

            if (element.parent('.dropdown-menu').length) {
                element
                    .closest('li.dropdown')
                    .addClass('active')
                    .end()
                    .find('[data-toggle="tab"]')
                    .attr('aria-expanded', true)
            }

            callback && callback()
        }

        $active.length && transition ?
            $active
            .one('bsTransitionEnd', next)
            .emulateTransitionEnd(Tab.TRANSITION_DURATION) :
            next()

        $active.removeClass('in')
    }


    // TAB PLUGIN DEFINITION
    // =====================

    function Plugin(option) {
        return this.each(function() {
            var $this = $(this)
            var data = $this.data('bs.tab')

            if (!data) $this.data('bs.tab', (data = new Tab(this)))
            if (typeof option == 'string') data[option]()
        })
    }

    var old = $.fn.tab

    $.fn.tab = Plugin
    $.fn.tab.Constructor = Tab


    // TAB NO CONFLICT
    // ===============

    $.fn.tab.noConflict = function() {
        $.fn.tab = old
        return this
    }


    // TAB DATA-API
    // ============

    var clickHandler = function(e) {
        e.preventDefault()
        Plugin.call($(this), 'show')
    }

    $(document)
        .on('click.bs.tab.data-api', '[data-toggle="tab"]', clickHandler)
        .on('click.bs.tab.data-api', '[data-toggle="pill"]', clickHandler)

}(jQuery);

/* ========================================================================
 * Bootstrap: transition.js v3.3.6
 * http://getbootstrap.com/javascript/#transitions
 * ========================================================================
 * Copyright 2011-2015 Twitter, Inc.
 * Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
 * ======================================================================== */


+

function($) {
    'use strict';

    // CSS TRANSITION SUPPORT (Shoutout: http://www.modernizr.com/)
    // ============================================================

    function transitionEnd() {
        var el = document.createElement('bootstrap')

        var transEndEventNames = {
            WebkitTransition: 'webkitTransitionEnd',
            MozTransition: 'transitionend',
            OTransition: 'oTransitionEnd otransitionend',
            transition: 'transitionend'
        }

        for (var name in transEndEventNames) {
            if (el.style[name] !== undefined) {
                return {
                    end: transEndEventNames[name]
                }
            }
        }

        return false // explicit for ie8 (  ._.)
    }

    // http://blog.alexmaccaw.com/css-transitions
    $.fn.emulateTransitionEnd = function(duration) {
        var called = false
        var $el = this
        $(this).one('bsTransitionEnd', function() {
            called = true
        })
        var callback = function() {
            if (!called) $($el).trigger($.support.transition.end)
        }
        setTimeout(callback, duration)
        return this
    }

    $(function() {
        $.support.transition = transitionEnd()

        if (!$.support.transition) return

        $.event.special.bsTransitionEnd = {
            bindType: $.support.transition.end,
            delegateType: $.support.transition.end,
            handle: function(e) {
                if ($(e.target).is(this)) return e.handleObj.handler.apply(this, arguments)
            }
        }
    })

}(jQuery);

/*!
 * enquire.js v2.1.2 - Awesome Media Queries in JavaScript
 * Copyright (c) 2014 Nick Williams - http://wicky.nillia.ms/enquire.js
 * License: MIT (http://www.opensource.org/licenses/mit-license.php)
 */

! function(a, b, c) {
    var d = window.matchMedia;
    "undefined" != typeof module && module.exports ? module.exports = c(d) : "function" == typeof define && define.amd ? define(function() {
        return b[a] = c(d)
    }) : b[a] = c(d)
}("enquire", this, function(a) {
    "use strict";

    function b(a, b) {
        var c, d = 0,
            e = a.length;
        for (d; e > d && (c = b(a[d], d), c !== !1); d++);
    }

    function c(a) {
        return "[object Array]" === Object.prototype.toString.apply(a)
    }

    function d(a) {
        return "function" == typeof a
    }

    function e(a) {
        this.options = a, !a.deferSetup && this.setup()
    }

    function f(b, c) {
        this.query = b, this.isUnconditional = c, this.handlers = [], this.mql = a(b);
        var d = this;
        this.listener = function(a) {
            d.mql = a, d.assess()
        }, this.mql.addListener(this.listener)
    }

    function g() {
        if (!a) throw new Error("matchMedia not present, legacy browsers require a polyfill");
        this.queries = {}, this.browserIsIncapable = !a("only all").matches
    }
    return e.prototype = {
        setup: function() {
            this.options.setup && this.options.setup(), this.initialised = !0
        },
        on: function() {
            !this.initialised && this.setup(), this.options.match && this.options.match()
        },
        off: function() {
            this.options.unmatch && this.options.unmatch()
        },
        destroy: function() {
            this.options.destroy ? this.options.destroy() : this.off()
        },
        equals: function(a) {
            return this.options === a || this.options.match === a
        }
    }, f.prototype = {
        addHandler: function(a) {
            var b = new e(a);
            this.handlers.push(b), this.matches() && b.on()
        },
        removeHandler: function(a) {
            var c = this.handlers;
            b(c, function(b, d) {
                return b.equals(a) ? (b.destroy(), !c.splice(d, 1)) : void 0
            })
        },
        matches: function() {
            return this.mql.matches || this.isUnconditional
        },
        clear: function() {
            b(this.handlers, function(a) {
                a.destroy()
            }), this.mql.removeListener(this.listener), this.handlers.length = 0
        },
        assess: function() {
            var a = this.matches() ? "on" : "off";
            b(this.handlers, function(b) {
                b[a]()
            })
        }
    }, g.prototype = {
        register: function(a, e, g) {
            var h = this.queries,
                i = g && this.browserIsIncapable;
            return h[a] || (h[a] = new f(a, i)), d(e) && (e = {
                match: e
            }), c(e) || (e = [e]), b(e, function(b) {
                d(b) && (b = {
                    match: b
                }), h[a].addHandler(b)
            }), this
        },
        unregister: function(a, b) {
            var c = this.queries[a];
            return c && (b ? c.removeHandler(b) : (c.clear(), delete this.queries[a])), this
        }
    }, new g
});
/*! viewportSize | Author: Tyson Matanich, 2013 | License: MIT */
(function(n) {
    n.viewportSize = {}, n.viewportSize.getHeight = function() {
        return t("Height")
    }, n.viewportSize.getWidth = function() {
        return t("Width")
    };
    var t = function(t) {
        var f, o = t.toLowerCase(),
            e = n.document,
            i = e.documentElement,
            r, u;
        return n["inner" + t] === undefined ? f = i["client" + t] : n["inner" + t] != i["client" + t] ? (r = e.createElement("body"), r.id = "vpw-test-b", r.style.cssText = "overflow:scroll", u = e.createElement("div"), u.id = "vpw-test-d", u.style.cssText = "position:absolute;top:-1000px", u.innerHTML = "<style>@media(" + o + ":" + i["client" + t] + "px){body#vpw-test-b div#vpw-test-d{" + o + ":7px!important}}<\/style>", r.appendChild(u), i.insertBefore(r, e.head), f = u["offset" + t] == 7 ? i["client" + t] : n["inner" + t], i.removeChild(r)) : f = n["inner" + t], f
    }
})(this);
/*
 * jQuery throttle / debounce - v1.1 - 3/7/2010
 * http://benalman.com/projects/jquery-throttle-debounce-plugin/
 * 
 * Copyright (c) 2010 "Cowboy" Ben Alman
 * Dual licensed under the MIT and GPL licenses.
 * http://benalman.com/about/license/
 */
(function(b, c) {
    var $ = b.jQuery || b.Cowboy || (b.Cowboy = {}),
        a;
    $.throttle = a = function(e, f, j, i) {
        var h, d = 0;
        if (typeof f !== "boolean") {
            i = j;
            j = f;
            f = c
        }

        function g() {
            var o = this,
                m = +new Date() - d,
                n = arguments;

            function l() {
                d = +new Date();
                j.apply(o, n)
            }

            function k() {
                h = c
            }
            if (i && !h) {
                l()
            }
            h && clearTimeout(h);
            if (i === c && m > e) {
                l()
            } else {
                if (f !== true) {
                    h = setTimeout(i ? k : l, i === c ? e - m : e)
                }
            }
        }
        if ($.guid) {
            g.guid = j.guid = j.guid || $.guid++
        }
        return g
    };
    $.debounce = function(d, e, f) {
        return f === c ? a(d, e, false) : a(d, f, e !== false)
    }
})(this);
/*! nouislider - 8.5.1 - 2016-04-24 16:00:29 */

! function(a) {
    "function" == typeof define && define.amd ? define([], a) : "object" == typeof exports ? module.exports = a() : window.noUiSlider = a()
}(function() {
    "use strict";

    function a(a) {
        return a.filter(function(a) {
            return this[a] ? !1 : this[a] = !0
        }, {})
    }

    function b(a, b) {
        return Math.round(a / b) * b
    }

    function c(a) {
        var b = a.getBoundingClientRect(),
            c = a.ownerDocument,
            d = c.documentElement,
            e = l();
        return /webkit.*Chrome.*Mobile/i.test(navigator.userAgent) && (e.x = 0), {
            top: b.top + e.y - d.clientTop,
            left: b.left + e.x - d.clientLeft
        }
    }

    function d(a) {
        return "number" == typeof a && !isNaN(a) && isFinite(a)
    }

    function e(a, b, c) {
        i(a, b), setTimeout(function() {
            j(a, b)
        }, c)
    }

    function f(a) {
        return Math.max(Math.min(a, 100), 0)
    }

    function g(a) {
        return Array.isArray(a) ? a : [a]
    }

    function h(a) {
        var b = a.split(".");
        return b.length > 1 ? b[1].length : 0
    }

    function i(a, b) {
        a.classList ? a.classList.add(b) : a.className += " " + b
    }

    function j(a, b) {
        a.classList ? a.classList.remove(b) : a.className = a.className.replace(new RegExp("(^|\\b)" + b.split(" ").join("|") + "(\\b|$)", "gi"), " ")
    }

    function k(a, b) {
        return a.classList ? a.classList.contains(b) : new RegExp("\\b" + b + "\\b").test(a.className)
    }

    function l() {
        var a = void 0 !== window.pageXOffset,
            b = "CSS1Compat" === (document.compatMode || ""),
            c = a ? window.pageXOffset : b ? document.documentElement.scrollLeft : document.body.scrollLeft,
            d = a ? window.pageYOffset : b ? document.documentElement.scrollTop : document.body.scrollTop;
        return {
            x: c,
            y: d
        }
    }

    function m() {
        return window.navigator.pointerEnabled ? {
            start: "pointerdown",
            move: "pointermove",
            end: "pointerup"
        } : window.navigator.msPointerEnabled ? {
            start: "MSPointerDown",
            move: "MSPointerMove",
            end: "MSPointerUp"
        } : {
            start: "mousedown touchstart",
            move: "mousemove touchmove",
            end: "mouseup touchend"
        }
    }

    function n(a, b) {
        return 100 / (b - a)
    }

    function o(a, b) {
        return 100 * b / (a[1] - a[0])
    }

    function p(a, b) {
        return o(a, a[0] < 0 ? b + Math.abs(a[0]) : b - a[0])
    }

    function q(a, b) {
        return b * (a[1] - a[0]) / 100 + a[0]
    }

    function r(a, b) {
        for (var c = 1; a >= b[c];) c += 1;
        return c
    }

    function s(a, b, c) {
        if (c >= a.slice(-1)[0]) return 100;
        var d, e, f, g, h = r(c, a);
        return d = a[h - 1], e = a[h], f = b[h - 1], g = b[h], f + p([d, e], c) / n(f, g)
    }

    function t(a, b, c) {
        if (c >= 100) return a.slice(-1)[0];
        var d, e, f, g, h = r(c, b);
        return d = a[h - 1], e = a[h], f = b[h - 1], g = b[h], q([d, e], (c - f) * n(f, g))
    }

    function u(a, c, d, e) {
        if (100 === e) return e;
        var f, g, h = r(e, a);
        return d ? (f = a[h - 1], g = a[h], e - f > (g - f) / 2 ? g : f) : c[h - 1] ? a[h - 1] + b(e - a[h - 1], c[h - 1]) : e
    }

    function v(a, b, c) {
        var e;
        if ("number" == typeof b && (b = [b]), "[object Array]" !== Object.prototype.toString.call(b)) throw new Error("noUiSlider: 'range' contains invalid value.");
        if (e = "min" === a ? 0 : "max" === a ? 100 : parseFloat(a), !d(e) || !d(b[0])) throw new Error("noUiSlider: 'range' value isn't numeric.");
        c.xPct.push(e), c.xVal.push(b[0]), e ? c.xSteps.push(isNaN(b[1]) ? !1 : b[1]) : isNaN(b[1]) || (c.xSteps[0] = b[1])
    }

    function w(a, b, c) {
        return b ? void(c.xSteps[a] = o([c.xVal[a], c.xVal[a + 1]], b) / n(c.xPct[a], c.xPct[a + 1])) : !0
    }

    function x(a, b, c, d) {
        this.xPct = [], this.xVal = [], this.xSteps = [d || !1], this.xNumSteps = [!1], this.snap = b, this.direction = c;
        var e, f = [];
        for (e in a) a.hasOwnProperty(e) && f.push([a[e], e]);
        for (f.length && "object" == typeof f[0][0] ? f.sort(function(a, b) {
                return a[0][0] - b[0][0]
            }) : f.sort(function(a, b) {
                return a[0] - b[0]
            }), e = 0; e < f.length; e++) v(f[e][1], f[e][0], this);
        for (this.xNumSteps = this.xSteps.slice(0), e = 0; e < this.xNumSteps.length; e++) w(e, this.xNumSteps[e], this)
    }

    function y(a, b) {
        if (!d(b)) throw new Error("noUiSlider: 'step' is not numeric.");
        a.singleStep = b
    }

    function z(a, b) {
        if ("object" != typeof b || Array.isArray(b)) throw new Error("noUiSlider: 'range' is not an object.");
        if (void 0 === b.min || void 0 === b.max) throw new Error("noUiSlider: Missing 'min' or 'max' in 'range'.");
        if (b.min === b.max) throw new Error("noUiSlider: 'range' 'min' and 'max' cannot be equal.");
        a.spectrum = new x(b, a.snap, a.dir, a.singleStep)
    }

    function A(a, b) {
        if (b = g(b), !Array.isArray(b) || !b.length || b.length > 2) throw new Error("noUiSlider: 'start' option is incorrect.");
        a.handles = b.length, a.start = b
    }

    function B(a, b) {
        if (a.snap = b, "boolean" != typeof b) throw new Error("noUiSlider: 'snap' option must be a boolean.")
    }

    function C(a, b) {
        if (a.animate = b, "boolean" != typeof b) throw new Error("noUiSlider: 'animate' option must be a boolean.")
    }

    function D(a, b) {
        if (a.animationDuration = b, "number" != typeof b) throw new Error("noUiSlider: 'animationDuration' option must be a number.")
    }

    function E(a, b) {
        if ("lower" === b && 1 === a.handles) a.connect = 1;
        else if ("upper" === b && 1 === a.handles) a.connect = 2;
        else if (b === !0 && 2 === a.handles) a.connect = 3;
        else {
            if (b !== !1) throw new Error("noUiSlider: 'connect' option doesn't match handle count.");
            a.connect = 0
        }
    }

    function F(a, b) {
        switch (b) {
            case "horizontal":
                a.ort = 0;
                break;
            case "vertical":
                a.ort = 1;
                break;
            default:
                throw new Error("noUiSlider: 'orientation' option is invalid.")
        }
    }

    function G(a, b) {
        if (!d(b)) throw new Error("noUiSlider: 'margin' option must be numeric.");
        if (0 !== b && (a.margin = a.spectrum.getMargin(b), !a.margin)) throw new Error("noUiSlider: 'margin' option is only supported on linear sliders.")
    }

    function H(a, b) {
        if (!d(b)) throw new Error("noUiSlider: 'limit' option must be numeric.");
        if (a.limit = a.spectrum.getMargin(b), !a.limit) throw new Error("noUiSlider: 'limit' option is only supported on linear sliders.")
    }

    function I(a, b) {
        switch (b) {
            case "ltr":
                a.dir = 0;
                break;
            case "rtl":
                a.dir = 1, a.connect = [0, 2, 1, 3][a.connect];
                break;
            default:
                throw new Error("noUiSlider: 'direction' option was not recognized.")
        }
    }

    function J(a, b) {
        if ("string" != typeof b) throw new Error("noUiSlider: 'behaviour' must be a string containing options.");
        var c = b.indexOf("tap") >= 0,
            d = b.indexOf("drag") >= 0,
            e = b.indexOf("fixed") >= 0,
            f = b.indexOf("snap") >= 0,
            g = b.indexOf("hover") >= 0;
        if (d && !a.connect) throw new Error("noUiSlider: 'drag' behaviour must be used with 'connect': true.");
        a.events = {
            tap: c || f,
            drag: d,
            fixed: e,
            snap: f,
            hover: g
        }
    }

    function K(a, b) {
        var c;
        if (b !== !1)
            if (b === !0)
                for (a.tooltips = [], c = 0; c < a.handles; c++) a.tooltips.push(!0);
            else {
                if (a.tooltips = g(b), a.tooltips.length !== a.handles) throw new Error("noUiSlider: must pass a formatter for all handles.");
                a.tooltips.forEach(function(a) {
                    if ("boolean" != typeof a && ("object" != typeof a || "function" != typeof a.to)) throw new Error("noUiSlider: 'tooltips' must be passed a formatter or 'false'.")
                })
            }
    }

    function L(a, b) {
        if (a.format = b, "function" == typeof b.to && "function" == typeof b.from) return !0;
        throw new Error("noUiSlider: 'format' requires 'to' and 'from' methods.")
    }

    function M(a, b) {
        if (void 0 !== b && "string" != typeof b && b !== !1) throw new Error("noUiSlider: 'cssPrefix' must be a string or `false`.");
        a.cssPrefix = b
    }

    function N(a, b) {
        if (void 0 !== b && "object" != typeof b) throw new Error("noUiSlider: 'cssClasses' must be an object.");
        if ("string" == typeof a.cssPrefix) {
            a.cssClasses = {};
            for (var c in b) b.hasOwnProperty(c) && (a.cssClasses[c] = a.cssPrefix + b[c])
        } else a.cssClasses = b
    }

    function O(a) {
        var b, c = {
            margin: 0,
            limit: 0,
            animate: !0,
            animationDuration: 300,
            format: R
        };
        b = {
            step: {
                r: !1,
                t: y
            },
            start: {
                r: !0,
                t: A
            },
            connect: {
                r: !0,
                t: E
            },
            direction: {
                r: !0,
                t: I
            },
            snap: {
                r: !1,
                t: B
            },
            animate: {
                r: !1,
                t: C
            },
            animationDuration: {
                r: !1,
                t: D
            },
            range: {
                r: !0,
                t: z
            },
            orientation: {
                r: !1,
                t: F
            },
            margin: {
                r: !1,
                t: G
            },
            limit: {
                r: !1,
                t: H
            },
            behaviour: {
                r: !0,
                t: J
            },
            format: {
                r: !1,
                t: L
            },
            tooltips: {
                r: !1,
                t: K
            },
            cssPrefix: {
                r: !1,
                t: M
            },
            cssClasses: {
                r: !1,
                t: N
            }
        };
        var d = {
            connect: !1,
            direction: "ltr",
            behaviour: "tap",
            orientation: "horizontal",
            cssPrefix: "noUi-",
            cssClasses: {
                target: "target",
                base: "base",
                origin: "origin",
                handle: "handle",
                handleLower: "handle-lower",
                handleUpper: "handle-upper",
                horizontal: "horizontal",
                vertical: "vertical",
                background: "background",
                connect: "connect",
                ltr: "ltr",
                rtl: "rtl",
                draggable: "draggable",
                drag: "state-drag",
                tap: "state-tap",
                active: "active",
                stacking: "stacking",
                tooltip: "tooltip",
                pips: "pips",
                pipsHorizontal: "pips-horizontal",
                pipsVertical: "pips-vertical",
                marker: "marker",
                markerHorizontal: "marker-horizontal",
                markerVertical: "marker-vertical",
                markerNormal: "marker-normal",
                markerLarge: "marker-large",
                markerSub: "marker-sub",
                value: "value",
                valueHorizontal: "value-horizontal",
                valueVertical: "value-vertical",
                valueNormal: "value-normal",
                valueLarge: "value-large",
                valueSub: "value-sub"
            }
        };
        return Object.keys(b).forEach(function(e) {
            if (void 0 === a[e] && void 0 === d[e]) {
                if (b[e].r) throw new Error("noUiSlider: '" + e + "' is required.");
                return !0
            }
            b[e].t(c, void 0 === a[e] ? d[e] : a[e])
        }), c.pips = a.pips, c.style = c.ort ? "top" : "left", c
    }

    function P(b, d, n) {
        function o(a, b, c) {
            var d = a + b[0],
                e = a + b[1];
            return c ? (0 > d && (e += Math.abs(d)), e > 100 && (d -= e - 100), [f(d), f(e)]) : [d, e]
        }

        function p(a, b) {
            a.preventDefault();
            var c, d, e = 0 === a.type.indexOf("touch"),
                f = 0 === a.type.indexOf("mouse"),
                g = 0 === a.type.indexOf("pointer"),
                h = a;
            return 0 === a.type.indexOf("MSPointer") && (g = !0), e && (c = a.changedTouches[0].pageX, d = a.changedTouches[0].pageY), b = b || l(), (f || g) && (c = a.clientX + b.x, d = a.clientY + b.y), h.pageOffset = b, h.points = [c, d], h.cursor = f || g, h
        }

        function q(a, b) {
            var c = document.createElement("div"),
                e = document.createElement("div"),
                f = [d.cssClasses.handleLower, d.cssClasses.handleUpper];
            return a && f.reverse(), i(e, d.cssClasses.handle), i(e, f[b]), i(c, d.cssClasses.origin), c.appendChild(e), c
        }

        function r(a, b, c) {
            switch (a) {
                case 1:
                    i(b, d.cssClasses.connect), i(c[0], d.cssClasses.background);
                    break;
                case 3:
                    i(c[1], d.cssClasses.background);
                case 2:
                    i(c[0], d.cssClasses.connect);
                case 0:
                    i(b, d.cssClasses.background)
            }
        }

        function s(a, b, c) {
            var d, e = [];
            for (d = 0; a > d; d += 1) e.push(c.appendChild(q(b, d)));
            return e
        }

        function t(a, b, c) {
            i(c, d.cssClasses.target), 0 === a ? i(c, d.cssClasses.ltr) : i(c, d.cssClasses.rtl), 0 === b ? i(c, d.cssClasses.horizontal) : i(c, d.cssClasses.vertical);
            var e = document.createElement("div");
            return i(e, d.cssClasses.base), c.appendChild(e), e
        }

        function u(a, b) {
            if (!d.tooltips[b]) return !1;
            var c = document.createElement("div");
            return c.className = d.cssClasses.tooltip, a.firstChild.appendChild(c)
        }

        function v() {
            d.dir && d.tooltips.reverse();
            var a = W.map(u);
            d.dir && (a.reverse(), d.tooltips.reverse()), S("update", function(b, c, e) {
                a[c] && (a[c].innerHTML = d.tooltips[c] === !0 ? b[c] : d.tooltips[c].to(e[c]))
            })
        }

        function w(a, b, c) {
            if ("range" === a || "steps" === a) return _.xVal;
            if ("count" === a) {
                var d, e = 100 / (b - 1),
                    f = 0;
                for (b = [];
                    (d = f++ * e) <= 100;) b.push(d);
                a = "positions"
            }
            return "positions" === a ? b.map(function(a) {
                return _.fromStepping(c ? _.getStep(a) : a)
            }) : "values" === a ? c ? b.map(function(a) {
                return _.fromStepping(_.getStep(_.toStepping(a)))
            }) : b : void 0
        }

        function x(b, c, d) {
            function e(a, b) {
                return (a + b).toFixed(7) / 1
            }
            var f = _.direction,
                g = {},
                h = _.xVal[0],
                i = _.xVal[_.xVal.length - 1],
                j = !1,
                k = !1,
                l = 0;
            return _.direction = 0, d = a(d.slice().sort(function(a, b) {
                return a - b
            })), d[0] !== h && (d.unshift(h), j = !0), d[d.length - 1] !== i && (d.push(i), k = !0), d.forEach(function(a, f) {
                var h, i, m, n, o, p, q, r, s, t, u = a,
                    v = d[f + 1];
                if ("steps" === c && (h = _.xNumSteps[f]), h || (h = v - u), u !== !1 && void 0 !== v)
                    for (i = u; v >= i; i = e(i, h)) {
                        for (n = _.toStepping(i), o = n - l, r = o / b, s = Math.round(r), t = o / s, m = 1; s >= m; m += 1) p = l + m * t, g[p.toFixed(5)] = ["x", 0];
                        q = d.indexOf(i) > -1 ? 1 : "steps" === c ? 2 : 0, !f && j && (q = 0), i === v && k || (g[n.toFixed(5)] = [i, q]), l = n
                    }
            }), _.direction = f, g
        }

        function y(a, b, c) {
            function e(a, b) {
                var c = b === d.cssClasses.value,
                    e = c ? m : n,
                    f = c ? k : l;
                return b + " " + e[d.ort] + " " + f[a]
            }

            function f(a, b, c) {
                return 'class="' + e(c[1], b) + '" style="' + d.style + ": " + a + '%"'
            }

            function g(a, e) {
                _.direction && (a = 100 - a), e[1] = e[1] && b ? b(e[0], e[1]) : e[1], j += "<div " + f(a, d.cssClasses.marker, e) + "></div>", e[1] && (j += "<div " + f(a, d.cssClasses.value, e) + ">" + c.to(e[0]) + "</div>")
            }
            var h = document.createElement("div"),
                j = "",
                k = [d.cssClasses.valueNormal, d.cssClasses.valueLarge, d.cssClasses.valueSub],
                l = [d.cssClasses.markerNormal, d.cssClasses.markerLarge, d.cssClasses.markerSub],
                m = [d.cssClasses.valueHorizontal, d.cssClasses.valueVertical],
                n = [d.cssClasses.markerHorizontal, d.cssClasses.markerVertical];
            return i(h, d.cssClasses.pips), i(h, 0 === d.ort ? d.cssClasses.pipsHorizontal : d.cssClasses.pipsVertical), Object.keys(a).forEach(function(b) {
                g(b, a[b])
            }), h.innerHTML = j, h
        }

        function z(a) {
            var b = a.mode,
                c = a.density || 1,
                d = a.filter || !1,
                e = a.values || !1,
                f = a.stepped || !1,
                g = w(b, e, f),
                h = x(c, b, g),
                i = a.format || {
                    to: Math.round
                };
            return Z.appendChild(y(h, d, i))
        }

        function A() {
            var a = V.getBoundingClientRect(),
                b = "offset" + ["Width", "Height"][d.ort];
            return 0 === d.ort ? a.width || V[b] : a.height || V[b]
        }

        function B(a, b, c) {
            var e;
            for (e = 0; e < d.handles; e++)
                if (-1 === $[e]) return;
            void 0 !== b && 1 !== d.handles && (b = Math.abs(b - d.dir)), Object.keys(ba).forEach(function(d) {
                var e = d.split(".")[0];
                a === e && ba[d].forEach(function(a) {
                    a.call(X, g(P()), b, g(C(Array.prototype.slice.call(aa))), c || !1, $)
                })
            })
        }

        function C(a) {
            return 1 === a.length ? a[0] : d.dir ? a.reverse() : a
        }

        function D(a, b, c, e) {
            var f = function(b) {
                    return Z.hasAttribute("disabled") ? !1 : k(Z, d.cssClasses.tap) ? !1 : (b = p(b, e.pageOffset), a === Y.start && void 0 !== b.buttons && b.buttons > 1 ? !1 : e.hover && b.buttons ? !1 : (b.calcPoint = b.points[d.ort], void c(b, e)))
                },
                g = [];
            return a.split(" ").forEach(function(a) {
                b.addEventListener(a, f, !1), g.push([a, f])
            }), g
        }

        function E(a, b) {
            if (-1 === navigator.appVersion.indexOf("MSIE 9") && 0 === a.buttons && 0 !== b.buttonsProperty) return F(a, b);
            var c, d, e = b.handles || W,
                f = !1,
                g = 100 * (a.calcPoint - b.start) / b.baseSize,
                h = e[0] === W[0] ? 0 : 1;
            if (c = o(g, b.positions, e.length > 1), f = L(e[0], c[h], 1 === e.length), e.length > 1) {
                if (f = L(e[1], c[h ? 0 : 1], !1) || f)
                    for (d = 0; d < b.handles.length; d++) B("slide", d)
            } else f && B("slide", h)
        }

        function F(a, b) {
            var c = V.querySelector("." + d.cssClasses.active),
                e = b.handles[0] === W[0] ? 0 : 1;
            null !== c && j(c, d.cssClasses.active), a.cursor && (document.body.style.cursor = "", document.body.removeEventListener("selectstart", document.body.noUiListener));
            var f = document.documentElement;
            f.noUiListeners.forEach(function(a) {
                f.removeEventListener(a[0], a[1])
            }), j(Z, d.cssClasses.drag), B("set", e), B("change", e), void 0 !== b.handleNumber && B("end", b.handleNumber)
        }

        function G(a, b) {
            "mouseout" === a.type && "HTML" === a.target.nodeName && null === a.relatedTarget && F(a, b)
        }

        function H(a, b) {
            var c = document.documentElement;
            if (1 === b.handles.length) {
                if (b.handles[0].hasAttribute("disabled")) return !1;
                i(b.handles[0].children[0], d.cssClasses.active)
            }
            a.preventDefault(), a.stopPropagation();
            var e = D(Y.move, c, E, {
                    start: a.calcPoint,
                    baseSize: A(),
                    pageOffset: a.pageOffset,
                    handles: b.handles,
                    handleNumber: b.handleNumber,
                    buttonsProperty: a.buttons,
                    positions: [$[0], $[W.length - 1]]
                }),
                f = D(Y.end, c, F, {
                    handles: b.handles,
                    handleNumber: b.handleNumber
                }),
                g = D("mouseout", c, G, {
                    handles: b.handles,
                    handleNumber: b.handleNumber
                });
            if (c.noUiListeners = e.concat(f, g), a.cursor) {
                document.body.style.cursor = getComputedStyle(a.target).cursor, W.length > 1 && i(Z, d.cssClasses.drag);
                var h = function() {
                    return !1
                };
                document.body.noUiListener = h, document.body.addEventListener("selectstart", h, !1)
            }
            void 0 !== b.handleNumber && B("start", b.handleNumber)
        }

        function I(a) {
            var b, f, g = a.calcPoint,
                h = 0;
            return a.stopPropagation(), W.forEach(function(a) {
                h += c(a)[d.style]
            }), b = h / 2 > g || 1 === W.length ? 0 : 1, W[b].hasAttribute("disabled") && (b = b ? 0 : 1), g -= c(V)[d.style], f = 100 * g / A(), d.events.snap || e(Z, d.cssClasses.tap, d.animationDuration), W[b].hasAttribute("disabled") ? !1 : (L(W[b], f), B("slide", b, !0), B("set", b, !0), B("change", b, !0), void(d.events.snap && H(a, {
                handles: [W[b]]
            })))
        }

        function J(a) {
            var b = a.calcPoint - c(V)[d.style],
                e = _.getStep(100 * b / A()),
                f = _.fromStepping(e);
            Object.keys(ba).forEach(function(a) {
                "hover" === a.split(".")[0] && ba[a].forEach(function(a) {
                    a.call(X, f)
                })
            })
        }

        function K(a) {
            if (a.fixed || W.forEach(function(a, b) {
                    D(Y.start, a.children[0], H, {
                        handles: [a],
                        handleNumber: b
                    })
                }), a.tap && D(Y.start, V, I, {
                    handles: W
                }), a.hover && D(Y.move, V, J, {
                    hover: !0
                }), a.drag) {
                var b = [V.querySelector("." + d.cssClasses.connect)];
                i(b[0], d.cssClasses.draggable), a.fixed && b.push(W[b[0] === W[0] ? 1 : 0].children[0]), b.forEach(function(a) {
                    D(Y.start, a, H, {
                        handles: W
                    })
                })
            }
        }

        function L(a, b, c) {
            var e = a !== W[0] ? 1 : 0,
                g = $[0] + d.margin,
                h = $[1] - d.margin,
                k = $[0] + d.limit,
                l = $[1] - d.limit;
            return W.length > 1 && (b = e ? Math.max(b, g) : Math.min(b, h)), c !== !1 && d.limit && W.length > 1 && (b = e ? Math.min(b, k) : Math.max(b, l)), b = _.getStep(b), b = f(b), b === $[e] ? !1 : (window.requestAnimationFrame ? window.requestAnimationFrame(function() {
                a.style[d.style] = b + "%"
            }) : a.style[d.style] = b + "%", a.previousSibling || (j(a, d.cssClasses.stacking), b > 50 && i(a, d.cssClasses.stacking)), $[e] = b, aa[e] = _.fromStepping(b), B("update", e), !0)
        }

        function M(a, b) {
            var c, e, f;
            for (d.limit && (a += 1), c = 0; a > c; c += 1) e = c % 2, f = b[e], null !== f && f !== !1 && ("number" == typeof f && (f = String(f)), f = d.format.from(f), (f === !1 || isNaN(f) || L(W[e], _.toStepping(f), c === 3 - d.dir) === !1) && B("update", e))
        }

        function N(a, b) {
            var c, f, h = g(a);
            for (b = void 0 === b ? !0 : !!b, d.dir && d.handles > 1 && h.reverse(), d.animate && -1 !== $[0] && e(Z, d.cssClasses.tap, d.animationDuration), c = W.length > 1 ? 3 : 1, 1 === h.length && (c = 1), M(c, h), f = 0; f < W.length; f++) null !== h[f] && b && B("set", f)
        }

        function P() {
            var a, b = [];
            for (a = 0; a < d.handles; a += 1) b[a] = d.format.to(aa[a]);
            return C(b)
        }

        function Q() {
            for (var a in d.cssClasses) d.cssClasses.hasOwnProperty(a) && j(Z, d.cssClasses[a]);
            for (; Z.firstChild;) Z.removeChild(Z.firstChild);
            delete Z.noUiSlider
        }

        function R() {
            var a = $.map(function(a, b) {
                var c = _.getApplicableStep(a),
                    d = h(String(c[2])),
                    e = aa[b],
                    f = 100 === a ? null : c[2],
                    g = Number((e - c[2]).toFixed(d)),
                    i = 0 === a ? null : g >= c[1] ? c[2] : c[0] || !1;
                return [i, f]
            });
            return C(a)
        }

        function S(a, b) {
            ba[a] = ba[a] || [], ba[a].push(b), "update" === a.split(".")[0] && W.forEach(function(a, b) {
                B("update", b)
            })
        }

        function T(a) {
            var b = a && a.split(".")[0],
                c = b && a.substring(b.length);
            Object.keys(ba).forEach(function(a) {
                var d = a.split(".")[0],
                    e = a.substring(d.length);
                b && b !== d || c && c !== e || delete ba[a]
            })
        }

        function U(a, b) {
            var c = P(),
                e = O({
                    start: [0, 0],
                    margin: a.margin,
                    limit: a.limit,
                    step: void 0 === a.step ? d.singleStep : a.step,
                    range: a.range,
                    animate: a.animate,
                    snap: void 0 === a.snap ? d.snap : a.snap
                });
            ["margin", "limit", "range", "animate"].forEach(function(b) {
                void 0 !== a[b] && (d[b] = a[b])
            }), e.spectrum.direction = _.direction, _ = e.spectrum, $ = [-1, -1], N(a.start || c, b)
        }
        var V, W, X, Y = m(),
            Z = b,
            $ = [-1, -1],
            _ = d.spectrum,
            aa = [],
            ba = {};
        if (Z.noUiSlider) throw new Error("Slider was already initialized.");
        return V = t(d.dir, d.ort, Z), W = s(d.handles, d.dir, V), r(d.connect, Z, W), d.pips && z(d.pips), d.tooltips && v(), X = {
            destroy: Q,
            steps: R,
            on: S,
            off: T,
            get: P,
            set: N,
            updateOptions: U,
            options: n,
            target: Z,
            pips: z
        }, K(d.events), X
    }

    function Q(a, b) {
        if (!a.nodeName) throw new Error("noUiSlider.create requires a single element.");
        var c = O(b, a),
            d = P(a, c, b);
        return d.set(c.start), a.noUiSlider = d, d
    }
    x.prototype.getMargin = function(a) {
        return 2 === this.xPct.length ? o(this.xVal, a) : !1
    }, x.prototype.toStepping = function(a) {
        return a = s(this.xVal, this.xPct, a), this.direction && (a = 100 - a), a
    }, x.prototype.fromStepping = function(a) {
        return this.direction && (a = 100 - a), t(this.xVal, this.xPct, a)
    }, x.prototype.getStep = function(a) {
        return this.direction && (a = 100 - a), a = u(this.xPct, this.xSteps, this.snap, a), this.direction && (a = 100 - a), a
    }, x.prototype.getApplicableStep = function(a) {
        var b = r(a, this.xPct),
            c = 100 === a ? 2 : 1;
        return [this.xNumSteps[b - 2], this.xVal[b - c], this.xNumSteps[b - c]]
    }, x.prototype.convert = function(a) {
        return this.getStep(this.toStepping(a))
    };
    var R = {
        to: function(a) {
            return void 0 !== a && a.toFixed(2)
        },
        from: Number
    };
    return {
        create: Q
    }
});
/*!
 * Bootstrap-select v1.10.0 (http://silviomoreto.github.io/bootstrap-select)
 *
 * Copyright 2013-2016 bootstrap-select
 * Licensed under MIT (https://github.com/silviomoreto/bootstrap-select/blob/master/LICENSE)
 */
! function(a, b) {
    "function" == typeof define && define.amd ? define(["jquery"], function(a) {
        return b(a)
    }) : "object" == typeof exports ? module.exports = b(require("jquery")) : b(jQuery)
}(this, function(a) {
    ! function(a) {
        "use strict";

        function b(b) {
            var c = [{
                re: /[\xC0-\xC6]/g,
                ch: "A"
            }, {
                re: /[\xE0-\xE6]/g,
                ch: "a"
            }, {
                re: /[\xC8-\xCB]/g,
                ch: "E"
            }, {
                re: /[\xE8-\xEB]/g,
                ch: "e"
            }, {
                re: /[\xCC-\xCF]/g,
                ch: "I"
            }, {
                re: /[\xEC-\xEF]/g,
                ch: "i"
            }, {
                re: /[\xD2-\xD6]/g,
                ch: "O"
            }, {
                re: /[\xF2-\xF6]/g,
                ch: "o"
            }, {
                re: /[\xD9-\xDC]/g,
                ch: "U"
            }, {
                re: /[\xF9-\xFC]/g,
                ch: "u"
            }, {
                re: /[\xC7-\xE7]/g,
                ch: "c"
            }, {
                re: /[\xD1]/g,
                ch: "N"
            }, {
                re: /[\xF1]/g,
                ch: "n"
            }];
            return a.each(c, function() {
                b = b.replace(this.re, this.ch)
            }), b
        }

        function c(a) {
            var b = {
                    "&": "&amp;",
                    "<": "&lt;",
                    ">": "&gt;",
                    '"': "&quot;",
                    "'": "&#x27;",
                    "`": "&#x60;"
                },
                c = "(?:" + Object.keys(b).join("|") + ")",
                d = new RegExp(c),
                e = new RegExp(c, "g"),
                f = null == a ? "" : "" + a;
            return d.test(f) ? f.replace(e, function(a) {
                return b[a]
            }) : f
        }

        function d(b, c) {
            var d = arguments,
                f = b,
                g = c;
            [].shift.apply(d);
            var h, i = this.each(function() {
                var b = a(this);
                if (b.is("select")) {
                    var c = b.data("selectpicker"),
                        i = "object" == typeof f && f;
                    if (c) {
                        if (i)
                            for (var j in i) i.hasOwnProperty(j) && (c.options[j] = i[j])
                    } else {
                        var k = a.extend({}, e.DEFAULTS, a.fn.selectpicker.defaults || {}, b.data(), i);
                        k.template = a.extend({}, e.DEFAULTS.template, a.fn.selectpicker.defaults ? a.fn.selectpicker.defaults.template : {}, b.data().template, i.template), b.data("selectpicker", c = new e(this, k, g))
                    }
                    "string" == typeof f && (h = c[f] instanceof Function ? c[f].apply(c, d) : c.options[f])
                }
            });
            return "undefined" != typeof h ? h : i
        }
        String.prototype.includes || ! function() {
            var a = {}.toString,
                b = function() {
                    try {
                        var a = {},
                            b = Object.defineProperty,
                            c = b(a, a, a) && b
                    } catch (d) {}
                    return c
                }(),
                c = "".indexOf,
                d = function(b) {
                    if (null == this) throw new TypeError;
                    var d = String(this);
                    if (b && "[object RegExp]" == a.call(b)) throw new TypeError;
                    var e = d.length,
                        f = String(b),
                        g = f.length,
                        h = arguments.length > 1 ? arguments[1] : void 0,
                        i = h ? Number(h) : 0;
                    i != i && (i = 0);
                    var j = Math.min(Math.max(i, 0), e);
                    return g + j > e ? !1 : -1 != c.call(d, f, i)
                };
            b ? b(String.prototype, "includes", {
                value: d,
                configurable: !0,
                writable: !0
            }) : String.prototype.includes = d
        }(), String.prototype.startsWith || ! function() {
            var a = function() {
                    try {
                        var a = {},
                            b = Object.defineProperty,
                            c = b(a, a, a) && b
                    } catch (d) {}
                    return c
                }(),
                b = {}.toString,
                c = function(a) {
                    if (null == this) throw new TypeError;
                    var c = String(this);
                    if (a && "[object RegExp]" == b.call(a)) throw new TypeError;
                    var d = c.length,
                        e = String(a),
                        f = e.length,
                        g = arguments.length > 1 ? arguments[1] : void 0,
                        h = g ? Number(g) : 0;
                    h != h && (h = 0);
                    var i = Math.min(Math.max(h, 0), d);
                    if (f + i > d) return !1;
                    for (var j = -1; ++j < f;)
                        if (c.charCodeAt(i + j) != e.charCodeAt(j)) return !1;
                    return !0
                };
            a ? a(String.prototype, "startsWith", {
                value: c,
                configurable: !0,
                writable: !0
            }) : String.prototype.startsWith = c
        }(), Object.keys || (Object.keys = function(a, b, c) {
            c = [];
            for (b in a) c.hasOwnProperty.call(a, b) && c.push(b);
            return c
        }), a.fn.triggerNative = function(a) {
            var b, c = this[0];
            c.dispatchEvent ? ("function" == typeof Event ? b = new Event(a, {
                bubbles: !0
            }) : (b = document.createEvent("Event"), b.initEvent(a, !0, !1)), c.dispatchEvent(b)) : (c.fireEvent && (b = document.createEventObject(), b.eventType = a, c.fireEvent("on" + a, b)), this.trigger(a))
        }, a.expr[":"].icontains = function(b, c, d) {
            var e = a(b),
                f = (e.data("tokens") || e.text()).toUpperCase();
            return f.includes(d[3].toUpperCase())
        }, a.expr[":"].ibegins = function(b, c, d) {
            var e = a(b),
                f = (e.data("tokens") || e.text()).toUpperCase();
            return f.startsWith(d[3].toUpperCase())
        }, a.expr[":"].aicontains = function(b, c, d) {
            var e = a(b),
                f = (e.data("tokens") || e.data("normalizedText") || e.text()).toUpperCase();
            return f.includes(d[3].toUpperCase())
        }, a.expr[":"].aibegins = function(b, c, d) {
            var e = a(b),
                f = (e.data("tokens") || e.data("normalizedText") || e.text()).toUpperCase();
            return f.startsWith(d[3].toUpperCase())
        };
        var e = function(b, c, d) {
            d && (d.stopPropagation(), d.preventDefault()), this.$element = a(b), this.$newElement = null, this.$button = null, this.$menu = null, this.$lis = null, this.options = c, null === this.options.title && (this.options.title = this.$element.attr("title")), this.val = e.prototype.val, this.render = e.prototype.render, this.refresh = e.prototype.refresh, this.setStyle = e.prototype.setStyle, this.selectAll = e.prototype.selectAll, this.deselectAll = e.prototype.deselectAll, this.destroy = e.prototype.destroy, this.remove = e.prototype.remove, this.show = e.prototype.show, this.hide = e.prototype.hide, this.init()
        };
        e.VERSION = "1.10.0", e.DEFAULTS = {
            noneSelectedText: "Nothing selected",
            noneResultsText: "No results matched {0}",
            countSelectedText: function(a, b) {
                return 1 == a ? "{0} item selected" : "{0} items selected"
            },
            maxOptionsText: function(a, b) {
                return [1 == a ? "Limit reached ({n} item max)" : "Limit reached ({n} items max)", 1 == b ? "Group limit reached ({n} item max)" : "Group limit reached ({n} items max)"]
            },
            selectAllText: "Select All",
            deselectAllText: "Deselect All",
            doneButton: !1,
            doneButtonText: "Close",
            multipleSeparator: ", ",
            styleBase: "btn",
            style: "btn-default",
            size: "auto",
            title: null,
            selectedTextFormat: "values",
            width: !1,
            container: !1,
            hideDisabled: !1,
            showSubtext: !1,
            showIcon: !0,
            showContent: !0,
            dropupAuto: !0,
            header: !1,
            liveSearch: !1,
            liveSearchPlaceholder: null,
            liveSearchNormalize: !1,
            liveSearchStyle: "contains",
            actionsBox: !1,
            iconBase: "glyphicon",
            tickIcon: "glyphicon-ok",
            showTick: !1,
            template: {
                caret: '<span class="caret"></span>'
            },
            maxOptions: !1,
            mobile: !1,
            selectOnTab: !1,
            dropdownAlignRight: !1
        }, e.prototype = {
            constructor: e,
            init: function() {
                var b = this,
                    c = this.$element.attr("id");
                this.$element.addClass("bs-select-hidden"), this.liObj = {}, this.multiple = this.$element.prop("multiple"), this.autofocus = this.$element.prop("autofocus"), this.$newElement = this.createView(), this.$element.after(this.$newElement).appendTo(this.$newElement), this.$button = this.$newElement.children("button"), this.$menu = this.$newElement.children(".dropdown-menu"), this.$menuInner = this.$menu.children(".inner"), this.$searchbox = this.$menu.find("input"), this.$element.removeClass("bs-select-hidden"), this.options.dropdownAlignRight && this.$menu.addClass("dropdown-menu-right"), "undefined" != typeof c && (this.$button.attr("data-id", c), a('label[for="' + c + '"]').click(function(a) {
                    a.preventDefault(), b.$button.focus()
                })), this.checkDisabled(), this.clickListener(), this.options.liveSearch && this.liveSearchListener(), this.render(), this.setStyle(), this.setWidth(), this.options.container && this.selectPosition(), this.$menu.data("this", this), this.$newElement.data("this", this), this.options.mobile && this.mobile(), this.$newElement.on({
                    "hide.bs.dropdown": function(a) {
                        b.$element.trigger("hide.bs.select", a)
                    },
                    "hidden.bs.dropdown": function(a) {
                        b.$element.trigger("hidden.bs.select", a)
                    },
                    "show.bs.dropdown": function(a) {
                        b.$element.trigger("show.bs.select", a)
                    },
                    "shown.bs.dropdown": function(a) {
                        b.$element.trigger("shown.bs.select", a)
                    }
                }), b.$element[0].hasAttribute("required") && this.$element.on("invalid", function() {
                    b.$button.addClass("bs-invalid").focus(), b.$element.on({
                        "focus.bs.select": function() {
                            b.$button.focus(), b.$element.off("focus.bs.select")
                        },
                        "shown.bs.select": function() {
                            b.$element.val(b.$element.val()).off("shown.bs.select")
                        },
                        "rendered.bs.select": function() {
                            this.validity.valid && b.$button.removeClass("bs-invalid"), b.$element.off("rendered.bs.select")
                        }
                    })
                }), setTimeout(function() {
                    b.$element.trigger("loaded.bs.select")
                })
            },
            createDropdown: function() {
                var b = this.multiple || this.options.showTick ? " show-tick" : "",
                    d = this.$element.parent().hasClass("input-group") ? " input-group-btn" : "",
                    e = this.autofocus ? " autofocus" : "",
                    f = this.options.header ? '<div class="popover-title"><button type="button" class="close" aria-hidden="true">&times;</button>' + this.options.header + "</div>" : "",
                    g = this.options.liveSearch ? '<div class="bs-searchbox"><input type="text" class="form-control" autocomplete="off"' + (null === this.options.liveSearchPlaceholder ? "" : ' placeholder="' + c(this.options.liveSearchPlaceholder) + '"') + "></div>" : "",
                    h = this.multiple && this.options.actionsBox ? '<div class="bs-actionsbox"><div class="btn-group btn-group-sm btn-block"><button type="button" class="actions-btn bs-select-all btn btn-default">' + this.options.selectAllText + '</button><button type="button" class="actions-btn bs-deselect-all btn btn-default">' + this.options.deselectAllText + "</button></div></div>" : "",
                    i = this.multiple && this.options.doneButton ? '<div class="bs-donebutton"><div class="btn-group btn-block"><button type="button" class="btn btn-sm btn-default">' + this.options.doneButtonText + "</button></div></div>" : "",
                    j = '<div class="btn-group bootstrap-select' + b + d + '"><button type="button" class="' + this.options.styleBase + ' dropdown-toggle" data-toggle="dropdown"' + e + '><span class="filter-option pull-left"></span>&nbsp;<span class="bs-caret">' + this.options.template.caret + '</span></button><div class="dropdown-menu open">' + f + g + h + '<ul class="dropdown-menu inner" role="menu"></ul>' + i + "</div></div>";
                return a(j)
            },
            createView: function() {
                var a = this.createDropdown(),
                    b = this.createLi();
                return a.find("ul")[0].innerHTML = b, a
            },
            reloadLi: function() {
                this.destroyLi();
                var a = this.createLi();
                this.$menuInner[0].innerHTML = a
            },
            destroyLi: function() {
                this.$menu.find("li").remove()
            },
            createLi: function() {
                var d = this,
                    e = [],
                    f = 0,
                    g = document.createElement("option"),
                    h = -1,
                    i = function(a, b, c, d) {
                        return "<li" + ("undefined" != typeof c & "" !== c ? ' class="' + c + '"' : "") + ("undefined" != typeof b & null !== b ? ' data-original-index="' + b + '"' : "") + ("undefined" != typeof d & null !== d ? 'data-optgroup="' + d + '"' : "") + ">" + a + "</li>"
                    },
                    j = function(a, e, f, g) {
                        return '<a tabindex="0"' + ("undefined" != typeof e ? ' class="' + e + '"' : "") + ("undefined" != typeof f ? ' style="' + f + '"' : "") + (d.options.liveSearchNormalize ? ' data-normalized-text="' + b(c(a)) + '"' : "") + ("undefined" != typeof g || null !== g ? ' data-tokens="' + g + '"' : "") + ">" + a + '<span class="' + d.options.iconBase + " " + d.options.tickIcon + ' check-mark"></span></a>'
                    };
                if (this.options.title && !this.multiple && (h--, !this.$element.find(".bs-title-option").length)) {
                    var k = this.$element[0];
                    g.className = "bs-title-option", g.appendChild(document.createTextNode(this.options.title)), g.value = "", k.insertBefore(g, k.firstChild), void 0 === a(k.options[k.selectedIndex]).attr("selected") && (g.selected = !0)
                }
                return this.$element.find("option").each(function(b) {
                    var c = a(this);
                    if (h++, !c.hasClass("bs-title-option")) {
                        var g = this.className || "",
                            k = this.style.cssText,
                            l = c.data("content") ? c.data("content") : c.html(),
                            m = c.data("tokens") ? c.data("tokens") : null,
                            n = "undefined" != typeof c.data("subtext") ? '<small class="text-muted">' + c.data("subtext") + "</small>" : "",
                            o = "undefined" != typeof c.data("icon") ? '<span class="' + d.options.iconBase + " " + c.data("icon") + '"></span> ' : "",
                            p = "OPTGROUP" === this.parentNode.tagName,
                            q = this.disabled || p && this.parentNode.disabled;
                        if ("" !== o && q && (o = "<span>" + o + "</span>"), d.options.hideDisabled && q && !p) return void h--;
                        if (c.data("content") || (l = o + '<span class="text">' + l + n + "</span>"), p && c.data("divider") !== !0) {
                            var r = " " + this.parentNode.className || "";
                            if (0 === c.index()) {
                                f += 1;
                                var s = this.parentNode.label,
                                    t = "undefined" != typeof c.parent().data("subtext") ? '<small class="text-muted">' + c.parent().data("subtext") + "</small>" : "",
                                    u = c.parent().data("icon") ? '<span class="' + d.options.iconBase + " " + c.parent().data("icon") + '"></span> ' : "";
                                s = u + '<span class="text">' + s + t + "</span>", 0 !== b && e.length > 0 && (h++, e.push(i("", null, "divider", f + "div"))), h++, e.push(i(s, null, "dropdown-header" + r, f))
                            }
                            if (d.options.hideDisabled && q) return void h--;
                            e.push(i(j(l, "opt " + g + r, k, m), b, "", f))
                        } else c.data("divider") === !0 ? e.push(i("", b, "divider")) : c.data("hidden") === !0 ? e.push(i(j(l, g, k, m), b, "hidden is-hidden")) : (this.previousElementSibling && "OPTGROUP" === this.previousElementSibling.tagName && (h++, e.push(i("", null, "divider", f + "div"))), e.push(i(j(l, g, k, m), b)));
                        d.liObj[b] = h
                    }
                }), this.multiple || 0 !== this.$element.find("option:selected").length || this.options.title || this.$element.find("option").eq(0).prop("selected", !0).attr("selected", "selected"), e.join("")
            },
            findLis: function() {
                return null == this.$lis && (this.$lis = this.$menu.find("li")), this.$lis
            },
            render: function(b) {
                var c, d = this;
                b !== !1 && this.$element.find("option").each(function(a) {
                    var b = d.findLis().eq(d.liObj[a]);
                    d.setDisabled(a, this.disabled || "OPTGROUP" === this.parentNode.tagName && this.parentNode.disabled, b), d.setSelected(a, this.selected, b)
                }), this.tabIndex();
                var e = this.$element.find("option").map(function() {
                        if (this.selected) {
                            if (d.options.hideDisabled && (this.disabled || "OPTGROUP" === this.parentNode.tagName && this.parentNode.disabled)) return;
                            var b, c = a(this),
                                e = c.data("icon") && d.options.showIcon ? '<i class="' + d.options.iconBase + " " + c.data("icon") + '"></i> ' : "";
                            return b = d.options.showSubtext && c.data("subtext") && !d.multiple ? ' <small class="text-muted">' + c.data("subtext") + "</small>" : "", "undefined" != typeof c.attr("title") ? c.attr("title") : c.data("content") && d.options.showContent ? c.data("content") : e + c.html() + b
                        }
                    }).toArray(),
                    f = this.multiple ? e.join(this.options.multipleSeparator) : e[0];
                if (this.multiple && this.options.selectedTextFormat.indexOf("count") > -1) {
                    var g = this.options.selectedTextFormat.split(">");
                    if (g.length > 1 && e.length > g[1] || 1 == g.length && e.length >= 2) {
                        c = this.options.hideDisabled ? ", [disabled]" : "";
                        var h = this.$element.find("option").not('[data-divider="true"], [data-hidden="true"]' + c).length,
                            i = "function" == typeof this.options.countSelectedText ? this.options.countSelectedText(e.length, h) : this.options.countSelectedText;
                        f = i.replace("{0}", e.length.toString()).replace("{1}", h.toString())
                    }
                }
                void 0 == this.options.title && (this.options.title = this.$element.attr("title")), "static" == this.options.selectedTextFormat && (f = this.options.title), f || (f = "undefined" != typeof this.options.title ? this.options.title : this.options.noneSelectedText), this.$button.attr("title", a.trim(f.replace(/<[^>]*>?/g, ""))), this.$button.children(".filter-option").html(f), this.$element.trigger("rendered.bs.select")
            },
            setStyle: function(a, b) {
                this.$element.attr("class") && this.$newElement.addClass(this.$element.attr("class").replace(/selectpicker|mobile-device|bs-select-hidden|validate\[.*\]/gi, ""));
                var c = a ? a : this.options.style;
                "add" == b ? this.$button.addClass(c) : "remove" == b ? this.$button.removeClass(c) : (this.$button.removeClass(this.options.style), this.$button.addClass(c))
            },
            liHeight: function(b) {
                if (b || this.options.size !== !1 && !this.sizeInfo) {
                    var c = document.createElement("div"),
                        d = document.createElement("div"),
                        e = document.createElement("ul"),
                        f = document.createElement("li"),
                        g = document.createElement("li"),
                        h = document.createElement("a"),
                        i = document.createElement("span"),
                        j = this.options.header && this.$menu.find(".popover-title").length > 0 ? this.$menu.find(".popover-title")[0].cloneNode(!0) : null,
                        k = this.options.liveSearch ? document.createElement("div") : null,
                        l = this.options.actionsBox && this.multiple && this.$menu.find(".bs-actionsbox").length > 0 ? this.$menu.find(".bs-actionsbox")[0].cloneNode(!0) : null,
                        m = this.options.doneButton && this.multiple && this.$menu.find(".bs-donebutton").length > 0 ? this.$menu.find(".bs-donebutton")[0].cloneNode(!0) : null;
                    if (i.className = "text", c.className = this.$menu[0].parentNode.className + " open", d.className = "dropdown-menu open", e.className = "dropdown-menu inner", f.className = "divider", i.appendChild(document.createTextNode("Inner text")), h.appendChild(i), g.appendChild(h), e.appendChild(g), e.appendChild(f), j && d.appendChild(j), k) {
                        var n = document.createElement("span");
                        k.className = "bs-searchbox", n.className = "form-control", k.appendChild(n), d.appendChild(k)
                    }
                    l && d.appendChild(l), d.appendChild(e), m && d.appendChild(m), c.appendChild(d), document.body.appendChild(c);
                    var o = h.offsetHeight,
                        p = j ? j.offsetHeight : 0,
                        q = k ? k.offsetHeight : 0,
                        r = l ? l.offsetHeight : 0,
                        s = m ? m.offsetHeight : 0,
                        t = a(f).outerHeight(!0),
                        u = "function" == typeof getComputedStyle ? getComputedStyle(d) : !1,
                        v = u ? null : a(d),
                        w = parseInt(u ? u.paddingTop : v.css("paddingTop")) + parseInt(u ? u.paddingBottom : v.css("paddingBottom")) + parseInt(u ? u.borderTopWidth : v.css("borderTopWidth")) + parseInt(u ? u.borderBottomWidth : v.css("borderBottomWidth")),
                        x = w + parseInt(u ? u.marginTop : v.css("marginTop")) + parseInt(u ? u.marginBottom : v.css("marginBottom")) + 2;
                    document.body.removeChild(c), this.sizeInfo = {
                        liHeight: o,
                        headerHeight: p,
                        searchHeight: q,
                        actionsHeight: r,
                        doneButtonHeight: s,
                        dividerHeight: t,
                        menuPadding: w,
                        menuExtras: x
                    }
                }
            },
            setSize: function() {
                if (this.findLis(), this.liHeight(), this.options.header && this.$menu.css("padding-top", 0), this.options.size !== !1) {
                    var b, c, d, e, f = this,
                        g = this.$menu,
                        h = this.$menuInner,
                        i = a(window),
                        j = this.$newElement[0].offsetHeight,
                        k = this.sizeInfo.liHeight,
                        l = this.sizeInfo.headerHeight,
                        m = this.sizeInfo.searchHeight,
                        n = this.sizeInfo.actionsHeight,
                        o = this.sizeInfo.doneButtonHeight,
                        p = this.sizeInfo.dividerHeight,
                        q = this.sizeInfo.menuPadding,
                        r = this.sizeInfo.menuExtras,
                        s = this.options.hideDisabled ? ".disabled" : "",
                        t = function() {
                            d = f.$newElement.offset().top - i.scrollTop(), e = i.height() - d - j
                        };
                    if (t(), "auto" === this.options.size) {
                        var u = function() {
                            var i, j = function(b, c) {
                                    return function(d) {
                                        return c ? d.classList ? d.classList.contains(b) : a(d).hasClass(b) : !(d.classList ? d.classList.contains(b) : a(d).hasClass(b))
                                    }
                                },
                                p = f.$menuInner[0].getElementsByTagName("li"),
                                s = Array.prototype.filter ? Array.prototype.filter.call(p, j("hidden", !1)) : f.$lis.not(".hidden"),
                                u = Array.prototype.filter ? Array.prototype.filter.call(s, j("dropdown-header", !0)) : s.filter(".dropdown-header");
                            t(), b = e - r, f.options.container ? (g.data("height") || g.data("height", g.height()), c = g.data("height")) : c = g.height(), f.options.dropupAuto && f.$newElement.toggleClass("dropup", d > e && c > b - r), f.$newElement.hasClass("dropup") && (b = d - r), i = s.length + u.length > 3 ? 3 * k + r - 2 : 0, g.css({
                                "max-height": b + "px",
                                overflow: "hidden",
                                "min-height": i + l + m + n + o + "px"
                            }), h.css({
                                "max-height": b - l - m - n - o - q + "px",
                                "overflow-y": "auto",
                                "min-height": Math.max(i - q, 0) + "px"
                            })
                        };
                        u(), this.$searchbox.off("input.getSize propertychange.getSize").on("input.getSize propertychange.getSize", u), i.off("resize.getSize scroll.getSize").on("resize.getSize scroll.getSize", u)
                    } else if (this.options.size && "auto" != this.options.size && this.$lis.not(s).length > this.options.size) {
                        var v = this.$lis.not(".divider").not(s).children().slice(0, this.options.size).last().parent().index(),
                            w = this.$lis.slice(0, v + 1).filter(".divider").length;
                        b = k * this.options.size + w * p + q, f.options.container ? (g.data("height") || g.data("height", g.height()), c = g.data("height")) : c = g.height(), f.options.dropupAuto && this.$newElement.toggleClass("dropup", d > e && c > b - r), g.css({
                            "max-height": b + l + m + n + o + "px",
                            overflow: "hidden",
                            "min-height": ""
                        }), h.css({
                            "max-height": b - q + "px",
                            "overflow-y": "auto",
                            "min-height": ""
                        })
                    }
                }
            },
            setWidth: function() {
                if ("auto" === this.options.width) {
                    this.$menu.css("min-width", "0");
                    var a = this.$menu.parent().clone().appendTo("body"),
                        b = this.options.container ? this.$newElement.clone().appendTo("body") : a,
                        c = a.children(".dropdown-menu").outerWidth(),
                        d = b.css("width", "auto").children("button").outerWidth();
                    a.remove(), b.remove(), this.$newElement.css("width", Math.max(c, d) + "px")
                } else "fit" === this.options.width ? (this.$menu.css("min-width", ""), this.$newElement.css("width", "").addClass("fit-width")) : this.options.width ? (this.$menu.css("min-width", ""), this.$newElement.css("width", this.options.width)) : (this.$menu.css("min-width", ""), this.$newElement.css("width", ""));
                this.$newElement.hasClass("fit-width") && "fit" !== this.options.width && this.$newElement.removeClass("fit-width")
            },
            selectPosition: function() {
                this.$bsContainer = a('<div class="bs-container" />');
                var b, c, d = this,
                    e = function(a) {
                        d.$bsContainer.addClass(a.attr("class").replace(/form-control|fit-width/gi, "")).toggleClass("dropup", a.hasClass("dropup")), b = a.offset(), c = a.hasClass("dropup") ? 0 : a[0].offsetHeight, d.$bsContainer.css({
                            top: b.top + c,
                            left: b.left,
                            width: a[0].offsetWidth
                        })
                    };
                this.$button.on("click", function() {
                    var b = a(this);
                    d.isDisabled() || (e(d.$newElement), d.$bsContainer.appendTo(d.options.container).toggleClass("open", !b.hasClass("open")).append(d.$menu))
                }), a(window).on("resize scroll", function() {
                    e(d.$newElement)
                }), this.$element.on("hide.bs.select", function() {
                    d.$menu.data("height", d.$menu.height()), d.$bsContainer.detach()
                })
            },
            setSelected: function(a, b, c) {
                c || (c = this.findLis().eq(this.liObj[a])), c.toggleClass("selected", b)
            },
            setDisabled: function(a, b, c) {
                c || (c = this.findLis().eq(this.liObj[a])), b ? c.addClass("disabled").children("a").attr("href", "#").attr("tabindex", -1) : c.removeClass("disabled").children("a").removeAttr("href").attr("tabindex", 0)
            },
            isDisabled: function() {
                return this.$element[0].disabled
            },
            checkDisabled: function() {
                var a = this;
                this.isDisabled() ? (this.$newElement.addClass("disabled"), this.$button.addClass("disabled").attr("tabindex", -1)) : (this.$button.hasClass("disabled") && (this.$newElement.removeClass("disabled"), this.$button.removeClass("disabled")), -1 != this.$button.attr("tabindex") || this.$element.data("tabindex") || this.$button.removeAttr("tabindex")), this.$button.click(function() {
                    return !a.isDisabled()
                })
            },
            tabIndex: function() {
                this.$element.data("tabindex") !== this.$element.attr("tabindex") && -98 !== this.$element.attr("tabindex") && "-98" !== this.$element.attr("tabindex") && (this.$element.data("tabindex", this.$element.attr("tabindex")), this.$button.attr("tabindex", this.$element.data("tabindex"))), this.$element.attr("tabindex", -98)
            },
            clickListener: function() {
                var b = this,
                    c = a(document);
                this.$newElement.on("touchstart.dropdown", ".dropdown-menu", function(a) {
                    a.stopPropagation()
                }), c.data("spaceSelect", !1), this.$button.on("keyup", function(a) {
                    /(32)/.test(a.keyCode.toString(10)) && c.data("spaceSelect") && (a.preventDefault(), c.data("spaceSelect", !1))
                }), this.$button.on("click", function() {
                    b.setSize()
                }), this.$element.on("shown.bs.select", function() {
                    if (b.options.liveSearch || b.multiple) {
                        if (!b.multiple) {
                            var a = b.liObj[b.$element[0].selectedIndex];
                            if ("number" != typeof a || b.options.size === !1) return;
                            var c = b.$lis.eq(a)[0].offsetTop - b.$menuInner[0].offsetTop;
                            c = c - b.$menuInner[0].offsetHeight / 2 + b.sizeInfo.liHeight / 2, b.$menuInner[0].scrollTop = c
                        }
                    } else b.$menuInner.find(".selected a").focus()
                }), this.$menuInner.on("click", "li a", function(c) {
                    var d = a(this),
                        e = d.parent().data("originalIndex"),
                        f = b.$element.val(),
                        g = b.$element.prop("selectedIndex");
                    if (b.multiple && c.stopPropagation(), c.preventDefault(), !b.isDisabled() && !d.parent().hasClass("disabled")) {
                        var h = b.$element.find("option"),
                            i = h.eq(e),
                            j = i.prop("selected"),
                            k = i.parent("optgroup"),
                            l = b.options.maxOptions,
                            m = k.data("maxOptions") || !1;
                        if (b.multiple) {
                            if (i.prop("selected", !j), b.setSelected(e, !j), d.blur(), l !== !1 || m !== !1) {
                                var n = l < h.filter(":selected").length,
                                    o = m < k.find("option:selected").length;
                                if (l && n || m && o)
                                    if (l && 1 == l) h.prop("selected", !1), i.prop("selected", !0), b.$menuInner.find(".selected").removeClass("selected"), b.setSelected(e, !0);
                                    else if (m && 1 == m) {
                                    k.find("option:selected").prop("selected", !1), i.prop("selected", !0);
                                    var p = d.parent().data("optgroup");
                                    b.$menuInner.find('[data-optgroup="' + p + '"]').removeClass("selected"), b.setSelected(e, !0)
                                } else {
                                    var q = "function" == typeof b.options.maxOptionsText ? b.options.maxOptionsText(l, m) : b.options.maxOptionsText,
                                        r = q[0].replace("{n}", l),
                                        s = q[1].replace("{n}", m),
                                        t = a('<div class="notify"></div>');
                                    q[2] && (r = r.replace("{var}", q[2][l > 1 ? 0 : 1]), s = s.replace("{var}", q[2][m > 1 ? 0 : 1])), i.prop("selected", !1), b.$menu.append(t), l && n && (t.append(a("<div>" + r + "</div>")), b.$element.trigger("maxReached.bs.select")), m && o && (t.append(a("<div>" + s + "</div>")), b.$element.trigger("maxReachedGrp.bs.select")), setTimeout(function() {
                                        b.setSelected(e, !1)
                                    }, 10), t.delay(750).fadeOut(300, function() {
                                        a(this).remove()
                                    })
                                }
                            }
                        } else h.prop("selected", !1), i.prop("selected", !0), b.$menuInner.find(".selected").removeClass("selected"), b.setSelected(e, !0);
                        b.multiple ? b.options.liveSearch && b.$searchbox.focus() : b.$button.focus(), (f != b.$element.val() && b.multiple || g != b.$element.prop("selectedIndex") && !b.multiple) && b.$element.trigger("changed.bs.select", [e, i.prop("selected"), j]).triggerNative("change")
                    }
                }), this.$menu.on("click", "li.disabled a, .popover-title, .popover-title :not(.close)", function(c) {
                    c.currentTarget == this && (c.preventDefault(), c.stopPropagation(), b.options.liveSearch && !a(c.target).hasClass("close") ? b.$searchbox.focus() : b.$button.focus())
                }), this.$menuInner.on("click", ".divider, .dropdown-header", function(a) {
                    a.preventDefault(), a.stopPropagation(), b.options.liveSearch ? b.$searchbox.focus() : b.$button.focus()
                }), this.$menu.on("click", ".popover-title .close", function() {
                    b.$button.click()
                }), this.$searchbox.on("click", function(a) {
                    a.stopPropagation()
                }), this.$menu.on("click", ".actions-btn", function(c) {
                    b.options.liveSearch ? b.$searchbox.focus() : b.$button.focus(), c.preventDefault(), c.stopPropagation(), a(this).hasClass("bs-select-all") ? b.selectAll() : b.deselectAll()
                }), this.$element.change(function() {
                    b.render(!1)
                })
            },
            liveSearchListener: function() {
                var d = this,
                    e = a('<li class="no-results"></li>');
                this.$button.on("click.dropdown.data-api touchstart.dropdown.data-api", function() {
                    d.$menuInner.find(".active").removeClass("active"), d.$searchbox.val() && (d.$searchbox.val(""), d.$lis.not(".is-hidden").removeClass("hidden"), e.parent().length && e.remove()), d.multiple || d.$menuInner.find(".selected").addClass("active"), setTimeout(function() {
                        d.$searchbox.focus()
                    }, 10)
                }), this.$searchbox.on("click.dropdown.data-api focus.dropdown.data-api touchend.dropdown.data-api", function(a) {
                    a.stopPropagation()
                }), this.$searchbox.on("input propertychange", function() {
                    if (d.$searchbox.val()) {
                        var f = d.$lis.not(".is-hidden").removeClass("hidden").children("a");
                        f = d.options.liveSearchNormalize ? f.not(":a" + d._searchStyle() + '("' + b(d.$searchbox.val()) + '")') : f.not(":" + d._searchStyle() + '("' + d.$searchbox.val() + '")'), f.parent().addClass("hidden"), d.$lis.filter(".dropdown-header").each(function() {
                            var b = a(this),
                                c = b.data("optgroup");
                            0 === d.$lis.filter("[data-optgroup=" + c + "]").not(b).not(".hidden").length && (b.addClass("hidden"), d.$lis.filter("[data-optgroup=" + c + "div]").addClass("hidden"))
                        });
                        var g = d.$lis.not(".hidden");
                        g.each(function(b) {
                            var c = a(this);
                            c.hasClass("divider") && (c.index() === g.first().index() || c.index() === g.last().index() || g.eq(b + 1).hasClass("divider")) && c.addClass("hidden")
                        }), d.$lis.not(".hidden, .no-results").length ? e.parent().length && e.remove() : (e.parent().length && e.remove(), e.html(d.options.noneResultsText.replace("{0}", '"' + c(d.$searchbox.val()) + '"')).show(), d.$menuInner.append(e))
                    } else d.$lis.not(".is-hidden").removeClass("hidden"), e.parent().length && e.remove();
                    d.$lis.filter(".active").removeClass("active"), d.$searchbox.val() && d.$lis.not(".hidden, .divider, .dropdown-header").eq(0).addClass("active").children("a").focus(), a(this).focus()
                })
            },
            _searchStyle: function() {
                var a = {
                    begins: "ibegins",
                    startsWith: "ibegins"
                };
                return a[this.options.liveSearchStyle] || "icontains"
            },
            val: function(a) {
                return "undefined" != typeof a ? (this.$element.val(a), this.render(), this.$element) : this.$element.val()
            },
            changeAll: function(b) {
                "undefined" == typeof b && (b = !0), this.findLis();
                for (var c = this.$element.find("option"), d = this.$lis.not(".divider, .dropdown-header, .disabled, .hidden").toggleClass("selected", b), e = d.length, f = [], g = 0; e > g; g++) {
                    var h = d[g].getAttribute("data-original-index");
                    f[f.length] = c.eq(h)[0]
                }
                a(f).prop("selected", b), this.render(!1), this.$element.trigger("changed.bs.select").triggerNative("change")
            },
            selectAll: function() {
                return this.changeAll(!0)
            },
            deselectAll: function() {
                return this.changeAll(!1)
            },
            toggle: function(a) {
                a = a || window.event, a && a.stopPropagation(), this.$button.trigger("click")
            },
            keydown: function(c) {
                var d, e, f, g, h, i, j, k, l, m = a(this),
                    n = m.is("input") ? m.parent().parent() : m.parent(),
                    o = n.data("this"),
                    p = ":not(.disabled, .hidden, .dropdown-header, .divider)",
                    q = {
                        32: " ",
                        48: "0",
                        49: "1",
                        50: "2",
                        51: "3",
                        52: "4",
                        53: "5",
                        54: "6",
                        55: "7",
                        56: "8",
                        57: "9",
                        59: ";",
                        65: "a",
                        66: "b",
                        67: "c",
                        68: "d",
                        69: "e",
                        70: "f",
                        71: "g",
                        72: "h",
                        73: "i",
                        74: "j",
                        75: "k",
                        76: "l",
                        77: "m",
                        78: "n",
                        79: "o",
                        80: "p",
                        81: "q",
                        82: "r",
                        83: "s",
                        84: "t",
                        85: "u",
                        86: "v",
                        87: "w",
                        88: "x",
                        89: "y",
                        90: "z",
                        96: "0",
                        97: "1",
                        98: "2",
                        99: "3",
                        100: "4",
                        101: "5",
                        102: "6",
                        103: "7",
                        104: "8",
                        105: "9"
                    };
                if (o.options.liveSearch && (n = m.parent().parent()), o.options.container && (n = o.$menu), d = a("[role=menu] li", n), l = o.$newElement.hasClass("open"), !l && (c.keyCode >= 48 && c.keyCode <= 57 || c.keyCode >= 96 && c.keyCode <= 105 || c.keyCode >= 65 && c.keyCode <= 90) && (o.options.container ? o.$button.trigger("click") : (o.setSize(), o.$menu.parent().addClass("open"), l = !0), o.$searchbox.focus()), o.options.liveSearch && (/(^9$|27)/.test(c.keyCode.toString(10)) && l && 0 === o.$menu.find(".active").length && (c.preventDefault(), o.$menu.parent().removeClass("open"), o.options.container && o.$newElement.removeClass("open"), o.$button.focus()), d = a("[role=menu] li" + p, n), m.val() || /(38|40)/.test(c.keyCode.toString(10)) || 0 === d.filter(".active").length && (d = o.$menuInner.find("li"), d = o.options.liveSearchNormalize ? d.filter(":a" + o._searchStyle() + "(" + b(q[c.keyCode]) + ")") : d.filter(":" + o._searchStyle() + "(" + q[c.keyCode] + ")"))), d.length) {
                    if (/(38|40)/.test(c.keyCode.toString(10))) e = d.index(d.find("a").filter(":focus").parent()), g = d.filter(p).first().index(), h = d.filter(p).last().index(), f = d.eq(e).nextAll(p).eq(0).index(), i = d.eq(e).prevAll(p).eq(0).index(), j = d.eq(f).prevAll(p).eq(0).index(), o.options.liveSearch && (d.each(function(b) {
                        a(this).hasClass("disabled") || a(this).data("index", b)
                    }), e = d.index(d.filter(".active")), g = d.first().data("index"), h = d.last().data("index"), f = d.eq(e).nextAll().eq(0).data("index"), i = d.eq(e).prevAll().eq(0).data("index"), j = d.eq(f).prevAll().eq(0).data("index")), k = m.data("prevIndex"), 38 == c.keyCode ? (o.options.liveSearch && e--, e != j && e > i && (e = i), g > e && (e = g), e == k && (e = h)) : 40 == c.keyCode && (o.options.liveSearch && e++, -1 == e && (e = 0), e != j && f > e && (e = f), e > h && (e = h), e == k && (e = g)), m.data("prevIndex", e), o.options.liveSearch ? (c.preventDefault(), m.hasClass("dropdown-toggle") || (d.removeClass("active").eq(e).addClass("active").children("a").focus(), m.focus())) : d.eq(e).children("a").focus();
                    else if (!m.is("input")) {
                        var r, s, t = [];
                        d.each(function() {
                            a(this).hasClass("disabled") || a.trim(a(this).children("a").text().toLowerCase()).substring(0, 1) == q[c.keyCode] && t.push(a(this).index())
                        }), r = a(document).data("keycount"), r++, a(document).data("keycount", r), s = a.trim(a(":focus").text().toLowerCase()).substring(0, 1), s != q[c.keyCode] ? (r = 1, a(document).data("keycount", r)) : r >= t.length && (a(document).data("keycount", 0), r > t.length && (r = 1)), d.eq(t[r - 1]).children("a").focus()
                    }
                    if ((/(13|32)/.test(c.keyCode.toString(10)) || /(^9$)/.test(c.keyCode.toString(10)) && o.options.selectOnTab) && l) {
                        if (/(32)/.test(c.keyCode.toString(10)) || c.preventDefault(), o.options.liveSearch) /(32)/.test(c.keyCode.toString(10)) || (o.$menuInner.find(".active a").click(), m.focus());
                        else {
                            var u = a(":focus");
                            u.click(), u.focus(), c.preventDefault(), a(document).data("spaceSelect", !0)
                        }
                        a(document).data("keycount", 0)
                    }(/(^9$|27)/.test(c.keyCode.toString(10)) && l && (o.multiple || o.options.liveSearch) || /(27)/.test(c.keyCode.toString(10)) && !l) && (o.$menu.parent().removeClass("open"), o.options.container && o.$newElement.removeClass("open"), o.$button.focus())
                }
            },
            mobile: function() {
                this.$element.addClass("mobile-device")
            },
            refresh: function() {
                this.$lis = null, this.liObj = {}, this.reloadLi(), this.render(), this.checkDisabled(), this.liHeight(!0), this.setStyle(), this.setWidth(), this.$lis && this.$searchbox.trigger("propertychange"), this.$element.trigger("refreshed.bs.select")
            },
            hide: function() {
                this.$newElement.hide()
            },
            show: function() {
                this.$newElement.show()
            },
            remove: function() {
                this.$newElement.remove(), this.$element.remove()
            },
            destroy: function() {
                this.$newElement.before(this.$element).remove(), this.$bsContainer ? this.$bsContainer.remove() : this.$menu.remove(), this.$element.off(".bs.select").removeData("selectpicker").removeClass("bs-select-hidden selectpicker")
            }
        };
        var f = a.fn.selectpicker;
        a.fn.selectpicker = d, a.fn.selectpicker.Constructor = e, a.fn.selectpicker.noConflict = function() {
            return a.fn.selectpicker = f, this
        }, a(document).data("keycount", 0).on("keydown.bs.select", '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="menu"], .bs-searchbox input', e.prototype.keydown).on("focusin.modal", '.bootstrap-select [data-toggle=dropdown], .bootstrap-select [role="menu"], .bs-searchbox input', function(a) {
            a.stopPropagation()
        }), a(window).on("load.bs.select.data-api", function() {
            a(".selectpicker").each(function() {
                var b = a(this);
                d.call(b, b.data())
            })
        })
    }(a)
});
//# sourceMappingURL=bootstrap-select.js.map
/* ========================================================================
 * bootstrap-switch - v3.3.2
 * http://www.bootstrap-switch.org
 * ========================================================================
 * Copyright 2012-2013 Mattia Larentis
 *
 * ========================================================================
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * ========================================================================
 */

(function() {
    var t = [].slice;
    ! function(e, i) {
        "use strict";
        var n;
        return n = function() {
            function t(t, i) {
                null == i && (i = {}), this.$element = e(t), this.options = e.extend({}, e.fn.bootstrapSwitch.defaults, {
                    state: this.$element.is(":checked"),
                    size: this.$element.data("size"),
                    animate: this.$element.data("animate"),
                    disabled: this.$element.is(":disabled"),
                    readonly: this.$element.is("[readonly]"),
                    indeterminate: this.$element.data("indeterminate"),
                    inverse: this.$element.data("inverse"),
                    radioAllOff: this.$element.data("radio-all-off"),
                    onColor: this.$element.data("on-color"),
                    offColor: this.$element.data("off-color"),
                    onText: this.$element.data("on-text"),
                    offText: this.$element.data("off-text"),
                    labelText: this.$element.data("label-text"),
                    handleWidth: this.$element.data("handle-width"),
                    labelWidth: this.$element.data("label-width"),
                    baseClass: this.$element.data("base-class"),
                    wrapperClass: this.$element.data("wrapper-class")
                }, i), this.$wrapper = e("<div>", {
                    "class": function(t) {
                        return function() {
                            var e;
                            return e = ["" + t.options.baseClass].concat(t._getClasses(t.options.wrapperClass)), e.push(t.options.state ? "" + t.options.baseClass + "-on" : "" + t.options.baseClass + "-off"), null != t.options.size && e.push("" + t.options.baseClass + "-" + t.options.size), t.options.disabled && e.push("" + t.options.baseClass + "-disabled"), t.options.readonly && e.push("" + t.options.baseClass + "-readonly"), t.options.indeterminate && e.push("" + t.options.baseClass + "-indeterminate"), t.options.inverse && e.push("" + t.options.baseClass + "-inverse"), t.$element.attr("id") && e.push("" + t.options.baseClass + "-id-" + t.$element.attr("id")), e.join(" ")
                        }
                    }(this)()
                }), this.$container = e("<div>", {
                    "class": "" + this.options.baseClass + "-container"
                }), this.$on = e("<span>", {
                    html: this.options.onText,
                    "class": "" + this.options.baseClass + "-handle-on " + this.options.baseClass + "-" + this.options.onColor
                }), this.$off = e("<span>", {
                    html: this.options.offText,
                    "class": "" + this.options.baseClass + "-handle-off " + this.options.baseClass + "-" + this.options.offColor
                }), this.$label = e("<span>", {
                    html: this.options.labelText,
                    "class": "" + this.options.baseClass + "-label"
                }), this.$element.on("init.bootstrapSwitch", function(e) {
                    return function() {
                        return e.options.onInit.apply(t, arguments)
                    }
                }(this)), this.$element.on("switchChange.bootstrapSwitch", function(e) {
                    return function() {
                        return e.options.onSwitchChange.apply(t, arguments)
                    }
                }(this)), this.$container = this.$element.wrap(this.$container).parent(), this.$wrapper = this.$container.wrap(this.$wrapper).parent(), this.$element.before(this.options.inverse ? this.$off : this.$on).before(this.$label).before(this.options.inverse ? this.$on : this.$off), this.options.indeterminate && this.$element.prop("indeterminate", !0), this._init(), this._elementHandlers(), this._handleHandlers(), this._labelHandlers(), this._formHandler(), this._externalLabelHandler(), this.$element.trigger("init.bootstrapSwitch")
            }
            return t.prototype._constructor = t, t.prototype.state = function(t, e) {
                return "undefined" == typeof t ? this.options.state : this.options.disabled || this.options.readonly ? this.$element : this.options.state && !this.options.radioAllOff && this.$element.is(":radio") ? this.$element : (this.options.indeterminate && this.indeterminate(!1), t = !!t, this.$element.prop("checked", t).trigger("change.bootstrapSwitch", e), this.$element)
            }, t.prototype.toggleState = function(t) {
                return this.options.disabled || this.options.readonly ? this.$element : this.options.indeterminate ? (this.indeterminate(!1), this.state(!0)) : this.$element.prop("checked", !this.options.state).trigger("change.bootstrapSwitch", t)
            }, t.prototype.size = function(t) {
                return "undefined" == typeof t ? this.options.size : (null != this.options.size && this.$wrapper.removeClass("" + this.options.baseClass + "-" + this.options.size), t && this.$wrapper.addClass("" + this.options.baseClass + "-" + t), this._width(), this._containerPosition(), this.options.size = t, this.$element)
            }, t.prototype.animate = function(t) {
                return "undefined" == typeof t ? this.options.animate : (t = !!t, t === this.options.animate ? this.$element : this.toggleAnimate())
            }, t.prototype.toggleAnimate = function() {
                return this.options.animate = !this.options.animate, this.$wrapper.toggleClass("" + this.options.baseClass + "-animate"), this.$element
            }, t.prototype.disabled = function(t) {
                return "undefined" == typeof t ? this.options.disabled : (t = !!t, t === this.options.disabled ? this.$element : this.toggleDisabled())
            }, t.prototype.toggleDisabled = function() {
                return this.options.disabled = !this.options.disabled, this.$element.prop("disabled", this.options.disabled), this.$wrapper.toggleClass("" + this.options.baseClass + "-disabled"), this.$element
            }, t.prototype.readonly = function(t) {
                return "undefined" == typeof t ? this.options.readonly : (t = !!t, t === this.options.readonly ? this.$element : this.toggleReadonly())
            }, t.prototype.toggleReadonly = function() {
                return this.options.readonly = !this.options.readonly, this.$element.prop("readonly", this.options.readonly), this.$wrapper.toggleClass("" + this.options.baseClass + "-readonly"), this.$element
            }, t.prototype.indeterminate = function(t) {
                return "undefined" == typeof t ? this.options.indeterminate : (t = !!t, t === this.options.indeterminate ? this.$element : this.toggleIndeterminate())
            }, t.prototype.toggleIndeterminate = function() {
                return this.options.indeterminate = !this.options.indeterminate, this.$element.prop("indeterminate", this.options.indeterminate), this.$wrapper.toggleClass("" + this.options.baseClass + "-indeterminate"), this._containerPosition(), this.$element
            }, t.prototype.inverse = function(t) {
                return "undefined" == typeof t ? this.options.inverse : (t = !!t, t === this.options.inverse ? this.$element : this.toggleInverse())
            }, t.prototype.toggleInverse = function() {
                var t, e;
                return this.$wrapper.toggleClass("" + this.options.baseClass + "-inverse"), e = this.$on.clone(!0), t = this.$off.clone(!0), this.$on.replaceWith(t), this.$off.replaceWith(e), this.$on = t, this.$off = e, this.options.inverse = !this.options.inverse, this.$element
            }, t.prototype.onColor = function(t) {
                var e;
                return e = this.options.onColor, "undefined" == typeof t ? e : (null != e && this.$on.removeClass("" + this.options.baseClass + "-" + e), this.$on.addClass("" + this.options.baseClass + "-" + t), this.options.onColor = t, this.$element)
            }, t.prototype.offColor = function(t) {
                var e;
                return e = this.options.offColor, "undefined" == typeof t ? e : (null != e && this.$off.removeClass("" + this.options.baseClass + "-" + e), this.$off.addClass("" + this.options.baseClass + "-" + t), this.options.offColor = t, this.$element)
            }, t.prototype.onText = function(t) {
                return "undefined" == typeof t ? this.options.onText : (this.$on.html(t), this._width(), this._containerPosition(), this.options.onText = t, this.$element)
            }, t.prototype.offText = function(t) {
                return "undefined" == typeof t ? this.options.offText : (this.$off.html(t), this._width(), this._containerPosition(), this.options.offText = t, this.$element)
            }, t.prototype.labelText = function(t) {
                return "undefined" == typeof t ? this.options.labelText : (this.$label.html(t), this._width(), this.options.labelText = t, this.$element)
            }, t.prototype.handleWidth = function(t) {
                return "undefined" == typeof t ? this.options.handleWidth : (this.options.handleWidth = t, this._width(), this._containerPosition(), this.$element)
            }, t.prototype.labelWidth = function(t) {
                return "undefined" == typeof t ? this.options.labelWidth : (this.options.labelWidth = t, this._width(), this._containerPosition(), this.$element)
            }, t.prototype.baseClass = function() {
                return this.options.baseClass
            }, t.prototype.wrapperClass = function(t) {
                return "undefined" == typeof t ? this.options.wrapperClass : (t || (t = e.fn.bootstrapSwitch.defaults.wrapperClass), this.$wrapper.removeClass(this._getClasses(this.options.wrapperClass).join(" ")), this.$wrapper.addClass(this._getClasses(t).join(" ")), this.options.wrapperClass = t, this.$element)
            }, t.prototype.radioAllOff = function(t) {
                return "undefined" == typeof t ? this.options.radioAllOff : (t = !!t, t === this.options.radioAllOff ? this.$element : (this.options.radioAllOff = t, this.$element))
            }, t.prototype.onInit = function(t) {
                return "undefined" == typeof t ? this.options.onInit : (t || (t = e.fn.bootstrapSwitch.defaults.onInit), this.options.onInit = t, this.$element)
            }, t.prototype.onSwitchChange = function(t) {
                return "undefined" == typeof t ? this.options.onSwitchChange : (t || (t = e.fn.bootstrapSwitch.defaults.onSwitchChange), this.options.onSwitchChange = t, this.$element)
            }, t.prototype.destroy = function() {
                var t;
                return t = this.$element.closest("form"), t.length && t.off("reset.bootstrapSwitch").removeData("bootstrap-switch"), this.$container.children().not(this.$element).remove(), this.$element.unwrap().unwrap().off(".bootstrapSwitch").removeData("bootstrap-switch"), this.$element
            }, t.prototype._width = function() {
                var t, e;
                return t = this.$on.add(this.$off), t.add(this.$label).css("width", ""), e = "auto" === this.options.handleWidth ? Math.max(this.$on.width(), this.$off.width()) : this.options.handleWidth, t.width(e), this.$label.width(function(t) {
                    return function(i, n) {
                        return "auto" !== t.options.labelWidth ? t.options.labelWidth : e > n ? e : n
                    }
                }(this)), this._handleWidth = this.$on.outerWidth(), this._labelWidth = this.$label.outerWidth(), this.$container.width(2 * this._handleWidth + this._labelWidth), this.$wrapper.width(this._handleWidth + this._labelWidth)
            }, t.prototype._containerPosition = function(t, e) {
                return null == t && (t = this.options.state), this.$container.css("margin-left", function(e) {
                    return function() {
                        var i;
                        return i = [0, "-" + e._handleWidth + "px"], e.options.indeterminate ? "-" + e._handleWidth / 2 + "px" : t ? e.options.inverse ? i[1] : i[0] : e.options.inverse ? i[0] : i[1]
                    }
                }(this)), e ? setTimeout(function() {
                    return e()
                }, 50) : void 0
            }, t.prototype._init = function() {
                var t, e;
                return t = function(t) {
                    return function() {
                        return t._width(), t._containerPosition(null, function() {
                            return t.options.animate ? t.$wrapper.addClass("" + t.options.baseClass + "-animate") : void 0
                        })
                    }
                }(this), this.$wrapper.is(":visible") ? t() : e = i.setInterval(function(n) {
                    return function() {
                        return n.$wrapper.is(":visible") ? (t(), i.clearInterval(e)) : void 0
                    }
                }(this), 50)
            }, t.prototype._elementHandlers = function() {
                return this.$element.on({
                    "change.bootstrapSwitch": function(t) {
                        return function(i, n) {
                            var o;
                            return i.preventDefault(), i.stopImmediatePropagation(), o = t.$element.is(":checked"), t._containerPosition(o), o !== t.options.state ? (t.options.state = o, t.$wrapper.toggleClass("" + t.options.baseClass + "-off").toggleClass("" + t.options.baseClass + "-on"), n ? void 0 : (t.$element.is(":radio") && e("[name='" + t.$element.attr("name") + "']").not(t.$element).prop("checked", !1).trigger("change.bootstrapSwitch", !0), t.$element.trigger("switchChange.bootstrapSwitch", [o]))) : void 0
                        }
                    }(this),
                    "focus.bootstrapSwitch": function(t) {
                        return function(e) {
                            return e.preventDefault(), t.$wrapper.addClass("" + t.options.baseClass + "-focused")
                        }
                    }(this),
                    "blur.bootstrapSwitch": function(t) {
                        return function(e) {
                            return e.preventDefault(), t.$wrapper.removeClass("" + t.options.baseClass + "-focused")
                        }
                    }(this),
                    "keydown.bootstrapSwitch": function(t) {
                        return function(e) {
                            if (e.which && !t.options.disabled && !t.options.readonly) switch (e.which) {
                                case 37:
                                    return e.preventDefault(), e.stopImmediatePropagation(), t.state(!1);
                                case 39:
                                    return e.preventDefault(), e.stopImmediatePropagation(), t.state(!0)
                            }
                        }
                    }(this)
                })
            }, t.prototype._handleHandlers = function() {
                return this.$on.on("click.bootstrapSwitch", function(t) {
                    return function(e) {
                        return e.preventDefault(), e.stopPropagation(), t.state(!1), t.$element.trigger("focus.bootstrapSwitch")
                    }
                }(this)), this.$off.on("click.bootstrapSwitch", function(t) {
                    return function(e) {
                        return e.preventDefault(), e.stopPropagation(), t.state(!0), t.$element.trigger("focus.bootstrapSwitch")
                    }
                }(this))
            }, t.prototype._labelHandlers = function() {
                return this.$label.on({
                    "mousedown.bootstrapSwitch touchstart.bootstrapSwitch": function(t) {
                        return function(e) {
                            return t._dragStart || t.options.disabled || t.options.readonly ? void 0 : (e.preventDefault(), e.stopPropagation(), t._dragStart = (e.pageX || e.originalEvent.touches[0].pageX) - parseInt(t.$container.css("margin-left"), 10), t.options.animate && t.$wrapper.removeClass("" + t.options.baseClass + "-animate"), t.$element.trigger("focus.bootstrapSwitch"))
                        }
                    }(this),
                    "mousemove.bootstrapSwitch touchmove.bootstrapSwitch": function(t) {
                        return function(e) {
                            var i;
                            if (null != t._dragStart && (e.preventDefault(), i = (e.pageX || e.originalEvent.touches[0].pageX) - t._dragStart, !(i < -t._handleWidth || i > 0))) return t._dragEnd = i, t.$container.css("margin-left", "" + t._dragEnd + "px")
                        }
                    }(this),
                    "mouseup.bootstrapSwitch touchend.bootstrapSwitch": function(t) {
                        return function(e) {
                            var i;
                            if (t._dragStart) return e.preventDefault(), t.options.animate && t.$wrapper.addClass("" + t.options.baseClass + "-animate"), t._dragEnd ? (i = t._dragEnd > -(t._handleWidth / 2), t._dragEnd = !1, t.state(t.options.inverse ? !i : i)) : t.state(!t.options.state), t._dragStart = !1
                        }
                    }(this),
                    "mouseleave.bootstrapSwitch": function(t) {
                        return function() {
                            return t.$label.trigger("mouseup.bootstrapSwitch")
                        }
                    }(this)
                })
            }, t.prototype._externalLabelHandler = function() {
                var t;
                return t = this.$element.closest("label"), t.on("click", function(e) {
                    return function(i) {
                        return i.preventDefault(), i.stopImmediatePropagation(), i.target === t[0] ? e.toggleState() : void 0
                    }
                }(this))
            }, t.prototype._formHandler = function() {
                var t;
                return t = this.$element.closest("form"), t.data("bootstrap-switch") ? void 0 : t.on("reset.bootstrapSwitch", function() {
                    return i.setTimeout(function() {
                        return t.find("input").filter(function() {
                            return e(this).data("bootstrap-switch")
                        }).each(function() {
                            return e(this).bootstrapSwitch("state", this.checked)
                        })
                    }, 1)
                }).data("bootstrap-switch", !0)
            }, t.prototype._getClasses = function(t) {
                var i, n, o, s;
                if (!e.isArray(t)) return ["" + this.options.baseClass + "-" + t];
                for (n = [], o = 0, s = t.length; s > o; o++) i = t[o], n.push("" + this.options.baseClass + "-" + i);
                return n
            }, t
        }(), e.fn.bootstrapSwitch = function() {
            var i, o, s;
            return o = arguments[0], i = 2 <= arguments.length ? t.call(arguments, 1) : [], s = this, this.each(function() {
                var t, a;
                return t = e(this), a = t.data("bootstrap-switch"), a || t.data("bootstrap-switch", a = new n(this, o)), "string" == typeof o ? s = a[o].apply(a, i) : void 0
            }), s
        }, e.fn.bootstrapSwitch.Constructor = n, e.fn.bootstrapSwitch.defaults = {
            state: !0,
            size: null,
            animate: !0,
            disabled: !1,
            readonly: !1,
            indeterminate: !1,
            inverse: !1,
            radioAllOff: !1,
            onColor: "primary",
            offColor: "default",
            onText: "ON",
            offText: "OFF",
            labelText: "&nbsp;",
            handleWidth: "auto",
            labelWidth: "auto",
            baseClass: "bootstrap-switch",
            wrapperClass: "wrapper",
            onInit: function() {},
            onSwitchChange: function() {}
        }
    }(window.jQuery, window)
}).call(this);
/*!
 * ----------------------------------------------------------------------------
 * "THE BEER-WARE LICENSE" (Revision 42):
 * <jevin9@gmail.com> wrote this file. As long as you retain this notice you
 * can do whatever you want with this stuff. If we meet some day, and you think
 * this stuff is worth it, you can buy me a beer in return. Jevin O. Sewaruth
 * ----------------------------------------------------------------------------
 *
 * Autogrow Textarea Plugin Version v3.0
 * http://www.technoreply.com/autogrow-textarea-plugin-3-0
 * 
 * THIS PLUGIN IS DELIVERD ON A PAY WHAT YOU WHANT BASIS. IF THE PLUGIN WAS USEFUL TO YOU, PLEASE CONSIDER BUYING THE PLUGIN HERE :
 * https://sites.fastspring.com/technoreply/instant/autogrowtextareaplugin
 *
 * Date: October 15, 2012
 */
;
jQuery.fn.autoGrow = function(a) {
    return this.each(function() {
        var d = jQuery.extend({
            extraLine: true
        }, a);
        var e = function(g) {
            jQuery(g).after('<div class="autogrow-textarea-mirror"></div>');
            return jQuery(g).next(".autogrow-textarea-mirror")[0]
        };
        var b = function(g) {
            f.innerHTML = String(g.value).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/ /g, "&nbsp;").replace(/\n/g, "<br />") + (d.extraLine ? ".<br/>." : "");
            if (jQuery(g).height() != jQuery(f).height()) {
                jQuery(g).height(jQuery(f).height())
            }
        };
        var c = function() {
            b(this)
        };
        var f = e(this);
        f.style.display = "none";
        f.style.wordWrap = "break-word";
        f.style.whiteSpace = "normal";
        f.style.padding = jQuery(this).css("padding");
        f.style.width = jQuery(this).css("width");
        f.style.fontFamily = jQuery(this).css("font-family");
        f.style.fontSize = jQuery(this).css("font-size");
        f.style.lineHeight = jQuery(this).css("line-height");
        this.style.overflow = "hidden";
        this.style.minHeight = this.rows + "em";
        this.onkeyup = c;
        b(this)
    })
};
/*!
 * Chart.js
 * http://chartjs.org/
 * Version: 2.1.3
 *
 * Copyright 2016 Nick Downie
 * Released under the MIT license
 * https://github.com/chartjs/Chart.js/blob/master/LICENSE.md
 */
(function e(t, n, r) {
    function s(o, u) {
        if (!n[o]) {
            if (!t[o]) {
                var a = typeof require == "function" && require;
                if (!u && a) return a(o, !0);
                if (i) return i(o, !0);
                var f = new Error("Cannot find module '" + o + "'");
                throw f.code = "MODULE_NOT_FOUND", f
            }
            var l = n[o] = {
                exports: {}
            };
            t[o][0].call(l.exports, function(e) {
                var n = t[o][1][e];
                return s(n ? n : e)
            }, l, l.exports, e, t, n, r)
        }
        return n[o].exports
    }
    var i = typeof require == "function" && require;
    for (var o = 0; o < r.length; o++) s(r[o]);
    return s
})({
    1: [function(require, module, exports) {
        /* MIT license */
        var colorNames = require('color-name');

        module.exports = {
            getRgba: getRgba,
            getHsla: getHsla,
            getRgb: getRgb,
            getHsl: getHsl,
            getHwb: getHwb,
            getAlpha: getAlpha,

            hexString: hexString,
            rgbString: rgbString,
            rgbaString: rgbaString,
            percentString: percentString,
            percentaString: percentaString,
            hslString: hslString,
            hslaString: hslaString,
            hwbString: hwbString,
            keyword: keyword
        }

        function getRgba(string) {
            if (!string) {
                return;
            }
            var abbr = /^#([a-fA-F0-9]{3})$/,
                hex = /^#([a-fA-F0-9]{6})$/,
                rgba = /^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/,
                per = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/,
                keyword = /(\w+)/;

            var rgb = [0, 0, 0],
                a = 1,
                match = string.match(abbr);
            if (match) {
                match = match[1];
                for (var i = 0; i < rgb.length; i++) {
                    rgb[i] = parseInt(match[i] + match[i], 16);
                }
            } else if (match = string.match(hex)) {
                match = match[1];
                for (var i = 0; i < rgb.length; i++) {
                    rgb[i] = parseInt(match.slice(i * 2, i * 2 + 2), 16);
                }
            } else if (match = string.match(rgba)) {
                for (var i = 0; i < rgb.length; i++) {
                    rgb[i] = parseInt(match[i + 1]);
                }
                a = parseFloat(match[4]);
            } else if (match = string.match(per)) {
                for (var i = 0; i < rgb.length; i++) {
                    rgb[i] = Math.round(parseFloat(match[i + 1]) * 2.55);
                }
                a = parseFloat(match[4]);
            } else if (match = string.match(keyword)) {
                if (match[1] == "transparent") {
                    return [0, 0, 0, 0];
                }
                rgb = colorNames[match[1]];
                if (!rgb) {
                    return;
                }
            }

            for (var i = 0; i < rgb.length; i++) {
                rgb[i] = scale(rgb[i], 0, 255);
            }
            if (!a && a != 0) {
                a = 1;
            } else {
                a = scale(a, 0, 1);
            }
            rgb[3] = a;
            return rgb;
        }

        function getHsla(string) {
            if (!string) {
                return;
            }
            var hsl = /^hsla?\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/;
            var match = string.match(hsl);
            if (match) {
                var alpha = parseFloat(match[4]);
                var h = scale(parseInt(match[1]), 0, 360),
                    s = scale(parseFloat(match[2]), 0, 100),
                    l = scale(parseFloat(match[3]), 0, 100),
                    a = scale(isNaN(alpha) ? 1 : alpha, 0, 1);
                return [h, s, l, a];
            }
        }

        function getHwb(string) {
            if (!string) {
                return;
            }
            var hwb = /^hwb\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/;
            var match = string.match(hwb);
            if (match) {
                var alpha = parseFloat(match[4]);
                var h = scale(parseInt(match[1]), 0, 360),
                    w = scale(parseFloat(match[2]), 0, 100),
                    b = scale(parseFloat(match[3]), 0, 100),
                    a = scale(isNaN(alpha) ? 1 : alpha, 0, 1);
                return [h, w, b, a];
            }
        }

        function getRgb(string) {
            var rgba = getRgba(string);
            return rgba && rgba.slice(0, 3);
        }

        function getHsl(string) {
            var hsla = getHsla(string);
            return hsla && hsla.slice(0, 3);
        }

        function getAlpha(string) {
            var vals = getRgba(string);
            if (vals) {
                return vals[3];
            } else if (vals = getHsla(string)) {
                return vals[3];
            } else if (vals = getHwb(string)) {
                return vals[3];
            }
        }

        // generators
        function hexString(rgb) {
            return "#" + hexDouble(rgb[0]) + hexDouble(rgb[1]) +
                hexDouble(rgb[2]);
        }

        function rgbString(rgba, alpha) {
            if (alpha < 1 || (rgba[3] && rgba[3] < 1)) {
                return rgbaString(rgba, alpha);
            }
            return "rgb(" + rgba[0] + ", " + rgba[1] + ", " + rgba[2] + ")";
        }

        function rgbaString(rgba, alpha) {
            if (alpha === undefined) {
                alpha = (rgba[3] !== undefined ? rgba[3] : 1);
            }
            return "rgba(" + rgba[0] + ", " + rgba[1] + ", " + rgba[2] +
                ", " + alpha + ")";
        }

        function percentString(rgba, alpha) {
            if (alpha < 1 || (rgba[3] && rgba[3] < 1)) {
                return percentaString(rgba, alpha);
            }
            var r = Math.round(rgba[0] / 255 * 100),
                g = Math.round(rgba[1] / 255 * 100),
                b = Math.round(rgba[2] / 255 * 100);

            return "rgb(" + r + "%, " + g + "%, " + b + "%)";
        }

        function percentaString(rgba, alpha) {
            var r = Math.round(rgba[0] / 255 * 100),
                g = Math.round(rgba[1] / 255 * 100),
                b = Math.round(rgba[2] / 255 * 100);
            return "rgba(" + r + "%, " + g + "%, " + b + "%, " + (alpha || rgba[3] || 1) + ")";
        }

        function hslString(hsla, alpha) {
            if (alpha < 1 || (hsla[3] && hsla[3] < 1)) {
                return hslaString(hsla, alpha);
            }
            return "hsl(" + hsla[0] + ", " + hsla[1] + "%, " + hsla[2] + "%)";
        }

        function hslaString(hsla, alpha) {
            if (alpha === undefined) {
                alpha = (hsla[3] !== undefined ? hsla[3] : 1);
            }
            return "hsla(" + hsla[0] + ", " + hsla[1] + "%, " + hsla[2] + "%, " +
                alpha + ")";
        }

        // hwb is a bit different than rgb(a) & hsl(a) since there is no alpha specific syntax
        // (hwb have alpha optional & 1 is default value)
        function hwbString(hwb, alpha) {
            if (alpha === undefined) {
                alpha = (hwb[3] !== undefined ? hwb[3] : 1);
            }
            return "hwb(" + hwb[0] + ", " + hwb[1] + "%, " + hwb[2] + "%" +
                (alpha !== undefined && alpha !== 1 ? ", " + alpha : "") + ")";
        }

        function keyword(rgb) {
            return reverseNames[rgb.slice(0, 3)];
        }

        // helpers
        function scale(num, min, max) {
            return Math.min(Math.max(min, num), max);
        }

        function hexDouble(num) {
            var str = num.toString(16).toUpperCase();
            return (str.length < 2) ? "0" + str : str;
        }


        //create a list of reverse color names
        var reverseNames = {};
        for (var name in colorNames) {
            reverseNames[colorNames[name]] = name;
        }

    }, {
        "color-name": 5
    }],
    2: [function(require, module, exports) {
        /* MIT license */

        var convert = require("color-convert"),
            string = require("chartjs-color-string");

        var Color = function(obj) {
            if (obj instanceof Color) return obj;
            if (!(this instanceof Color)) return new Color(obj);

            this.values = {
                rgb: [0, 0, 0],
                hsl: [0, 0, 0],
                hsv: [0, 0, 0],
                hwb: [0, 0, 0],
                cmyk: [0, 0, 0, 0],
                alpha: 1
            }

            // parse Color() argument
            if (typeof obj == "string") {
                var vals = string.getRgba(obj);
                if (vals) {
                    this.setValues("rgb", vals);
                } else if (vals = string.getHsla(obj)) {
                    this.setValues("hsl", vals);
                } else if (vals = string.getHwb(obj)) {
                    this.setValues("hwb", vals);
                } else {
                    throw new Error("Unable to parse color from string \"" + obj + "\"");
                }
            } else if (typeof obj == "object") {
                var vals = obj;
                if (vals["r"] !== undefined || vals["red"] !== undefined) {
                    this.setValues("rgb", vals)
                } else if (vals["l"] !== undefined || vals["lightness"] !== undefined) {
                    this.setValues("hsl", vals)
                } else if (vals["v"] !== undefined || vals["value"] !== undefined) {
                    this.setValues("hsv", vals)
                } else if (vals["w"] !== undefined || vals["whiteness"] !== undefined) {
                    this.setValues("hwb", vals)
                } else if (vals["c"] !== undefined || vals["cyan"] !== undefined) {
                    this.setValues("cmyk", vals)
                } else {
                    throw new Error("Unable to parse color from object " + JSON.stringify(obj));
                }
            }
        }

        Color.prototype = {
            rgb: function(vals) {
                return this.setSpace("rgb", arguments);
            },
            hsl: function(vals) {
                return this.setSpace("hsl", arguments);
            },
            hsv: function(vals) {
                return this.setSpace("hsv", arguments);
            },
            hwb: function(vals) {
                return this.setSpace("hwb", arguments);
            },
            cmyk: function(vals) {
                return this.setSpace("cmyk", arguments);
            },

            rgbArray: function() {
                return this.values.rgb;
            },
            hslArray: function() {
                return this.values.hsl;
            },
            hsvArray: function() {
                return this.values.hsv;
            },
            hwbArray: function() {
                if (this.values.alpha !== 1) {
                    return this.values.hwb.concat([this.values.alpha])
                }
                return this.values.hwb;
            },
            cmykArray: function() {
                return this.values.cmyk;
            },
            rgbaArray: function() {
                var rgb = this.values.rgb;
                return rgb.concat([this.values.alpha]);
            },
            hslaArray: function() {
                var hsl = this.values.hsl;
                return hsl.concat([this.values.alpha]);
            },
            alpha: function(val) {
                if (val === undefined) {
                    return this.values.alpha;
                }
                this.setValues("alpha", val);
                return this;
            },

            red: function(val) {
                return this.setChannel("rgb", 0, val);
            },
            green: function(val) {
                return this.setChannel("rgb", 1, val);
            },
            blue: function(val) {
                return this.setChannel("rgb", 2, val);
            },
            hue: function(val) {
                return this.setChannel("hsl", 0, val);
            },
            saturation: function(val) {
                return this.setChannel("hsl", 1, val);
            },
            lightness: function(val) {
                return this.setChannel("hsl", 2, val);
            },
            saturationv: function(val) {
                return this.setChannel("hsv", 1, val);
            },
            whiteness: function(val) {
                return this.setChannel("hwb", 1, val);
            },
            blackness: function(val) {
                return this.setChannel("hwb", 2, val);
            },
            value: function(val) {
                return this.setChannel("hsv", 2, val);
            },
            cyan: function(val) {
                return this.setChannel("cmyk", 0, val);
            },
            magenta: function(val) {
                return this.setChannel("cmyk", 1, val);
            },
            yellow: function(val) {
                return this.setChannel("cmyk", 2, val);
            },
            black: function(val) {
                return this.setChannel("cmyk", 3, val);
            },

            hexString: function() {
                return string.hexString(this.values.rgb);
            },
            rgbString: function() {
                return string.rgbString(this.values.rgb, this.values.alpha);
            },
            rgbaString: function() {
                return string.rgbaString(this.values.rgb, this.values.alpha);
            },
            percentString: function() {
                return string.percentString(this.values.rgb, this.values.alpha);
            },
            hslString: function() {
                return string.hslString(this.values.hsl, this.values.alpha);
            },
            hslaString: function() {
                return string.hslaString(this.values.hsl, this.values.alpha);
            },
            hwbString: function() {
                return string.hwbString(this.values.hwb, this.values.alpha);
            },
            keyword: function() {
                return string.keyword(this.values.rgb, this.values.alpha);
            },

            rgbNumber: function() {
                return (this.values.rgb[0] << 16) | (this.values.rgb[1] << 8) | this.values.rgb[2];
            },

            luminosity: function() {
                // http://www.w3.org/TR/WCAG20/#relativeluminancedef
                var rgb = this.values.rgb;
                var lum = [];
                for (var i = 0; i < rgb.length; i++) {
                    var chan = rgb[i] / 255;
                    lum[i] = (chan <= 0.03928) ? chan / 12.92 : Math.pow(((chan + 0.055) / 1.055), 2.4)
                }
                return 0.2126 * lum[0] + 0.7152 * lum[1] + 0.0722 * lum[2];
            },

            contrast: function(color2) {
                // http://www.w3.org/TR/WCAG20/#contrast-ratiodef
                var lum1 = this.luminosity();
                var lum2 = color2.luminosity();
                if (lum1 > lum2) {
                    return (lum1 + 0.05) / (lum2 + 0.05)
                };
                return (lum2 + 0.05) / (lum1 + 0.05);
            },

            level: function(color2) {
                var contrastRatio = this.contrast(color2);
                return (contrastRatio >= 7.1) ? 'AAA' : (contrastRatio >= 4.5) ? 'AA' : '';
            },

            dark: function() {
                // YIQ equation from http://24ways.org/2010/calculating-color-contrast
                var rgb = this.values.rgb,
                    yiq = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
                return yiq < 128;
            },

            light: function() {
                return !this.dark();
            },

            negate: function() {
                var rgb = []
                for (var i = 0; i < 3; i++) {
                    rgb[i] = 255 - this.values.rgb[i];
                }
                this.setValues("rgb", rgb);
                return this;
            },

            lighten: function(ratio) {
                this.values.hsl[2] += this.values.hsl[2] * ratio;
                this.setValues("hsl", this.values.hsl);
                return this;
            },

            darken: function(ratio) {
                this.values.hsl[2] -= this.values.hsl[2] * ratio;
                this.setValues("hsl", this.values.hsl);
                return this;
            },

            saturate: function(ratio) {
                this.values.hsl[1] += this.values.hsl[1] * ratio;
                this.setValues("hsl", this.values.hsl);
                return this;
            },

            desaturate: function(ratio) {
                this.values.hsl[1] -= this.values.hsl[1] * ratio;
                this.setValues("hsl", this.values.hsl);
                return this;
            },

            whiten: function(ratio) {
                this.values.hwb[1] += this.values.hwb[1] * ratio;
                this.setValues("hwb", this.values.hwb);
                return this;
            },

            blacken: function(ratio) {
                this.values.hwb[2] += this.values.hwb[2] * ratio;
                this.setValues("hwb", this.values.hwb);
                return this;
            },

            greyscale: function() {
                var rgb = this.values.rgb;
                // http://en.wikipedia.org/wiki/Grayscale#Converting_color_to_grayscale
                var val = rgb[0] * 0.3 + rgb[1] * 0.59 + rgb[2] * 0.11;
                this.setValues("rgb", [val, val, val]);
                return this;
            },

            clearer: function(ratio) {
                this.setValues("alpha", this.values.alpha - (this.values.alpha * ratio));
                return this;
            },

            opaquer: function(ratio) {
                this.setValues("alpha", this.values.alpha + (this.values.alpha * ratio));
                return this;
            },

            rotate: function(degrees) {
                var hue = this.values.hsl[0];
                hue = (hue + degrees) % 360;
                hue = hue < 0 ? 360 + hue : hue;
                this.values.hsl[0] = hue;
                this.setValues("hsl", this.values.hsl);
                return this;
            },

            mix: function(color2, weight) {
                weight = 1 - (weight == null ? 0.5 : weight);

                // algorithm from Sass's mix(). Ratio of first color in mix is
                // determined by the alphas of both colors and the weight
                var t1 = weight * 2 - 1,
                    d = this.alpha() - color2.alpha();

                var weight1 = (((t1 * d == -1) ? t1 : (t1 + d) / (1 + t1 * d)) + 1) / 2;
                var weight2 = 1 - weight1;

                var rgb = this.rgbArray();
                var rgb2 = color2.rgbArray();

                for (var i = 0; i < rgb.length; i++) {
                    rgb[i] = rgb[i] * weight1 + rgb2[i] * weight2;
                }
                this.setValues("rgb", rgb);

                var alpha = this.alpha() * weight + color2.alpha() * (1 - weight);
                this.setValues("alpha", alpha);

                return this;
            },

            toJSON: function() {
                return this.rgb();
            },

            clone: function() {
                return new Color(this.rgb());
            }
        }


        Color.prototype.getValues = function(space) {
            var vals = {};
            for (var i = 0; i < space.length; i++) {
                vals[space.charAt(i)] = this.values[space][i];
            }
            if (this.values.alpha != 1) {
                vals["a"] = this.values.alpha;
            }
            // {r: 255, g: 255, b: 255, a: 0.4}
            return vals;
        }

        Color.prototype.setValues = function(space, vals) {
            var spaces = {
                "rgb": ["red", "green", "blue"],
                "hsl": ["hue", "saturation", "lightness"],
                "hsv": ["hue", "saturation", "value"],
                "hwb": ["hue", "whiteness", "blackness"],
                "cmyk": ["cyan", "magenta", "yellow", "black"]
            };

            var maxes = {
                "rgb": [255, 255, 255],
                "hsl": [360, 100, 100],
                "hsv": [360, 100, 100],
                "hwb": [360, 100, 100],
                "cmyk": [100, 100, 100, 100]
            };

            var alpha = 1;
            if (space == "alpha") {
                alpha = vals;
            } else if (vals.length) {
                // [10, 10, 10]
                this.values[space] = vals.slice(0, space.length);
                alpha = vals[space.length];
            } else if (vals[space.charAt(0)] !== undefined) {
                // {r: 10, g: 10, b: 10}
                for (var i = 0; i < space.length; i++) {
                    this.values[space][i] = vals[space.charAt(i)];
                }
                alpha = vals.a;
            } else if (vals[spaces[space][0]] !== undefined) {
                // {red: 10, green: 10, blue: 10}
                var chans = spaces[space];
                for (var i = 0; i < space.length; i++) {
                    this.values[space][i] = vals[chans[i]];
                }
                alpha = vals.alpha;
            }
            this.values.alpha = Math.max(0, Math.min(1, (alpha !== undefined ? alpha : this.values.alpha)));
            if (space == "alpha") {
                return;
            }

            // cap values of the space prior converting all values
            for (var i = 0; i < space.length; i++) {
                var capped = Math.max(0, Math.min(maxes[space][i], this.values[space][i]));
                this.values[space][i] = Math.round(capped);
            }

            // convert to all the other color spaces
            for (var sname in spaces) {
                if (sname != space) {
                    this.values[sname] = convert[space][sname](this.values[space])
                }

                // cap values
                for (var i = 0; i < sname.length; i++) {
                    var capped = Math.max(0, Math.min(maxes[sname][i], this.values[sname][i]));
                    this.values[sname][i] = Math.round(capped);
                }
            }
            return true;
        }

        Color.prototype.setSpace = function(space, args) {
            var vals = args[0];
            if (vals === undefined) {
                // color.rgb()
                return this.getValues(space);
            }
            // color.rgb(10, 10, 10)
            if (typeof vals == "number") {
                vals = Array.prototype.slice.call(args);
            }
            this.setValues(space, vals);
            return this;
        }

        Color.prototype.setChannel = function(space, index, val) {
            if (val === undefined) {
                // color.red()
                return this.values[space][index];
            }
            // color.red(100)
            this.values[space][index] = val;
            this.setValues(space, this.values[space]);
            return this;
        }

        window.Color = module.exports = Color

    }, {
        "chartjs-color-string": 1,
        "color-convert": 4
    }],
    3: [function(require, module, exports) {
        /* MIT license */

        module.exports = {
            rgb2hsl: rgb2hsl,
            rgb2hsv: rgb2hsv,
            rgb2hwb: rgb2hwb,
            rgb2cmyk: rgb2cmyk,
            rgb2keyword: rgb2keyword,
            rgb2xyz: rgb2xyz,
            rgb2lab: rgb2lab,
            rgb2lch: rgb2lch,

            hsl2rgb: hsl2rgb,
            hsl2hsv: hsl2hsv,
            hsl2hwb: hsl2hwb,
            hsl2cmyk: hsl2cmyk,
            hsl2keyword: hsl2keyword,

            hsv2rgb: hsv2rgb,
            hsv2hsl: hsv2hsl,
            hsv2hwb: hsv2hwb,
            hsv2cmyk: hsv2cmyk,
            hsv2keyword: hsv2keyword,

            hwb2rgb: hwb2rgb,
            hwb2hsl: hwb2hsl,
            hwb2hsv: hwb2hsv,
            hwb2cmyk: hwb2cmyk,
            hwb2keyword: hwb2keyword,

            cmyk2rgb: cmyk2rgb,
            cmyk2hsl: cmyk2hsl,
            cmyk2hsv: cmyk2hsv,
            cmyk2hwb: cmyk2hwb,
            cmyk2keyword: cmyk2keyword,

            keyword2rgb: keyword2rgb,
            keyword2hsl: keyword2hsl,
            keyword2hsv: keyword2hsv,
            keyword2hwb: keyword2hwb,
            keyword2cmyk: keyword2cmyk,
            keyword2lab: keyword2lab,
            keyword2xyz: keyword2xyz,

            xyz2rgb: xyz2rgb,
            xyz2lab: xyz2lab,
            xyz2lch: xyz2lch,

            lab2xyz: lab2xyz,
            lab2rgb: lab2rgb,
            lab2lch: lab2lch,

            lch2lab: lch2lab,
            lch2xyz: lch2xyz,
            lch2rgb: lch2rgb
        }


        function rgb2hsl(rgb) {
            var r = rgb[0] / 255,
                g = rgb[1] / 255,
                b = rgb[2] / 255,
                min = Math.min(r, g, b),
                max = Math.max(r, g, b),
                delta = max - min,
                h, s, l;

            if (max == min)
                h = 0;
            else if (r == max)
                h = (g - b) / delta;
            else if (g == max)
                h = 2 + (b - r) / delta;
            else if (b == max)
                h = 4 + (r - g) / delta;

            h = Math.min(h * 60, 360);

            if (h < 0)
                h += 360;

            l = (min + max) / 2;

            if (max == min)
                s = 0;
            else if (l <= 0.5)
                s = delta / (max + min);
            else
                s = delta / (2 - max - min);

            return [h, s * 100, l * 100];
        }

        function rgb2hsv(rgb) {
            var r = rgb[0],
                g = rgb[1],
                b = rgb[2],
                min = Math.min(r, g, b),
                max = Math.max(r, g, b),
                delta = max - min,
                h, s, v;

            if (max == 0)
                s = 0;
            else
                s = (delta / max * 1000) / 10;

            if (max == min)
                h = 0;
            else if (r == max)
                h = (g - b) / delta;
            else if (g == max)
                h = 2 + (b - r) / delta;
            else if (b == max)
                h = 4 + (r - g) / delta;

            h = Math.min(h * 60, 360);

            if (h < 0)
                h += 360;

            v = ((max / 255) * 1000) / 10;

            return [h, s, v];
        }

        function rgb2hwb(rgb) {
            var r = rgb[0],
                g = rgb[1],
                b = rgb[2],
                h = rgb2hsl(rgb)[0],
                w = 1 / 255 * Math.min(r, Math.min(g, b)),
                b = 1 - 1 / 255 * Math.max(r, Math.max(g, b));

            return [h, w * 100, b * 100];
        }

        function rgb2cmyk(rgb) {
            var r = rgb[0] / 255,
                g = rgb[1] / 255,
                b = rgb[2] / 255,
                c, m, y, k;

            k = Math.min(1 - r, 1 - g, 1 - b);
            c = (1 - r - k) / (1 - k) || 0;
            m = (1 - g - k) / (1 - k) || 0;
            y = (1 - b - k) / (1 - k) || 0;
            return [c * 100, m * 100, y * 100, k * 100];
        }

        function rgb2keyword(rgb) {
            return reverseKeywords[JSON.stringify(rgb)];
        }

        function rgb2xyz(rgb) {
            var r = rgb[0] / 255,
                g = rgb[1] / 255,
                b = rgb[2] / 255;

            // assume sRGB
            r = r > 0.04045 ? Math.pow(((r + 0.055) / 1.055), 2.4) : (r / 12.92);
            g = g > 0.04045 ? Math.pow(((g + 0.055) / 1.055), 2.4) : (g / 12.92);
            b = b > 0.04045 ? Math.pow(((b + 0.055) / 1.055), 2.4) : (b / 12.92);

            var x = (r * 0.4124) + (g * 0.3576) + (b * 0.1805);
            var y = (r * 0.2126) + (g * 0.7152) + (b * 0.0722);
            var z = (r * 0.0193) + (g * 0.1192) + (b * 0.9505);

            return [x * 100, y * 100, z * 100];
        }

        function rgb2lab(rgb) {
            var xyz = rgb2xyz(rgb),
                x = xyz[0],
                y = xyz[1],
                z = xyz[2],
                l, a, b;

            x /= 95.047;
            y /= 100;
            z /= 108.883;

            x = x > 0.008856 ? Math.pow(x, 1 / 3) : (7.787 * x) + (16 / 116);
            y = y > 0.008856 ? Math.pow(y, 1 / 3) : (7.787 * y) + (16 / 116);
            z = z > 0.008856 ? Math.pow(z, 1 / 3) : (7.787 * z) + (16 / 116);

            l = (116 * y) - 16;
            a = 500 * (x - y);
            b = 200 * (y - z);

            return [l, a, b];
        }

        function rgb2lch(args) {
            return lab2lch(rgb2lab(args));
        }

        function hsl2rgb(hsl) {
            var h = hsl[0] / 360,
                s = hsl[1] / 100,
                l = hsl[2] / 100,
                t1, t2, t3, rgb, val;

            if (s == 0) {
                val = l * 255;
                return [val, val, val];
            }

            if (l < 0.5)
                t2 = l * (1 + s);
            else
                t2 = l + s - l * s;
            t1 = 2 * l - t2;

            rgb = [0, 0, 0];
            for (var i = 0; i < 3; i++) {
                t3 = h + 1 / 3 * -(i - 1);
                t3 < 0 && t3++;
                t3 > 1 && t3--;

                if (6 * t3 < 1)
                    val = t1 + (t2 - t1) * 6 * t3;
                else if (2 * t3 < 1)
                    val = t2;
                else if (3 * t3 < 2)
                    val = t1 + (t2 - t1) * (2 / 3 - t3) * 6;
                else
                    val = t1;

                rgb[i] = val * 255;
            }

            return rgb;
        }

        function hsl2hsv(hsl) {
            var h = hsl[0],
                s = hsl[1] / 100,
                l = hsl[2] / 100,
                sv, v;

            if (l === 0) {
                // no need to do calc on black
                // also avoids divide by 0 error
                return [0, 0, 0];
            }

            l *= 2;
            s *= (l <= 1) ? l : 2 - l;
            v = (l + s) / 2;
            sv = (2 * s) / (l + s);
            return [h, sv * 100, v * 100];
        }

        function hsl2hwb(args) {
            return rgb2hwb(hsl2rgb(args));
        }

        function hsl2cmyk(args) {
            return rgb2cmyk(hsl2rgb(args));
        }

        function hsl2keyword(args) {
            return rgb2keyword(hsl2rgb(args));
        }


        function hsv2rgb(hsv) {
            var h = hsv[0] / 60,
                s = hsv[1] / 100,
                v = hsv[2] / 100,
                hi = Math.floor(h) % 6;

            var f = h - Math.floor(h),
                p = 255 * v * (1 - s),
                q = 255 * v * (1 - (s * f)),
                t = 255 * v * (1 - (s * (1 - f))),
                v = 255 * v;

            switch (hi) {
                case 0:
                    return [v, t, p];
                case 1:
                    return [q, v, p];
                case 2:
                    return [p, v, t];
                case 3:
                    return [p, q, v];
                case 4:
                    return [t, p, v];
                case 5:
                    return [v, p, q];
            }
        }

        function hsv2hsl(hsv) {
            var h = hsv[0],
                s = hsv[1] / 100,
                v = hsv[2] / 100,
                sl, l;

            l = (2 - s) * v;
            sl = s * v;
            sl /= (l <= 1) ? l : 2 - l;
            sl = sl || 0;
            l /= 2;
            return [h, sl * 100, l * 100];
        }

        function hsv2hwb(args) {
            return rgb2hwb(hsv2rgb(args))
        }

        function hsv2cmyk(args) {
            return rgb2cmyk(hsv2rgb(args));
        }

        function hsv2keyword(args) {
            return rgb2keyword(hsv2rgb(args));
        }

        // http://dev.w3.org/csswg/css-color/#hwb-to-rgb
        function hwb2rgb(hwb) {
            var h = hwb[0] / 360,
                wh = hwb[1] / 100,
                bl = hwb[2] / 100,
                ratio = wh + bl,
                i, v, f, n;

            // wh + bl cant be > 1
            if (ratio > 1) {
                wh /= ratio;
                bl /= ratio;
            }

            i = Math.floor(6 * h);
            v = 1 - bl;
            f = 6 * h - i;
            if ((i & 0x01) != 0) {
                f = 1 - f;
            }
            n = wh + f * (v - wh); // linear interpolation

            switch (i) {
                default:
                    case 6:
                    case 0:
                    r = v;g = n;b = wh;
                break;
                case 1:
                        r = n;g = v;b = wh;
                    break;
                case 2:
                        r = wh;g = v;b = n;
                    break;
                case 3:
                        r = wh;g = n;b = v;
                    break;
                case 4:
                        r = n;g = wh;b = v;
                    break;
                case 5:
                        r = v;g = wh;b = n;
                    break;
            }

            return [r * 255, g * 255, b * 255];
        }

        function hwb2hsl(args) {
            return rgb2hsl(hwb2rgb(args));
        }

        function hwb2hsv(args) {
            return rgb2hsv(hwb2rgb(args));
        }

        function hwb2cmyk(args) {
            return rgb2cmyk(hwb2rgb(args));
        }

        function hwb2keyword(args) {
            return rgb2keyword(hwb2rgb(args));
        }

        function cmyk2rgb(cmyk) {
            var c = cmyk[0] / 100,
                m = cmyk[1] / 100,
                y = cmyk[2] / 100,
                k = cmyk[3] / 100,
                r, g, b;

            r = 1 - Math.min(1, c * (1 - k) + k);
            g = 1 - Math.min(1, m * (1 - k) + k);
            b = 1 - Math.min(1, y * (1 - k) + k);
            return [r * 255, g * 255, b * 255];
        }

        function cmyk2hsl(args) {
            return rgb2hsl(cmyk2rgb(args));
        }

        function cmyk2hsv(args) {
            return rgb2hsv(cmyk2rgb(args));
        }

        function cmyk2hwb(args) {
            return rgb2hwb(cmyk2rgb(args));
        }

        function cmyk2keyword(args) {
            return rgb2keyword(cmyk2rgb(args));
        }


        function xyz2rgb(xyz) {
            var x = xyz[0] / 100,
                y = xyz[1] / 100,
                z = xyz[2] / 100,
                r, g, b;

            r = (x * 3.2406) + (y * -1.5372) + (z * -0.4986);
            g = (x * -0.9689) + (y * 1.8758) + (z * 0.0415);
            b = (x * 0.0557) + (y * -0.2040) + (z * 1.0570);

            // assume sRGB
            r = r > 0.0031308 ? ((1.055 * Math.pow(r, 1.0 / 2.4)) - 0.055) :
                r = (r * 12.92);

            g = g > 0.0031308 ? ((1.055 * Math.pow(g, 1.0 / 2.4)) - 0.055) :
                g = (g * 12.92);

            b = b > 0.0031308 ? ((1.055 * Math.pow(b, 1.0 / 2.4)) - 0.055) :
                b = (b * 12.92);

            r = Math.min(Math.max(0, r), 1);
            g = Math.min(Math.max(0, g), 1);
            b = Math.min(Math.max(0, b), 1);

            return [r * 255, g * 255, b * 255];
        }

        function xyz2lab(xyz) {
            var x = xyz[0],
                y = xyz[1],
                z = xyz[2],
                l, a, b;

            x /= 95.047;
            y /= 100;
            z /= 108.883;

            x = x > 0.008856 ? Math.pow(x, 1 / 3) : (7.787 * x) + (16 / 116);
            y = y > 0.008856 ? Math.pow(y, 1 / 3) : (7.787 * y) + (16 / 116);
            z = z > 0.008856 ? Math.pow(z, 1 / 3) : (7.787 * z) + (16 / 116);

            l = (116 * y) - 16;
            a = 500 * (x - y);
            b = 200 * (y - z);

            return [l, a, b];
        }

        function xyz2lch(args) {
            return lab2lch(xyz2lab(args));
        }

        function lab2xyz(lab) {
            var l = lab[0],
                a = lab[1],
                b = lab[2],
                x, y, z, y2;

            if (l <= 8) {
                y = (l * 100) / 903.3;
                y2 = (7.787 * (y / 100)) + (16 / 116);
            } else {
                y = 100 * Math.pow((l + 16) / 116, 3);
                y2 = Math.pow(y / 100, 1 / 3);
            }

            x = x / 95.047 <= 0.008856 ? x = (95.047 * ((a / 500) + y2 - (16 / 116))) / 7.787 : 95.047 * Math.pow((a / 500) + y2, 3);

            z = z / 108.883 <= 0.008859 ? z = (108.883 * (y2 - (b / 200) - (16 / 116))) / 7.787 : 108.883 * Math.pow(y2 - (b / 200), 3);

            return [x, y, z];
        }

        function lab2lch(lab) {
            var l = lab[0],
                a = lab[1],
                b = lab[2],
                hr, h, c;

            hr = Math.atan2(b, a);
            h = hr * 360 / 2 / Math.PI;
            if (h < 0) {
                h += 360;
            }
            c = Math.sqrt(a * a + b * b);
            return [l, c, h];
        }

        function lab2rgb(args) {
            return xyz2rgb(lab2xyz(args));
        }

        function lch2lab(lch) {
            var l = lch[0],
                c = lch[1],
                h = lch[2],
                a, b, hr;

            hr = h / 360 * 2 * Math.PI;
            a = c * Math.cos(hr);
            b = c * Math.sin(hr);
            return [l, a, b];
        }

        function lch2xyz(args) {
            return lab2xyz(lch2lab(args));
        }

        function lch2rgb(args) {
            return lab2rgb(lch2lab(args));
        }

        function keyword2rgb(keyword) {
            return cssKeywords[keyword];
        }

        function keyword2hsl(args) {
            return rgb2hsl(keyword2rgb(args));
        }

        function keyword2hsv(args) {
            return rgb2hsv(keyword2rgb(args));
        }

        function keyword2hwb(args) {
            return rgb2hwb(keyword2rgb(args));
        }

        function keyword2cmyk(args) {
            return rgb2cmyk(keyword2rgb(args));
        }

        function keyword2lab(args) {
            return rgb2lab(keyword2rgb(args));
        }

        function keyword2xyz(args) {
            return rgb2xyz(keyword2rgb(args));
        }

        var cssKeywords = {
            aliceblue: [240, 248, 255],
            antiquewhite: [250, 235, 215],
            aqua: [0, 255, 255],
            aquamarine: [127, 255, 212],
            azure: [240, 255, 255],
            beige: [245, 245, 220],
            bisque: [255, 228, 196],
            black: [0, 0, 0],
            blanchedalmond: [255, 235, 205],
            blue: [0, 0, 255],
            blueviolet: [138, 43, 226],
            brown: [165, 42, 42],
            burlywood: [222, 184, 135],
            cadetblue: [95, 158, 160],
            chartreuse: [127, 255, 0],
            chocolate: [210, 105, 30],
            coral: [255, 127, 80],
            cornflowerblue: [100, 149, 237],
            cornsilk: [255, 248, 220],
            crimson: [220, 20, 60],
            cyan: [0, 255, 255],
            darkblue: [0, 0, 139],
            darkcyan: [0, 139, 139],
            darkgoldenrod: [184, 134, 11],
            darkgray: [169, 169, 169],
            darkgreen: [0, 100, 0],
            darkgrey: [169, 169, 169],
            darkkhaki: [189, 183, 107],
            darkmagenta: [139, 0, 139],
            darkolivegreen: [85, 107, 47],
            darkorange: [255, 140, 0],
            darkorchid: [153, 50, 204],
            darkred: [139, 0, 0],
            darksalmon: [233, 150, 122],
            darkseagreen: [143, 188, 143],
            darkslateblue: [72, 61, 139],
            darkslategray: [47, 79, 79],
            darkslategrey: [47, 79, 79],
            darkturquoise: [0, 206, 209],
            darkviolet: [148, 0, 211],
            deeppink: [255, 20, 147],
            deepskyblue: [0, 191, 255],
            dimgray: [105, 105, 105],
            dimgrey: [105, 105, 105],
            dodgerblue: [30, 144, 255],
            firebrick: [178, 34, 34],
            floralwhite: [255, 250, 240],
            forestgreen: [34, 139, 34],
            fuchsia: [255, 0, 255],
            gainsboro: [220, 220, 220],
            ghostwhite: [248, 248, 255],
            gold: [255, 215, 0],
            goldenrod: [218, 165, 32],
            gray: [128, 128, 128],
            green: [0, 128, 0],
            greenyellow: [173, 255, 47],
            grey: [128, 128, 128],
            honeydew: [240, 255, 240],
            hotpink: [255, 105, 180],
            indianred: [205, 92, 92],
            indigo: [75, 0, 130],
            ivory: [255, 255, 240],
            khaki: [240, 230, 140],
            lavender: [230, 230, 250],
            lavenderblush: [255, 240, 245],
            lawngreen: [124, 252, 0],
            lemonchiffon: [255, 250, 205],
            lightblue: [173, 216, 230],
            lightcoral: [240, 128, 128],
            lightcyan: [224, 255, 255],
            lightgoldenrodyellow: [250, 250, 210],
            lightgray: [211, 211, 211],
            lightgreen: [144, 238, 144],
            lightgrey: [211, 211, 211],
            lightpink: [255, 182, 193],
            lightsalmon: [255, 160, 122],
            lightseagreen: [32, 178, 170],
            lightskyblue: [135, 206, 250],
            lightslategray: [119, 136, 153],
            lightslategrey: [119, 136, 153],
            lightsteelblue: [176, 196, 222],
            lightyellow: [255, 255, 224],
            lime: [0, 255, 0],
            limegreen: [50, 205, 50],
            linen: [250, 240, 230],
            magenta: [255, 0, 255],
            maroon: [128, 0, 0],
            mediumaquamarine: [102, 205, 170],
            mediumblue: [0, 0, 205],
            mediumorchid: [186, 85, 211],
            mediumpurple: [147, 112, 219],
            mediumseagreen: [60, 179, 113],
            mediumslateblue: [123, 104, 238],
            mediumspringgreen: [0, 250, 154],
            mediumturquoise: [72, 209, 204],
            mediumvioletred: [199, 21, 133],
            midnightblue: [25, 25, 112],
            mintcream: [245, 255, 250],
            mistyrose: [255, 228, 225],
            moccasin: [255, 228, 181],
            navajowhite: [255, 222, 173],
            navy: [0, 0, 128],
            oldlace: [253, 245, 230],
            olive: [128, 128, 0],
            olivedrab: [107, 142, 35],
            orange: [255, 165, 0],
            orangered: [255, 69, 0],
            orchid: [218, 112, 214],
            palegoldenrod: [238, 232, 170],
            palegreen: [152, 251, 152],
            paleturquoise: [175, 238, 238],
            palevioletred: [219, 112, 147],
            papayawhip: [255, 239, 213],
            peachpuff: [255, 218, 185],
            peru: [205, 133, 63],
            pink: [255, 192, 203],
            plum: [221, 160, 221],
            powderblue: [176, 224, 230],
            purple: [128, 0, 128],
            rebeccapurple: [102, 51, 153],
            red: [255, 0, 0],
            rosybrown: [188, 143, 143],
            royalblue: [65, 105, 225],
            saddlebrown: [139, 69, 19],
            salmon: [250, 128, 114],
            sandybrown: [244, 164, 96],
            seagreen: [46, 139, 87],
            seashell: [255, 245, 238],
            sienna: [160, 82, 45],
            silver: [192, 192, 192],
            skyblue: [135, 206, 235],
            slateblue: [106, 90, 205],
            slategray: [112, 128, 144],
            slategrey: [112, 128, 144],
            snow: [255, 250, 250],
            springgreen: [0, 255, 127],
            steelblue: [70, 130, 180],
            tan: [210, 180, 140],
            teal: [0, 128, 128],
            thistle: [216, 191, 216],
            tomato: [255, 99, 71],
            turquoise: [64, 224, 208],
            violet: [238, 130, 238],
            wheat: [245, 222, 179],
            white: [255, 255, 255],
            whitesmoke: [245, 245, 245],
            yellow: [255, 255, 0],
            yellowgreen: [154, 205, 50]
        };

        var reverseKeywords = {};
        for (var key in cssKeywords) {
            reverseKeywords[JSON.stringify(cssKeywords[key])] = key;
        }

    }, {}],
    4: [function(require, module, exports) {
        var conversions = require("./conversions");

        var convert = function() {
            return new Converter();
        }

        for (var func in conversions) {
            // export Raw versions
            convert[func + "Raw"] = (function(func) {
                // accept array or plain args
                return function(arg) {
                    if (typeof arg == "number")
                        arg = Array.prototype.slice.call(arguments);
                    return conversions[func](arg);
                }
            })(func);

            var pair = /(\w+)2(\w+)/.exec(func),
                from = pair[1],
                to = pair[2];

            // export rgb2hsl and ["rgb"]["hsl"]
            convert[from] = convert[from] || {};

            convert[from][to] = convert[func] = (function(func) {
                return function(arg) {
                    if (typeof arg == "number")
                        arg = Array.prototype.slice.call(arguments);

                    var val = conversions[func](arg);
                    if (typeof val == "string" || val === undefined)
                        return val; // keyword

                    for (var i = 0; i < val.length; i++)
                        val[i] = Math.round(val[i]);
                    return val;
                }
            })(func);
        }


        /* Converter does lazy conversion and caching */
        var Converter = function() {
            this.convs = {};
        };

        /* Either get the values for a space or
          set the values for a space, depending on args */
        Converter.prototype.routeSpace = function(space, args) {
            var values = args[0];
            if (values === undefined) {
                // color.rgb()
                return this.getValues(space);
            }
            // color.rgb(10, 10, 10)
            if (typeof values == "number") {
                values = Array.prototype.slice.call(args);
            }

            return this.setValues(space, values);
        };

        /* Set the values for a space, invalidating cache */
        Converter.prototype.setValues = function(space, values) {
            this.space = space;
            this.convs = {};
            this.convs[space] = values;
            return this;
        };

        /* Get the values for a space. If there's already
          a conversion for the space, fetch it, otherwise
          compute it */
        Converter.prototype.getValues = function(space) {
            var vals = this.convs[space];
            if (!vals) {
                var fspace = this.space,
                    from = this.convs[fspace];
                vals = convert[fspace][space](from);

                this.convs[space] = vals;
            }
            return vals;
        };

        ["rgb", "hsl", "hsv", "cmyk", "keyword"].forEach(function(space) {
            Converter.prototype[space] = function(vals) {
                return this.routeSpace(space, arguments);
            }
        });

        module.exports = convert;
    }, {
        "./conversions": 3
    }],
    5: [function(require, module, exports) {
        module.exports = {
            "aliceblue": [240, 248, 255],
            "antiquewhite": [250, 235, 215],
            "aqua": [0, 255, 255],
            "aquamarine": [127, 255, 212],
            "azure": [240, 255, 255],
            "beige": [245, 245, 220],
            "bisque": [255, 228, 196],
            "black": [0, 0, 0],
            "blanchedalmond": [255, 235, 205],
            "blue": [0, 0, 255],
            "blueviolet": [138, 43, 226],
            "brown": [165, 42, 42],
            "burlywood": [222, 184, 135],
            "cadetblue": [95, 158, 160],
            "chartreuse": [127, 255, 0],
            "chocolate": [210, 105, 30],
            "coral": [255, 127, 80],
            "cornflowerblue": [100, 149, 237],
            "cornsilk": [255, 248, 220],
            "crimson": [220, 20, 60],
            "cyan": [0, 255, 255],
            "darkblue": [0, 0, 139],
            "darkcyan": [0, 139, 139],
            "darkgoldenrod": [184, 134, 11],
            "darkgray": [169, 169, 169],
            "darkgreen": [0, 100, 0],
            "darkgrey": [169, 169, 169],
            "darkkhaki": [189, 183, 107],
            "darkmagenta": [139, 0, 139],
            "darkolivegreen": [85, 107, 47],
            "darkorange": [255, 140, 0],
            "darkorchid": [153, 50, 204],
            "darkred": [139, 0, 0],
            "darksalmon": [233, 150, 122],
            "darkseagreen": [143, 188, 143],
            "darkslateblue": [72, 61, 139],
            "darkslategray": [47, 79, 79],
            "darkslategrey": [47, 79, 79],
            "darkturquoise": [0, 206, 209],
            "darkviolet": [148, 0, 211],
            "deeppink": [255, 20, 147],
            "deepskyblue": [0, 191, 255],
            "dimgray": [105, 105, 105],
            "dimgrey": [105, 105, 105],
            "dodgerblue": [30, 144, 255],
            "firebrick": [178, 34, 34],
            "floralwhite": [255, 250, 240],
            "forestgreen": [34, 139, 34],
            "fuchsia": [255, 0, 255],
            "gainsboro": [220, 220, 220],
            "ghostwhite": [248, 248, 255],
            "gold": [255, 215, 0],
            "goldenrod": [218, 165, 32],
            "gray": [128, 128, 128],
            "green": [0, 128, 0],
            "greenyellow": [173, 255, 47],
            "grey": [128, 128, 128],
            "honeydew": [240, 255, 240],
            "hotpink": [255, 105, 180],
            "indianred": [205, 92, 92],
            "indigo": [75, 0, 130],
            "ivory": [255, 255, 240],
            "khaki": [240, 230, 140],
            "lavender": [230, 230, 250],
            "lavenderblush": [255, 240, 245],
            "lawngreen": [124, 252, 0],
            "lemonchiffon": [255, 250, 205],
            "lightblue": [173, 216, 230],
            "lightcoral": [240, 128, 128],
            "lightcyan": [224, 255, 255],
            "lightgoldenrodyellow": [250, 250, 210],
            "lightgray": [211, 211, 211],
            "lightgreen": [144, 238, 144],
            "lightgrey": [211, 211, 211],
            "lightpink": [255, 182, 193],
            "lightsalmon": [255, 160, 122],
            "lightseagreen": [32, 178, 170],
            "lightskyblue": [135, 206, 250],
            "lightslategray": [119, 136, 153],
            "lightslategrey": [119, 136, 153],
            "lightsteelblue": [176, 196, 222],
            "lightyellow": [255, 255, 224],
            "lime": [0, 255, 0],
            "limegreen": [50, 205, 50],
            "linen": [250, 240, 230],
            "magenta": [255, 0, 255],
            "maroon": [128, 0, 0],
            "mediumaquamarine": [102, 205, 170],
            "mediumblue": [0, 0, 205],
            "mediumorchid": [186, 85, 211],
            "mediumpurple": [147, 112, 219],
            "mediumseagreen": [60, 179, 113],
            "mediumslateblue": [123, 104, 238],
            "mediumspringgreen": [0, 250, 154],
            "mediumturquoise": [72, 209, 204],
            "mediumvioletred": [199, 21, 133],
            "midnightblue": [25, 25, 112],
            "mintcream": [245, 255, 250],
            "mistyrose": [255, 228, 225],
            "moccasin": [255, 228, 181],
            "navajowhite": [255, 222, 173],
            "navy": [0, 0, 128],
            "oldlace": [253, 245, 230],
            "olive": [128, 128, 0],
            "olivedrab": [107, 142, 35],
            "orange": [255, 165, 0],
            "orangered": [255, 69, 0],
            "orchid": [218, 112, 214],
            "palegoldenrod": [238, 232, 170],
            "palegreen": [152, 251, 152],
            "paleturquoise": [175, 238, 238],
            "palevioletred": [219, 112, 147],
            "papayawhip": [255, 239, 213],
            "peachpuff": [255, 218, 185],
            "peru": [205, 133, 63],
            "pink": [255, 192, 203],
            "plum": [221, 160, 221],
            "powderblue": [176, 224, 230],
            "purple": [128, 0, 128],
            "rebeccapurple": [102, 51, 153],
            "red": [255, 0, 0],
            "rosybrown": [188, 143, 143],
            "royalblue": [65, 105, 225],
            "saddlebrown": [139, 69, 19],
            "salmon": [250, 128, 114],
            "sandybrown": [244, 164, 96],
            "seagreen": [46, 139, 87],
            "seashell": [255, 245, 238],
            "sienna": [160, 82, 45],
            "silver": [192, 192, 192],
            "skyblue": [135, 206, 235],
            "slateblue": [106, 90, 205],
            "slategray": [112, 128, 144],
            "slategrey": [112, 128, 144],
            "snow": [255, 250, 250],
            "springgreen": [0, 255, 127],
            "steelblue": [70, 130, 180],
            "tan": [210, 180, 140],
            "teal": [0, 128, 128],
            "thistle": [216, 191, 216],
            "tomato": [255, 99, 71],
            "turquoise": [64, 224, 208],
            "violet": [238, 130, 238],
            "wheat": [245, 222, 179],
            "white": [255, 255, 255],
            "whitesmoke": [245, 245, 245],
            "yellow": [255, 255, 0],
            "yellowgreen": [154, 205, 50]
        };
    }, {}],
    6: [function(require, module, exports) {
        //! moment.js
        //! version : 2.13.0
        //! authors : Tim Wood, Iskren Chernev, Moment.js contributors
        //! license : MIT
        //! momentjs.com

        ;
        (function(global, factory) {
            typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
                typeof define === 'function' && define.amd ? define(factory) :
                global.moment = factory()
        }(this, function() {
            'use strict';

            var hookCallback;

            function utils_hooks__hooks() {
                return hookCallback.apply(null, arguments);
            }

            // This is done to register the method called with moment()
            // without creating circular dependencies.
            function setHookCallback(callback) {
                hookCallback = callback;
            }

            function isArray(input) {
                return input instanceof Array || Object.prototype.toString.call(input) === '[object Array]';
            }

            function isDate(input) {
                return input instanceof Date || Object.prototype.toString.call(input) === '[object Date]';
            }

            function map(arr, fn) {
                var res = [],
                    i;
                for (i = 0; i < arr.length; ++i) {
                    res.push(fn(arr[i], i));
                }
                return res;
            }

            function hasOwnProp(a, b) {
                return Object.prototype.hasOwnProperty.call(a, b);
            }

            function extend(a, b) {
                for (var i in b) {
                    if (hasOwnProp(b, i)) {
                        a[i] = b[i];
                    }
                }

                if (hasOwnProp(b, 'toString')) {
                    a.toString = b.toString;
                }

                if (hasOwnProp(b, 'valueOf')) {
                    a.valueOf = b.valueOf;
                }

                return a;
            }

            function create_utc__createUTC(input, format, locale, strict) {
                return createLocalOrUTC(input, format, locale, strict, true).utc();
            }

            function defaultParsingFlags() {
                // We need to deep clone this object.
                return {
                    empty: false,
                    unusedTokens: [],
                    unusedInput: [],
                    overflow: -2,
                    charsLeftOver: 0,
                    nullInput: false,
                    invalidMonth: null,
                    invalidFormat: false,
                    userInvalidated: false,
                    iso: false,
                    parsedDateParts: [],
                    meridiem: null
                };
            }

            function getParsingFlags(m) {
                if (m._pf == null) {
                    m._pf = defaultParsingFlags();
                }
                return m._pf;
            }

            var some;
            if (Array.prototype.some) {
                some = Array.prototype.some;
            } else {
                some = function(fun) {
                    var t = Object(this);
                    var len = t.length >>> 0;

                    for (var i = 0; i < len; i++) {
                        if (i in t && fun.call(this, t[i], i, t)) {
                            return true;
                        }
                    }

                    return false;
                };
            }

            function valid__isValid(m) {
                if (m._isValid == null) {
                    var flags = getParsingFlags(m);
                    var parsedParts = some.call(flags.parsedDateParts, function(i) {
                        return i != null;
                    });
                    m._isValid = !isNaN(m._d.getTime()) &&
                        flags.overflow < 0 &&
                        !flags.empty &&
                        !flags.invalidMonth &&
                        !flags.invalidWeekday &&
                        !flags.nullInput &&
                        !flags.invalidFormat &&
                        !flags.userInvalidated &&
                        (!flags.meridiem || (flags.meridiem && parsedParts));

                    if (m._strict) {
                        m._isValid = m._isValid &&
                            flags.charsLeftOver === 0 &&
                            flags.unusedTokens.length === 0 &&
                            flags.bigHour === undefined;
                    }
                }
                return m._isValid;
            }

            function valid__createInvalid(flags) {
                var m = create_utc__createUTC(NaN);
                if (flags != null) {
                    extend(getParsingFlags(m), flags);
                } else {
                    getParsingFlags(m).userInvalidated = true;
                }

                return m;
            }

            function isUndefined(input) {
                return input === void 0;
            }

            // Plugins that add properties should also add the key here (null value),
            // so we can properly clone ourselves.
            var momentProperties = utils_hooks__hooks.momentProperties = [];

            function copyConfig(to, from) {
                var i, prop, val;

                if (!isUndefined(from._isAMomentObject)) {
                    to._isAMomentObject = from._isAMomentObject;
                }
                if (!isUndefined(from._i)) {
                    to._i = from._i;
                }
                if (!isUndefined(from._f)) {
                    to._f = from._f;
                }
                if (!isUndefined(from._l)) {
                    to._l = from._l;
                }
                if (!isUndefined(from._strict)) {
                    to._strict = from._strict;
                }
                if (!isUndefined(from._tzm)) {
                    to._tzm = from._tzm;
                }
                if (!isUndefined(from._isUTC)) {
                    to._isUTC = from._isUTC;
                }
                if (!isUndefined(from._offset)) {
                    to._offset = from._offset;
                }
                if (!isUndefined(from._pf)) {
                    to._pf = getParsingFlags(from);
                }
                if (!isUndefined(from._locale)) {
                    to._locale = from._locale;
                }

                if (momentProperties.length > 0) {
                    for (i in momentProperties) {
                        prop = momentProperties[i];
                        val = from[prop];
                        if (!isUndefined(val)) {
                            to[prop] = val;
                        }
                    }
                }

                return to;
            }

            var updateInProgress = false;

            // Moment prototype object
            function Moment(config) {
                copyConfig(this, config);
                this._d = new Date(config._d != null ? config._d.getTime() : NaN);
                // Prevent infinite loop in case updateOffset creates new moment
                // objects.
                if (updateInProgress === false) {
                    updateInProgress = true;
                    utils_hooks__hooks.updateOffset(this);
                    updateInProgress = false;
                }
            }

            function isMoment(obj) {
                return obj instanceof Moment || (obj != null && obj._isAMomentObject != null);
            }

            function absFloor(number) {
                if (number < 0) {
                    return Math.ceil(number);
                } else {
                    return Math.floor(number);
                }
            }

            function toInt(argumentForCoercion) {
                var coercedNumber = +argumentForCoercion,
                    value = 0;

                if (coercedNumber !== 0 && isFinite(coercedNumber)) {
                    value = absFloor(coercedNumber);
                }

                return value;
            }

            // compare two arrays, return the number of differences
            function compareArrays(array1, array2, dontConvert) {
                var len = Math.min(array1.length, array2.length),
                    lengthDiff = Math.abs(array1.length - array2.length),
                    diffs = 0,
                    i;
                for (i = 0; i < len; i++) {
                    if ((dontConvert && array1[i] !== array2[i]) ||
                        (!dontConvert && toInt(array1[i]) !== toInt(array2[i]))) {
                        diffs++;
                    }
                }
                return diffs + lengthDiff;
            }

            function warn(msg) {
                if (utils_hooks__hooks.suppressDeprecationWarnings === false &&
                    (typeof console !== 'undefined') && console.warn) {
                    console.warn('Deprecation warning: ' + msg);
                }
            }

            function deprecate(msg, fn) {
                var firstTime = true;

                return extend(function() {
                    if (utils_hooks__hooks.deprecationHandler != null) {
                        utils_hooks__hooks.deprecationHandler(null, msg);
                    }
                    if (firstTime) {
                        warn(msg + '\nArguments: ' + Array.prototype.slice.call(arguments).join(', ') + '\n' + (new Error()).stack);
                        firstTime = false;
                    }
                    return fn.apply(this, arguments);
                }, fn);
            }

            var deprecations = {};

            function deprecateSimple(name, msg) {
                if (utils_hooks__hooks.deprecationHandler != null) {
                    utils_hooks__hooks.deprecationHandler(name, msg);
                }
                if (!deprecations[name]) {
                    warn(msg);
                    deprecations[name] = true;
                }
            }

            utils_hooks__hooks.suppressDeprecationWarnings = false;
            utils_hooks__hooks.deprecationHandler = null;

            function isFunction(input) {
                return input instanceof Function || Object.prototype.toString.call(input) === '[object Function]';
            }

            function isObject(input) {
                return Object.prototype.toString.call(input) === '[object Object]';
            }

            function locale_set__set(config) {
                var prop, i;
                for (i in config) {
                    prop = config[i];
                    if (isFunction(prop)) {
                        this[i] = prop;
                    } else {
                        this['_' + i] = prop;
                    }
                }
                this._config = config;
                // Lenient ordinal parsing accepts just a number in addition to
                // number + (possibly) stuff coming from _ordinalParseLenient.
                this._ordinalParseLenient = new RegExp(this._ordinalParse.source + '|' + (/\d{1,2}/).source);
            }

            function mergeConfigs(parentConfig, childConfig) {
                var res = extend({}, parentConfig),
                    prop;
                for (prop in childConfig) {
                    if (hasOwnProp(childConfig, prop)) {
                        if (isObject(parentConfig[prop]) && isObject(childConfig[prop])) {
                            res[prop] = {};
                            extend(res[prop], parentConfig[prop]);
                            extend(res[prop], childConfig[prop]);
                        } else if (childConfig[prop] != null) {
                            res[prop] = childConfig[prop];
                        } else {
                            delete res[prop];
                        }
                    }
                }
                return res;
            }

            function Locale(config) {
                if (config != null) {
                    this.set(config);
                }
            }

            var keys;

            if (Object.keys) {
                keys = Object.keys;
            } else {
                keys = function(obj) {
                    var i, res = [];
                    for (i in obj) {
                        if (hasOwnProp(obj, i)) {
                            res.push(i);
                        }
                    }
                    return res;
                };
            }

            // internal storage for locale config files
            var locales = {};
            var globalLocale;

            function normalizeLocale(key) {
                return key ? key.toLowerCase().replace('_', '-') : key;
            }

            // pick the locale from the array
            // try ['en-au', 'en-gb'] as 'en-au', 'en-gb', 'en', as in move through the list trying each
            // substring from most specific to least, but move to the next array item if it's a more specific variant than the current root
            function chooseLocale(names) {
                var i = 0,
                    j, next, locale, split;

                while (i < names.length) {
                    split = normalizeLocale(names[i]).split('-');
                    j = split.length;
                    next = normalizeLocale(names[i + 1]);
                    next = next ? next.split('-') : null;
                    while (j > 0) {
                        locale = loadLocale(split.slice(0, j).join('-'));
                        if (locale) {
                            return locale;
                        }
                        if (next && next.length >= j && compareArrays(split, next, true) >= j - 1) {
                            //the next array item is better than a shallower substring of this one
                            break;
                        }
                        j--;
                    }
                    i++;
                }
                return null;
            }

            function loadLocale(name) {
                var oldLocale = null;
                // TODO: Find a better way to register and load all the locales in Node
                if (!locales[name] && (typeof module !== 'undefined') &&
                    module && module.exports) {
                    try {
                        oldLocale = globalLocale._abbr;
                        require('./locale/' + name);
                        // because defineLocale currently also sets the global locale, we
                        // want to undo that for lazy loaded locales
                        locale_locales__getSetGlobalLocale(oldLocale);
                    } catch (e) {}
                }
                return locales[name];
            }

            // This function will load locale and then set the global locale.  If
            // no arguments are passed in, it will simply return the current global
            // locale key.
            function locale_locales__getSetGlobalLocale(key, values) {
                var data;
                if (key) {
                    if (isUndefined(values)) {
                        data = locale_locales__getLocale(key);
                    } else {
                        data = defineLocale(key, values);
                    }

                    if (data) {
                        // moment.duration._locale = moment._locale = data;
                        globalLocale = data;
                    }
                }

                return globalLocale._abbr;
            }

            function defineLocale(name, config) {
                if (config !== null) {
                    config.abbr = name;
                    if (locales[name] != null) {
                        deprecateSimple('defineLocaleOverride',
                            'use moment.updateLocale(localeName, config) to change ' +
                            'an existing locale. moment.defineLocale(localeName, ' +
                            'config) should only be used for creating a new locale');
                        config = mergeConfigs(locales[name]._config, config);
                    } else if (config.parentLocale != null) {
                        if (locales[config.parentLocale] != null) {
                            config = mergeConfigs(locales[config.parentLocale]._config, config);
                        } else {
                            // treat as if there is no base config
                            deprecateSimple('parentLocaleUndefined',
                                'specified parentLocale is not defined yet');
                        }
                    }
                    locales[name] = new Locale(config);

                    // backwards compat for now: also set the locale
                    locale_locales__getSetGlobalLocale(name);

                    return locales[name];
                } else {
                    // useful for testing
                    delete locales[name];
                    return null;
                }
            }

            function updateLocale(name, config) {
                if (config != null) {
                    var locale;
                    if (locales[name] != null) {
                        config = mergeConfigs(locales[name]._config, config);
                    }
                    locale = new Locale(config);
                    locale.parentLocale = locales[name];
                    locales[name] = locale;

                    // backwards compat for now: also set the locale
                    locale_locales__getSetGlobalLocale(name);
                } else {
                    // pass null for config to unupdate, useful for tests
                    if (locales[name] != null) {
                        if (locales[name].parentLocale != null) {
                            locales[name] = locales[name].parentLocale;
                        } else if (locales[name] != null) {
                            delete locales[name];
                        }
                    }
                }
                return locales[name];
            }

            // returns locale data
            function locale_locales__getLocale(key) {
                var locale;

                if (key && key._locale && key._locale._abbr) {
                    key = key._locale._abbr;
                }

                if (!key) {
                    return globalLocale;
                }

                if (!isArray(key)) {
                    //short-circuit everything else
                    locale = loadLocale(key);
                    if (locale) {
                        return locale;
                    }
                    key = [key];
                }

                return chooseLocale(key);
            }

            function locale_locales__listLocales() {
                return keys(locales);
            }

            var aliases = {};

            function addUnitAlias(unit, shorthand) {
                var lowerCase = unit.toLowerCase();
                aliases[lowerCase] = aliases[lowerCase + 's'] = aliases[shorthand] = unit;
            }

            function normalizeUnits(units) {
                return typeof units === 'string' ? aliases[units] || aliases[units.toLowerCase()] : undefined;
            }

            function normalizeObjectUnits(inputObject) {
                var normalizedInput = {},
                    normalizedProp,
                    prop;

                for (prop in inputObject) {
                    if (hasOwnProp(inputObject, prop)) {
                        normalizedProp = normalizeUnits(prop);
                        if (normalizedProp) {
                            normalizedInput[normalizedProp] = inputObject[prop];
                        }
                    }
                }

                return normalizedInput;
            }

            function makeGetSet(unit, keepTime) {
                return function(value) {
                    if (value != null) {
                        get_set__set(this, unit, value);
                        utils_hooks__hooks.updateOffset(this, keepTime);
                        return this;
                    } else {
                        return get_set__get(this, unit);
                    }
                };
            }

            function get_set__get(mom, unit) {
                return mom.isValid() ?
                    mom._d['get' + (mom._isUTC ? 'UTC' : '') + unit]() : NaN;
            }

            function get_set__set(mom, unit, value) {
                if (mom.isValid()) {
                    mom._d['set' + (mom._isUTC ? 'UTC' : '') + unit](value);
                }
            }

            // MOMENTS

            function getSet(units, value) {
                var unit;
                if (typeof units === 'object') {
                    for (unit in units) {
                        this.set(unit, units[unit]);
                    }
                } else {
                    units = normalizeUnits(units);
                    if (isFunction(this[units])) {
                        return this[units](value);
                    }
                }
                return this;
            }

            function zeroFill(number, targetLength, forceSign) {
                var absNumber = '' + Math.abs(number),
                    zerosToFill = targetLength - absNumber.length,
                    sign = number >= 0;
                return (sign ? (forceSign ? '+' : '') : '-') +
                    Math.pow(10, Math.max(0, zerosToFill)).toString().substr(1) + absNumber;
            }

            var formattingTokens = /(\[[^\[]*\])|(\\)?([Hh]mm(ss)?|Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Qo?|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|kk?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g;

            var localFormattingTokens = /(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g;

            var formatFunctions = {};

            var formatTokenFunctions = {};

            // token:    'M'
            // padded:   ['MM', 2]
            // ordinal:  'Mo'
            // callback: function () { this.month() + 1 }
            function addFormatToken(token, padded, ordinal, callback) {
                var func = callback;
                if (typeof callback === 'string') {
                    func = function() {
                        return this[callback]();
                    };
                }
                if (token) {
                    formatTokenFunctions[token] = func;
                }
                if (padded) {
                    formatTokenFunctions[padded[0]] = function() {
                        return zeroFill(func.apply(this, arguments), padded[1], padded[2]);
                    };
                }
                if (ordinal) {
                    formatTokenFunctions[ordinal] = function() {
                        return this.localeData().ordinal(func.apply(this, arguments), token);
                    };
                }
            }

            function removeFormattingTokens(input) {
                if (input.match(/\[[\s\S]/)) {
                    return input.replace(/^\[|\]$/g, '');
                }
                return input.replace(/\\/g, '');
            }

            function makeFormatFunction(format) {
                var array = format.match(formattingTokens),
                    i, length;

                for (i = 0, length = array.length; i < length; i++) {
                    if (formatTokenFunctions[array[i]]) {
                        array[i] = formatTokenFunctions[array[i]];
                    } else {
                        array[i] = removeFormattingTokens(array[i]);
                    }
                }

                return function(mom) {
                    var output = '',
                        i;
                    for (i = 0; i < length; i++) {
                        output += array[i] instanceof Function ? array[i].call(mom, format) : array[i];
                    }
                    return output;
                };
            }

            // format date using native date object
            function formatMoment(m, format) {
                if (!m.isValid()) {
                    return m.localeData().invalidDate();
                }

                format = expandFormat(format, m.localeData());
                formatFunctions[format] = formatFunctions[format] || makeFormatFunction(format);

                return formatFunctions[format](m);
            }

            function expandFormat(format, locale) {
                var i = 5;

                function replaceLongDateFormatTokens(input) {
                    return locale.longDateFormat(input) || input;
                }

                localFormattingTokens.lastIndex = 0;
                while (i >= 0 && localFormattingTokens.test(format)) {
                    format = format.replace(localFormattingTokens, replaceLongDateFormatTokens);
                    localFormattingTokens.lastIndex = 0;
                    i -= 1;
                }

                return format;
            }

            var match1 = /\d/; //       0 - 9
            var match2 = /\d\d/; //      00 - 99
            var match3 = /\d{3}/; //     000 - 999
            var match4 = /\d{4}/; //    0000 - 9999
            var match6 = /[+-]?\d{6}/; // -999999 - 999999
            var match1to2 = /\d\d?/; //       0 - 99
            var match3to4 = /\d\d\d\d?/; //     999 - 9999
            var match5to6 = /\d\d\d\d\d\d?/; //   99999 - 999999
            var match1to3 = /\d{1,3}/; //       0 - 999
            var match1to4 = /\d{1,4}/; //       0 - 9999
            var match1to6 = /[+-]?\d{1,6}/; // -999999 - 999999

            var matchUnsigned = /\d+/; //       0 - inf
            var matchSigned = /[+-]?\d+/; //    -inf - inf

            var matchOffset = /Z|[+-]\d\d:?\d\d/gi; // +00:00 -00:00 +0000 -0000 or Z
            var matchShortOffset = /Z|[+-]\d\d(?::?\d\d)?/gi; // +00 -00 +00:00 -00:00 +0000 -0000 or Z

            var matchTimestamp = /[+-]?\d+(\.\d{1,3})?/; // 123456789 123456789.123

            // any word (or two) characters or numbers including two/three word month in arabic.
            // includes scottish gaelic two word and hyphenated months
            var matchWord = /[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i;


            var regexes = {};

            function addRegexToken(token, regex, strictRegex) {
                regexes[token] = isFunction(regex) ? regex : function(isStrict, localeData) {
                    return (isStrict && strictRegex) ? strictRegex : regex;
                };
            }

            function getParseRegexForToken(token, config) {
                if (!hasOwnProp(regexes, token)) {
                    return new RegExp(unescapeFormat(token));
                }

                return regexes[token](config._strict, config._locale);
            }

            // Code from http://stackoverflow.com/questions/3561493/is-there-a-regexp-escape-function-in-javascript
            function unescapeFormat(s) {
                return regexEscape(s.replace('\\', '').replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g, function(matched, p1, p2, p3, p4) {
                    return p1 || p2 || p3 || p4;
                }));
            }

            function regexEscape(s) {
                return s.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
            }

            var tokens = {};

            function addParseToken(token, callback) {
                var i, func = callback;
                if (typeof token === 'string') {
                    token = [token];
                }
                if (typeof callback === 'number') {
                    func = function(input, array) {
                        array[callback] = toInt(input);
                    };
                }
                for (i = 0; i < token.length; i++) {
                    tokens[token[i]] = func;
                }
            }

            function addWeekParseToken(token, callback) {
                addParseToken(token, function(input, array, config, token) {
                    config._w = config._w || {};
                    callback(input, config._w, config, token);
                });
            }

            function addTimeToArrayFromToken(token, input, config) {
                if (input != null && hasOwnProp(tokens, token)) {
                    tokens[token](input, config._a, config, token);
                }
            }

            var YEAR = 0;
            var MONTH = 1;
            var DATE = 2;
            var HOUR = 3;
            var MINUTE = 4;
            var SECOND = 5;
            var MILLISECOND = 6;
            var WEEK = 7;
            var WEEKDAY = 8;

            var indexOf;

            if (Array.prototype.indexOf) {
                indexOf = Array.prototype.indexOf;
            } else {
                indexOf = function(o) {
                    // I know
                    var i;
                    for (i = 0; i < this.length; ++i) {
                        if (this[i] === o) {
                            return i;
                        }
                    }
                    return -1;
                };
            }

            function daysInMonth(year, month) {
                return new Date(Date.UTC(year, month + 1, 0)).getUTCDate();
            }

            // FORMATTING

            addFormatToken('M', ['MM', 2], 'Mo', function() {
                return this.month() + 1;
            });

            addFormatToken('MMM', 0, 0, function(format) {
                return this.localeData().monthsShort(this, format);
            });

            addFormatToken('MMMM', 0, 0, function(format) {
                return this.localeData().months(this, format);
            });

            // ALIASES

            addUnitAlias('month', 'M');

            // PARSING

            addRegexToken('M', match1to2);
            addRegexToken('MM', match1to2, match2);
            addRegexToken('MMM', function(isStrict, locale) {
                return locale.monthsShortRegex(isStrict);
            });
            addRegexToken('MMMM', function(isStrict, locale) {
                return locale.monthsRegex(isStrict);
            });

            addParseToken(['M', 'MM'], function(input, array) {
                array[MONTH] = toInt(input) - 1;
            });

            addParseToken(['MMM', 'MMMM'], function(input, array, config, token) {
                var month = config._locale.monthsParse(input, token, config._strict);
                // if we didn't find a month name, mark the date as invalid.
                if (month != null) {
                    array[MONTH] = month;
                } else {
                    getParsingFlags(config).invalidMonth = input;
                }
            });

            // LOCALES

            var MONTHS_IN_FORMAT = /D[oD]?(\[[^\[\]]*\]|\s+)+MMMM?/;
            var defaultLocaleMonths = 'January_February_March_April_May_June_July_August_September_October_November_December'.split('_');

            function localeMonths(m, format) {
                return isArray(this._months) ? this._months[m.month()] :
                    this._months[MONTHS_IN_FORMAT.test(format) ? 'format' : 'standalone'][m.month()];
            }

            var defaultLocaleMonthsShort = 'Jan_Feb_Mar_Apr_May_Jun_Jul_Aug_Sep_Oct_Nov_Dec'.split('_');

            function localeMonthsShort(m, format) {
                return isArray(this._monthsShort) ? this._monthsShort[m.month()] :
                    this._monthsShort[MONTHS_IN_FORMAT.test(format) ? 'format' : 'standalone'][m.month()];
            }

            function units_month__handleStrictParse(monthName, format, strict) {
                var i, ii, mom, llc = monthName.toLocaleLowerCase();
                if (!this._monthsParse) {
                    // this is not used
                    this._monthsParse = [];
                    this._longMonthsParse = [];
                    this._shortMonthsParse = [];
                    for (i = 0; i < 12; ++i) {
                        mom = create_utc__createUTC([2000, i]);
                        this._shortMonthsParse[i] = this.monthsShort(mom, '').toLocaleLowerCase();
                        this._longMonthsParse[i] = this.months(mom, '').toLocaleLowerCase();
                    }
                }

                if (strict) {
                    if (format === 'MMM') {
                        ii = indexOf.call(this._shortMonthsParse, llc);
                        return ii !== -1 ? ii : null;
                    } else {
                        ii = indexOf.call(this._longMonthsParse, llc);
                        return ii !== -1 ? ii : null;
                    }
                } else {
                    if (format === 'MMM') {
                        ii = indexOf.call(this._shortMonthsParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._longMonthsParse, llc);
                        return ii !== -1 ? ii : null;
                    } else {
                        ii = indexOf.call(this._longMonthsParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._shortMonthsParse, llc);
                        return ii !== -1 ? ii : null;
                    }
                }
            }

            function localeMonthsParse(monthName, format, strict) {
                var i, mom, regex;

                if (this._monthsParseExact) {
                    return units_month__handleStrictParse.call(this, monthName, format, strict);
                }

                if (!this._monthsParse) {
                    this._monthsParse = [];
                    this._longMonthsParse = [];
                    this._shortMonthsParse = [];
                }

                // TODO: add sorting
                // Sorting makes sure if one month (or abbr) is a prefix of another
                // see sorting in computeMonthsParse
                for (i = 0; i < 12; i++) {
                    // make the regex if we don't have it already
                    mom = create_utc__createUTC([2000, i]);
                    if (strict && !this._longMonthsParse[i]) {
                        this._longMonthsParse[i] = new RegExp('^' + this.months(mom, '').replace('.', '') + '$', 'i');
                        this._shortMonthsParse[i] = new RegExp('^' + this.monthsShort(mom, '').replace('.', '') + '$', 'i');
                    }
                    if (!strict && !this._monthsParse[i]) {
                        regex = '^' + this.months(mom, '') + '|^' + this.monthsShort(mom, '');
                        this._monthsParse[i] = new RegExp(regex.replace('.', ''), 'i');
                    }
                    // test the regex
                    if (strict && format === 'MMMM' && this._longMonthsParse[i].test(monthName)) {
                        return i;
                    } else if (strict && format === 'MMM' && this._shortMonthsParse[i].test(monthName)) {
                        return i;
                    } else if (!strict && this._monthsParse[i].test(monthName)) {
                        return i;
                    }
                }
            }

            // MOMENTS

            function setMonth(mom, value) {
                var dayOfMonth;

                if (!mom.isValid()) {
                    // No op
                    return mom;
                }

                if (typeof value === 'string') {
                    if (/^\d+$/.test(value)) {
                        value = toInt(value);
                    } else {
                        value = mom.localeData().monthsParse(value);
                        // TODO: Another silent failure?
                        if (typeof value !== 'number') {
                            return mom;
                        }
                    }
                }

                dayOfMonth = Math.min(mom.date(), daysInMonth(mom.year(), value));
                mom._d['set' + (mom._isUTC ? 'UTC' : '') + 'Month'](value, dayOfMonth);
                return mom;
            }

            function getSetMonth(value) {
                if (value != null) {
                    setMonth(this, value);
                    utils_hooks__hooks.updateOffset(this, true);
                    return this;
                } else {
                    return get_set__get(this, 'Month');
                }
            }

            function getDaysInMonth() {
                return daysInMonth(this.year(), this.month());
            }

            var defaultMonthsShortRegex = matchWord;

            function monthsShortRegex(isStrict) {
                if (this._monthsParseExact) {
                    if (!hasOwnProp(this, '_monthsRegex')) {
                        computeMonthsParse.call(this);
                    }
                    if (isStrict) {
                        return this._monthsShortStrictRegex;
                    } else {
                        return this._monthsShortRegex;
                    }
                } else {
                    return this._monthsShortStrictRegex && isStrict ?
                        this._monthsShortStrictRegex : this._monthsShortRegex;
                }
            }

            var defaultMonthsRegex = matchWord;

            function monthsRegex(isStrict) {
                if (this._monthsParseExact) {
                    if (!hasOwnProp(this, '_monthsRegex')) {
                        computeMonthsParse.call(this);
                    }
                    if (isStrict) {
                        return this._monthsStrictRegex;
                    } else {
                        return this._monthsRegex;
                    }
                } else {
                    return this._monthsStrictRegex && isStrict ?
                        this._monthsStrictRegex : this._monthsRegex;
                }
            }

            function computeMonthsParse() {
                function cmpLenRev(a, b) {
                    return b.length - a.length;
                }

                var shortPieces = [],
                    longPieces = [],
                    mixedPieces = [],
                    i, mom;
                for (i = 0; i < 12; i++) {
                    // make the regex if we don't have it already
                    mom = create_utc__createUTC([2000, i]);
                    shortPieces.push(this.monthsShort(mom, ''));
                    longPieces.push(this.months(mom, ''));
                    mixedPieces.push(this.months(mom, ''));
                    mixedPieces.push(this.monthsShort(mom, ''));
                }
                // Sorting makes sure if one month (or abbr) is a prefix of another it
                // will match the longer piece.
                shortPieces.sort(cmpLenRev);
                longPieces.sort(cmpLenRev);
                mixedPieces.sort(cmpLenRev);
                for (i = 0; i < 12; i++) {
                    shortPieces[i] = regexEscape(shortPieces[i]);
                    longPieces[i] = regexEscape(longPieces[i]);
                    mixedPieces[i] = regexEscape(mixedPieces[i]);
                }

                this._monthsRegex = new RegExp('^(' + mixedPieces.join('|') + ')', 'i');
                this._monthsShortRegex = this._monthsRegex;
                this._monthsStrictRegex = new RegExp('^(' + longPieces.join('|') + ')', 'i');
                this._monthsShortStrictRegex = new RegExp('^(' + shortPieces.join('|') + ')', 'i');
            }

            function checkOverflow(m) {
                var overflow;
                var a = m._a;

                if (a && getParsingFlags(m).overflow === -2) {
                    overflow =
                        a[MONTH] < 0 || a[MONTH] > 11 ? MONTH :
                        a[DATE] < 1 || a[DATE] > daysInMonth(a[YEAR], a[MONTH]) ? DATE :
                        a[HOUR] < 0 || a[HOUR] > 24 || (a[HOUR] === 24 && (a[MINUTE] !== 0 || a[SECOND] !== 0 || a[MILLISECOND] !== 0)) ? HOUR :
                        a[MINUTE] < 0 || a[MINUTE] > 59 ? MINUTE :
                        a[SECOND] < 0 || a[SECOND] > 59 ? SECOND :
                        a[MILLISECOND] < 0 || a[MILLISECOND] > 999 ? MILLISECOND :
                        -1;

                    if (getParsingFlags(m)._overflowDayOfYear && (overflow < YEAR || overflow > DATE)) {
                        overflow = DATE;
                    }
                    if (getParsingFlags(m)._overflowWeeks && overflow === -1) {
                        overflow = WEEK;
                    }
                    if (getParsingFlags(m)._overflowWeekday && overflow === -1) {
                        overflow = WEEKDAY;
                    }

                    getParsingFlags(m).overflow = overflow;
                }

                return m;
            }

            // iso 8601 regex
            // 0000-00-00 0000-W00 or 0000-W00-0 + T + 00 or 00:00 or 00:00:00 or 00:00:00.000 + +00:00 or +0000 or +00)
            var extendedIsoRegex = /^\s*((?:[+-]\d{6}|\d{4})-(?:\d\d-\d\d|W\d\d-\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?::\d\d(?::\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/;
            var basicIsoRegex = /^\s*((?:[+-]\d{6}|\d{4})(?:\d\d\d\d|W\d\d\d|W\d\d|\d\d\d|\d\d))(?:(T| )(\d\d(?:\d\d(?:\d\d(?:[.,]\d+)?)?)?)([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?/;

            var tzRegex = /Z|[+-]\d\d(?::?\d\d)?/;

            var isoDates = [
                ['YYYYYY-MM-DD', /[+-]\d{6}-\d\d-\d\d/],
                ['YYYY-MM-DD', /\d{4}-\d\d-\d\d/],
                ['GGGG-[W]WW-E', /\d{4}-W\d\d-\d/],
                ['GGGG-[W]WW', /\d{4}-W\d\d/, false],
                ['YYYY-DDD', /\d{4}-\d{3}/],
                ['YYYY-MM', /\d{4}-\d\d/, false],
                ['YYYYYYMMDD', /[+-]\d{10}/],
                ['YYYYMMDD', /\d{8}/],
                // YYYYMM is NOT allowed by the standard
                ['GGGG[W]WWE', /\d{4}W\d{3}/],
                ['GGGG[W]WW', /\d{4}W\d{2}/, false],
                ['YYYYDDD', /\d{7}/]
            ];

            // iso time formats and regexes
            var isoTimes = [
                ['HH:mm:ss.SSSS', /\d\d:\d\d:\d\d\.\d+/],
                ['HH:mm:ss,SSSS', /\d\d:\d\d:\d\d,\d+/],
                ['HH:mm:ss', /\d\d:\d\d:\d\d/],
                ['HH:mm', /\d\d:\d\d/],
                ['HHmmss.SSSS', /\d\d\d\d\d\d\.\d+/],
                ['HHmmss,SSSS', /\d\d\d\d\d\d,\d+/],
                ['HHmmss', /\d\d\d\d\d\d/],
                ['HHmm', /\d\d\d\d/],
                ['HH', /\d\d/]
            ];

            var aspNetJsonRegex = /^\/?Date\((\-?\d+)/i;

            // date from iso format
            function configFromISO(config) {
                var i, l,
                    string = config._i,
                    match = extendedIsoRegex.exec(string) || basicIsoRegex.exec(string),
                    allowTime, dateFormat, timeFormat, tzFormat;

                if (match) {
                    getParsingFlags(config).iso = true;

                    for (i = 0, l = isoDates.length; i < l; i++) {
                        if (isoDates[i][1].exec(match[1])) {
                            dateFormat = isoDates[i][0];
                            allowTime = isoDates[i][2] !== false;
                            break;
                        }
                    }
                    if (dateFormat == null) {
                        config._isValid = false;
                        return;
                    }
                    if (match[3]) {
                        for (i = 0, l = isoTimes.length; i < l; i++) {
                            if (isoTimes[i][1].exec(match[3])) {
                                // match[2] should be 'T' or space
                                timeFormat = (match[2] || ' ') + isoTimes[i][0];
                                break;
                            }
                        }
                        if (timeFormat == null) {
                            config._isValid = false;
                            return;
                        }
                    }
                    if (!allowTime && timeFormat != null) {
                        config._isValid = false;
                        return;
                    }
                    if (match[4]) {
                        if (tzRegex.exec(match[4])) {
                            tzFormat = 'Z';
                        } else {
                            config._isValid = false;
                            return;
                        }
                    }
                    config._f = dateFormat + (timeFormat || '') + (tzFormat || '');
                    configFromStringAndFormat(config);
                } else {
                    config._isValid = false;
                }
            }

            // date from iso format or fallback
            function configFromString(config) {
                var matched = aspNetJsonRegex.exec(config._i);

                if (matched !== null) {
                    config._d = new Date(+matched[1]);
                    return;
                }

                configFromISO(config);
                if (config._isValid === false) {
                    delete config._isValid;
                    utils_hooks__hooks.createFromInputFallback(config);
                }
            }

            utils_hooks__hooks.createFromInputFallback = deprecate(
                'moment construction falls back to js Date. This is ' +
                'discouraged and will be removed in upcoming major ' +
                'release. Please refer to ' +
                'https://github.com/moment/moment/issues/1407 for more info.',
                function(config) {
                    config._d = new Date(config._i + (config._useUTC ? ' UTC' : ''));
                }
            );

            function createDate(y, m, d, h, M, s, ms) {
                //can't just apply() to create a date:
                //http://stackoverflow.com/questions/181348/instantiating-a-javascript-object-by-calling-prototype-constructor-apply
                var date = new Date(y, m, d, h, M, s, ms);

                //the date constructor remaps years 0-99 to 1900-1999
                if (y < 100 && y >= 0 && isFinite(date.getFullYear())) {
                    date.setFullYear(y);
                }
                return date;
            }

            function createUTCDate(y) {
                var date = new Date(Date.UTC.apply(null, arguments));

                //the Date.UTC function remaps years 0-99 to 1900-1999
                if (y < 100 && y >= 0 && isFinite(date.getUTCFullYear())) {
                    date.setUTCFullYear(y);
                }
                return date;
            }

            // FORMATTING

            addFormatToken('Y', 0, 0, function() {
                var y = this.year();
                return y <= 9999 ? '' + y : '+' + y;
            });

            addFormatToken(0, ['YY', 2], 0, function() {
                return this.year() % 100;
            });

            addFormatToken(0, ['YYYY', 4], 0, 'year');
            addFormatToken(0, ['YYYYY', 5], 0, 'year');
            addFormatToken(0, ['YYYYYY', 6, true], 0, 'year');

            // ALIASES

            addUnitAlias('year', 'y');

            // PARSING

            addRegexToken('Y', matchSigned);
            addRegexToken('YY', match1to2, match2);
            addRegexToken('YYYY', match1to4, match4);
            addRegexToken('YYYYY', match1to6, match6);
            addRegexToken('YYYYYY', match1to6, match6);

            addParseToken(['YYYYY', 'YYYYYY'], YEAR);
            addParseToken('YYYY', function(input, array) {
                array[YEAR] = input.length === 2 ? utils_hooks__hooks.parseTwoDigitYear(input) : toInt(input);
            });
            addParseToken('YY', function(input, array) {
                array[YEAR] = utils_hooks__hooks.parseTwoDigitYear(input);
            });
            addParseToken('Y', function(input, array) {
                array[YEAR] = parseInt(input, 10);
            });

            // HELPERS

            function daysInYear(year) {
                return isLeapYear(year) ? 366 : 365;
            }

            function isLeapYear(year) {
                return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
            }

            // HOOKS

            utils_hooks__hooks.parseTwoDigitYear = function(input) {
                return toInt(input) + (toInt(input) > 68 ? 1900 : 2000);
            };

            // MOMENTS

            var getSetYear = makeGetSet('FullYear', true);

            function getIsLeapYear() {
                return isLeapYear(this.year());
            }

            // start-of-first-week - start-of-year
            function firstWeekOffset(year, dow, doy) {
                var // first-week day -- which january is always in the first week (4 for iso, 1 for other)
                    fwd = 7 + dow - doy,
                    // first-week day local weekday -- which local weekday is fwd
                    fwdlw = (7 + createUTCDate(year, 0, fwd).getUTCDay() - dow) % 7;

                return -fwdlw + fwd - 1;
            }

            //http://en.wikipedia.org/wiki/ISO_week_date#Calculating_a_date_given_the_year.2C_week_number_and_weekday
            function dayOfYearFromWeeks(year, week, weekday, dow, doy) {
                var localWeekday = (7 + weekday - dow) % 7,
                    weekOffset = firstWeekOffset(year, dow, doy),
                    dayOfYear = 1 + 7 * (week - 1) + localWeekday + weekOffset,
                    resYear, resDayOfYear;

                if (dayOfYear <= 0) {
                    resYear = year - 1;
                    resDayOfYear = daysInYear(resYear) + dayOfYear;
                } else if (dayOfYear > daysInYear(year)) {
                    resYear = year + 1;
                    resDayOfYear = dayOfYear - daysInYear(year);
                } else {
                    resYear = year;
                    resDayOfYear = dayOfYear;
                }

                return {
                    year: resYear,
                    dayOfYear: resDayOfYear
                };
            }

            function weekOfYear(mom, dow, doy) {
                var weekOffset = firstWeekOffset(mom.year(), dow, doy),
                    week = Math.floor((mom.dayOfYear() - weekOffset - 1) / 7) + 1,
                    resWeek, resYear;

                if (week < 1) {
                    resYear = mom.year() - 1;
                    resWeek = week + weeksInYear(resYear, dow, doy);
                } else if (week > weeksInYear(mom.year(), dow, doy)) {
                    resWeek = week - weeksInYear(mom.year(), dow, doy);
                    resYear = mom.year() + 1;
                } else {
                    resYear = mom.year();
                    resWeek = week;
                }

                return {
                    week: resWeek,
                    year: resYear
                };
            }

            function weeksInYear(year, dow, doy) {
                var weekOffset = firstWeekOffset(year, dow, doy),
                    weekOffsetNext = firstWeekOffset(year + 1, dow, doy);
                return (daysInYear(year) - weekOffset + weekOffsetNext) / 7;
            }

            // Pick the first defined of two or three arguments.
            function defaults(a, b, c) {
                if (a != null) {
                    return a;
                }
                if (b != null) {
                    return b;
                }
                return c;
            }

            function currentDateArray(config) {
                // hooks is actually the exported moment object
                var nowValue = new Date(utils_hooks__hooks.now());
                if (config._useUTC) {
                    return [nowValue.getUTCFullYear(), nowValue.getUTCMonth(), nowValue.getUTCDate()];
                }
                return [nowValue.getFullYear(), nowValue.getMonth(), nowValue.getDate()];
            }

            // convert an array to a date.
            // the array should mirror the parameters below
            // note: all values past the year are optional and will default to the lowest possible value.
            // [year, month, day , hour, minute, second, millisecond]
            function configFromArray(config) {
                var i, date, input = [],
                    currentDate, yearToUse;

                if (config._d) {
                    return;
                }

                currentDate = currentDateArray(config);

                //compute day of the year from weeks and weekdays
                if (config._w && config._a[DATE] == null && config._a[MONTH] == null) {
                    dayOfYearFromWeekInfo(config);
                }

                //if the day of the year is set, figure out what it is
                if (config._dayOfYear) {
                    yearToUse = defaults(config._a[YEAR], currentDate[YEAR]);

                    if (config._dayOfYear > daysInYear(yearToUse)) {
                        getParsingFlags(config)._overflowDayOfYear = true;
                    }

                    date = createUTCDate(yearToUse, 0, config._dayOfYear);
                    config._a[MONTH] = date.getUTCMonth();
                    config._a[DATE] = date.getUTCDate();
                }

                // Default to current date.
                // * if no year, month, day of month are given, default to today
                // * if day of month is given, default month and year
                // * if month is given, default only year
                // * if year is given, don't default anything
                for (i = 0; i < 3 && config._a[i] == null; ++i) {
                    config._a[i] = input[i] = currentDate[i];
                }

                // Zero out whatever was not defaulted, including time
                for (; i < 7; i++) {
                    config._a[i] = input[i] = (config._a[i] == null) ? (i === 2 ? 1 : 0) : config._a[i];
                }

                // Check for 24:00:00.000
                if (config._a[HOUR] === 24 &&
                    config._a[MINUTE] === 0 &&
                    config._a[SECOND] === 0 &&
                    config._a[MILLISECOND] === 0) {
                    config._nextDay = true;
                    config._a[HOUR] = 0;
                }

                config._d = (config._useUTC ? createUTCDate : createDate).apply(null, input);
                // Apply timezone offset from input. The actual utcOffset can be changed
                // with parseZone.
                if (config._tzm != null) {
                    config._d.setUTCMinutes(config._d.getUTCMinutes() - config._tzm);
                }

                if (config._nextDay) {
                    config._a[HOUR] = 24;
                }
            }

            function dayOfYearFromWeekInfo(config) {
                var w, weekYear, week, weekday, dow, doy, temp, weekdayOverflow;

                w = config._w;
                if (w.GG != null || w.W != null || w.E != null) {
                    dow = 1;
                    doy = 4;

                    // TODO: We need to take the current isoWeekYear, but that depends on
                    // how we interpret now (local, utc, fixed offset). So create
                    // a now version of current config (take local/utc/offset flags, and
                    // create now).
                    weekYear = defaults(w.GG, config._a[YEAR], weekOfYear(local__createLocal(), 1, 4).year);
                    week = defaults(w.W, 1);
                    weekday = defaults(w.E, 1);
                    if (weekday < 1 || weekday > 7) {
                        weekdayOverflow = true;
                    }
                } else {
                    dow = config._locale._week.dow;
                    doy = config._locale._week.doy;

                    weekYear = defaults(w.gg, config._a[YEAR], weekOfYear(local__createLocal(), dow, doy).year);
                    week = defaults(w.w, 1);

                    if (w.d != null) {
                        // weekday -- low day numbers are considered next week
                        weekday = w.d;
                        if (weekday < 0 || weekday > 6) {
                            weekdayOverflow = true;
                        }
                    } else if (w.e != null) {
                        // local weekday -- counting starts from begining of week
                        weekday = w.e + dow;
                        if (w.e < 0 || w.e > 6) {
                            weekdayOverflow = true;
                        }
                    } else {
                        // default to begining of week
                        weekday = dow;
                    }
                }
                if (week < 1 || week > weeksInYear(weekYear, dow, doy)) {
                    getParsingFlags(config)._overflowWeeks = true;
                } else if (weekdayOverflow != null) {
                    getParsingFlags(config)._overflowWeekday = true;
                } else {
                    temp = dayOfYearFromWeeks(weekYear, week, weekday, dow, doy);
                    config._a[YEAR] = temp.year;
                    config._dayOfYear = temp.dayOfYear;
                }
            }

            // constant that refers to the ISO standard
            utils_hooks__hooks.ISO_8601 = function() {};

            // date from string and format string
            function configFromStringAndFormat(config) {
                // TODO: Move this to another part of the creation flow to prevent circular deps
                if (config._f === utils_hooks__hooks.ISO_8601) {
                    configFromISO(config);
                    return;
                }

                config._a = [];
                getParsingFlags(config).empty = true;

                // This array is used to make a Date, either with `new Date` or `Date.UTC`
                var string = '' + config._i,
                    i, parsedInput, tokens, token, skipped,
                    stringLength = string.length,
                    totalParsedInputLength = 0;

                tokens = expandFormat(config._f, config._locale).match(formattingTokens) || [];

                for (i = 0; i < tokens.length; i++) {
                    token = tokens[i];
                    parsedInput = (string.match(getParseRegexForToken(token, config)) || [])[0];
                    // console.log('token', token, 'parsedInput', parsedInput,
                    //         'regex', getParseRegexForToken(token, config));
                    if (parsedInput) {
                        skipped = string.substr(0, string.indexOf(parsedInput));
                        if (skipped.length > 0) {
                            getParsingFlags(config).unusedInput.push(skipped);
                        }
                        string = string.slice(string.indexOf(parsedInput) + parsedInput.length);
                        totalParsedInputLength += parsedInput.length;
                    }
                    // don't parse if it's not a known token
                    if (formatTokenFunctions[token]) {
                        if (parsedInput) {
                            getParsingFlags(config).empty = false;
                        } else {
                            getParsingFlags(config).unusedTokens.push(token);
                        }
                        addTimeToArrayFromToken(token, parsedInput, config);
                    } else if (config._strict && !parsedInput) {
                        getParsingFlags(config).unusedTokens.push(token);
                    }
                }

                // add remaining unparsed input length to the string
                getParsingFlags(config).charsLeftOver = stringLength - totalParsedInputLength;
                if (string.length > 0) {
                    getParsingFlags(config).unusedInput.push(string);
                }

                // clear _12h flag if hour is <= 12
                if (getParsingFlags(config).bigHour === true &&
                    config._a[HOUR] <= 12 &&
                    config._a[HOUR] > 0) {
                    getParsingFlags(config).bigHour = undefined;
                }

                getParsingFlags(config).parsedDateParts = config._a.slice(0);
                getParsingFlags(config).meridiem = config._meridiem;
                // handle meridiem
                config._a[HOUR] = meridiemFixWrap(config._locale, config._a[HOUR], config._meridiem);

                configFromArray(config);
                checkOverflow(config);
            }


            function meridiemFixWrap(locale, hour, meridiem) {
                var isPm;

                if (meridiem == null) {
                    // nothing to do
                    return hour;
                }
                if (locale.meridiemHour != null) {
                    return locale.meridiemHour(hour, meridiem);
                } else if (locale.isPM != null) {
                    // Fallback
                    isPm = locale.isPM(meridiem);
                    if (isPm && hour < 12) {
                        hour += 12;
                    }
                    if (!isPm && hour === 12) {
                        hour = 0;
                    }
                    return hour;
                } else {
                    // this is not supposed to happen
                    return hour;
                }
            }

            // date from string and array of format strings
            function configFromStringAndArray(config) {
                var tempConfig,
                    bestMoment,

                    scoreToBeat,
                    i,
                    currentScore;

                if (config._f.length === 0) {
                    getParsingFlags(config).invalidFormat = true;
                    config._d = new Date(NaN);
                    return;
                }

                for (i = 0; i < config._f.length; i++) {
                    currentScore = 0;
                    tempConfig = copyConfig({}, config);
                    if (config._useUTC != null) {
                        tempConfig._useUTC = config._useUTC;
                    }
                    tempConfig._f = config._f[i];
                    configFromStringAndFormat(tempConfig);

                    if (!valid__isValid(tempConfig)) {
                        continue;
                    }

                    // if there is any input that was not parsed add a penalty for that format
                    currentScore += getParsingFlags(tempConfig).charsLeftOver;

                    //or tokens
                    currentScore += getParsingFlags(tempConfig).unusedTokens.length * 10;

                    getParsingFlags(tempConfig).score = currentScore;

                    if (scoreToBeat == null || currentScore < scoreToBeat) {
                        scoreToBeat = currentScore;
                        bestMoment = tempConfig;
                    }
                }

                extend(config, bestMoment || tempConfig);
            }

            function configFromObject(config) {
                if (config._d) {
                    return;
                }

                var i = normalizeObjectUnits(config._i);
                config._a = map([i.year, i.month, i.day || i.date, i.hour, i.minute, i.second, i.millisecond], function(obj) {
                    return obj && parseInt(obj, 10);
                });

                configFromArray(config);
            }

            function createFromConfig(config) {
                var res = new Moment(checkOverflow(prepareConfig(config)));
                if (res._nextDay) {
                    // Adding is smart enough around DST
                    res.add(1, 'd');
                    res._nextDay = undefined;
                }

                return res;
            }

            function prepareConfig(config) {
                var input = config._i,
                    format = config._f;

                config._locale = config._locale || locale_locales__getLocale(config._l);

                if (input === null || (format === undefined && input === '')) {
                    return valid__createInvalid({
                        nullInput: true
                    });
                }

                if (typeof input === 'string') {
                    config._i = input = config._locale.preparse(input);
                }

                if (isMoment(input)) {
                    return new Moment(checkOverflow(input));
                } else if (isArray(format)) {
                    configFromStringAndArray(config);
                } else if (format) {
                    configFromStringAndFormat(config);
                } else if (isDate(input)) {
                    config._d = input;
                } else {
                    configFromInput(config);
                }

                if (!valid__isValid(config)) {
                    config._d = null;
                }

                return config;
            }

            function configFromInput(config) {
                var input = config._i;
                if (input === undefined) {
                    config._d = new Date(utils_hooks__hooks.now());
                } else if (isDate(input)) {
                    config._d = new Date(input.valueOf());
                } else if (typeof input === 'string') {
                    configFromString(config);
                } else if (isArray(input)) {
                    config._a = map(input.slice(0), function(obj) {
                        return parseInt(obj, 10);
                    });
                    configFromArray(config);
                } else if (typeof(input) === 'object') {
                    configFromObject(config);
                } else if (typeof(input) === 'number') {
                    // from milliseconds
                    config._d = new Date(input);
                } else {
                    utils_hooks__hooks.createFromInputFallback(config);
                }
            }

            function createLocalOrUTC(input, format, locale, strict, isUTC) {
                var c = {};

                if (typeof(locale) === 'boolean') {
                    strict = locale;
                    locale = undefined;
                }
                // object construction must be done this way.
                // https://github.com/moment/moment/issues/1423
                c._isAMomentObject = true;
                c._useUTC = c._isUTC = isUTC;
                c._l = locale;
                c._i = input;
                c._f = format;
                c._strict = strict;

                return createFromConfig(c);
            }

            function local__createLocal(input, format, locale, strict) {
                return createLocalOrUTC(input, format, locale, strict, false);
            }

            var prototypeMin = deprecate(
                'moment().min is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548',
                function() {
                    var other = local__createLocal.apply(null, arguments);
                    if (this.isValid() && other.isValid()) {
                        return other < this ? this : other;
                    } else {
                        return valid__createInvalid();
                    }
                }
            );

            var prototypeMax = deprecate(
                'moment().max is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548',
                function() {
                    var other = local__createLocal.apply(null, arguments);
                    if (this.isValid() && other.isValid()) {
                        return other > this ? this : other;
                    } else {
                        return valid__createInvalid();
                    }
                }
            );

            // Pick a moment m from moments so that m[fn](other) is true for all
            // other. This relies on the function fn to be transitive.
            //
            // moments should either be an array of moment objects or an array, whose
            // first element is an array of moment objects.
            function pickBy(fn, moments) {
                var res, i;
                if (moments.length === 1 && isArray(moments[0])) {
                    moments = moments[0];
                }
                if (!moments.length) {
                    return local__createLocal();
                }
                res = moments[0];
                for (i = 1; i < moments.length; ++i) {
                    if (!moments[i].isValid() || moments[i][fn](res)) {
                        res = moments[i];
                    }
                }
                return res;
            }

            // TODO: Use [].sort instead?
            function min() {
                var args = [].slice.call(arguments, 0);

                return pickBy('isBefore', args);
            }

            function max() {
                var args = [].slice.call(arguments, 0);

                return pickBy('isAfter', args);
            }

            var now = function() {
                return Date.now ? Date.now() : +(new Date());
            };

            function Duration(duration) {
                var normalizedInput = normalizeObjectUnits(duration),
                    years = normalizedInput.year || 0,
                    quarters = normalizedInput.quarter || 0,
                    months = normalizedInput.month || 0,
                    weeks = normalizedInput.week || 0,
                    days = normalizedInput.day || 0,
                    hours = normalizedInput.hour || 0,
                    minutes = normalizedInput.minute || 0,
                    seconds = normalizedInput.second || 0,
                    milliseconds = normalizedInput.millisecond || 0;

                // representation for dateAddRemove
                this._milliseconds = +milliseconds +
                    seconds * 1e3 + // 1000
                    minutes * 6e4 + // 1000 * 60
                    hours * 1000 * 60 * 60; //using 1000 * 60 * 60 instead of 36e5 to avoid floating point rounding errors https://github.com/moment/moment/issues/2978
                // Because of dateAddRemove treats 24 hours as different from a
                // day when working around DST, we need to store them separately
                this._days = +days +
                    weeks * 7;
                // It is impossible translate months into days without knowing
                // which months you are are talking about, so we have to store
                // it separately.
                this._months = +months +
                    quarters * 3 +
                    years * 12;

                this._data = {};

                this._locale = locale_locales__getLocale();

                this._bubble();
            }

            function isDuration(obj) {
                return obj instanceof Duration;
            }

            // FORMATTING

            function offset(token, separator) {
                addFormatToken(token, 0, 0, function() {
                    var offset = this.utcOffset();
                    var sign = '+';
                    if (offset < 0) {
                        offset = -offset;
                        sign = '-';
                    }
                    return sign + zeroFill(~~(offset / 60), 2) + separator + zeroFill(~~(offset) % 60, 2);
                });
            }

            offset('Z', ':');
            offset('ZZ', '');

            // PARSING

            addRegexToken('Z', matchShortOffset);
            addRegexToken('ZZ', matchShortOffset);
            addParseToken(['Z', 'ZZ'], function(input, array, config) {
                config._useUTC = true;
                config._tzm = offsetFromString(matchShortOffset, input);
            });

            // HELPERS

            // timezone chunker
            // '+10:00' > ['10',  '00']
            // '-1530'  > ['-15', '30']
            var chunkOffset = /([\+\-]|\d\d)/gi;

            function offsetFromString(matcher, string) {
                var matches = ((string || '').match(matcher) || []);
                var chunk = matches[matches.length - 1] || [];
                var parts = (chunk + '').match(chunkOffset) || ['-', 0, 0];
                var minutes = +(parts[1] * 60) + toInt(parts[2]);

                return parts[0] === '+' ? minutes : -minutes;
            }

            // Return a moment from input, that is local/utc/zone equivalent to model.
            function cloneWithOffset(input, model) {
                var res, diff;
                if (model._isUTC) {
                    res = model.clone();
                    diff = (isMoment(input) || isDate(input) ? input.valueOf() : local__createLocal(input).valueOf()) - res.valueOf();
                    // Use low-level api, because this fn is low-level api.
                    res._d.setTime(res._d.valueOf() + diff);
                    utils_hooks__hooks.updateOffset(res, false);
                    return res;
                } else {
                    return local__createLocal(input).local();
                }
            }

            function getDateOffset(m) {
                // On Firefox.24 Date#getTimezoneOffset returns a floating point.
                // https://github.com/moment/moment/pull/1871
                return -Math.round(m._d.getTimezoneOffset() / 15) * 15;
            }

            // HOOKS

            // This function will be called whenever a moment is mutated.
            // It is intended to keep the offset in sync with the timezone.
            utils_hooks__hooks.updateOffset = function() {};

            // MOMENTS

            // keepLocalTime = true means only change the timezone, without
            // affecting the local hour. So 5:31:26 +0300 --[utcOffset(2, true)]-->
            // 5:31:26 +0200 It is possible that 5:31:26 doesn't exist with offset
            // +0200, so we adjust the time as needed, to be valid.
            //
            // Keeping the time actually adds/subtracts (one hour)
            // from the actual represented time. That is why we call updateOffset
            // a second time. In case it wants us to change the offset again
            // _changeInProgress == true case, then we have to adjust, because
            // there is no such time in the given timezone.
            function getSetOffset(input, keepLocalTime) {
                var offset = this._offset || 0,
                    localAdjust;
                if (!this.isValid()) {
                    return input != null ? this : NaN;
                }
                if (input != null) {
                    if (typeof input === 'string') {
                        input = offsetFromString(matchShortOffset, input);
                    } else if (Math.abs(input) < 16) {
                        input = input * 60;
                    }
                    if (!this._isUTC && keepLocalTime) {
                        localAdjust = getDateOffset(this);
                    }
                    this._offset = input;
                    this._isUTC = true;
                    if (localAdjust != null) {
                        this.add(localAdjust, 'm');
                    }
                    if (offset !== input) {
                        if (!keepLocalTime || this._changeInProgress) {
                            add_subtract__addSubtract(this, create__createDuration(input - offset, 'm'), 1, false);
                        } else if (!this._changeInProgress) {
                            this._changeInProgress = true;
                            utils_hooks__hooks.updateOffset(this, true);
                            this._changeInProgress = null;
                        }
                    }
                    return this;
                } else {
                    return this._isUTC ? offset : getDateOffset(this);
                }
            }

            function getSetZone(input, keepLocalTime) {
                if (input != null) {
                    if (typeof input !== 'string') {
                        input = -input;
                    }

                    this.utcOffset(input, keepLocalTime);

                    return this;
                } else {
                    return -this.utcOffset();
                }
            }

            function setOffsetToUTC(keepLocalTime) {
                return this.utcOffset(0, keepLocalTime);
            }

            function setOffsetToLocal(keepLocalTime) {
                if (this._isUTC) {
                    this.utcOffset(0, keepLocalTime);
                    this._isUTC = false;

                    if (keepLocalTime) {
                        this.subtract(getDateOffset(this), 'm');
                    }
                }
                return this;
            }

            function setOffsetToParsedOffset() {
                if (this._tzm) {
                    this.utcOffset(this._tzm);
                } else if (typeof this._i === 'string') {
                    this.utcOffset(offsetFromString(matchOffset, this._i));
                }
                return this;
            }

            function hasAlignedHourOffset(input) {
                if (!this.isValid()) {
                    return false;
                }
                input = input ? local__createLocal(input).utcOffset() : 0;

                return (this.utcOffset() - input) % 60 === 0;
            }

            function isDaylightSavingTime() {
                return (
                    this.utcOffset() > this.clone().month(0).utcOffset() ||
                    this.utcOffset() > this.clone().month(5).utcOffset()
                );
            }

            function isDaylightSavingTimeShifted() {
                if (!isUndefined(this._isDSTShifted)) {
                    return this._isDSTShifted;
                }

                var c = {};

                copyConfig(c, this);
                c = prepareConfig(c);

                if (c._a) {
                    var other = c._isUTC ? create_utc__createUTC(c._a) : local__createLocal(c._a);
                    this._isDSTShifted = this.isValid() &&
                        compareArrays(c._a, other.toArray()) > 0;
                } else {
                    this._isDSTShifted = false;
                }

                return this._isDSTShifted;
            }

            function isLocal() {
                return this.isValid() ? !this._isUTC : false;
            }

            function isUtcOffset() {
                return this.isValid() ? this._isUTC : false;
            }

            function isUtc() {
                return this.isValid() ? this._isUTC && this._offset === 0 : false;
            }

            // ASP.NET json date format regex
            var aspNetRegex = /^(\-)?(?:(\d*)[. ])?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?\d*)?$/;

            // from http://docs.closure-library.googlecode.com/git/closure_goog_date_date.js.source.html
            // somewhat more in line with 4.4.3.2 2004 spec, but allows decimal anywhere
            // and further modified to allow for strings containing both week and day
            var isoRegex = /^(-)?P(?:(-?[0-9,.]*)Y)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)W)?(?:(-?[0-9,.]*)D)?(?:T(?:(-?[0-9,.]*)H)?(?:(-?[0-9,.]*)M)?(?:(-?[0-9,.]*)S)?)?$/;

            function create__createDuration(input, key) {
                var duration = input,
                    // matching against regexp is expensive, do it on demand
                    match = null,
                    sign,
                    ret,
                    diffRes;

                if (isDuration(input)) {
                    duration = {
                        ms: input._milliseconds,
                        d: input._days,
                        M: input._months
                    };
                } else if (typeof input === 'number') {
                    duration = {};
                    if (key) {
                        duration[key] = input;
                    } else {
                        duration.milliseconds = input;
                    }
                } else if (!!(match = aspNetRegex.exec(input))) {
                    sign = (match[1] === '-') ? -1 : 1;
                    duration = {
                        y: 0,
                        d: toInt(match[DATE]) * sign,
                        h: toInt(match[HOUR]) * sign,
                        m: toInt(match[MINUTE]) * sign,
                        s: toInt(match[SECOND]) * sign,
                        ms: toInt(match[MILLISECOND]) * sign
                    };
                } else if (!!(match = isoRegex.exec(input))) {
                    sign = (match[1] === '-') ? -1 : 1;
                    duration = {
                        y: parseIso(match[2], sign),
                        M: parseIso(match[3], sign),
                        w: parseIso(match[4], sign),
                        d: parseIso(match[5], sign),
                        h: parseIso(match[6], sign),
                        m: parseIso(match[7], sign),
                        s: parseIso(match[8], sign)
                    };
                } else if (duration == null) { // checks for null or undefined
                    duration = {};
                } else if (typeof duration === 'object' && ('from' in duration || 'to' in duration)) {
                    diffRes = momentsDifference(local__createLocal(duration.from), local__createLocal(duration.to));

                    duration = {};
                    duration.ms = diffRes.milliseconds;
                    duration.M = diffRes.months;
                }

                ret = new Duration(duration);

                if (isDuration(input) && hasOwnProp(input, '_locale')) {
                    ret._locale = input._locale;
                }

                return ret;
            }

            create__createDuration.fn = Duration.prototype;

            function parseIso(inp, sign) {
                // We'd normally use ~~inp for this, but unfortunately it also
                // converts floats to ints.
                // inp may be undefined, so careful calling replace on it.
                var res = inp && parseFloat(inp.replace(',', '.'));
                // apply sign while we're at it
                return (isNaN(res) ? 0 : res) * sign;
            }

            function positiveMomentsDifference(base, other) {
                var res = {
                    milliseconds: 0,
                    months: 0
                };

                res.months = other.month() - base.month() +
                    (other.year() - base.year()) * 12;
                if (base.clone().add(res.months, 'M').isAfter(other)) {
                    --res.months;
                }

                res.milliseconds = +other - +(base.clone().add(res.months, 'M'));

                return res;
            }

            function momentsDifference(base, other) {
                var res;
                if (!(base.isValid() && other.isValid())) {
                    return {
                        milliseconds: 0,
                        months: 0
                    };
                }

                other = cloneWithOffset(other, base);
                if (base.isBefore(other)) {
                    res = positiveMomentsDifference(base, other);
                } else {
                    res = positiveMomentsDifference(other, base);
                    res.milliseconds = -res.milliseconds;
                    res.months = -res.months;
                }

                return res;
            }

            function absRound(number) {
                if (number < 0) {
                    return Math.round(-1 * number) * -1;
                } else {
                    return Math.round(number);
                }
            }

            // TODO: remove 'name' arg after deprecation is removed
            function createAdder(direction, name) {
                return function(val, period) {
                    var dur, tmp;
                    //invert the arguments, but complain about it
                    if (period !== null && !isNaN(+period)) {
                        deprecateSimple(name, 'moment().' + name + '(period, number) is deprecated. Please use moment().' + name + '(number, period).');
                        tmp = val;
                        val = period;
                        period = tmp;
                    }

                    val = typeof val === 'string' ? +val : val;
                    dur = create__createDuration(val, period);
                    add_subtract__addSubtract(this, dur, direction);
                    return this;
                };
            }

            function add_subtract__addSubtract(mom, duration, isAdding, updateOffset) {
                var milliseconds = duration._milliseconds,
                    days = absRound(duration._days),
                    months = absRound(duration._months);

                if (!mom.isValid()) {
                    // No op
                    return;
                }

                updateOffset = updateOffset == null ? true : updateOffset;

                if (milliseconds) {
                    mom._d.setTime(mom._d.valueOf() + milliseconds * isAdding);
                }
                if (days) {
                    get_set__set(mom, 'Date', get_set__get(mom, 'Date') + days * isAdding);
                }
                if (months) {
                    setMonth(mom, get_set__get(mom, 'Month') + months * isAdding);
                }
                if (updateOffset) {
                    utils_hooks__hooks.updateOffset(mom, days || months);
                }
            }

            var add_subtract__add = createAdder(1, 'add');
            var add_subtract__subtract = createAdder(-1, 'subtract');

            function moment_calendar__calendar(time, formats) {
                // We want to compare the start of today, vs this.
                // Getting start-of-today depends on whether we're local/utc/offset or not.
                var now = time || local__createLocal(),
                    sod = cloneWithOffset(now, this).startOf('day'),
                    diff = this.diff(sod, 'days', true),
                    format = diff < -6 ? 'sameElse' :
                    diff < -1 ? 'lastWeek' :
                    diff < 0 ? 'lastDay' :
                    diff < 1 ? 'sameDay' :
                    diff < 2 ? 'nextDay' :
                    diff < 7 ? 'nextWeek' : 'sameElse';

                var output = formats && (isFunction(formats[format]) ? formats[format]() : formats[format]);

                return this.format(output || this.localeData().calendar(format, this, local__createLocal(now)));
            }

            function clone() {
                return new Moment(this);
            }

            function isAfter(input, units) {
                var localInput = isMoment(input) ? input : local__createLocal(input);
                if (!(this.isValid() && localInput.isValid())) {
                    return false;
                }
                units = normalizeUnits(!isUndefined(units) ? units : 'millisecond');
                if (units === 'millisecond') {
                    return this.valueOf() > localInput.valueOf();
                } else {
                    return localInput.valueOf() < this.clone().startOf(units).valueOf();
                }
            }

            function isBefore(input, units) {
                var localInput = isMoment(input) ? input : local__createLocal(input);
                if (!(this.isValid() && localInput.isValid())) {
                    return false;
                }
                units = normalizeUnits(!isUndefined(units) ? units : 'millisecond');
                if (units === 'millisecond') {
                    return this.valueOf() < localInput.valueOf();
                } else {
                    return this.clone().endOf(units).valueOf() < localInput.valueOf();
                }
            }

            function isBetween(from, to, units, inclusivity) {
                inclusivity = inclusivity || '()';
                return (inclusivity[0] === '(' ? this.isAfter(from, units) : !this.isBefore(from, units)) &&
                    (inclusivity[1] === ')' ? this.isBefore(to, units) : !this.isAfter(to, units));
            }

            function isSame(input, units) {
                var localInput = isMoment(input) ? input : local__createLocal(input),
                    inputMs;
                if (!(this.isValid() && localInput.isValid())) {
                    return false;
                }
                units = normalizeUnits(units || 'millisecond');
                if (units === 'millisecond') {
                    return this.valueOf() === localInput.valueOf();
                } else {
                    inputMs = localInput.valueOf();
                    return this.clone().startOf(units).valueOf() <= inputMs && inputMs <= this.clone().endOf(units).valueOf();
                }
            }

            function isSameOrAfter(input, units) {
                return this.isSame(input, units) || this.isAfter(input, units);
            }

            function isSameOrBefore(input, units) {
                return this.isSame(input, units) || this.isBefore(input, units);
            }

            function diff(input, units, asFloat) {
                var that,
                    zoneDelta,
                    delta, output;

                if (!this.isValid()) {
                    return NaN;
                }

                that = cloneWithOffset(input, this);

                if (!that.isValid()) {
                    return NaN;
                }

                zoneDelta = (that.utcOffset() - this.utcOffset()) * 6e4;

                units = normalizeUnits(units);

                if (units === 'year' || units === 'month' || units === 'quarter') {
                    output = monthDiff(this, that);
                    if (units === 'quarter') {
                        output = output / 3;
                    } else if (units === 'year') {
                        output = output / 12;
                    }
                } else {
                    delta = this - that;
                    output = units === 'second' ? delta / 1e3 : // 1000
                        units === 'minute' ? delta / 6e4 : // 1000 * 60
                        units === 'hour' ? delta / 36e5 : // 1000 * 60 * 60
                        units === 'day' ? (delta - zoneDelta) / 864e5 : // 1000 * 60 * 60 * 24, negate dst
                        units === 'week' ? (delta - zoneDelta) / 6048e5 : // 1000 * 60 * 60 * 24 * 7, negate dst
                        delta;
                }
                return asFloat ? output : absFloor(output);
            }

            function monthDiff(a, b) {
                // difference in months
                var wholeMonthDiff = ((b.year() - a.year()) * 12) + (b.month() - a.month()),
                    // b is in (anchor - 1 month, anchor + 1 month)
                    anchor = a.clone().add(wholeMonthDiff, 'months'),
                    anchor2, adjust;

                if (b - anchor < 0) {
                    anchor2 = a.clone().add(wholeMonthDiff - 1, 'months');
                    // linear across the month
                    adjust = (b - anchor) / (anchor - anchor2);
                } else {
                    anchor2 = a.clone().add(wholeMonthDiff + 1, 'months');
                    // linear across the month
                    adjust = (b - anchor) / (anchor2 - anchor);
                }

                //check for negative zero, return zero if negative zero
                return -(wholeMonthDiff + adjust) || 0;
            }

            utils_hooks__hooks.defaultFormat = 'YYYY-MM-DDTHH:mm:ssZ';
            utils_hooks__hooks.defaultFormatUtc = 'YYYY-MM-DDTHH:mm:ss[Z]';

            function toString() {
                return this.clone().locale('en').format('ddd MMM DD YYYY HH:mm:ss [GMT]ZZ');
            }

            function moment_format__toISOString() {
                var m = this.clone().utc();
                if (0 < m.year() && m.year() <= 9999) {
                    if (isFunction(Date.prototype.toISOString)) {
                        // native implementation is ~50x faster, use it when we can
                        return this.toDate().toISOString();
                    } else {
                        return formatMoment(m, 'YYYY-MM-DD[T]HH:mm:ss.SSS[Z]');
                    }
                } else {
                    return formatMoment(m, 'YYYYYY-MM-DD[T]HH:mm:ss.SSS[Z]');
                }
            }

            function format(inputString) {
                if (!inputString) {
                    inputString = this.isUtc() ? utils_hooks__hooks.defaultFormatUtc : utils_hooks__hooks.defaultFormat;
                }
                var output = formatMoment(this, inputString);
                return this.localeData().postformat(output);
            }

            function from(time, withoutSuffix) {
                if (this.isValid() &&
                    ((isMoment(time) && time.isValid()) ||
                        local__createLocal(time).isValid())) {
                    return create__createDuration({
                        to: this,
                        from: time
                    }).locale(this.locale()).humanize(!withoutSuffix);
                } else {
                    return this.localeData().invalidDate();
                }
            }

            function fromNow(withoutSuffix) {
                return this.from(local__createLocal(), withoutSuffix);
            }

            function to(time, withoutSuffix) {
                if (this.isValid() &&
                    ((isMoment(time) && time.isValid()) ||
                        local__createLocal(time).isValid())) {
                    return create__createDuration({
                        from: this,
                        to: time
                    }).locale(this.locale()).humanize(!withoutSuffix);
                } else {
                    return this.localeData().invalidDate();
                }
            }

            function toNow(withoutSuffix) {
                return this.to(local__createLocal(), withoutSuffix);
            }

            // If passed a locale key, it will set the locale for this
            // instance.  Otherwise, it will return the locale configuration
            // variables for this instance.
            function locale(key) {
                var newLocaleData;

                if (key === undefined) {
                    return this._locale._abbr;
                } else {
                    newLocaleData = locale_locales__getLocale(key);
                    if (newLocaleData != null) {
                        this._locale = newLocaleData;
                    }
                    return this;
                }
            }

            var lang = deprecate(
                'moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.',
                function(key) {
                    if (key === undefined) {
                        return this.localeData();
                    } else {
                        return this.locale(key);
                    }
                }
            );

            function localeData() {
                return this._locale;
            }

            function startOf(units) {
                units = normalizeUnits(units);
                // the following switch intentionally omits break keywords
                // to utilize falling through the cases.
                switch (units) {
                    case 'year':
                        this.month(0);
                        /* falls through */
                    case 'quarter':
                    case 'month':
                        this.date(1);
                        /* falls through */
                    case 'week':
                    case 'isoWeek':
                    case 'day':
                    case 'date':
                        this.hours(0);
                        /* falls through */
                    case 'hour':
                        this.minutes(0);
                        /* falls through */
                    case 'minute':
                        this.seconds(0);
                        /* falls through */
                    case 'second':
                        this.milliseconds(0);
                }

                // weeks are a special case
                if (units === 'week') {
                    this.weekday(0);
                }
                if (units === 'isoWeek') {
                    this.isoWeekday(1);
                }

                // quarters are also special
                if (units === 'quarter') {
                    this.month(Math.floor(this.month() / 3) * 3);
                }

                return this;
            }

            function endOf(units) {
                units = normalizeUnits(units);
                if (units === undefined || units === 'millisecond') {
                    return this;
                }

                // 'date' is an alias for 'day', so it should be considered as such.
                if (units === 'date') {
                    units = 'day';
                }

                return this.startOf(units).add(1, (units === 'isoWeek' ? 'week' : units)).subtract(1, 'ms');
            }

            function to_type__valueOf() {
                return this._d.valueOf() - ((this._offset || 0) * 60000);
            }

            function unix() {
                return Math.floor(this.valueOf() / 1000);
            }

            function toDate() {
                return this._offset ? new Date(this.valueOf()) : this._d;
            }

            function toArray() {
                var m = this;
                return [m.year(), m.month(), m.date(), m.hour(), m.minute(), m.second(), m.millisecond()];
            }

            function toObject() {
                var m = this;
                return {
                    years: m.year(),
                    months: m.month(),
                    date: m.date(),
                    hours: m.hours(),
                    minutes: m.minutes(),
                    seconds: m.seconds(),
                    milliseconds: m.milliseconds()
                };
            }

            function toJSON() {
                // new Date(NaN).toJSON() === null
                return this.isValid() ? this.toISOString() : null;
            }

            function moment_valid__isValid() {
                return valid__isValid(this);
            }

            function parsingFlags() {
                return extend({}, getParsingFlags(this));
            }

            function invalidAt() {
                return getParsingFlags(this).overflow;
            }

            function creationData() {
                return {
                    input: this._i,
                    format: this._f,
                    locale: this._locale,
                    isUTC: this._isUTC,
                    strict: this._strict
                };
            }

            // FORMATTING

            addFormatToken(0, ['gg', 2], 0, function() {
                return this.weekYear() % 100;
            });

            addFormatToken(0, ['GG', 2], 0, function() {
                return this.isoWeekYear() % 100;
            });

            function addWeekYearFormatToken(token, getter) {
                addFormatToken(0, [token, token.length], 0, getter);
            }

            addWeekYearFormatToken('gggg', 'weekYear');
            addWeekYearFormatToken('ggggg', 'weekYear');
            addWeekYearFormatToken('GGGG', 'isoWeekYear');
            addWeekYearFormatToken('GGGGG', 'isoWeekYear');

            // ALIASES

            addUnitAlias('weekYear', 'gg');
            addUnitAlias('isoWeekYear', 'GG');

            // PARSING

            addRegexToken('G', matchSigned);
            addRegexToken('g', matchSigned);
            addRegexToken('GG', match1to2, match2);
            addRegexToken('gg', match1to2, match2);
            addRegexToken('GGGG', match1to4, match4);
            addRegexToken('gggg', match1to4, match4);
            addRegexToken('GGGGG', match1to6, match6);
            addRegexToken('ggggg', match1to6, match6);

            addWeekParseToken(['gggg', 'ggggg', 'GGGG', 'GGGGG'], function(input, week, config, token) {
                week[token.substr(0, 2)] = toInt(input);
            });

            addWeekParseToken(['gg', 'GG'], function(input, week, config, token) {
                week[token] = utils_hooks__hooks.parseTwoDigitYear(input);
            });

            // MOMENTS

            function getSetWeekYear(input) {
                return getSetWeekYearHelper.call(this,
                    input,
                    this.week(),
                    this.weekday(),
                    this.localeData()._week.dow,
                    this.localeData()._week.doy);
            }

            function getSetISOWeekYear(input) {
                return getSetWeekYearHelper.call(this,
                    input, this.isoWeek(), this.isoWeekday(), 1, 4);
            }

            function getISOWeeksInYear() {
                return weeksInYear(this.year(), 1, 4);
            }

            function getWeeksInYear() {
                var weekInfo = this.localeData()._week;
                return weeksInYear(this.year(), weekInfo.dow, weekInfo.doy);
            }

            function getSetWeekYearHelper(input, week, weekday, dow, doy) {
                var weeksTarget;
                if (input == null) {
                    return weekOfYear(this, dow, doy).year;
                } else {
                    weeksTarget = weeksInYear(input, dow, doy);
                    if (week > weeksTarget) {
                        week = weeksTarget;
                    }
                    return setWeekAll.call(this, input, week, weekday, dow, doy);
                }
            }

            function setWeekAll(weekYear, week, weekday, dow, doy) {
                var dayOfYearData = dayOfYearFromWeeks(weekYear, week, weekday, dow, doy),
                    date = createUTCDate(dayOfYearData.year, 0, dayOfYearData.dayOfYear);

                this.year(date.getUTCFullYear());
                this.month(date.getUTCMonth());
                this.date(date.getUTCDate());
                return this;
            }

            // FORMATTING

            addFormatToken('Q', 0, 'Qo', 'quarter');

            // ALIASES

            addUnitAlias('quarter', 'Q');

            // PARSING

            addRegexToken('Q', match1);
            addParseToken('Q', function(input, array) {
                array[MONTH] = (toInt(input) - 1) * 3;
            });

            // MOMENTS

            function getSetQuarter(input) {
                return input == null ? Math.ceil((this.month() + 1) / 3) : this.month((input - 1) * 3 + this.month() % 3);
            }

            // FORMATTING

            addFormatToken('w', ['ww', 2], 'wo', 'week');
            addFormatToken('W', ['WW', 2], 'Wo', 'isoWeek');

            // ALIASES

            addUnitAlias('week', 'w');
            addUnitAlias('isoWeek', 'W');

            // PARSING

            addRegexToken('w', match1to2);
            addRegexToken('ww', match1to2, match2);
            addRegexToken('W', match1to2);
            addRegexToken('WW', match1to2, match2);

            addWeekParseToken(['w', 'ww', 'W', 'WW'], function(input, week, config, token) {
                week[token.substr(0, 1)] = toInt(input);
            });

            // HELPERS

            // LOCALES

            function localeWeek(mom) {
                return weekOfYear(mom, this._week.dow, this._week.doy).week;
            }

            var defaultLocaleWeek = {
                dow: 0, // Sunday is the first day of the week.
                doy: 6 // The week that contains Jan 1st is the first week of the year.
            };

            function localeFirstDayOfWeek() {
                return this._week.dow;
            }

            function localeFirstDayOfYear() {
                return this._week.doy;
            }

            // MOMENTS

            function getSetWeek(input) {
                var week = this.localeData().week(this);
                return input == null ? week : this.add((input - week) * 7, 'd');
            }

            function getSetISOWeek(input) {
                var week = weekOfYear(this, 1, 4).week;
                return input == null ? week : this.add((input - week) * 7, 'd');
            }

            // FORMATTING

            addFormatToken('D', ['DD', 2], 'Do', 'date');

            // ALIASES

            addUnitAlias('date', 'D');

            // PARSING

            addRegexToken('D', match1to2);
            addRegexToken('DD', match1to2, match2);
            addRegexToken('Do', function(isStrict, locale) {
                return isStrict ? locale._ordinalParse : locale._ordinalParseLenient;
            });

            addParseToken(['D', 'DD'], DATE);
            addParseToken('Do', function(input, array) {
                array[DATE] = toInt(input.match(match1to2)[0], 10);
            });

            // MOMENTS

            var getSetDayOfMonth = makeGetSet('Date', true);

            // FORMATTING

            addFormatToken('d', 0, 'do', 'day');

            addFormatToken('dd', 0, 0, function(format) {
                return this.localeData().weekdaysMin(this, format);
            });

            addFormatToken('ddd', 0, 0, function(format) {
                return this.localeData().weekdaysShort(this, format);
            });

            addFormatToken('dddd', 0, 0, function(format) {
                return this.localeData().weekdays(this, format);
            });

            addFormatToken('e', 0, 0, 'weekday');
            addFormatToken('E', 0, 0, 'isoWeekday');

            // ALIASES

            addUnitAlias('day', 'd');
            addUnitAlias('weekday', 'e');
            addUnitAlias('isoWeekday', 'E');

            // PARSING

            addRegexToken('d', match1to2);
            addRegexToken('e', match1to2);
            addRegexToken('E', match1to2);
            addRegexToken('dd', function(isStrict, locale) {
                return locale.weekdaysMinRegex(isStrict);
            });
            addRegexToken('ddd', function(isStrict, locale) {
                return locale.weekdaysShortRegex(isStrict);
            });
            addRegexToken('dddd', function(isStrict, locale) {
                return locale.weekdaysRegex(isStrict);
            });

            addWeekParseToken(['dd', 'ddd', 'dddd'], function(input, week, config, token) {
                var weekday = config._locale.weekdaysParse(input, token, config._strict);
                // if we didn't get a weekday name, mark the date as invalid
                if (weekday != null) {
                    week.d = weekday;
                } else {
                    getParsingFlags(config).invalidWeekday = input;
                }
            });

            addWeekParseToken(['d', 'e', 'E'], function(input, week, config, token) {
                week[token] = toInt(input);
            });

            // HELPERS

            function parseWeekday(input, locale) {
                if (typeof input !== 'string') {
                    return input;
                }

                if (!isNaN(input)) {
                    return parseInt(input, 10);
                }

                input = locale.weekdaysParse(input);
                if (typeof input === 'number') {
                    return input;
                }

                return null;
            }

            // LOCALES

            var defaultLocaleWeekdays = 'Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday'.split('_');

            function localeWeekdays(m, format) {
                return isArray(this._weekdays) ? this._weekdays[m.day()] :
                    this._weekdays[this._weekdays.isFormat.test(format) ? 'format' : 'standalone'][m.day()];
            }

            var defaultLocaleWeekdaysShort = 'Sun_Mon_Tue_Wed_Thu_Fri_Sat'.split('_');

            function localeWeekdaysShort(m) {
                return this._weekdaysShort[m.day()];
            }

            var defaultLocaleWeekdaysMin = 'Su_Mo_Tu_We_Th_Fr_Sa'.split('_');

            function localeWeekdaysMin(m) {
                return this._weekdaysMin[m.day()];
            }

            function day_of_week__handleStrictParse(weekdayName, format, strict) {
                var i, ii, mom, llc = weekdayName.toLocaleLowerCase();
                if (!this._weekdaysParse) {
                    this._weekdaysParse = [];
                    this._shortWeekdaysParse = [];
                    this._minWeekdaysParse = [];

                    for (i = 0; i < 7; ++i) {
                        mom = create_utc__createUTC([2000, 1]).day(i);
                        this._minWeekdaysParse[i] = this.weekdaysMin(mom, '').toLocaleLowerCase();
                        this._shortWeekdaysParse[i] = this.weekdaysShort(mom, '').toLocaleLowerCase();
                        this._weekdaysParse[i] = this.weekdays(mom, '').toLocaleLowerCase();
                    }
                }

                if (strict) {
                    if (format === 'dddd') {
                        ii = indexOf.call(this._weekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    } else if (format === 'ddd') {
                        ii = indexOf.call(this._shortWeekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    } else {
                        ii = indexOf.call(this._minWeekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    }
                } else {
                    if (format === 'dddd') {
                        ii = indexOf.call(this._weekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._shortWeekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._minWeekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    } else if (format === 'ddd') {
                        ii = indexOf.call(this._shortWeekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._weekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._minWeekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    } else {
                        ii = indexOf.call(this._minWeekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._weekdaysParse, llc);
                        if (ii !== -1) {
                            return ii;
                        }
                        ii = indexOf.call(this._shortWeekdaysParse, llc);
                        return ii !== -1 ? ii : null;
                    }
                }
            }

            function localeWeekdaysParse(weekdayName, format, strict) {
                var i, mom, regex;

                if (this._weekdaysParseExact) {
                    return day_of_week__handleStrictParse.call(this, weekdayName, format, strict);
                }

                if (!this._weekdaysParse) {
                    this._weekdaysParse = [];
                    this._minWeekdaysParse = [];
                    this._shortWeekdaysParse = [];
                    this._fullWeekdaysParse = [];
                }

                for (i = 0; i < 7; i++) {
                    // make the regex if we don't have it already

                    mom = create_utc__createUTC([2000, 1]).day(i);
                    if (strict && !this._fullWeekdaysParse[i]) {
                        this._fullWeekdaysParse[i] = new RegExp('^' + this.weekdays(mom, '').replace('.', '\.?') + '$', 'i');
                        this._shortWeekdaysParse[i] = new RegExp('^' + this.weekdaysShort(mom, '').replace('.', '\.?') + '$', 'i');
                        this._minWeekdaysParse[i] = new RegExp('^' + this.weekdaysMin(mom, '').replace('.', '\.?') + '$', 'i');
                    }
                    if (!this._weekdaysParse[i]) {
                        regex = '^' + this.weekdays(mom, '') + '|^' + this.weekdaysShort(mom, '') + '|^' + this.weekdaysMin(mom, '');
                        this._weekdaysParse[i] = new RegExp(regex.replace('.', ''), 'i');
                    }
                    // test the regex
                    if (strict && format === 'dddd' && this._fullWeekdaysParse[i].test(weekdayName)) {
                        return i;
                    } else if (strict && format === 'ddd' && this._shortWeekdaysParse[i].test(weekdayName)) {
                        return i;
                    } else if (strict && format === 'dd' && this._minWeekdaysParse[i].test(weekdayName)) {
                        return i;
                    } else if (!strict && this._weekdaysParse[i].test(weekdayName)) {
                        return i;
                    }
                }
            }

            // MOMENTS

            function getSetDayOfWeek(input) {
                if (!this.isValid()) {
                    return input != null ? this : NaN;
                }
                var day = this._isUTC ? this._d.getUTCDay() : this._d.getDay();
                if (input != null) {
                    input = parseWeekday(input, this.localeData());
                    return this.add(input - day, 'd');
                } else {
                    return day;
                }
            }

            function getSetLocaleDayOfWeek(input) {
                if (!this.isValid()) {
                    return input != null ? this : NaN;
                }
                var weekday = (this.day() + 7 - this.localeData()._week.dow) % 7;
                return input == null ? weekday : this.add(input - weekday, 'd');
            }

            function getSetISODayOfWeek(input) {
                if (!this.isValid()) {
                    return input != null ? this : NaN;
                }
                // behaves the same as moment#day except
                // as a getter, returns 7 instead of 0 (1-7 range instead of 0-6)
                // as a setter, sunday should belong to the previous week.
                return input == null ? this.day() || 7 : this.day(this.day() % 7 ? input : input - 7);
            }

            var defaultWeekdaysRegex = matchWord;

            function weekdaysRegex(isStrict) {
                if (this._weekdaysParseExact) {
                    if (!hasOwnProp(this, '_weekdaysRegex')) {
                        computeWeekdaysParse.call(this);
                    }
                    if (isStrict) {
                        return this._weekdaysStrictRegex;
                    } else {
                        return this._weekdaysRegex;
                    }
                } else {
                    return this._weekdaysStrictRegex && isStrict ?
                        this._weekdaysStrictRegex : this._weekdaysRegex;
                }
            }

            var defaultWeekdaysShortRegex = matchWord;

            function weekdaysShortRegex(isStrict) {
                if (this._weekdaysParseExact) {
                    if (!hasOwnProp(this, '_weekdaysRegex')) {
                        computeWeekdaysParse.call(this);
                    }
                    if (isStrict) {
                        return this._weekdaysShortStrictRegex;
                    } else {
                        return this._weekdaysShortRegex;
                    }
                } else {
                    return this._weekdaysShortStrictRegex && isStrict ?
                        this._weekdaysShortStrictRegex : this._weekdaysShortRegex;
                }
            }

            var defaultWeekdaysMinRegex = matchWord;

            function weekdaysMinRegex(isStrict) {
                if (this._weekdaysParseExact) {
                    if (!hasOwnProp(this, '_weekdaysRegex')) {
                        computeWeekdaysParse.call(this);
                    }
                    if (isStrict) {
                        return this._weekdaysMinStrictRegex;
                    } else {
                        return this._weekdaysMinRegex;
                    }
                } else {
                    return this._weekdaysMinStrictRegex && isStrict ?
                        this._weekdaysMinStrictRegex : this._weekdaysMinRegex;
                }
            }


            function computeWeekdaysParse() {
                function cmpLenRev(a, b) {
                    return b.length - a.length;
                }

                var minPieces = [],
                    shortPieces = [],
                    longPieces = [],
                    mixedPieces = [],
                    i, mom, minp, shortp, longp;
                for (i = 0; i < 7; i++) {
                    // make the regex if we don't have it already
                    mom = create_utc__createUTC([2000, 1]).day(i);
                    minp = this.weekdaysMin(mom, '');
                    shortp = this.weekdaysShort(mom, '');
                    longp = this.weekdays(mom, '');
                    minPieces.push(minp);
                    shortPieces.push(shortp);
                    longPieces.push(longp);
                    mixedPieces.push(minp);
                    mixedPieces.push(shortp);
                    mixedPieces.push(longp);
                }
                // Sorting makes sure if one weekday (or abbr) is a prefix of another it
                // will match the longer piece.
                minPieces.sort(cmpLenRev);
                shortPieces.sort(cmpLenRev);
                longPieces.sort(cmpLenRev);
                mixedPieces.sort(cmpLenRev);
                for (i = 0; i < 7; i++) {
                    shortPieces[i] = regexEscape(shortPieces[i]);
                    longPieces[i] = regexEscape(longPieces[i]);
                    mixedPieces[i] = regexEscape(mixedPieces[i]);
                }

                this._weekdaysRegex = new RegExp('^(' + mixedPieces.join('|') + ')', 'i');
                this._weekdaysShortRegex = this._weekdaysRegex;
                this._weekdaysMinRegex = this._weekdaysRegex;

                this._weekdaysStrictRegex = new RegExp('^(' + longPieces.join('|') + ')', 'i');
                this._weekdaysShortStrictRegex = new RegExp('^(' + shortPieces.join('|') + ')', 'i');
                this._weekdaysMinStrictRegex = new RegExp('^(' + minPieces.join('|') + ')', 'i');
            }

            // FORMATTING

            addFormatToken('DDD', ['DDDD', 3], 'DDDo', 'dayOfYear');

            // ALIASES

            addUnitAlias('dayOfYear', 'DDD');

            // PARSING

            addRegexToken('DDD', match1to3);
            addRegexToken('DDDD', match3);
            addParseToken(['DDD', 'DDDD'], function(input, array, config) {
                config._dayOfYear = toInt(input);
            });

            // HELPERS

            // MOMENTS

            function getSetDayOfYear(input) {
                var dayOfYear = Math.round((this.clone().startOf('day') - this.clone().startOf('year')) / 864e5) + 1;
                return input == null ? dayOfYear : this.add((input - dayOfYear), 'd');
            }

            // FORMATTING

            function hFormat() {
                return this.hours() % 12 || 12;
            }

            function kFormat() {
                return this.hours() || 24;
            }

            addFormatToken('H', ['HH', 2], 0, 'hour');
            addFormatToken('h', ['hh', 2], 0, hFormat);
            addFormatToken('k', ['kk', 2], 0, kFormat);

            addFormatToken('hmm', 0, 0, function() {
                return '' + hFormat.apply(this) + zeroFill(this.minutes(), 2);
            });

            addFormatToken('hmmss', 0, 0, function() {
                return '' + hFormat.apply(this) + zeroFill(this.minutes(), 2) +
                    zeroFill(this.seconds(), 2);
            });

            addFormatToken('Hmm', 0, 0, function() {
                return '' + this.hours() + zeroFill(this.minutes(), 2);
            });

            addFormatToken('Hmmss', 0, 0, function() {
                return '' + this.hours() + zeroFill(this.minutes(), 2) +
                    zeroFill(this.seconds(), 2);
            });

            function meridiem(token, lowercase) {
                addFormatToken(token, 0, 0, function() {
                    return this.localeData().meridiem(this.hours(), this.minutes(), lowercase);
                });
            }

            meridiem('a', true);
            meridiem('A', false);

            // ALIASES

            addUnitAlias('hour', 'h');

            // PARSING

            function matchMeridiem(isStrict, locale) {
                return locale._meridiemParse;
            }

            addRegexToken('a', matchMeridiem);
            addRegexToken('A', matchMeridiem);
            addRegexToken('H', match1to2);
            addRegexToken('h', match1to2);
            addRegexToken('HH', match1to2, match2);
            addRegexToken('hh', match1to2, match2);

            addRegexToken('hmm', match3to4);
            addRegexToken('hmmss', match5to6);
            addRegexToken('Hmm', match3to4);
            addRegexToken('Hmmss', match5to6);

            addParseToken(['H', 'HH'], HOUR);
            addParseToken(['a', 'A'], function(input, array, config) {
                config._isPm = config._locale.isPM(input);
                config._meridiem = input;
            });
            addParseToken(['h', 'hh'], function(input, array, config) {
                array[HOUR] = toInt(input);
                getParsingFlags(config).bigHour = true;
            });
            addParseToken('hmm', function(input, array, config) {
                var pos = input.length - 2;
                array[HOUR] = toInt(input.substr(0, pos));
                array[MINUTE] = toInt(input.substr(pos));
                getParsingFlags(config).bigHour = true;
            });
            addParseToken('hmmss', function(input, array, config) {
                var pos1 = input.length - 4;
                var pos2 = input.length - 2;
                array[HOUR] = toInt(input.substr(0, pos1));
                array[MINUTE] = toInt(input.substr(pos1, 2));
                array[SECOND] = toInt(input.substr(pos2));
                getParsingFlags(config).bigHour = true;
            });
            addParseToken('Hmm', function(input, array, config) {
                var pos = input.length - 2;
                array[HOUR] = toInt(input.substr(0, pos));
                array[MINUTE] = toInt(input.substr(pos));
            });
            addParseToken('Hmmss', function(input, array, config) {
                var pos1 = input.length - 4;
                var pos2 = input.length - 2;
                array[HOUR] = toInt(input.substr(0, pos1));
                array[MINUTE] = toInt(input.substr(pos1, 2));
                array[SECOND] = toInt(input.substr(pos2));
            });

            // LOCALES

            function localeIsPM(input) {
                // IE8 Quirks Mode & IE7 Standards Mode do not allow accessing strings like arrays
                // Using charAt should be more compatible.
                return ((input + '').toLowerCase().charAt(0) === 'p');
            }

            var defaultLocaleMeridiemParse = /[ap]\.?m?\.?/i;

            function localeMeridiem(hours, minutes, isLower) {
                if (hours > 11) {
                    return isLower ? 'pm' : 'PM';
                } else {
                    return isLower ? 'am' : 'AM';
                }
            }


            // MOMENTS

            // Setting the hour should keep the time, because the user explicitly
            // specified which hour he wants. So trying to maintain the same hour (in
            // a new timezone) makes sense. Adding/subtracting hours does not follow
            // this rule.
            var getSetHour = makeGetSet('Hours', true);

            // FORMATTING

            addFormatToken('m', ['mm', 2], 0, 'minute');

            // ALIASES

            addUnitAlias('minute', 'm');

            // PARSING

            addRegexToken('m', match1to2);
            addRegexToken('mm', match1to2, match2);
            addParseToken(['m', 'mm'], MINUTE);

            // MOMENTS

            var getSetMinute = makeGetSet('Minutes', false);

            // FORMATTING

            addFormatToken('s', ['ss', 2], 0, 'second');

            // ALIASES

            addUnitAlias('second', 's');

            // PARSING

            addRegexToken('s', match1to2);
            addRegexToken('ss', match1to2, match2);
            addParseToken(['s', 'ss'], SECOND);

            // MOMENTS

            var getSetSecond = makeGetSet('Seconds', false);

            // FORMATTING

            addFormatToken('S', 0, 0, function() {
                return ~~(this.millisecond() / 100);
            });

            addFormatToken(0, ['SS', 2], 0, function() {
                return ~~(this.millisecond() / 10);
            });

            addFormatToken(0, ['SSS', 3], 0, 'millisecond');
            addFormatToken(0, ['SSSS', 4], 0, function() {
                return this.millisecond() * 10;
            });
            addFormatToken(0, ['SSSSS', 5], 0, function() {
                return this.millisecond() * 100;
            });
            addFormatToken(0, ['SSSSSS', 6], 0, function() {
                return this.millisecond() * 1000;
            });
            addFormatToken(0, ['SSSSSSS', 7], 0, function() {
                return this.millisecond() * 10000;
            });
            addFormatToken(0, ['SSSSSSSS', 8], 0, function() {
                return this.millisecond() * 100000;
            });
            addFormatToken(0, ['SSSSSSSSS', 9], 0, function() {
                return this.millisecond() * 1000000;
            });


            // ALIASES

            addUnitAlias('millisecond', 'ms');

            // PARSING

            addRegexToken('S', match1to3, match1);
            addRegexToken('SS', match1to3, match2);
            addRegexToken('SSS', match1to3, match3);

            var token;
            for (token = 'SSSS'; token.length <= 9; token += 'S') {
                addRegexToken(token, matchUnsigned);
            }

            function parseMs(input, array) {
                array[MILLISECOND] = toInt(('0.' + input) * 1000);
            }

            for (token = 'S'; token.length <= 9; token += 'S') {
                addParseToken(token, parseMs);
            }
            // MOMENTS

            var getSetMillisecond = makeGetSet('Milliseconds', false);

            // FORMATTING

            addFormatToken('z', 0, 0, 'zoneAbbr');
            addFormatToken('zz', 0, 0, 'zoneName');

            // MOMENTS

            function getZoneAbbr() {
                return this._isUTC ? 'UTC' : '';
            }

            function getZoneName() {
                return this._isUTC ? 'Coordinated Universal Time' : '';
            }

            var momentPrototype__proto = Moment.prototype;

            momentPrototype__proto.add = add_subtract__add;
            momentPrototype__proto.calendar = moment_calendar__calendar;
            momentPrototype__proto.clone = clone;
            momentPrototype__proto.diff = diff;
            momentPrototype__proto.endOf = endOf;
            momentPrototype__proto.format = format;
            momentPrototype__proto.from = from;
            momentPrototype__proto.fromNow = fromNow;
            momentPrototype__proto.to = to;
            momentPrototype__proto.toNow = toNow;
            momentPrototype__proto.get = getSet;
            momentPrototype__proto.invalidAt = invalidAt;
            momentPrototype__proto.isAfter = isAfter;
            momentPrototype__proto.isBefore = isBefore;
            momentPrototype__proto.isBetween = isBetween;
            momentPrototype__proto.isSame = isSame;
            momentPrototype__proto.isSameOrAfter = isSameOrAfter;
            momentPrototype__proto.isSameOrBefore = isSameOrBefore;
            momentPrototype__proto.isValid = moment_valid__isValid;
            momentPrototype__proto.lang = lang;
            momentPrototype__proto.locale = locale;
            momentPrototype__proto.localeData = localeData;
            momentPrototype__proto.max = prototypeMax;
            momentPrototype__proto.min = prototypeMin;
            momentPrototype__proto.parsingFlags = parsingFlags;
            momentPrototype__proto.set = getSet;
            momentPrototype__proto.startOf = startOf;
            momentPrototype__proto.subtract = add_subtract__subtract;
            momentPrototype__proto.toArray = toArray;
            momentPrototype__proto.toObject = toObject;
            momentPrototype__proto.toDate = toDate;
            momentPrototype__proto.toISOString = moment_format__toISOString;
            momentPrototype__proto.toJSON = toJSON;
            momentPrototype__proto.toString = toString;
            momentPrototype__proto.unix = unix;
            momentPrototype__proto.valueOf = to_type__valueOf;
            momentPrototype__proto.creationData = creationData;

            // Year
            momentPrototype__proto.year = getSetYear;
            momentPrototype__proto.isLeapYear = getIsLeapYear;

            // Week Year
            momentPrototype__proto.weekYear = getSetWeekYear;
            momentPrototype__proto.isoWeekYear = getSetISOWeekYear;

            // Quarter
            momentPrototype__proto.quarter = momentPrototype__proto.quarters = getSetQuarter;

            // Month
            momentPrototype__proto.month = getSetMonth;
            momentPrototype__proto.daysInMonth = getDaysInMonth;

            // Week
            momentPrototype__proto.week = momentPrototype__proto.weeks = getSetWeek;
            momentPrototype__proto.isoWeek = momentPrototype__proto.isoWeeks = getSetISOWeek;
            momentPrototype__proto.weeksInYear = getWeeksInYear;
            momentPrototype__proto.isoWeeksInYear = getISOWeeksInYear;

            // Day
            momentPrototype__proto.date = getSetDayOfMonth;
            momentPrototype__proto.day = momentPrototype__proto.days = getSetDayOfWeek;
            momentPrototype__proto.weekday = getSetLocaleDayOfWeek;
            momentPrototype__proto.isoWeekday = getSetISODayOfWeek;
            momentPrototype__proto.dayOfYear = getSetDayOfYear;

            // Hour
            momentPrototype__proto.hour = momentPrototype__proto.hours = getSetHour;

            // Minute
            momentPrototype__proto.minute = momentPrototype__proto.minutes = getSetMinute;

            // Second
            momentPrototype__proto.second = momentPrototype__proto.seconds = getSetSecond;

            // Millisecond
            momentPrototype__proto.millisecond = momentPrototype__proto.milliseconds = getSetMillisecond;

            // Offset
            momentPrototype__proto.utcOffset = getSetOffset;
            momentPrototype__proto.utc = setOffsetToUTC;
            momentPrototype__proto.local = setOffsetToLocal;
            momentPrototype__proto.parseZone = setOffsetToParsedOffset;
            momentPrototype__proto.hasAlignedHourOffset = hasAlignedHourOffset;
            momentPrototype__proto.isDST = isDaylightSavingTime;
            momentPrototype__proto.isDSTShifted = isDaylightSavingTimeShifted;
            momentPrototype__proto.isLocal = isLocal;
            momentPrototype__proto.isUtcOffset = isUtcOffset;
            momentPrototype__proto.isUtc = isUtc;
            momentPrototype__proto.isUTC = isUtc;

            // Timezone
            momentPrototype__proto.zoneAbbr = getZoneAbbr;
            momentPrototype__proto.zoneName = getZoneName;

            // Deprecations
            momentPrototype__proto.dates = deprecate('dates accessor is deprecated. Use date instead.', getSetDayOfMonth);
            momentPrototype__proto.months = deprecate('months accessor is deprecated. Use month instead', getSetMonth);
            momentPrototype__proto.years = deprecate('years accessor is deprecated. Use year instead', getSetYear);
            momentPrototype__proto.zone = deprecate('moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779', getSetZone);

            var momentPrototype = momentPrototype__proto;

            function moment__createUnix(input) {
                return local__createLocal(input * 1000);
            }

            function moment__createInZone() {
                return local__createLocal.apply(null, arguments).parseZone();
            }

            var defaultCalendar = {
                sameDay: '[Today at] LT',
                nextDay: '[Tomorrow at] LT',
                nextWeek: 'dddd [at] LT',
                lastDay: '[Yesterday at] LT',
                lastWeek: '[Last] dddd [at] LT',
                sameElse: 'L'
            };

            function locale_calendar__calendar(key, mom, now) {
                var output = this._calendar[key];
                return isFunction(output) ? output.call(mom, now) : output;
            }

            var defaultLongDateFormat = {
                LTS: 'h:mm:ss A',
                LT: 'h:mm A',
                L: 'MM/DD/YYYY',
                LL: 'MMMM D, YYYY',
                LLL: 'MMMM D, YYYY h:mm A',
                LLLL: 'dddd, MMMM D, YYYY h:mm A'
            };

            function longDateFormat(key) {
                var format = this._longDateFormat[key],
                    formatUpper = this._longDateFormat[key.toUpperCase()];

                if (format || !formatUpper) {
                    return format;
                }

                this._longDateFormat[key] = formatUpper.replace(/MMMM|MM|DD|dddd/g, function(val) {
                    return val.slice(1);
                });

                return this._longDateFormat[key];
            }

            var defaultInvalidDate = 'Invalid date';

            function invalidDate() {
                return this._invalidDate;
            }

            var defaultOrdinal = '%d';
            var defaultOrdinalParse = /\d{1,2}/;

            function ordinal(number) {
                return this._ordinal.replace('%d', number);
            }

            function preParsePostFormat(string) {
                return string;
            }

            var defaultRelativeTime = {
                future: 'in %s',
                past: '%s ago',
                s: 'a few seconds',
                m: 'a minute',
                mm: '%d minutes',
                h: 'an hour',
                hh: '%d hours',
                d: 'a day',
                dd: '%d days',
                M: 'a month',
                MM: '%d months',
                y: 'a year',
                yy: '%d years'
            };

            function relative__relativeTime(number, withoutSuffix, string, isFuture) {
                var output = this._relativeTime[string];
                return (isFunction(output)) ?
                    output(number, withoutSuffix, string, isFuture) :
                    output.replace(/%d/i, number);
            }

            function pastFuture(diff, output) {
                var format = this._relativeTime[diff > 0 ? 'future' : 'past'];
                return isFunction(format) ? format(output) : format.replace(/%s/i, output);
            }

            var prototype__proto = Locale.prototype;

            prototype__proto._calendar = defaultCalendar;
            prototype__proto.calendar = locale_calendar__calendar;
            prototype__proto._longDateFormat = defaultLongDateFormat;
            prototype__proto.longDateFormat = longDateFormat;
            prototype__proto._invalidDate = defaultInvalidDate;
            prototype__proto.invalidDate = invalidDate;
            prototype__proto._ordinal = defaultOrdinal;
            prototype__proto.ordinal = ordinal;
            prototype__proto._ordinalParse = defaultOrdinalParse;
            prototype__proto.preparse = preParsePostFormat;
            prototype__proto.postformat = preParsePostFormat;
            prototype__proto._relativeTime = defaultRelativeTime;
            prototype__proto.relativeTime = relative__relativeTime;
            prototype__proto.pastFuture = pastFuture;
            prototype__proto.set = locale_set__set;

            // Month
            prototype__proto.months = localeMonths;
            prototype__proto._months = defaultLocaleMonths;
            prototype__proto.monthsShort = localeMonthsShort;
            prototype__proto._monthsShort = defaultLocaleMonthsShort;
            prototype__proto.monthsParse = localeMonthsParse;
            prototype__proto._monthsRegex = defaultMonthsRegex;
            prototype__proto.monthsRegex = monthsRegex;
            prototype__proto._monthsShortRegex = defaultMonthsShortRegex;
            prototype__proto.monthsShortRegex = monthsShortRegex;

            // Week
            prototype__proto.week = localeWeek;
            prototype__proto._week = defaultLocaleWeek;
            prototype__proto.firstDayOfYear = localeFirstDayOfYear;
            prototype__proto.firstDayOfWeek = localeFirstDayOfWeek;

            // Day of Week
            prototype__proto.weekdays = localeWeekdays;
            prototype__proto._weekdays = defaultLocaleWeekdays;
            prototype__proto.weekdaysMin = localeWeekdaysMin;
            prototype__proto._weekdaysMin = defaultLocaleWeekdaysMin;
            prototype__proto.weekdaysShort = localeWeekdaysShort;
            prototype__proto._weekdaysShort = defaultLocaleWeekdaysShort;
            prototype__proto.weekdaysParse = localeWeekdaysParse;

            prototype__proto._weekdaysRegex = defaultWeekdaysRegex;
            prototype__proto.weekdaysRegex = weekdaysRegex;
            prototype__proto._weekdaysShortRegex = defaultWeekdaysShortRegex;
            prototype__proto.weekdaysShortRegex = weekdaysShortRegex;
            prototype__proto._weekdaysMinRegex = defaultWeekdaysMinRegex;
            prototype__proto.weekdaysMinRegex = weekdaysMinRegex;

            // Hours
            prototype__proto.isPM = localeIsPM;
            prototype__proto._meridiemParse = defaultLocaleMeridiemParse;
            prototype__proto.meridiem = localeMeridiem;

            function lists__get(format, index, field, setter) {
                var locale = locale_locales__getLocale();
                var utc = create_utc__createUTC().set(setter, index);
                return locale[field](utc, format);
            }

            function listMonthsImpl(format, index, field) {
                if (typeof format === 'number') {
                    index = format;
                    format = undefined;
                }

                format = format || '';

                if (index != null) {
                    return lists__get(format, index, field, 'month');
                }

                var i;
                var out = [];
                for (i = 0; i < 12; i++) {
                    out[i] = lists__get(format, i, field, 'month');
                }
                return out;
            }

            // ()
            // (5)
            // (fmt, 5)
            // (fmt)
            // (true)
            // (true, 5)
            // (true, fmt, 5)
            // (true, fmt)
            function listWeekdaysImpl(localeSorted, format, index, field) {
                if (typeof localeSorted === 'boolean') {
                    if (typeof format === 'number') {
                        index = format;
                        format = undefined;
                    }

                    format = format || '';
                } else {
                    format = localeSorted;
                    index = format;
                    localeSorted = false;

                    if (typeof format === 'number') {
                        index = format;
                        format = undefined;
                    }

                    format = format || '';
                }

                var locale = locale_locales__getLocale(),
                    shift = localeSorted ? locale._week.dow : 0;

                if (index != null) {
                    return lists__get(format, (index + shift) % 7, field, 'day');
                }

                var i;
                var out = [];
                for (i = 0; i < 7; i++) {
                    out[i] = lists__get(format, (i + shift) % 7, field, 'day');
                }
                return out;
            }

            function lists__listMonths(format, index) {
                return listMonthsImpl(format, index, 'months');
            }

            function lists__listMonthsShort(format, index) {
                return listMonthsImpl(format, index, 'monthsShort');
            }

            function lists__listWeekdays(localeSorted, format, index) {
                return listWeekdaysImpl(localeSorted, format, index, 'weekdays');
            }

            function lists__listWeekdaysShort(localeSorted, format, index) {
                return listWeekdaysImpl(localeSorted, format, index, 'weekdaysShort');
            }

            function lists__listWeekdaysMin(localeSorted, format, index) {
                return listWeekdaysImpl(localeSorted, format, index, 'weekdaysMin');
            }

            locale_locales__getSetGlobalLocale('en', {
                ordinalParse: /\d{1,2}(th|st|nd|rd)/,
                ordinal: function(number) {
                    var b = number % 10,
                        output = (toInt(number % 100 / 10) === 1) ? 'th' :
                        (b === 1) ? 'st' :
                        (b === 2) ? 'nd' :
                        (b === 3) ? 'rd' : 'th';
                    return number + output;
                }
            });

            // Side effect imports
            utils_hooks__hooks.lang = deprecate('moment.lang is deprecated. Use moment.locale instead.', locale_locales__getSetGlobalLocale);
            utils_hooks__hooks.langData = deprecate('moment.langData is deprecated. Use moment.localeData instead.', locale_locales__getLocale);

            var mathAbs = Math.abs;

            function duration_abs__abs() {
                var data = this._data;

                this._milliseconds = mathAbs(this._milliseconds);
                this._days = mathAbs(this._days);
                this._months = mathAbs(this._months);

                data.milliseconds = mathAbs(data.milliseconds);
                data.seconds = mathAbs(data.seconds);
                data.minutes = mathAbs(data.minutes);
                data.hours = mathAbs(data.hours);
                data.months = mathAbs(data.months);
                data.years = mathAbs(data.years);

                return this;
            }

            function duration_add_subtract__addSubtract(duration, input, value, direction) {
                var other = create__createDuration(input, value);

                duration._milliseconds += direction * other._milliseconds;
                duration._days += direction * other._days;
                duration._months += direction * other._months;

                return duration._bubble();
            }

            // supports only 2.0-style add(1, 's') or add(duration)
            function duration_add_subtract__add(input, value) {
                return duration_add_subtract__addSubtract(this, input, value, 1);
            }

            // supports only 2.0-style subtract(1, 's') or subtract(duration)
            function duration_add_subtract__subtract(input, value) {
                return duration_add_subtract__addSubtract(this, input, value, -1);
            }

            function absCeil(number) {
                if (number < 0) {
                    return Math.floor(number);
                } else {
                    return Math.ceil(number);
                }
            }

            function bubble() {
                var milliseconds = this._milliseconds;
                var days = this._days;
                var months = this._months;
                var data = this._data;
                var seconds, minutes, hours, years, monthsFromDays;

                // if we have a mix of positive and negative values, bubble down first
                // check: https://github.com/moment/moment/issues/2166
                if (!((milliseconds >= 0 && days >= 0 && months >= 0) ||
                        (milliseconds <= 0 && days <= 0 && months <= 0))) {
                    milliseconds += absCeil(monthsToDays(months) + days) * 864e5;
                    days = 0;
                    months = 0;
                }

                // The following code bubbles up values, see the tests for
                // examples of what that means.
                data.milliseconds = milliseconds % 1000;

                seconds = absFloor(milliseconds / 1000);
                data.seconds = seconds % 60;

                minutes = absFloor(seconds / 60);
                data.minutes = minutes % 60;

                hours = absFloor(minutes / 60);
                data.hours = hours % 24;

                days += absFloor(hours / 24);

                // convert days to months
                monthsFromDays = absFloor(daysToMonths(days));
                months += monthsFromDays;
                days -= absCeil(monthsToDays(monthsFromDays));

                // 12 months -> 1 year
                years = absFloor(months / 12);
                months %= 12;

                data.days = days;
                data.months = months;
                data.years = years;

                return this;
            }

            function daysToMonths(days) {
                // 400 years have 146097 days (taking into account leap year rules)
                // 400 years have 12 months === 4800
                return days * 4800 / 146097;
            }

            function monthsToDays(months) {
                // the reverse of daysToMonths
                return months * 146097 / 4800;
            }

            function as(units) {
                var days;
                var months;
                var milliseconds = this._milliseconds;

                units = normalizeUnits(units);

                if (units === 'month' || units === 'year') {
                    days = this._days + milliseconds / 864e5;
                    months = this._months + daysToMonths(days);
                    return units === 'month' ? months : months / 12;
                } else {
                    // handle milliseconds separately because of floating point math errors (issue #1867)
                    days = this._days + Math.round(monthsToDays(this._months));
                    switch (units) {
                        case 'week':
                            return days / 7 + milliseconds / 6048e5;
                        case 'day':
                            return days + milliseconds / 864e5;
                        case 'hour':
                            return days * 24 + milliseconds / 36e5;
                        case 'minute':
                            return days * 1440 + milliseconds / 6e4;
                        case 'second':
                            return days * 86400 + milliseconds / 1000;
                            // Math.floor prevents floating point math errors here
                        case 'millisecond':
                            return Math.floor(days * 864e5) + milliseconds;
                        default:
                            throw new Error('Unknown unit ' + units);
                    }
                }
            }

            // TODO: Use this.as('ms')?
            function duration_as__valueOf() {
                return (
                    this._milliseconds +
                    this._days * 864e5 +
                    (this._months % 12) * 2592e6 +
                    toInt(this._months / 12) * 31536e6
                );
            }

            function makeAs(alias) {
                return function() {
                    return this.as(alias);
                };
            }

            var asMilliseconds = makeAs('ms');
            var asSeconds = makeAs('s');
            var asMinutes = makeAs('m');
            var asHours = makeAs('h');
            var asDays = makeAs('d');
            var asWeeks = makeAs('w');
            var asMonths = makeAs('M');
            var asYears = makeAs('y');

            function duration_get__get(units) {
                units = normalizeUnits(units);
                return this[units + 's']();
            }

            function makeGetter(name) {
                return function() {
                    return this._data[name];
                };
            }

            var milliseconds = makeGetter('milliseconds');
            var seconds = makeGetter('seconds');
            var minutes = makeGetter('minutes');
            var hours = makeGetter('hours');
            var days = makeGetter('days');
            var months = makeGetter('months');
            var years = makeGetter('years');

            function weeks() {
                return absFloor(this.days() / 7);
            }

            var round = Math.round;
            var thresholds = {
                s: 45, // seconds to minute
                m: 45, // minutes to hour
                h: 22, // hours to day
                d: 26, // days to month
                M: 11 // months to year
            };

            // helper function for moment.fn.from, moment.fn.fromNow, and moment.duration.fn.humanize
            function substituteTimeAgo(string, number, withoutSuffix, isFuture, locale) {
                return locale.relativeTime(number || 1, !!withoutSuffix, string, isFuture);
            }

            function duration_humanize__relativeTime(posNegDuration, withoutSuffix, locale) {
                var duration = create__createDuration(posNegDuration).abs();
                var seconds = round(duration.as('s'));
                var minutes = round(duration.as('m'));
                var hours = round(duration.as('h'));
                var days = round(duration.as('d'));
                var months = round(duration.as('M'));
                var years = round(duration.as('y'));

                var a = seconds < thresholds.s && ['s', seconds] ||
                    minutes <= 1 && ['m'] ||
                    minutes < thresholds.m && ['mm', minutes] ||
                    hours <= 1 && ['h'] ||
                    hours < thresholds.h && ['hh', hours] ||
                    days <= 1 && ['d'] ||
                    days < thresholds.d && ['dd', days] ||
                    months <= 1 && ['M'] ||
                    months < thresholds.M && ['MM', months] ||
                    years <= 1 && ['y'] || ['yy', years];

                a[2] = withoutSuffix;
                a[3] = +posNegDuration > 0;
                a[4] = locale;
                return substituteTimeAgo.apply(null, a);
            }

            // This function allows you to set a threshold for relative time strings
            function duration_humanize__getSetRelativeTimeThreshold(threshold, limit) {
                if (thresholds[threshold] === undefined) {
                    return false;
                }
                if (limit === undefined) {
                    return thresholds[threshold];
                }
                thresholds[threshold] = limit;
                return true;
            }

            function humanize(withSuffix) {
                var locale = this.localeData();
                var output = duration_humanize__relativeTime(this, !withSuffix, locale);

                if (withSuffix) {
                    output = locale.pastFuture(+this, output);
                }

                return locale.postformat(output);
            }

            var iso_string__abs = Math.abs;

            function iso_string__toISOString() {
                // for ISO strings we do not use the normal bubbling rules:
                //  * milliseconds bubble up until they become hours
                //  * days do not bubble at all
                //  * months bubble up until they become years
                // This is because there is no context-free conversion between hours and days
                // (think of clock changes)
                // and also not between days and months (28-31 days per month)
                var seconds = iso_string__abs(this._milliseconds) / 1000;
                var days = iso_string__abs(this._days);
                var months = iso_string__abs(this._months);
                var minutes, hours, years;

                // 3600 seconds -> 60 minutes -> 1 hour
                minutes = absFloor(seconds / 60);
                hours = absFloor(minutes / 60);
                seconds %= 60;
                minutes %= 60;

                // 12 months -> 1 year
                years = absFloor(months / 12);
                months %= 12;


                // inspired by https://github.com/dordille/moment-isoduration/blob/master/moment.isoduration.js
                var Y = years;
                var M = months;
                var D = days;
                var h = hours;
                var m = minutes;
                var s = seconds;
                var total = this.asSeconds();

                if (!total) {
                    // this is the same as C#'s (Noda) and python (isodate)...
                    // but not other JS (goog.date)
                    return 'P0D';
                }

                return (total < 0 ? '-' : '') +
                    'P' +
                    (Y ? Y + 'Y' : '') +
                    (M ? M + 'M' : '') +
                    (D ? D + 'D' : '') +
                    ((h || m || s) ? 'T' : '') +
                    (h ? h + 'H' : '') +
                    (m ? m + 'M' : '') +
                    (s ? s + 'S' : '');
            }

            var duration_prototype__proto = Duration.prototype;

            duration_prototype__proto.abs = duration_abs__abs;
            duration_prototype__proto.add = duration_add_subtract__add;
            duration_prototype__proto.subtract = duration_add_subtract__subtract;
            duration_prototype__proto.as = as;
            duration_prototype__proto.asMilliseconds = asMilliseconds;
            duration_prototype__proto.asSeconds = asSeconds;
            duration_prototype__proto.asMinutes = asMinutes;
            duration_prototype__proto.asHours = asHours;
            duration_prototype__proto.asDays = asDays;
            duration_prototype__proto.asWeeks = asWeeks;
            duration_prototype__proto.asMonths = asMonths;
            duration_prototype__proto.asYears = asYears;
            duration_prototype__proto.valueOf = duration_as__valueOf;
            duration_prototype__proto._bubble = bubble;
            duration_prototype__proto.get = duration_get__get;
            duration_prototype__proto.milliseconds = milliseconds;
            duration_prototype__proto.seconds = seconds;
            duration_prototype__proto.minutes = minutes;
            duration_prototype__proto.hours = hours;
            duration_prototype__proto.days = days;
            duration_prototype__proto.weeks = weeks;
            duration_prototype__proto.months = months;
            duration_prototype__proto.years = years;
            duration_prototype__proto.humanize = humanize;
            duration_prototype__proto.toISOString = iso_string__toISOString;
            duration_prototype__proto.toString = iso_string__toISOString;
            duration_prototype__proto.toJSON = iso_string__toISOString;
            duration_prototype__proto.locale = locale;
            duration_prototype__proto.localeData = localeData;

            // Deprecations
            duration_prototype__proto.toIsoString = deprecate('toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)', iso_string__toISOString);
            duration_prototype__proto.lang = lang;

            // Side effect imports

            // FORMATTING

            addFormatToken('X', 0, 0, 'unix');
            addFormatToken('x', 0, 0, 'valueOf');

            // PARSING

            addRegexToken('x', matchSigned);
            addRegexToken('X', matchTimestamp);
            addParseToken('X', function(input, array, config) {
                config._d = new Date(parseFloat(input, 10) * 1000);
            });
            addParseToken('x', function(input, array, config) {
                config._d = new Date(toInt(input));
            });

            // Side effect imports


            utils_hooks__hooks.version = '2.13.0';

            setHookCallback(local__createLocal);

            utils_hooks__hooks.fn = momentPrototype;
            utils_hooks__hooks.min = min;
            utils_hooks__hooks.max = max;
            utils_hooks__hooks.now = now;
            utils_hooks__hooks.utc = create_utc__createUTC;
            utils_hooks__hooks.unix = moment__createUnix;
            utils_hooks__hooks.months = lists__listMonths;
            utils_hooks__hooks.isDate = isDate;
            utils_hooks__hooks.locale = locale_locales__getSetGlobalLocale;
            utils_hooks__hooks.invalid = valid__createInvalid;
            utils_hooks__hooks.duration = create__createDuration;
            utils_hooks__hooks.isMoment = isMoment;
            utils_hooks__hooks.weekdays = lists__listWeekdays;
            utils_hooks__hooks.parseZone = moment__createInZone;
            utils_hooks__hooks.localeData = locale_locales__getLocale;
            utils_hooks__hooks.isDuration = isDuration;
            utils_hooks__hooks.monthsShort = lists__listMonthsShort;
            utils_hooks__hooks.weekdaysMin = lists__listWeekdaysMin;
            utils_hooks__hooks.defineLocale = defineLocale;
            utils_hooks__hooks.updateLocale = updateLocale;
            utils_hooks__hooks.locales = locale_locales__listLocales;
            utils_hooks__hooks.weekdaysShort = lists__listWeekdaysShort;
            utils_hooks__hooks.normalizeUnits = normalizeUnits;
            utils_hooks__hooks.relativeTimeThreshold = duration_humanize__getSetRelativeTimeThreshold;
            utils_hooks__hooks.prototype = momentPrototype;

            var _moment = utils_hooks__hooks;

            return _moment;

        }));
    }, {}],
    7: [function(require, module, exports) {
        var Chart = require('./core/core.js')();

        require('./core/core.helpers')(Chart);
        require('./core/core.element')(Chart);
        require('./core/core.animation')(Chart);
        require('./core/core.controller')(Chart);
        require('./core/core.datasetController')(Chart);
        require('./core/core.layoutService')(Chart);
        require('./core/core.legend')(Chart);
        require('./core/core.plugin.js')(Chart);
        require('./core/core.scale')(Chart);
        require('./core/core.scaleService')(Chart);
        require('./core/core.title')(Chart);
        require('./core/core.tooltip')(Chart);

        require('./controllers/controller.bar')(Chart);
        require('./controllers/controller.bubble')(Chart);
        require('./controllers/controller.doughnut')(Chart);
        require('./controllers/controller.line')(Chart);
        require('./controllers/controller.polarArea')(Chart);
        require('./controllers/controller.radar')(Chart);

        require('./scales/scale.category')(Chart);
        require('./scales/scale.linear')(Chart);
        require('./scales/scale.logarithmic')(Chart);
        require('./scales/scale.radialLinear')(Chart);
        require('./scales/scale.time')(Chart);

        require('./elements/element.arc')(Chart);
        require('./elements/element.line')(Chart);
        require('./elements/element.point')(Chart);
        require('./elements/element.rectangle')(Chart);

        require('./charts/Chart.Bar')(Chart);
        require('./charts/Chart.Bubble')(Chart);
        require('./charts/Chart.Doughnut')(Chart);
        require('./charts/Chart.Line')(Chart);
        require('./charts/Chart.PolarArea')(Chart);
        require('./charts/Chart.Radar')(Chart);
        require('./charts/Chart.Scatter')(Chart);

        window.Chart = module.exports = Chart;

    }, {
        "./charts/Chart.Bar": 8,
        "./charts/Chart.Bubble": 9,
        "./charts/Chart.Doughnut": 10,
        "./charts/Chart.Line": 11,
        "./charts/Chart.PolarArea": 12,
        "./charts/Chart.Radar": 13,
        "./charts/Chart.Scatter": 14,
        "./controllers/controller.bar": 15,
        "./controllers/controller.bubble": 16,
        "./controllers/controller.doughnut": 17,
        "./controllers/controller.line": 18,
        "./controllers/controller.polarArea": 19,
        "./controllers/controller.radar": 20,
        "./core/core.animation": 21,
        "./core/core.controller": 22,
        "./core/core.datasetController": 23,
        "./core/core.element": 24,
        "./core/core.helpers": 25,
        "./core/core.js": 26,
        "./core/core.layoutService": 27,
        "./core/core.legend": 28,
        "./core/core.plugin.js": 29,
        "./core/core.scale": 30,
        "./core/core.scaleService": 31,
        "./core/core.title": 32,
        "./core/core.tooltip": 33,
        "./elements/element.arc": 34,
        "./elements/element.line": 35,
        "./elements/element.point": 36,
        "./elements/element.rectangle": 37,
        "./scales/scale.category": 38,
        "./scales/scale.linear": 39,
        "./scales/scale.logarithmic": 40,
        "./scales/scale.radialLinear": 41,
        "./scales/scale.time": 42
    }],
    8: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            Chart.Bar = function(context, config) {
                config.type = 'bar';

                return new Chart(context, config);
            };

        };
    }, {}],
    9: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            Chart.Bubble = function(context, config) {
                config.type = 'bubble';
                return new Chart(context, config);
            };

        };
    }, {}],
    10: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            Chart.Doughnut = function(context, config) {
                config.type = 'doughnut';

                return new Chart(context, config);
            };

        };
    }, {}],
    11: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            Chart.Line = function(context, config) {
                config.type = 'line';

                return new Chart(context, config);
            };

        };
    }, {}],
    12: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            Chart.PolarArea = function(context, config) {
                config.type = 'polarArea';

                return new Chart(context, config);
            };

        };
    }, {}],
    13: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            var defaultConfig = {
                aspectRatio: 1
            };

            Chart.Radar = function(context, config) {
                config.options = helpers.configMerge(defaultConfig, config.options);
                config.type = 'radar';

                return new Chart(context, config);
            };

        };

    }, {}],
    14: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var defaultConfig = {
                hover: {
                    mode: 'single'
                },

                scales: {
                    xAxes: [{
                        type: "linear", // scatter should not use a category axis
                        position: "bottom",
                        id: "x-axis-1" // need an ID so datasets can reference the scale
                    }],
                    yAxes: [{
                        type: "linear",
                        position: "left",
                        id: "y-axis-1"
                    }]
                },

                tooltips: {
                    callbacks: {
                        title: function(tooltipItems, data) {
                            // Title doesn't make sense for scatter since we format the data as a point
                            return '';
                        },
                        label: function(tooltipItem, data) {
                            return '(' + tooltipItem.xLabel + ', ' + tooltipItem.yLabel + ')';
                        }
                    }
                }
            };

            // Register the default config for this type
            Chart.defaults.scatter = defaultConfig;

            // Scatter charts use line controllers
            Chart.controllers.scatter = Chart.controllers.line;

            Chart.Scatter = function(context, config) {
                config.type = 'scatter';
                return new Chart(context, config);
            };

        };
    }, {}],
    15: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.bar = {
                hover: {
                    mode: "label"
                },

                scales: {
                    xAxes: [{
                        type: "category",

                        // Specific to Bar Controller
                        categoryPercentage: 0.8,
                        barPercentage: 0.9,

                        // grid line settings
                        gridLines: {
                            offsetGridLines: true
                        }
                    }],
                    yAxes: [{
                        type: "linear"
                    }]
                }
            };

            Chart.controllers.bar = Chart.DatasetController.extend({
                initialize: function(chart, datasetIndex) {
                    Chart.DatasetController.prototype.initialize.call(this, chart, datasetIndex);

                    // Use this to indicate that this is a bar dataset.
                    this.getMeta().bar = true;
                },
                // Get the number of datasets that display bars. We use this to correctly calculate the bar width
                getBarCount: function getBarCount() {
                    var barCount = 0;
                    helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                        var meta = this.chart.getDatasetMeta(datasetIndex);
                        if (meta.bar && this.chart.isDatasetVisible(datasetIndex)) {
                            ++barCount;
                        }
                    }, this);
                    return barCount;
                },

                addElements: function() {
                    var meta = this.getMeta();
                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Rectangle({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index
                        });
                    }, this);
                },

                addElementAndReset: function(index) {
                    var rectangle = new Chart.elements.Rectangle({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    var numBars = this.getBarCount();

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, rectangle);
                    this.updateElement(rectangle, index, true, numBars);
                },

                update: function update(reset) {
                    var numBars = this.getBarCount();

                    helpers.each(this.getMeta().data, function(rectangle, index) {
                        this.updateElement(rectangle, index, reset, numBars);
                    }, this);
                },

                updateElement: function updateElement(rectangle, index, reset, numBars) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var yScalePoint;

                    if (yScale.min < 0 && yScale.max < 0) {
                        // all less than 0. use the top
                        yScalePoint = yScale.getPixelForValue(yScale.max);
                    } else if (yScale.min > 0 && yScale.max > 0) {
                        yScalePoint = yScale.getPixelForValue(yScale.min);
                    } else {
                        yScalePoint = yScale.getPixelForValue(0);
                    }

                    helpers.extend(rectangle, {
                        // Utility
                        _chart: this.chart.chart,
                        _xScale: xScale,
                        _yScale: yScale,
                        _datasetIndex: this.index,
                        _index: index,


                        // Desired view properties
                        _model: {
                            x: this.calculateBarX(index, this.index),
                            y: reset ? yScalePoint : this.calculateBarY(index, this.index),

                            // Tooltip
                            label: this.chart.data.labels[index],
                            datasetLabel: this.getDataset().label,

                            // Appearance
                            base: reset ? yScalePoint : this.calculateBarBase(this.index, index),
                            width: this.calculateBarWidth(numBars),
                            backgroundColor: rectangle.custom && rectangle.custom.backgroundColor ? rectangle.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.rectangle.backgroundColor),
                            borderSkipped: rectangle.custom && rectangle.custom.borderSkipped ? rectangle.custom.borderSkipped : this.chart.options.elements.rectangle.borderSkipped,
                            borderColor: rectangle.custom && rectangle.custom.borderColor ? rectangle.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.rectangle.borderColor),
                            borderWidth: rectangle.custom && rectangle.custom.borderWidth ? rectangle.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.rectangle.borderWidth)
                        }
                    });
                    rectangle.pivot();
                },

                calculateBarBase: function(datasetIndex, index) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var base = 0;

                    if (yScale.options.stacked) {

                        var value = this.chart.data.datasets[datasetIndex].data[index];

                        if (value < 0) {
                            for (var i = 0; i < datasetIndex; i++) {
                                var negDS = this.chart.data.datasets[i];
                                var negDSMeta = this.chart.getDatasetMeta(i);
                                if (negDSMeta.bar && negDSMeta.yAxisID === yScale.id && this.chart.isDatasetVisible(i)) {
                                    base += negDS.data[index] < 0 ? negDS.data[index] : 0;
                                }
                            }
                        } else {
                            for (var j = 0; j < datasetIndex; j++) {
                                var posDS = this.chart.data.datasets[j];
                                var posDSMeta = this.chart.getDatasetMeta(j);
                                if (posDSMeta.bar && posDSMeta.yAxisID === yScale.id && this.chart.isDatasetVisible(j)) {
                                    base += posDS.data[index] > 0 ? posDS.data[index] : 0;
                                }
                            }
                        }

                        return yScale.getPixelForValue(base);
                    }

                    base = yScale.getPixelForValue(yScale.min);

                    if (yScale.beginAtZero || ((yScale.min <= 0 && yScale.max >= 0) || (yScale.min >= 0 && yScale.max <= 0))) {
                        base = yScale.getPixelForValue(0, 0);
                        //base += yScale.options.gridLines.lineWidth;
                    } else if (yScale.min < 0 && yScale.max < 0) {
                        // All values are negative. Use the top as the base
                        base = yScale.getPixelForValue(yScale.max);
                    }

                    return base;

                },

                getRuler: function() {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var datasetCount = this.getBarCount();

                    var tickWidth = (function() {
                        var min = xScale.getPixelForTick(1) - xScale.getPixelForTick(0);
                        for (var i = 2; i < xScale.ticks.length; i++) {
                            min = Math.min(xScale.getPixelForTick(i) - xScale.getPixelForTick(i - 1), min);
                        }
                        return min;
                    }).call(this);
                    var categoryWidth = tickWidth * xScale.options.categoryPercentage;
                    var categorySpacing = (tickWidth - (tickWidth * xScale.options.categoryPercentage)) / 2;
                    var fullBarWidth = categoryWidth / datasetCount;

                    if (xScale.ticks.length !== this.chart.data.labels.length) {
                        var perc = xScale.ticks.length / this.chart.data.labels.length;
                        fullBarWidth = fullBarWidth * perc;
                    }

                    var barWidth = fullBarWidth * xScale.options.barPercentage;
                    var barSpacing = fullBarWidth - (fullBarWidth * xScale.options.barPercentage);

                    return {
                        datasetCount: datasetCount,
                        tickWidth: tickWidth,
                        categoryWidth: categoryWidth,
                        categorySpacing: categorySpacing,
                        fullBarWidth: fullBarWidth,
                        barWidth: barWidth,
                        barSpacing: barSpacing
                    };
                },

                calculateBarWidth: function() {
                    var xScale = this.getScaleForId(this.getMeta().xAxisID);
                    var ruler = this.getRuler();
                    return xScale.options.stacked ? ruler.categoryWidth : ruler.barWidth;
                },

                // Get bar index from the given dataset index accounting for the fact that not all bars are visible
                getBarIndex: function(datasetIndex) {
                    var barIndex = 0;
                    var meta, j;

                    for (j = 0; j < datasetIndex; ++j) {
                        meta = this.chart.getDatasetMeta(j);
                        if (meta.bar && this.chart.isDatasetVisible(j)) {
                            ++barIndex;
                        }
                    }

                    return barIndex;
                },

                calculateBarX: function(index, datasetIndex) {
                    var meta = this.getMeta();
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var barIndex = this.getBarIndex(datasetIndex);

                    var ruler = this.getRuler();
                    var leftTick = xScale.getPixelForValue(null, index, datasetIndex, this.chart.isCombo);
                    leftTick -= this.chart.isCombo ? (ruler.tickWidth / 2) : 0;

                    if (xScale.options.stacked) {
                        return leftTick + (ruler.categoryWidth / 2) + ruler.categorySpacing;
                    }

                    return leftTick +
                        (ruler.barWidth / 2) +
                        ruler.categorySpacing +
                        (ruler.barWidth * barIndex) +
                        (ruler.barSpacing / 2) +
                        (ruler.barSpacing * barIndex);
                },

                calculateBarY: function(index, datasetIndex) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var value = this.getDataset().data[index];

                    if (yScale.options.stacked) {

                        var sumPos = 0,
                            sumNeg = 0;

                        for (var i = 0; i < datasetIndex; i++) {
                            var ds = this.chart.data.datasets[i];
                            var dsMeta = this.chart.getDatasetMeta(i);
                            if (dsMeta.bar && dsMeta.yAxisID === yScale.id && this.chart.isDatasetVisible(i)) {
                                if (ds.data[index] < 0) {
                                    sumNeg += ds.data[index] || 0;
                                } else {
                                    sumPos += ds.data[index] || 0;
                                }
                            }
                        }

                        if (value < 0) {
                            return yScale.getPixelForValue(sumNeg + value);
                        } else {
                            return yScale.getPixelForValue(sumPos + value);
                        }
                    }

                    return yScale.getPixelForValue(value);
                },

                draw: function(ease) {
                    var easingDecimal = ease || 1;
                    helpers.each(this.getMeta().data, function(rectangle, index) {
                        var d = this.getDataset().data[index];
                        if (d !== null && d !== undefined && !isNaN(d)) {
                            rectangle.transition(easingDecimal).draw();
                        }
                    }, this);
                },

                setHoverStyle: function(rectangle) {
                    var dataset = this.chart.data.datasets[rectangle._datasetIndex];
                    var index = rectangle._index;

                    rectangle._model.backgroundColor = rectangle.custom && rectangle.custom.hoverBackgroundColor ? rectangle.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.hoverBackgroundColor, index, helpers.getHoverColor(rectangle._model.backgroundColor));
                    rectangle._model.borderColor = rectangle.custom && rectangle.custom.hoverBorderColor ? rectangle.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.hoverBorderColor, index, helpers.getHoverColor(rectangle._model.borderColor));
                    rectangle._model.borderWidth = rectangle.custom && rectangle.custom.hoverBorderWidth ? rectangle.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.hoverBorderWidth, index, rectangle._model.borderWidth);
                },

                removeHoverStyle: function(rectangle) {
                    var dataset = this.chart.data.datasets[rectangle._datasetIndex];
                    var index = rectangle._index;

                    rectangle._model.backgroundColor = rectangle.custom && rectangle.custom.backgroundColor ? rectangle.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.rectangle.backgroundColor);
                    rectangle._model.borderColor = rectangle.custom && rectangle.custom.borderColor ? rectangle.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.rectangle.borderColor);
                    rectangle._model.borderWidth = rectangle.custom && rectangle.custom.borderWidth ? rectangle.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.rectangle.borderWidth);
                }

            });


            // including horizontalBar in the bar file, instead of a file of its own
            // it extends bar (like pie extends doughnut)
            Chart.defaults.horizontalBar = {
                hover: {
                    mode: "label"
                },

                scales: {
                    xAxes: [{
                        type: "linear",
                        position: "bottom"
                    }],
                    yAxes: [{
                        position: "left",
                        type: "category",

                        // Specific to Horizontal Bar Controller
                        categoryPercentage: 0.8,
                        barPercentage: 0.9,

                        // grid line settings
                        gridLines: {
                            offsetGridLines: true
                        }
                    }]
                },
            };

            Chart.controllers.horizontalBar = Chart.controllers.bar.extend({
                updateElement: function updateElement(rectangle, index, reset, numBars) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var xScalePoint;

                    if (xScale.min < 0 && xScale.max < 0) {
                        // all less than 0. use the right
                        xScalePoint = xScale.getPixelForValue(xScale.max);
                    } else if (xScale.min > 0 && xScale.max > 0) {
                        xScalePoint = xScale.getPixelForValue(xScale.min);
                    } else {
                        xScalePoint = xScale.getPixelForValue(0);
                    }

                    helpers.extend(rectangle, {
                        // Utility
                        _chart: this.chart.chart,
                        _xScale: xScale,
                        _yScale: yScale,
                        _datasetIndex: this.index,
                        _index: index,

                        // Desired view properties
                        _model: {
                            x: reset ? xScalePoint : this.calculateBarX(index, this.index),
                            y: this.calculateBarY(index, this.index),

                            // Tooltip
                            label: this.chart.data.labels[index],
                            datasetLabel: this.getDataset().label,

                            // Appearance
                            base: reset ? xScalePoint : this.calculateBarBase(this.index, index),
                            height: this.calculateBarHeight(numBars),
                            backgroundColor: rectangle.custom && rectangle.custom.backgroundColor ? rectangle.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.rectangle.backgroundColor),
                            borderSkipped: rectangle.custom && rectangle.custom.borderSkipped ? rectangle.custom.borderSkipped : this.chart.options.elements.rectangle.borderSkipped,
                            borderColor: rectangle.custom && rectangle.custom.borderColor ? rectangle.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.rectangle.borderColor),
                            borderWidth: rectangle.custom && rectangle.custom.borderWidth ? rectangle.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.rectangle.borderWidth)
                        },

                        draw: function() {

                            var ctx = this._chart.ctx;
                            var vm = this._view;

                            var halfHeight = vm.height / 2,
                                topY = vm.y - halfHeight,
                                bottomY = vm.y + halfHeight,
                                right = vm.base - (vm.base - vm.x),
                                halfStroke = vm.borderWidth / 2;

                            // Canvas doesn't allow us to stroke inside the width so we can
                            // adjust the sizes to fit if we're setting a stroke on the line
                            if (vm.borderWidth) {
                                topY += halfStroke;
                                bottomY -= halfStroke;
                                right += halfStroke;
                            }

                            ctx.beginPath();

                            ctx.fillStyle = vm.backgroundColor;
                            ctx.strokeStyle = vm.borderColor;
                            ctx.lineWidth = vm.borderWidth;

                            // Corner points, from bottom-left to bottom-right clockwise
                            // | 1 2 |
                            // | 0 3 |
                            var corners = [
                                [vm.base, bottomY],
                                [vm.base, topY],
                                [right, topY],
                                [right, bottomY]
                            ];

                            // Find first (starting) corner with fallback to 'bottom'
                            var borders = ['bottom', 'left', 'top', 'right'];
                            var startCorner = borders.indexOf(vm.borderSkipped, 0);
                            if (startCorner === -1)
                                startCorner = 0;

                            function cornerAt(index) {
                                return corners[(startCorner + index) % 4];
                            }

                            // Draw rectangle from 'startCorner'
                            ctx.moveTo.apply(ctx, cornerAt(0));
                            for (var i = 1; i < 4; i++)
                                ctx.lineTo.apply(ctx, cornerAt(i));

                            ctx.fill();
                            if (vm.borderWidth) {
                                ctx.stroke();
                            }
                        },

                        inRange: function(mouseX, mouseY) {
                            var vm = this._view;
                            var inRange = false;

                            if (vm) {
                                if (vm.x < vm.base) {
                                    inRange = (mouseY >= vm.y - vm.height / 2 && mouseY <= vm.y + vm.height / 2) && (mouseX >= vm.x && mouseX <= vm.base);
                                } else {
                                    inRange = (mouseY >= vm.y - vm.height / 2 && mouseY <= vm.y + vm.height / 2) && (mouseX >= vm.base && mouseX <= vm.x);
                                }
                            }

                            return inRange;
                        }
                    });

                    rectangle.pivot();
                },

                calculateBarBase: function(datasetIndex, index) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var base = 0;

                    if (xScale.options.stacked) {

                        var value = this.chart.data.datasets[datasetIndex].data[index];

                        if (value < 0) {
                            for (var i = 0; i < datasetIndex; i++) {
                                var negDS = this.chart.data.datasets[i];
                                var negDSMeta = this.chart.getDatasetMeta(i);
                                if (negDSMeta.bar && negDSMeta.xAxisID === xScale.id && this.chart.isDatasetVisible(i)) {
                                    base += negDS.data[index] < 0 ? negDS.data[index] : 0;
                                }
                            }
                        } else {
                            for (var j = 0; j < datasetIndex; j++) {
                                var posDS = this.chart.data.datasets[j];
                                var posDSMeta = this.chart.getDatasetMeta(j);
                                if (posDSMeta.bar && posDSMeta.xAxisID === xScale.id && this.chart.isDatasetVisible(j)) {
                                    base += posDS.data[index] > 0 ? posDS.data[index] : 0;
                                }
                            }
                        }

                        return xScale.getPixelForValue(base);
                    }

                    base = xScale.getPixelForValue(xScale.min);

                    if (xScale.beginAtZero || ((xScale.min <= 0 && xScale.max >= 0) || (xScale.min >= 0 && xScale.max <= 0))) {
                        base = xScale.getPixelForValue(0, 0);
                    } else if (xScale.min < 0 && xScale.max < 0) {
                        // All values are negative. Use the right as the base
                        base = xScale.getPixelForValue(xScale.max);
                    }

                    return base;
                },

                getRuler: function() {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var datasetCount = this.getBarCount();

                    var tickHeight = (function() {
                        var min = yScale.getPixelForTick(1) - yScale.getPixelForTick(0);
                        for (var i = 2; i < this.getDataset().data.length; i++) {
                            min = Math.min(yScale.getPixelForTick(i) - yScale.getPixelForTick(i - 1), min);
                        }
                        return min;
                    }).call(this);
                    var categoryHeight = tickHeight * yScale.options.categoryPercentage;
                    var categorySpacing = (tickHeight - (tickHeight * yScale.options.categoryPercentage)) / 2;
                    var fullBarHeight = categoryHeight / datasetCount;

                    if (yScale.ticks.length !== this.chart.data.labels.length) {
                        var perc = yScale.ticks.length / this.chart.data.labels.length;
                        fullBarHeight = fullBarHeight * perc;
                    }

                    var barHeight = fullBarHeight * yScale.options.barPercentage;
                    var barSpacing = fullBarHeight - (fullBarHeight * yScale.options.barPercentage);

                    return {
                        datasetCount: datasetCount,
                        tickHeight: tickHeight,
                        categoryHeight: categoryHeight,
                        categorySpacing: categorySpacing,
                        fullBarHeight: fullBarHeight,
                        barHeight: barHeight,
                        barSpacing: barSpacing,
                    };
                },

                calculateBarHeight: function() {
                    var yScale = this.getScaleForId(this.getMeta().yAxisID);
                    var ruler = this.getRuler();
                    return yScale.options.stacked ? ruler.categoryHeight : ruler.barHeight;
                },

                calculateBarX: function(index, datasetIndex) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    var value = this.getDataset().data[index];

                    if (xScale.options.stacked) {

                        var sumPos = 0,
                            sumNeg = 0;

                        for (var i = 0; i < datasetIndex; i++) {
                            var ds = this.chart.data.datasets[i];
                            var dsMeta = this.chart.getDatasetMeta(i);
                            if (dsMeta.bar && dsMeta.xAxisID === xScale.id && this.chart.isDatasetVisible(i)) {
                                if (ds.data[index] < 0) {
                                    sumNeg += ds.data[index] || 0;
                                } else {
                                    sumPos += ds.data[index] || 0;
                                }
                            }
                        }

                        if (value < 0) {
                            return xScale.getPixelForValue(sumNeg + value);
                        } else {
                            return xScale.getPixelForValue(sumPos + value);
                        }
                    }

                    return xScale.getPixelForValue(value);
                },

                calculateBarY: function(index, datasetIndex) {
                    var meta = this.getMeta();
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var barIndex = this.getBarIndex(datasetIndex);

                    var ruler = this.getRuler();
                    var topTick = yScale.getPixelForValue(null, index, datasetIndex, this.chart.isCombo);
                    topTick -= this.chart.isCombo ? (ruler.tickHeight / 2) : 0;

                    if (yScale.options.stacked) {
                        return topTick + (ruler.categoryHeight / 2) + ruler.categorySpacing;
                    }

                    return topTick +
                        (ruler.barHeight / 2) +
                        ruler.categorySpacing +
                        (ruler.barHeight * barIndex) +
                        (ruler.barSpacing / 2) +
                        (ruler.barSpacing * barIndex);
                }
            });
        };

    }, {}],
    16: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.bubble = {
                hover: {
                    mode: "single"
                },

                scales: {
                    xAxes: [{
                        type: "linear", // bubble should probably use a linear scale by default
                        position: "bottom",
                        id: "x-axis-0" // need an ID so datasets can reference the scale
                    }],
                    yAxes: [{
                        type: "linear",
                        position: "left",
                        id: "y-axis-0"
                    }]
                },

                tooltips: {
                    callbacks: {
                        title: function(tooltipItems, data) {
                            // Title doesn't make sense for scatter since we format the data as a point
                            return '';
                        },
                        label: function(tooltipItem, data) {
                            var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                            var dataPoint = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                            return datasetLabel + ': (' + dataPoint.x + ', ' + dataPoint.y + ', ' + dataPoint.r + ')';
                        }
                    }
                }
            };


            Chart.controllers.bubble = Chart.DatasetController.extend({
                addElements: function() {
                    var meta = this.getMeta();
                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Point({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index
                        });
                    }, this);
                },
                addElementAndReset: function(index) {
                    var point = new Chart.elements.Point({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, point);
                    this.updateElement(point, index, true);
                },

                update: function update(reset) {
                    var meta = this.getMeta();
                    var points = meta.data;
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var scaleBase;

                    if (yScale.min < 0 && yScale.max < 0) {
                        scaleBase = yScale.getPixelForValue(yScale.max);
                    } else if (yScale.min > 0 && yScale.max > 0) {
                        scaleBase = yScale.getPixelForValue(yScale.min);
                    } else {
                        scaleBase = yScale.getPixelForValue(0);
                    }

                    // Update Points
                    helpers.each(points, function(point, index) {
                        this.updateElement(point, index, reset);
                    }, this);

                },

                updateElement: function(point, index, reset) {
                    var meta = this.getMeta();
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var scaleBase;

                    if (yScale.min < 0 && yScale.max < 0) {
                        scaleBase = yScale.getPixelForValue(yScale.max);
                    } else if (yScale.min > 0 && yScale.max > 0) {
                        scaleBase = yScale.getPixelForValue(yScale.min);
                    } else {
                        scaleBase = yScale.getPixelForValue(0);
                    }

                    helpers.extend(point, {
                        // Utility
                        _chart: this.chart.chart,
                        _xScale: xScale,
                        _yScale: yScale,
                        _datasetIndex: this.index,
                        _index: index,

                        // Desired view properties
                        _model: {
                            x: reset ? xScale.getPixelForDecimal(0.5) : xScale.getPixelForValue(this.getDataset().data[index], index, this.index, this.chart.isCombo),
                            y: reset ? scaleBase : yScale.getPixelForValue(this.getDataset().data[index], index, this.index),
                            // Appearance
                            radius: reset ? 0 : point.custom && point.custom.radius ? point.custom.radius : this.getRadius(this.getDataset().data[index]),
                            backgroundColor: point.custom && point.custom.backgroundColor ? point.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.point.backgroundColor),
                            borderColor: point.custom && point.custom.borderColor ? point.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.point.borderColor),
                            borderWidth: point.custom && point.custom.borderWidth ? point.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.point.borderWidth),

                            // Tooltip
                            hitRadius: point.custom && point.custom.hitRadius ? point.custom.hitRadius : helpers.getValueAtIndexOrDefault(this.getDataset().hitRadius, index, this.chart.options.elements.point.hitRadius)
                        }
                    });

                    point._model.skip = point.custom && point.custom.skip ? point.custom.skip : (isNaN(point._model.x) || isNaN(point._model.y));

                    point.pivot();
                },

                getRadius: function(value) {
                    return value.r || this.chart.options.elements.point.radius;
                },

                draw: function(ease) {
                    var easingDecimal = ease || 1;

                    // Transition and Draw the Points
                    helpers.each(this.getMeta().data, function(point, index) {
                        point.transition(easingDecimal);
                        point.draw();
                    });

                },

                setHoverStyle: function(point) {
                    // Point
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    point._model.radius = point.custom && point.custom.hoverRadius ? point.custom.hoverRadius : (helpers.getValueAtIndexOrDefault(dataset.hoverRadius, index, this.chart.options.elements.point.hoverRadius)) + this.getRadius(this.getDataset().data[point._index]);
                    point._model.backgroundColor = point.custom && point.custom.hoverBackgroundColor ? point.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.hoverBackgroundColor, index, helpers.getHoverColor(point._model.backgroundColor));
                    point._model.borderColor = point.custom && point.custom.hoverBorderColor ? point.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.hoverBorderColor, index, helpers.getHoverColor(point._model.borderColor));
                    point._model.borderWidth = point.custom && point.custom.hoverBorderWidth ? point.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.hoverBorderWidth, index, point._model.borderWidth);
                },

                removeHoverStyle: function(point) {
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    point._model.radius = point.custom && point.custom.radius ? point.custom.radius : this.getRadius(this.getDataset().data[point._index]);
                    point._model.backgroundColor = point.custom && point.custom.backgroundColor ? point.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.point.backgroundColor);
                    point._model.borderColor = point.custom && point.custom.borderColor ? point.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.point.borderColor);
                    point._model.borderWidth = point.custom && point.custom.borderWidth ? point.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.point.borderWidth);
                }
            });
        };

    }, {}],
    17: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.doughnut = {
                animation: {
                    //Boolean - Whether we animate the rotation of the Doughnut
                    animateRotate: true,
                    //Boolean - Whether we animate scaling the Doughnut from the centre
                    animateScale: false
                },
                aspectRatio: 1,
                hover: {
                    mode: 'single'
                },
                legendCallback: function(chart) {
                    var text = [];
                    text.push('<ul class="' + chart.id + '-legend">');

                    if (chart.data.datasets.length) {
                        for (var i = 0; i < chart.data.datasets[0].data.length; ++i) {
                            text.push('<li><span style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '"></span>');
                            if (chart.data.labels[i]) {
                                text.push(chart.data.labels[i]);
                            }
                            text.push('</li>');
                        }
                    }

                    text.push('</ul>');
                    return text.join("");
                },
                legend: {
                    labels: {
                        generateLabels: function(chart) {
                            var data = chart.data;
                            if (data.labels.length && data.datasets.length) {
                                return data.labels.map(function(label, i) {
                                    var meta = chart.getDatasetMeta(0);
                                    var ds = data.datasets[0];
                                    var arc = meta.data[i];
                                    var fill = arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(ds.backgroundColor, i, this.chart.options.elements.arc.backgroundColor);
                                    var stroke = arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(ds.borderColor, i, this.chart.options.elements.arc.borderColor);
                                    var bw = arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(ds.borderWidth, i, this.chart.options.elements.arc.borderWidth);

                                    return {
                                        text: label,
                                        fillStyle: fill,
                                        strokeStyle: stroke,
                                        lineWidth: bw,
                                        hidden: isNaN(ds.data[i]) || meta.data[i].hidden,

                                        // Extra data used for toggling the correct item
                                        index: i
                                    };
                                }, this);
                            } else {
                                return [];
                            }
                        }
                    },

                    onClick: function(e, legendItem) {
                        var index = legendItem.index;
                        var chart = this.chart;
                        var i, ilen, meta;

                        for (i = 0, ilen = (chart.data.datasets || []).length; i < ilen; ++i) {
                            meta = chart.getDatasetMeta(i);
                            meta.data[index].hidden = !meta.data[index].hidden;
                        }

                        chart.update();
                    }
                },

                //The percentage of the chart that we cut out of the middle.
                cutoutPercentage: 50,

                //The rotation of the chart, where the first data arc begins.
                rotation: Math.PI * -0.5,

                //The total circumference of the chart.
                circumference: Math.PI * 2.0,

                // Need to override these to give a nice default
                tooltips: {
                    callbacks: {
                        title: function() {
                            return '';
                        },
                        label: function(tooltipItem, data) {
                            return data.labels[tooltipItem.index] + ': ' + data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
                        }
                    }
                }
            };

            Chart.defaults.pie = helpers.clone(Chart.defaults.doughnut);
            helpers.extend(Chart.defaults.pie, {
                cutoutPercentage: 0
            });


            Chart.controllers.doughnut = Chart.controllers.pie = Chart.DatasetController.extend({
                linkScales: function() {
                    // no scales for doughnut
                },

                addElements: function() {
                    var meta = this.getMeta();
                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Arc({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index
                        });
                    }, this);
                },

                addElementAndReset: function(index, colorForNewElement) {
                    var arc = new Chart.elements.Arc({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    if (colorForNewElement && helpers.isArray(this.getDataset().backgroundColor)) {
                        this.getDataset().backgroundColor.splice(index, 0, colorForNewElement);
                    }

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, arc);
                    this.updateElement(arc, index, true);
                },

                // Get index of the dataset in relation to the visible datasets. This allows determining the inner and outer radius correctly
                getRingIndex: function getRingIndex(datasetIndex) {
                    var ringIndex = 0;

                    for (var j = 0; j < datasetIndex; ++j) {
                        if (this.chart.isDatasetVisible(j)) {
                            ++ringIndex;
                        }
                    }

                    return ringIndex;
                },

                update: function update(reset) {
                    var availableWidth = this.chart.chartArea.right - this.chart.chartArea.left - this.chart.options.elements.arc.borderWidth;
                    var availableHeight = this.chart.chartArea.bottom - this.chart.chartArea.top - this.chart.options.elements.arc.borderWidth;
                    var minSize = Math.min(availableWidth, availableHeight);
                    var offset = {
                        x: 0,
                        y: 0
                    };

                    // If the chart's circumference isn't a full circle, calculate minSize as a ratio of the width/height of the arc
                    if (this.chart.options.circumference < Math.PI * 2.0) {
                        var startAngle = this.chart.options.rotation % (Math.PI * 2.0);
                        startAngle += Math.PI * 2.0 * (startAngle >= Math.PI ? -1 : startAngle < -Math.PI ? 1 : 0);
                        var endAngle = startAngle + this.chart.options.circumference;
                        var start = {
                            x: Math.cos(startAngle),
                            y: Math.sin(startAngle)
                        };
                        var end = {
                            x: Math.cos(endAngle),
                            y: Math.sin(endAngle)
                        };
                        var contains0 = (startAngle <= 0 && 0 <= endAngle) || (startAngle <= Math.PI * 2.0 && Math.PI * 2.0 <= endAngle);
                        var contains90 = (startAngle <= Math.PI * 0.5 && Math.PI * 0.5 <= endAngle) || (startAngle <= Math.PI * 2.5 && Math.PI * 2.5 <= endAngle);
                        var contains180 = (startAngle <= -Math.PI && -Math.PI <= endAngle) || (startAngle <= Math.PI && Math.PI <= endAngle);
                        var contains270 = (startAngle <= -Math.PI * 0.5 && -Math.PI * 0.5 <= endAngle) || (startAngle <= Math.PI * 1.5 && Math.PI * 1.5 <= endAngle);
                        var cutout = this.chart.options.cutoutPercentage / 100.0;
                        var min = {
                            x: contains180 ? -1 : Math.min(start.x * (start.x < 0 ? 1 : cutout), end.x * (end.x < 0 ? 1 : cutout)),
                            y: contains270 ? -1 : Math.min(start.y * (start.y < 0 ? 1 : cutout), end.y * (end.y < 0 ? 1 : cutout))
                        };
                        var max = {
                            x: contains0 ? 1 : Math.max(start.x * (start.x > 0 ? 1 : cutout), end.x * (end.x > 0 ? 1 : cutout)),
                            y: contains90 ? 1 : Math.max(start.y * (start.y > 0 ? 1 : cutout), end.y * (end.y > 0 ? 1 : cutout))
                        };
                        var size = {
                            width: (max.x - min.x) * 0.5,
                            height: (max.y - min.y) * 0.5
                        };
                        minSize = Math.min(availableWidth / size.width, availableHeight / size.height);
                        offset = {
                            x: (max.x + min.x) * -0.5,
                            y: (max.y + min.y) * -0.5
                        };
                    }

                    this.chart.outerRadius = Math.max(minSize / 2, 0);
                    this.chart.innerRadius = Math.max(this.chart.options.cutoutPercentage ? (this.chart.outerRadius / 100) * (this.chart.options.cutoutPercentage) : 1, 0);
                    this.chart.radiusLength = (this.chart.outerRadius - this.chart.innerRadius) / this.chart.getVisibleDatasetCount();
                    this.chart.offsetX = offset.x * this.chart.outerRadius;
                    this.chart.offsetY = offset.y * this.chart.outerRadius;

                    this.getMeta().total = this.calculateTotal();

                    this.outerRadius = this.chart.outerRadius - (this.chart.radiusLength * this.getRingIndex(this.index));
                    this.innerRadius = this.outerRadius - this.chart.radiusLength;

                    helpers.each(this.getMeta().data, function(arc, index) {
                        this.updateElement(arc, index, reset);
                    }, this);
                },

                updateElement: function(arc, index, reset) {
                    var centerX = (this.chart.chartArea.left + this.chart.chartArea.right) / 2;
                    var centerY = (this.chart.chartArea.top + this.chart.chartArea.bottom) / 2;
                    var startAngle = this.chart.options.rotation; // non reset case handled later
                    var endAngle = this.chart.options.rotation; // non reset case handled later
                    var circumference = reset && this.chart.options.animation.animateRotate ? 0 : arc.hidden ? 0 : this.calculateCircumference(this.getDataset().data[index]) * (this.chart.options.circumference / (2.0 * Math.PI));
                    var innerRadius = reset && this.chart.options.animation.animateScale ? 0 : this.innerRadius;
                    var outerRadius = reset && this.chart.options.animation.animateScale ? 0 : this.outerRadius;

                    helpers.extend(arc, {
                        // Utility
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index,

                        // Desired view properties
                        _model: {
                            x: centerX + this.chart.offsetX,
                            y: centerY + this.chart.offsetY,
                            startAngle: startAngle,
                            endAngle: endAngle,
                            circumference: circumference,
                            outerRadius: outerRadius,
                            innerRadius: innerRadius,

                            backgroundColor: arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.arc.backgroundColor),
                            hoverBackgroundColor: arc.custom && arc.custom.hoverBackgroundColor ? arc.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().hoverBackgroundColor, index, this.chart.options.elements.arc.hoverBackgroundColor),
                            borderWidth: arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.arc.borderWidth),
                            borderColor: arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.arc.borderColor),

                            label: helpers.getValueAtIndexOrDefault(this.getDataset().label, index, this.chart.data.labels[index])
                        }
                    });

                    // Set correct angles if not resetting
                    if (!reset || !this.chart.options.animation.animateRotate) {

                        if (index === 0) {
                            arc._model.startAngle = this.chart.options.rotation;
                        } else {
                            arc._model.startAngle = this.getMeta().data[index - 1]._model.endAngle;
                        }

                        arc._model.endAngle = arc._model.startAngle + arc._model.circumference;
                    }

                    arc.pivot();
                },

                draw: function(ease) {
                    var easingDecimal = ease || 1;
                    helpers.each(this.getMeta().data, function(arc, index) {
                        arc.transition(easingDecimal).draw();
                    });
                },

                setHoverStyle: function(arc) {
                    var dataset = this.chart.data.datasets[arc._datasetIndex];
                    var index = arc._index;

                    arc._model.backgroundColor = arc.custom && arc.custom.hoverBackgroundColor ? arc.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.hoverBackgroundColor, index, helpers.getHoverColor(arc._model.backgroundColor));
                    arc._model.borderColor = arc.custom && arc.custom.hoverBorderColor ? arc.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.hoverBorderColor, index, helpers.getHoverColor(arc._model.borderColor));
                    arc._model.borderWidth = arc.custom && arc.custom.hoverBorderWidth ? arc.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.hoverBorderWidth, index, arc._model.borderWidth);
                },

                removeHoverStyle: function(arc) {
                    var dataset = this.chart.data.datasets[arc._datasetIndex];
                    var index = arc._index;

                    arc._model.backgroundColor = arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.arc.backgroundColor);
                    arc._model.borderColor = arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.arc.borderColor);
                    arc._model.borderWidth = arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.arc.borderWidth);
                },

                calculateTotal: function() {
                    var dataset = this.getDataset();
                    var meta = this.getMeta();
                    var total = 0;
                    var value;

                    helpers.each(meta.data, function(element, index) {
                        value = dataset.data[index];
                        if (!isNaN(value) && !element.hidden) {
                            total += Math.abs(value);
                        }
                    });

                    return total;
                },

                calculateCircumference: function(value) {
                    var total = this.getMeta().total;
                    if (total > 0 && !isNaN(value)) {
                        return (Math.PI * 2.0) * (value / total);
                    } else {
                        return 0;
                    }
                }
            });
        };

    }, {}],
    18: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.line = {
                showLines: true,

                hover: {
                    mode: "label"
                },

                scales: {
                    xAxes: [{
                        type: "category",
                        id: 'x-axis-0'
                    }],
                    yAxes: [{
                        type: "linear",
                        id: 'y-axis-0'
                    }]
                }
            };


            Chart.controllers.line = Chart.DatasetController.extend({
                addElements: function() {
                    var meta = this.getMeta();
                    meta.dataset = meta.dataset || new Chart.elements.Line({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _points: meta.data
                    });

                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Point({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index
                        });
                    }, this);
                },

                addElementAndReset: function(index) {
                    var point = new Chart.elements.Point({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, point);
                    this.updateElement(point, index, true);

                    // Make sure bezier control points are updated
                    if (this.chart.options.showLines && this.chart.options.elements.line.tension !== 0)
                        this.updateBezierControlPoints();
                },

                update: function update(reset) {
                    var meta = this.getMeta();
                    var line = meta.dataset;
                    var points = meta.data;

                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var scaleBase;

                    if (yScale.min < 0 && yScale.max < 0) {
                        scaleBase = yScale.getPixelForValue(yScale.max);
                    } else if (yScale.min > 0 && yScale.max > 0) {
                        scaleBase = yScale.getPixelForValue(yScale.min);
                    } else {
                        scaleBase = yScale.getPixelForValue(0);
                    }

                    // Update Line
                    if (this.chart.options.showLines) {
                        // Utility
                        line._scale = yScale;
                        line._datasetIndex = this.index;
                        // Data
                        line._children = points;
                        // Model

                        // Compatibility: If the properties are defined with only the old name, use those values
                        if ((this.getDataset().tension !== undefined) && (this.getDataset().lineTension === undefined)) {
                            this.getDataset().lineTension = this.getDataset().tension;
                        }

                        line._model = {
                            // Appearance
                            tension: line.custom && line.custom.tension ? line.custom.tension : helpers.getValueOrDefault(this.getDataset().lineTension, this.chart.options.elements.line.tension),
                            backgroundColor: line.custom && line.custom.backgroundColor ? line.custom.backgroundColor : (this.getDataset().backgroundColor || this.chart.options.elements.line.backgroundColor),
                            borderWidth: line.custom && line.custom.borderWidth ? line.custom.borderWidth : (this.getDataset().borderWidth || this.chart.options.elements.line.borderWidth),
                            borderColor: line.custom && line.custom.borderColor ? line.custom.borderColor : (this.getDataset().borderColor || this.chart.options.elements.line.borderColor),
                            borderCapStyle: line.custom && line.custom.borderCapStyle ? line.custom.borderCapStyle : (this.getDataset().borderCapStyle || this.chart.options.elements.line.borderCapStyle),
                            borderDash: line.custom && line.custom.borderDash ? line.custom.borderDash : (this.getDataset().borderDash || this.chart.options.elements.line.borderDash),
                            borderDashOffset: line.custom && line.custom.borderDashOffset ? line.custom.borderDashOffset : (this.getDataset().borderDashOffset || this.chart.options.elements.line.borderDashOffset),
                            borderJoinStyle: line.custom && line.custom.borderJoinStyle ? line.custom.borderJoinStyle : (this.getDataset().borderJoinStyle || this.chart.options.elements.line.borderJoinStyle),
                            fill: line.custom && line.custom.fill ? line.custom.fill : (this.getDataset().fill !== undefined ? this.getDataset().fill : this.chart.options.elements.line.fill),
                            // Scale
                            scaleTop: yScale.top,
                            scaleBottom: yScale.bottom,
                            scaleZero: scaleBase
                        };
                        line.pivot();
                    }

                    // Update Points
                    helpers.each(points, function(point, index) {
                        this.updateElement(point, index, reset);
                    }, this);

                    if (this.chart.options.showLines && this.chart.options.elements.line.tension !== 0)
                        this.updateBezierControlPoints();
                },

                getPointBackgroundColor: function(point, index) {
                    var backgroundColor = this.chart.options.elements.point.backgroundColor;
                    var dataset = this.getDataset();

                    if (point.custom && point.custom.backgroundColor) {
                        backgroundColor = point.custom.backgroundColor;
                    } else if (dataset.pointBackgroundColor) {
                        backgroundColor = helpers.getValueAtIndexOrDefault(dataset.pointBackgroundColor, index, backgroundColor);
                    } else if (dataset.backgroundColor) {
                        backgroundColor = dataset.backgroundColor;
                    }

                    return backgroundColor;
                },
                getPointBorderColor: function(point, index) {
                    var borderColor = this.chart.options.elements.point.borderColor;
                    var dataset = this.getDataset();

                    if (point.custom && point.custom.borderColor) {
                        borderColor = point.custom.borderColor;
                    } else if (dataset.pointBorderColor) {
                        borderColor = helpers.getValueAtIndexOrDefault(this.getDataset().pointBorderColor, index, borderColor);
                    } else if (dataset.borderColor) {
                        borderColor = dataset.borderColor;
                    }

                    return borderColor;
                },
                getPointBorderWidth: function(point, index) {
                    var borderWidth = this.chart.options.elements.point.borderWidth;
                    var dataset = this.getDataset();

                    if (point.custom && point.custom.borderWidth !== undefined) {
                        borderWidth = point.custom.borderWidth;
                    } else if (dataset.pointBorderWidth !== undefined) {
                        borderWidth = helpers.getValueAtIndexOrDefault(dataset.pointBorderWidth, index, borderWidth);
                    } else if (dataset.borderWidth !== undefined) {
                        borderWidth = dataset.borderWidth;
                    }

                    return borderWidth;
                },

                updateElement: function(point, index, reset) {
                    var meta = this.getMeta();
                    var yScale = this.getScaleForId(meta.yAxisID);
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var scaleBase;

                    if (yScale.min < 0 && yScale.max < 0) {
                        scaleBase = yScale.getPixelForValue(yScale.max);
                    } else if (yScale.min > 0 && yScale.max > 0) {
                        scaleBase = yScale.getPixelForValue(yScale.min);
                    } else {
                        scaleBase = yScale.getPixelForValue(0);
                    }

                    // Utility
                    point._chart = this.chart.chart;
                    point._xScale = xScale;
                    point._yScale = yScale;
                    point._datasetIndex = this.index;
                    point._index = index;

                    // Desired view properties

                    // Compatibility: If the properties are defined with only the old name, use those values
                    if ((this.getDataset().radius !== undefined) && (this.getDataset().pointRadius === undefined)) {
                        this.getDataset().pointRadius = this.getDataset().radius;
                    }
                    if ((this.getDataset().hitRadius !== undefined) && (this.getDataset().pointHitRadius === undefined)) {
                        this.getDataset().pointHitRadius = this.getDataset().hitRadius;
                    }

                    point._model = {
                        x: xScale.getPixelForValue(this.getDataset().data[index], index, this.index, this.chart.isCombo),
                        y: reset ? scaleBase : this.calculatePointY(this.getDataset().data[index], index, this.index, this.chart.isCombo),
                        // Appearance
                        radius: point.custom && point.custom.radius ? point.custom.radius : helpers.getValueAtIndexOrDefault(this.getDataset().pointRadius, index, this.chart.options.elements.point.radius),
                        pointStyle: point.custom && point.custom.pointStyle ? point.custom.pointStyle : helpers.getValueAtIndexOrDefault(this.getDataset().pointStyle, index, this.chart.options.elements.point.pointStyle),
                        backgroundColor: this.getPointBackgroundColor(point, index),
                        borderColor: this.getPointBorderColor(point, index),
                        borderWidth: this.getPointBorderWidth(point, index),
                        tension: meta.dataset._model ? meta.dataset._model.tension : 0,
                        // Tooltip
                        hitRadius: point.custom && point.custom.hitRadius ? point.custom.hitRadius : helpers.getValueAtIndexOrDefault(this.getDataset().pointHitRadius, index, this.chart.options.elements.point.hitRadius)
                    };

                    point._model.skip = point.custom && point.custom.skip ? point.custom.skip : (isNaN(point._model.x) || isNaN(point._model.y));
                },

                calculatePointY: function(value, index, datasetIndex, isCombo) {
                    var meta = this.getMeta();
                    var xScale = this.getScaleForId(meta.xAxisID);
                    var yScale = this.getScaleForId(meta.yAxisID);

                    if (yScale.options.stacked) {

                        var sumPos = 0,
                            sumNeg = 0;

                        for (var i = 0; i < datasetIndex; i++) {
                            var ds = this.chart.data.datasets[i];
                            var dsMeta = this.chart.getDatasetMeta(i);
                            if (dsMeta.type === 'line' && this.chart.isDatasetVisible(i)) {
                                if (ds.data[index] < 0) {
                                    sumNeg += ds.data[index] || 0;
                                } else {
                                    sumPos += ds.data[index] || 0;
                                }
                            }
                        }

                        if (value < 0) {
                            return yScale.getPixelForValue(sumNeg + value);
                        } else {
                            return yScale.getPixelForValue(sumPos + value);
                        }
                    }

                    return yScale.getPixelForValue(value);
                },

                updateBezierControlPoints: function() {
                    // Update bezier control points
                    var meta = this.getMeta();
                    helpers.each(meta.data, function(point, index) {
                        var controlPoints = helpers.splineCurve(
                            helpers.previousItem(meta.data, index)._model,
                            point._model,
                            helpers.nextItem(meta.data, index)._model,
                            meta.dataset._model.tension
                        );

                        // Prevent the bezier going outside of the bounds of the graph
                        point._model.controlPointPreviousX = Math.max(Math.min(controlPoints.previous.x, this.chart.chartArea.right), this.chart.chartArea.left);
                        point._model.controlPointPreviousY = Math.max(Math.min(controlPoints.previous.y, this.chart.chartArea.bottom), this.chart.chartArea.top);

                        point._model.controlPointNextX = Math.max(Math.min(controlPoints.next.x, this.chart.chartArea.right), this.chart.chartArea.left);
                        point._model.controlPointNextY = Math.max(Math.min(controlPoints.next.y, this.chart.chartArea.bottom), this.chart.chartArea.top);

                        // Now pivot the point for animation
                        point.pivot();
                    }, this);
                },

                draw: function(ease) {
                    var meta = this.getMeta();
                    var easingDecimal = ease || 1;

                    // Transition Point Locations
                    helpers.each(meta.data, function(point) {
                        point.transition(easingDecimal);
                    });

                    // Transition and Draw the line
                    if (this.chart.options.showLines)
                        meta.dataset.transition(easingDecimal).draw();

                    // Draw the points
                    helpers.each(meta.data, function(point) {
                        point.draw();
                    });
                },

                setHoverStyle: function(point) {
                    // Point
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    point._model.radius = point.custom && point.custom.hoverRadius ? point.custom.hoverRadius : helpers.getValueAtIndexOrDefault(dataset.pointHoverRadius, index, this.chart.options.elements.point.hoverRadius);
                    point._model.backgroundColor = point.custom && point.custom.hoverBackgroundColor ? point.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.pointHoverBackgroundColor, index, helpers.getHoverColor(point._model.backgroundColor));
                    point._model.borderColor = point.custom && point.custom.hoverBorderColor ? point.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.pointHoverBorderColor, index, helpers.getHoverColor(point._model.borderColor));
                    point._model.borderWidth = point.custom && point.custom.hoverBorderWidth ? point.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.pointHoverBorderWidth, index, point._model.borderWidth);
                },

                removeHoverStyle: function(point) {
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    // Compatibility: If the properties are defined with only the old name, use those values
                    if ((this.getDataset().radius !== undefined) && (this.getDataset().pointRadius === undefined)) {
                        this.getDataset().pointRadius = this.getDataset().radius;
                    }

                    point._model.radius = point.custom && point.custom.radius ? point.custom.radius : helpers.getValueAtIndexOrDefault(this.getDataset().pointRadius, index, this.chart.options.elements.point.radius);
                    point._model.backgroundColor = this.getPointBackgroundColor(point, index);
                    point._model.borderColor = this.getPointBorderColor(point, index);
                    point._model.borderWidth = this.getPointBorderWidth(point, index);
                }
            });
        };

    }, {}],
    19: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.polarArea = {

                scale: {
                    type: "radialLinear",
                    lineArc: true // so that lines are circular
                },

                //Boolean - Whether to animate the rotation of the chart
                animation: {
                    animateRotate: true,
                    animateScale: true
                },

                aspectRatio: 1,
                legendCallback: function(chart) {
                    var text = [];
                    text.push('<ul class="' + chart.id + '-legend">');

                    if (chart.data.datasets.length) {
                        for (var i = 0; i < chart.data.datasets[0].data.length; ++i) {
                            text.push('<li><span style="background-color:' + chart.data.datasets[0].backgroundColor[i] + '">');
                            if (chart.data.labels[i]) {
                                text.push(chart.data.labels[i]);
                            }
                            text.push('</span></li>');
                        }
                    }

                    text.push('</ul>');
                    return text.join("");
                },
                legend: {
                    labels: {
                        generateLabels: function(chart) {
                            var data = chart.data;
                            if (data.labels.length && data.datasets.length) {
                                return data.labels.map(function(label, i) {
                                    var meta = chart.getDatasetMeta(0);
                                    var ds = data.datasets[0];
                                    var arc = meta.data[i];
                                    var fill = arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(ds.backgroundColor, i, this.chart.options.elements.arc.backgroundColor);
                                    var stroke = arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(ds.borderColor, i, this.chart.options.elements.arc.borderColor);
                                    var bw = arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(ds.borderWidth, i, this.chart.options.elements.arc.borderWidth);

                                    return {
                                        text: label,
                                        fillStyle: fill,
                                        strokeStyle: stroke,
                                        lineWidth: bw,
                                        hidden: isNaN(ds.data[i]) || meta.data[i].hidden,

                                        // Extra data used for toggling the correct item
                                        index: i
                                    };
                                }, this);
                            } else {
                                return [];
                            }
                        }
                    },

                    onClick: function(e, legendItem) {
                        var index = legendItem.index;
                        var chart = this.chart;
                        var i, ilen, meta;

                        for (i = 0, ilen = (chart.data.datasets || []).length; i < ilen; ++i) {
                            meta = chart.getDatasetMeta(i);
                            meta.data[index].hidden = !meta.data[index].hidden;
                        }

                        chart.update();
                    }
                },

                // Need to override these to give a nice default
                tooltips: {
                    callbacks: {
                        title: function() {
                            return '';
                        },
                        label: function(tooltipItem, data) {
                            return data.labels[tooltipItem.index] + ': ' + tooltipItem.yLabel;
                        }
                    }
                }
            };

            Chart.controllers.polarArea = Chart.DatasetController.extend({
                linkScales: function() {
                    // no scales for doughnut
                },

                addElements: function() {
                    var meta = this.getMeta();
                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Arc({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index
                        });
                    }, this);
                },

                addElementAndReset: function(index) {
                    var arc = new Chart.elements.Arc({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, arc);
                    this.updateElement(arc, index, true);
                },

                update: function update(reset) {
                    var meta = this.getMeta();
                    var minSize = Math.min(this.chart.chartArea.right - this.chart.chartArea.left, this.chart.chartArea.bottom - this.chart.chartArea.top);
                    this.chart.outerRadius = Math.max((minSize - this.chart.options.elements.arc.borderWidth / 2) / 2, 0);
                    this.chart.innerRadius = Math.max(this.chart.options.cutoutPercentage ? (this.chart.outerRadius / 100) * (this.chart.options.cutoutPercentage) : 1, 0);
                    this.chart.radiusLength = (this.chart.outerRadius - this.chart.innerRadius) / this.chart.getVisibleDatasetCount();

                    this.outerRadius = this.chart.outerRadius - (this.chart.radiusLength * this.index);
                    this.innerRadius = this.outerRadius - this.chart.radiusLength;

                    meta.count = this.countVisibleElements();

                    helpers.each(meta.data, function(arc, index) {
                        this.updateElement(arc, index, reset);
                    }, this);
                },

                updateElement: function(arc, index, reset) {
                    var circumference = this.calculateCircumference(this.getDataset().data[index]);
                    var centerX = (this.chart.chartArea.left + this.chart.chartArea.right) / 2;
                    var centerY = (this.chart.chartArea.top + this.chart.chartArea.bottom) / 2;

                    // If there is NaN data before us, we need to calculate the starting angle correctly.
                    // We could be way more efficient here, but its unlikely that the polar area chart will have a lot of data
                    var visibleCount = 0;
                    var meta = this.getMeta();
                    for (var i = 0; i < index; ++i) {
                        if (!isNaN(this.getDataset().data[i]) && !meta.data[i].hidden) {
                            ++visibleCount;
                        }
                    }

                    var distance = arc.hidden ? 0 : this.chart.scale.getDistanceFromCenterForValue(this.getDataset().data[index]);
                    var startAngle = (-0.5 * Math.PI) + (circumference * visibleCount);
                    var endAngle = startAngle + (arc.hidden ? 0 : circumference);

                    var resetModel = {
                        x: centerX,
                        y: centerY,
                        innerRadius: 0,
                        outerRadius: this.chart.options.animation.animateScale ? 0 : this.chart.scale.getDistanceFromCenterForValue(this.getDataset().data[index]),
                        startAngle: this.chart.options.animation.animateRotate ? Math.PI * -0.5 : startAngle,
                        endAngle: this.chart.options.animation.animateRotate ? Math.PI * -0.5 : endAngle,

                        backgroundColor: arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.arc.backgroundColor),
                        borderWidth: arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.arc.borderWidth),
                        borderColor: arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.arc.borderColor),

                        label: helpers.getValueAtIndexOrDefault(this.chart.data.labels, index, this.chart.data.labels[index])
                    };

                    helpers.extend(arc, {
                        // Utility
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index,
                        _scale: this.chart.scale,

                        // Desired view properties
                        _model: reset ? resetModel : {
                            x: centerX,
                            y: centerY,
                            innerRadius: 0,
                            outerRadius: distance,
                            startAngle: startAngle,
                            endAngle: endAngle,

                            backgroundColor: arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.arc.backgroundColor),
                            borderWidth: arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.arc.borderWidth),
                            borderColor: arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.arc.borderColor),

                            label: helpers.getValueAtIndexOrDefault(this.chart.data.labels, index, this.chart.data.labels[index])
                        }
                    });

                    arc.pivot();
                },

                draw: function(ease) {
                    var easingDecimal = ease || 1;
                    helpers.each(this.getMeta().data, function(arc, index) {
                        arc.transition(easingDecimal).draw();
                    });
                },

                setHoverStyle: function(arc) {
                    var dataset = this.chart.data.datasets[arc._datasetIndex];
                    var index = arc._index;

                    arc._model.backgroundColor = arc.custom && arc.custom.hoverBackgroundColor ? arc.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.hoverBackgroundColor, index, helpers.getHoverColor(arc._model.backgroundColor));
                    arc._model.borderColor = arc.custom && arc.custom.hoverBorderColor ? arc.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.hoverBorderColor, index, helpers.getHoverColor(arc._model.borderColor));
                    arc._model.borderWidth = arc.custom && arc.custom.hoverBorderWidth ? arc.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.hoverBorderWidth, index, arc._model.borderWidth);
                },

                removeHoverStyle: function(arc) {
                    var dataset = this.chart.data.datasets[arc._datasetIndex];
                    var index = arc._index;

                    arc._model.backgroundColor = arc.custom && arc.custom.backgroundColor ? arc.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().backgroundColor, index, this.chart.options.elements.arc.backgroundColor);
                    arc._model.borderColor = arc.custom && arc.custom.borderColor ? arc.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().borderColor, index, this.chart.options.elements.arc.borderColor);
                    arc._model.borderWidth = arc.custom && arc.custom.borderWidth ? arc.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().borderWidth, index, this.chart.options.elements.arc.borderWidth);
                },

                countVisibleElements: function() {
                    var dataset = this.getDataset();
                    var meta = this.getMeta();
                    var count = 0;

                    helpers.each(meta.data, function(element, index) {
                        if (!isNaN(dataset.data[index]) && !element.hidden) {
                            count++;
                        }
                    });

                    return count;
                },

                calculateCircumference: function(value) {
                    var count = this.getMeta().count;
                    if (count > 0 && !isNaN(value)) {
                        return (2 * Math.PI) / count;
                    } else {
                        return 0;
                    }
                }
            });
        };

    }, {}],
    20: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;


            Chart.defaults.radar = {
                scale: {
                    type: "radialLinear"
                },
                elements: {
                    line: {
                        tension: 0 // no bezier in radar
                    }
                }
            };

            Chart.controllers.radar = Chart.DatasetController.extend({
                linkScales: function() {
                    // No need. Single scale only
                },

                addElements: function() {
                    var meta = this.getMeta();

                    meta.dataset = meta.dataset || new Chart.elements.Line({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _points: meta.data,
                        _loop: true
                    });

                    helpers.each(this.getDataset().data, function(value, index) {
                        meta.data[index] = meta.data[index] || new Chart.elements.Point({
                            _chart: this.chart.chart,
                            _datasetIndex: this.index,
                            _index: index,
                            _model: {
                                x: 0, //xScale.getPixelForValue(null, index, true),
                                y: 0 //this.chartArea.bottom,
                            }
                        });
                    }, this);
                },
                addElementAndReset: function(index) {
                    var point = new Chart.elements.Point({
                        _chart: this.chart.chart,
                        _datasetIndex: this.index,
                        _index: index
                    });

                    // Add to the points array and reset it
                    this.getMeta().data.splice(index, 0, point);
                    this.updateElement(point, index, true);

                    // Make sure bezier control points are updated
                    this.updateBezierControlPoints();
                },

                update: function update(reset) {
                    var meta = this.getMeta();
                    var line = meta.dataset;
                    var points = meta.data;

                    var scale = this.chart.scale;
                    var scaleBase;

                    if (scale.min < 0 && scale.max < 0) {
                        scaleBase = scale.getPointPositionForValue(0, scale.max);
                    } else if (scale.min > 0 && scale.max > 0) {
                        scaleBase = scale.getPointPositionForValue(0, scale.min);
                    } else {
                        scaleBase = scale.getPointPositionForValue(0, 0);
                    }

                    // Compatibility: If the properties are defined with only the old name, use those values
                    if ((this.getDataset().tension !== undefined) && (this.getDataset().lineTension === undefined)) {
                        this.getDataset().lineTension = this.getDataset().tension;
                    }

                    helpers.extend(meta.dataset, {
                        // Utility
                        _datasetIndex: this.index,
                        // Data
                        _children: points,
                        // Model
                        _model: {
                            // Appearance
                            tension: line.custom && line.custom.tension ? line.custom.tension : helpers.getValueOrDefault(this.getDataset().lineTension, this.chart.options.elements.line.tension),
                            backgroundColor: line.custom && line.custom.backgroundColor ? line.custom.backgroundColor : (this.getDataset().backgroundColor || this.chart.options.elements.line.backgroundColor),
                            borderWidth: line.custom && line.custom.borderWidth ? line.custom.borderWidth : (this.getDataset().borderWidth || this.chart.options.elements.line.borderWidth),
                            borderColor: line.custom && line.custom.borderColor ? line.custom.borderColor : (this.getDataset().borderColor || this.chart.options.elements.line.borderColor),
                            fill: line.custom && line.custom.fill ? line.custom.fill : (this.getDataset().fill !== undefined ? this.getDataset().fill : this.chart.options.elements.line.fill),
                            borderCapStyle: line.custom && line.custom.borderCapStyle ? line.custom.borderCapStyle : (this.getDataset().borderCapStyle || this.chart.options.elements.line.borderCapStyle),
                            borderDash: line.custom && line.custom.borderDash ? line.custom.borderDash : (this.getDataset().borderDash || this.chart.options.elements.line.borderDash),
                            borderDashOffset: line.custom && line.custom.borderDashOffset ? line.custom.borderDashOffset : (this.getDataset().borderDashOffset || this.chart.options.elements.line.borderDashOffset),
                            borderJoinStyle: line.custom && line.custom.borderJoinStyle ? line.custom.borderJoinStyle : (this.getDataset().borderJoinStyle || this.chart.options.elements.line.borderJoinStyle),

                            // Scale
                            scaleTop: scale.top,
                            scaleBottom: scale.bottom,
                            scaleZero: scaleBase
                        }
                    });

                    meta.dataset.pivot();

                    // Update Points
                    helpers.each(points, function(point, index) {
                        this.updateElement(point, index, reset);
                    }, this);


                    // Update bezier control points
                    this.updateBezierControlPoints();
                },
                updateElement: function(point, index, reset) {
                    var pointPosition = this.chart.scale.getPointPositionForValue(index, this.getDataset().data[index]);

                    helpers.extend(point, {
                        // Utility
                        _datasetIndex: this.index,
                        _index: index,
                        _scale: this.chart.scale,

                        // Desired view properties
                        _model: {
                            x: reset ? this.chart.scale.xCenter : pointPosition.x, // value not used in dataset scale, but we want a consistent API between scales
                            y: reset ? this.chart.scale.yCenter : pointPosition.y,

                            // Appearance
                            tension: point.custom && point.custom.tension ? point.custom.tension : helpers.getValueOrDefault(this.getDataset().tension, this.chart.options.elements.line.tension),
                            radius: point.custom && point.custom.radius ? point.custom.radius : helpers.getValueAtIndexOrDefault(this.getDataset().pointRadius, index, this.chart.options.elements.point.radius),
                            backgroundColor: point.custom && point.custom.backgroundColor ? point.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().pointBackgroundColor, index, this.chart.options.elements.point.backgroundColor),
                            borderColor: point.custom && point.custom.borderColor ? point.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().pointBorderColor, index, this.chart.options.elements.point.borderColor),
                            borderWidth: point.custom && point.custom.borderWidth ? point.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().pointBorderWidth, index, this.chart.options.elements.point.borderWidth),
                            pointStyle: point.custom && point.custom.pointStyle ? point.custom.pointStyle : helpers.getValueAtIndexOrDefault(this.getDataset().pointStyle, index, this.chart.options.elements.point.pointStyle),

                            // Tooltip
                            hitRadius: point.custom && point.custom.hitRadius ? point.custom.hitRadius : helpers.getValueAtIndexOrDefault(this.getDataset().hitRadius, index, this.chart.options.elements.point.hitRadius)
                        }
                    });

                    point._model.skip = point.custom && point.custom.skip ? point.custom.skip : (isNaN(point._model.x) || isNaN(point._model.y));
                },
                updateBezierControlPoints: function() {
                    var meta = this.getMeta();
                    helpers.each(meta.data, function(point, index) {
                        var controlPoints = helpers.splineCurve(
                            helpers.previousItem(meta.data, index, true)._model,
                            point._model,
                            helpers.nextItem(meta.data, index, true)._model,
                            point._model.tension
                        );

                        // Prevent the bezier going outside of the bounds of the graph
                        point._model.controlPointPreviousX = Math.max(Math.min(controlPoints.previous.x, this.chart.chartArea.right), this.chart.chartArea.left);
                        point._model.controlPointPreviousY = Math.max(Math.min(controlPoints.previous.y, this.chart.chartArea.bottom), this.chart.chartArea.top);

                        point._model.controlPointNextX = Math.max(Math.min(controlPoints.next.x, this.chart.chartArea.right), this.chart.chartArea.left);
                        point._model.controlPointNextY = Math.max(Math.min(controlPoints.next.y, this.chart.chartArea.bottom), this.chart.chartArea.top);

                        // Now pivot the point for animation
                        point.pivot();
                    }, this);
                },

                draw: function(ease) {
                    var meta = this.getMeta();
                    var easingDecimal = ease || 1;

                    // Transition Point Locations
                    helpers.each(meta.data, function(point, index) {
                        point.transition(easingDecimal);
                    });

                    // Transition and Draw the line
                    meta.dataset.transition(easingDecimal).draw();

                    // Draw the points
                    helpers.each(meta.data, function(point) {
                        point.draw();
                    });
                },

                setHoverStyle: function(point) {
                    // Point
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    point._model.radius = point.custom && point.custom.hoverRadius ? point.custom.hoverRadius : helpers.getValueAtIndexOrDefault(dataset.pointHoverRadius, index, this.chart.options.elements.point.hoverRadius);
                    point._model.backgroundColor = point.custom && point.custom.hoverBackgroundColor ? point.custom.hoverBackgroundColor : helpers.getValueAtIndexOrDefault(dataset.pointHoverBackgroundColor, index, helpers.getHoverColor(point._model.backgroundColor));
                    point._model.borderColor = point.custom && point.custom.hoverBorderColor ? point.custom.hoverBorderColor : helpers.getValueAtIndexOrDefault(dataset.pointHoverBorderColor, index, helpers.getHoverColor(point._model.borderColor));
                    point._model.borderWidth = point.custom && point.custom.hoverBorderWidth ? point.custom.hoverBorderWidth : helpers.getValueAtIndexOrDefault(dataset.pointHoverBorderWidth, index, point._model.borderWidth);
                },

                removeHoverStyle: function(point) {
                    var dataset = this.chart.data.datasets[point._datasetIndex];
                    var index = point._index;

                    point._model.radius = point.custom && point.custom.radius ? point.custom.radius : helpers.getValueAtIndexOrDefault(this.getDataset().radius, index, this.chart.options.elements.point.radius);
                    point._model.backgroundColor = point.custom && point.custom.backgroundColor ? point.custom.backgroundColor : helpers.getValueAtIndexOrDefault(this.getDataset().pointBackgroundColor, index, this.chart.options.elements.point.backgroundColor);
                    point._model.borderColor = point.custom && point.custom.borderColor ? point.custom.borderColor : helpers.getValueAtIndexOrDefault(this.getDataset().pointBorderColor, index, this.chart.options.elements.point.borderColor);
                    point._model.borderWidth = point.custom && point.custom.borderWidth ? point.custom.borderWidth : helpers.getValueAtIndexOrDefault(this.getDataset().pointBorderWidth, index, this.chart.options.elements.point.borderWidth);
                }
            });
        };

    }, {}],
    21: [function(require, module, exports) {
        /*global window: false */
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.global.animation = {
                duration: 1000,
                easing: "easeOutQuart",
                onProgress: helpers.noop,
                onComplete: helpers.noop
            };

            Chart.Animation = Chart.Element.extend({
                currentStep: null, // the current animation step
                numSteps: 60, // default number of steps
                easing: "", // the easing to use for this animation
                render: null, // render function used by the animation service

                onAnimationProgress: null, // user specified callback to fire on each step of the animation
                onAnimationComplete: null // user specified callback to fire when the animation finishes
            });

            Chart.animationService = {
                frameDuration: 17,
                animations: [],
                dropFrames: 0,
                request: null,
                addAnimation: function(chartInstance, animationObject, duration, lazy) {

                    if (!lazy) {
                        chartInstance.animating = true;
                    }

                    for (var index = 0; index < this.animations.length; ++index) {
                        if (this.animations[index].chartInstance === chartInstance) {
                            // replacing an in progress animation
                            this.animations[index].animationObject = animationObject;
                            return;
                        }
                    }

                    this.animations.push({
                        chartInstance: chartInstance,
                        animationObject: animationObject
                    });

                    // If there are no animations queued, manually kickstart a digest, for lack of a better word
                    if (this.animations.length === 1) {
                        this.requestAnimationFrame();
                    }
                },
                // Cancel the animation for a given chart instance
                cancelAnimation: function(chartInstance) {
                    var index = helpers.findIndex(this.animations, function(animationWrapper) {
                        return animationWrapper.chartInstance === chartInstance;
                    });

                    if (index !== -1) {
                        this.animations.splice(index, 1);
                        chartInstance.animating = false;
                    }
                },
                requestAnimationFrame: function() {
                    var me = this;
                    if (me.request === null) {
                        // Skip animation frame requests until the active one is executed.
                        // This can happen when processing mouse events, e.g. 'mousemove'
                        // and 'mouseout' events will trigger multiple renders.
                        me.request = helpers.requestAnimFrame.call(window, function() {
                            me.request = null;
                            me.startDigest();
                        });
                    }
                },
                startDigest: function() {

                    var startTime = Date.now();
                    var framesToDrop = 0;

                    if (this.dropFrames > 1) {
                        framesToDrop = Math.floor(this.dropFrames);
                        this.dropFrames = this.dropFrames % 1;
                    }

                    var i = 0;
                    while (i < this.animations.length) {
                        if (this.animations[i].animationObject.currentStep === null) {
                            this.animations[i].animationObject.currentStep = 0;
                        }

                        this.animations[i].animationObject.currentStep += 1 + framesToDrop;

                        if (this.animations[i].animationObject.currentStep > this.animations[i].animationObject.numSteps) {
                            this.animations[i].animationObject.currentStep = this.animations[i].animationObject.numSteps;
                        }

                        this.animations[i].animationObject.render(this.animations[i].chartInstance, this.animations[i].animationObject);
                        if (this.animations[i].animationObject.onAnimationProgress && this.animations[i].animationObject.onAnimationProgress.call) {
                            this.animations[i].animationObject.onAnimationProgress.call(this.animations[i].chartInstance, this.animations[i]);
                        }

                        if (this.animations[i].animationObject.currentStep === this.animations[i].animationObject.numSteps) {
                            if (this.animations[i].animationObject.onAnimationComplete && this.animations[i].animationObject.onAnimationComplete.call) {
                                this.animations[i].animationObject.onAnimationComplete.call(this.animations[i].chartInstance, this.animations[i]);
                            }

                            // executed the last frame. Remove the animation.
                            this.animations[i].chartInstance.animating = false;

                            this.animations.splice(i, 1);
                        } else {
                            ++i;
                        }
                    }

                    var endTime = Date.now();
                    var dropFrames = (endTime - startTime) / this.frameDuration;

                    this.dropFrames += dropFrames;

                    // Do we have more stuff to animate?
                    if (this.animations.length > 0) {
                        this.requestAnimationFrame();
                    }
                }
            };
        };
    }, {}],
    22: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;
            //Create a dictionary of chart types, to allow for extension of existing types
            Chart.types = {};

            //Store a reference to each instance - allowing us to globally resize chart instances on window resize.
            //Destroy method on the chart will remove the instance of the chart from this reference.
            Chart.instances = {};

            // Controllers available for dataset visualization eg. bar, line, slice, etc.
            Chart.controllers = {};

            // The main controller of a chart
            Chart.Controller = function(instance) {

                this.chart = instance;
                this.config = instance.config;
                this.options = this.config.options = helpers.configMerge(Chart.defaults.global, Chart.defaults[this.config.type], this.config.options || {});
                this.id = helpers.uid();

                Object.defineProperty(this, 'data', {
                    get: function() {
                        return this.config.data;
                    }
                });

                //Add the chart instance to the global namespace
                Chart.instances[this.id] = this;

                if (this.options.responsive) {
                    // Silent resize before chart draws
                    this.resize(true);
                }

                this.initialize();

                return this;
            };

            helpers.extend(Chart.Controller.prototype, {

                initialize: function initialize() {
                    // Before init plugin notification
                    Chart.pluginService.notifyPlugins('beforeInit', [this]);

                    this.bindEvents();

                    // Make sure controllers are built first so that each dataset is bound to an axis before the scales
                    // are built
                    this.ensureScalesHaveIDs();
                    this.buildOrUpdateControllers();
                    this.buildScales();
                    this.buildSurroundingItems();
                    this.updateLayout();
                    this.resetElements();
                    this.initToolTip();
                    this.update();

                    // After init plugin notification
                    Chart.pluginService.notifyPlugins('afterInit', [this]);

                    return this;
                },

                clear: function clear() {
                    helpers.clear(this.chart);
                    return this;
                },

                stop: function stop() {
                    // Stops any current animation loop occuring
                    Chart.animationService.cancelAnimation(this);
                    return this;
                },

                resize: function resize(silent) {
                    var canvas = this.chart.canvas;
                    var newWidth = helpers.getMaximumWidth(this.chart.canvas);
                    var newHeight = (this.options.maintainAspectRatio && isNaN(this.chart.aspectRatio) === false && isFinite(this.chart.aspectRatio) && this.chart.aspectRatio !== 0) ? newWidth / this.chart.aspectRatio : helpers.getMaximumHeight(this.chart.canvas);

                    var sizeChanged = this.chart.width !== newWidth || this.chart.height !== newHeight;

                    if (!sizeChanged)
                        return this;

                    canvas.width = this.chart.width = newWidth;
                    canvas.height = this.chart.height = newHeight;

                    helpers.retinaScale(this.chart);

                    if (!silent) {
                        this.stop();
                        this.update(this.options.responsiveAnimationDuration);
                    }

                    return this;
                },
                ensureScalesHaveIDs: function ensureScalesHaveIDs() {
                    var defaultXAxisID = 'x-axis-';
                    var defaultYAxisID = 'y-axis-';

                    if (this.options.scales) {
                        if (this.options.scales.xAxes && this.options.scales.xAxes.length) {
                            helpers.each(this.options.scales.xAxes, function(xAxisOptions, index) {
                                xAxisOptions.id = xAxisOptions.id || (defaultXAxisID + index);
                            });
                        }

                        if (this.options.scales.yAxes && this.options.scales.yAxes.length) {
                            // Build the y axes
                            helpers.each(this.options.scales.yAxes, function(yAxisOptions, index) {
                                yAxisOptions.id = yAxisOptions.id || (defaultYAxisID + index);
                            });
                        }
                    }
                },
                buildScales: function buildScales() {
                    // Map of scale ID to scale object so we can lookup later
                    this.scales = {};

                    // Build the x axes
                    if (this.options.scales) {
                        if (this.options.scales.xAxes && this.options.scales.xAxes.length) {
                            helpers.each(this.options.scales.xAxes, function(xAxisOptions, index) {
                                var xType = helpers.getValueOrDefault(xAxisOptions.type, 'category');
                                var ScaleClass = Chart.scaleService.getScaleConstructor(xType);
                                if (ScaleClass) {
                                    var scale = new ScaleClass({
                                        ctx: this.chart.ctx,
                                        options: xAxisOptions,
                                        chart: this,
                                        id: xAxisOptions.id
                                    });

                                    this.scales[scale.id] = scale;
                                }
                            }, this);
                        }

                        if (this.options.scales.yAxes && this.options.scales.yAxes.length) {
                            // Build the y axes
                            helpers.each(this.options.scales.yAxes, function(yAxisOptions, index) {
                                var yType = helpers.getValueOrDefault(yAxisOptions.type, 'linear');
                                var ScaleClass = Chart.scaleService.getScaleConstructor(yType);
                                if (ScaleClass) {
                                    var scale = new ScaleClass({
                                        ctx: this.chart.ctx,
                                        options: yAxisOptions,
                                        chart: this,
                                        id: yAxisOptions.id
                                    });

                                    this.scales[scale.id] = scale;
                                }
                            }, this);
                        }
                    }
                    if (this.options.scale) {
                        // Build radial axes
                        var ScaleClass = Chart.scaleService.getScaleConstructor(this.options.scale.type);
                        if (ScaleClass) {
                            var scale = new ScaleClass({
                                ctx: this.chart.ctx,
                                options: this.options.scale,
                                chart: this
                            });

                            this.scale = scale;

                            this.scales.radialScale = scale;
                        }
                    }

                    Chart.scaleService.addScalesToLayout(this);
                },

                buildSurroundingItems: function() {
                    if (this.options.title) {
                        this.titleBlock = new Chart.Title({
                            ctx: this.chart.ctx,
                            options: this.options.title,
                            chart: this
                        });

                        Chart.layoutService.addBox(this, this.titleBlock);
                    }

                    if (this.options.legend) {
                        this.legend = new Chart.Legend({
                            ctx: this.chart.ctx,
                            options: this.options.legend,
                            chart: this
                        });

                        Chart.layoutService.addBox(this, this.legend);
                    }
                },

                updateLayout: function() {
                    Chart.layoutService.update(this, this.chart.width, this.chart.height);
                },

                buildOrUpdateControllers: function buildOrUpdateControllers() {
                    var types = [];
                    var newControllers = [];

                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        var meta = this.getDatasetMeta(datasetIndex);
                        if (!meta.type) {
                            meta.type = dataset.type || this.config.type;
                        }

                        types.push(meta.type);

                        if (meta.controller) {
                            meta.controller.updateIndex(datasetIndex);
                        } else {
                            meta.controller = new Chart.controllers[meta.type](this, datasetIndex);
                            newControllers.push(meta.controller);
                        }
                    }, this);

                    if (types.length > 1) {
                        for (var i = 1; i < types.length; i++) {
                            if (types[i] !== types[i - 1]) {
                                this.isCombo = true;
                                break;
                            }
                        }
                    }

                    return newControllers;
                },

                resetElements: function resetElements() {
                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        this.getDatasetMeta(datasetIndex).controller.reset();
                    }, this);
                },

                update: function update(animationDuration, lazy) {
                    Chart.pluginService.notifyPlugins('beforeUpdate', [this]);

                    // In case the entire data object changed
                    this.tooltip._data = this.data;

                    // Make sure dataset controllers are updated and new controllers are reset
                    var newControllers = this.buildOrUpdateControllers();

                    // Make sure all dataset controllers have correct meta data counts
                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        this.getDatasetMeta(datasetIndex).controller.buildOrUpdateElements();
                    }, this);

                    Chart.layoutService.update(this, this.chart.width, this.chart.height);

                    // Apply changes to the dataets that require the scales to have been calculated i.e BorderColor chages
                    Chart.pluginService.notifyPlugins('afterScaleUpdate', [this]);

                    // Can only reset the new controllers after the scales have been updated
                    helpers.each(newControllers, function(controller) {
                        controller.reset();
                    });

                    // This will loop through any data and do the appropriate element update for the type
                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        this.getDatasetMeta(datasetIndex).controller.update();
                    }, this);

                    // Do this before render so that any plugins that need final scale updates can use it
                    Chart.pluginService.notifyPlugins('afterUpdate', [this]);

                    this.render(animationDuration, lazy);
                },

                render: function render(duration, lazy) {
                    Chart.pluginService.notifyPlugins('beforeRender', [this]);

                    if (this.options.animation && ((typeof duration !== 'undefined' && duration !== 0) || (typeof duration === 'undefined' && this.options.animation.duration !== 0))) {
                        var animation = new Chart.Animation();
                        animation.numSteps = (duration || this.options.animation.duration) / 16.66; //60 fps
                        animation.easing = this.options.animation.easing;

                        // render function
                        animation.render = function(chartInstance, animationObject) {
                            var easingFunction = helpers.easingEffects[animationObject.easing];
                            var stepDecimal = animationObject.currentStep / animationObject.numSteps;
                            var easeDecimal = easingFunction(stepDecimal);

                            chartInstance.draw(easeDecimal, stepDecimal, animationObject.currentStep);
                        };

                        // user events
                        animation.onAnimationProgress = this.options.animation.onProgress;
                        animation.onAnimationComplete = this.options.animation.onComplete;

                        Chart.animationService.addAnimation(this, animation, duration, lazy);
                    } else {
                        this.draw();
                        if (this.options.animation && this.options.animation.onComplete && this.options.animation.onComplete.call) {
                            this.options.animation.onComplete.call(this);
                        }
                    }
                    return this;
                },

                draw: function(ease) {
                    var easingDecimal = ease || 1;
                    this.clear();

                    Chart.pluginService.notifyPlugins('beforeDraw', [this, easingDecimal]);

                    // Draw all the scales
                    helpers.each(this.boxes, function(box) {
                        box.draw(this.chartArea);
                    }, this);
                    if (this.scale) {
                        this.scale.draw();
                    }

                    // Clip out the chart area so that anything outside does not draw. This is necessary for zoom and pan to function
                    this.chart.ctx.save();
                    this.chart.ctx.beginPath();
                    this.chart.ctx.rect(this.chartArea.left, this.chartArea.top, this.chartArea.right - this.chartArea.left, this.chartArea.bottom - this.chartArea.top);
                    this.chart.ctx.clip();

                    // Draw each dataset via its respective controller (reversed to support proper line stacking)
                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        if (this.isDatasetVisible(datasetIndex)) {
                            this.getDatasetMeta(datasetIndex).controller.draw(ease);
                        }
                    }, this, true);

                    // Restore from the clipping operation
                    this.chart.ctx.restore();

                    // Finally draw the tooltip
                    this.tooltip.transition(easingDecimal).draw();

                    Chart.pluginService.notifyPlugins('afterDraw', [this, easingDecimal]);
                },

                // Get the single element that was clicked on
                // @return : An object containing the dataset index and element index of the matching element. Also contains the rectangle that was draw
                getElementAtEvent: function(e) {
                    var eventPosition = helpers.getRelativePosition(e, this.chart);
                    var elementsArray = [];

                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        if (this.isDatasetVisible(datasetIndex)) {
                            var meta = this.getDatasetMeta(datasetIndex);
                            helpers.each(meta.data, function(element, index) {
                                if (element.inRange(eventPosition.x, eventPosition.y)) {
                                    elementsArray.push(element);
                                    return elementsArray;
                                }
                            });
                        }
                    }, this);

                    return elementsArray;
                },

                getElementsAtEvent: function(e) {
                    var eventPosition = helpers.getRelativePosition(e, this.chart);
                    var elementsArray = [];

                    var found = (function() {
                        if (this.data.datasets) {
                            for (var i = 0; i < this.data.datasets.length; i++) {
                                var meta = this.getDatasetMeta(i);
                                if (this.isDatasetVisible(i)) {
                                    for (var j = 0; j < meta.data.length; j++) {
                                        if (meta.data[j].inRange(eventPosition.x, eventPosition.y)) {
                                            return meta.data[j];
                                        }
                                    }
                                }
                            }
                        }
                    }).call(this);

                    if (!found) {
                        return elementsArray;
                    }

                    helpers.each(this.data.datasets, function(dataset, datasetIndex) {
                        if (this.isDatasetVisible(datasetIndex)) {
                            var meta = this.getDatasetMeta(datasetIndex);
                            elementsArray.push(meta.data[found._index]);
                        }
                    }, this);

                    return elementsArray;
                },

                getDatasetAtEvent: function(e) {
                    var elementsArray = this.getElementAtEvent(e);

                    if (elementsArray.length > 0) {
                        elementsArray = this.getDatasetMeta(elementsArray[0]._datasetIndex).data;
                    }

                    return elementsArray;
                },

                getDatasetMeta: function(datasetIndex) {
                    var dataset = this.data.datasets[datasetIndex];
                    if (!dataset._meta) {
                        dataset._meta = {};
                    }

                    var meta = dataset._meta[this.id];
                    if (!meta) {
                        meta = dataset._meta[this.id] = {
                            type: null,
                            data: [],
                            dataset: null,
                            controller: null,
                            hidden: null, // See isDatasetVisible() comment
                            xAxisID: null,
                            yAxisID: null
                        };
                    }

                    return meta;
                },

                getVisibleDatasetCount: function() {
                    var count = 0;
                    for (var i = 0, ilen = this.data.datasets.length; i < ilen; ++i) {
                        if (this.isDatasetVisible(i)) {
                            count++;
                        }
                    }
                    return count;
                },

                isDatasetVisible: function(datasetIndex) {
                    var meta = this.getDatasetMeta(datasetIndex);

                    // meta.hidden is a per chart dataset hidden flag override with 3 states: if true or false,
                    // the dataset.hidden value is ignored, else if null, the dataset hidden state is returned.
                    return typeof meta.hidden === 'boolean' ? !meta.hidden : !this.data.datasets[datasetIndex].hidden;
                },

                generateLegend: function generateLegend() {
                    return this.options.legendCallback(this);
                },

                destroy: function destroy() {
                    this.clear();
                    helpers.unbindEvents(this, this.events);
                    helpers.removeResizeListener(this.chart.canvas.parentNode);

                    // Reset canvas height/width attributes
                    var canvas = this.chart.canvas;
                    canvas.width = this.chart.width;
                    canvas.height = this.chart.height;

                    // if we scaled the canvas in response to a devicePixelRatio !== 1, we need to undo that transform here
                    if (this.chart.originalDevicePixelRatio !== undefined) {
                        this.chart.ctx.scale(1 / this.chart.originalDevicePixelRatio, 1 / this.chart.originalDevicePixelRatio);
                    }

                    // Reset to the old style since it may have been changed by the device pixel ratio changes
                    canvas.style.width = this.chart.originalCanvasStyleWidth;
                    canvas.style.height = this.chart.originalCanvasStyleHeight;

                    Chart.pluginService.notifyPlugins('destroy', [this]);

                    delete Chart.instances[this.id];
                },

                toBase64Image: function toBase64Image() {
                    return this.chart.canvas.toDataURL.apply(this.chart.canvas, arguments);
                },

                initToolTip: function initToolTip() {
                    this.tooltip = new Chart.Tooltip({
                        _chart: this.chart,
                        _chartInstance: this,
                        _data: this.data,
                        _options: this.options
                    }, this);
                },

                bindEvents: function bindEvents() {
                    helpers.bindEvents(this, this.options.events, function(evt) {
                        this.eventHandler(evt);
                    });
                },
                eventHandler: function eventHandler(e) {
                    this.lastActive = this.lastActive || [];
                    this.lastTooltipActive = this.lastTooltipActive || [];

                    // Find Active Elements for hover and tooltips
                    if (e.type === 'mouseout') {
                        this.active = [];
                        this.tooltipActive = [];
                    } else {

                        var _this = this;
                        var getItemsForMode = function(mode) {
                            switch (mode) {
                                case 'single':
                                    return _this.getElementAtEvent(e);
                                case 'label':
                                    return _this.getElementsAtEvent(e);
                                case 'dataset':
                                    return _this.getDatasetAtEvent(e);
                                default:
                                    return e;
                            }
                        };

                        this.active = getItemsForMode(this.options.hover.mode);
                        this.tooltipActive = getItemsForMode(this.options.tooltips.mode);
                    }

                    // On Hover hook
                    if (this.options.hover.onHover) {
                        this.options.hover.onHover.call(this, this.active);
                    }

                    if (e.type === 'mouseup' || e.type === 'click') {
                        if (this.options.onClick) {
                            this.options.onClick.call(this, e, this.active);
                        }

                        if (this.legend && this.legend.handleEvent) {
                            this.legend.handleEvent(e);
                        }
                    }

                    // Remove styling for last active (even if it may still be active)
                    if (this.lastActive.length) {
                        switch (this.options.hover.mode) {
                            case 'single':
                                this.getDatasetMeta(this.lastActive[0]._datasetIndex).controller.removeHoverStyle(this.lastActive[0], this.lastActive[0]._datasetIndex, this.lastActive[0]._index);
                                break;
                            case 'label':
                            case 'dataset':
                                for (var i = 0; i < this.lastActive.length; i++) {
                                    if (this.lastActive[i])
                                        this.getDatasetMeta(this.lastActive[i]._datasetIndex).controller.removeHoverStyle(this.lastActive[i], this.lastActive[i]._datasetIndex, this.lastActive[i]._index);
                                }
                                break;
                            default:
                                // Don't change anything
                        }
                    }

                    // Built in hover styling
                    if (this.active.length && this.options.hover.mode) {
                        switch (this.options.hover.mode) {
                            case 'single':
                                this.getDatasetMeta(this.active[0]._datasetIndex).controller.setHoverStyle(this.active[0]);
                                break;
                            case 'label':
                            case 'dataset':
                                for (var j = 0; j < this.active.length; j++) {
                                    if (this.active[j])
                                        this.getDatasetMeta(this.active[j]._datasetIndex).controller.setHoverStyle(this.active[j]);
                                }
                                break;
                            default:
                                // Don't change anything
                        }
                    }


                    // Built in Tooltips
                    if (this.options.tooltips.enabled || this.options.tooltips.custom) {

                        // The usual updates
                        this.tooltip.initialize();
                        this.tooltip._active = this.tooltipActive;
                        this.tooltip.update(true);
                    }

                    // Hover animations
                    this.tooltip.pivot();

                    if (!this.animating) {
                        var changed;

                        helpers.each(this.active, function(element, index) {
                            if (element !== this.lastActive[index]) {
                                changed = true;
                            }
                        }, this);

                        helpers.each(this.tooltipActive, function(element, index) {
                            if (element !== this.lastTooltipActive[index]) {
                                changed = true;
                            }
                        }, this);

                        // If entering, leaving, or changing elements, animate the change via pivot
                        if ((this.lastActive.length !== this.active.length) ||
                            (this.lastTooltipActive.length !== this.tooltipActive.length) ||
                            changed) {

                            this.stop();

                            if (this.options.tooltips.enabled || this.options.tooltips.custom) {
                                this.tooltip.update(true);
                            }

                            // We only need to render at this point. Updating will cause scales to be recomputed generating flicker & using more
                            // memory than necessary.
                            this.render(this.options.hover.animationDuration, true);
                        }
                    }

                    // Remember Last Actives
                    this.lastActive = this.active;
                    this.lastTooltipActive = this.tooltipActive;
                    return this;
                }
            });
        };

    }, {}],
    23: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;
            var noop = helpers.noop;

            // Base class for all dataset controllers (line, bar, etc)
            Chart.DatasetController = function(chart, datasetIndex) {
                this.initialize.call(this, chart, datasetIndex);
            };

            helpers.extend(Chart.DatasetController.prototype, {
                initialize: function(chart, datasetIndex) {
                    this.chart = chart;
                    this.index = datasetIndex;
                    this.linkScales();
                    this.addElements();
                },
                updateIndex: function(datasetIndex) {
                    this.index = datasetIndex;
                },

                linkScales: function() {
                    var meta = this.getMeta();
                    var dataset = this.getDataset();

                    if (meta.xAxisID === null) {
                        meta.xAxisID = dataset.xAxisID || this.chart.options.scales.xAxes[0].id;
                    }
                    if (meta.yAxisID === null) {
                        meta.yAxisID = dataset.yAxisID || this.chart.options.scales.yAxes[0].id;
                    }
                },

                getDataset: function() {
                    return this.chart.data.datasets[this.index];
                },

                getMeta: function() {
                    return this.chart.getDatasetMeta(this.index);
                },

                getScaleForId: function(scaleID) {
                    return this.chart.scales[scaleID];
                },

                reset: function() {
                    this.update(true);
                },

                buildOrUpdateElements: function buildOrUpdateElements() {
                    // Handle the number of data points changing
                    var meta = this.getMeta(),
                        md = meta.data,
                        numData = this.getDataset().data.length,
                        numMetaData = md.length;

                    // Make sure that we handle number of datapoints changing
                    if (numData < numMetaData) {
                        // Remove excess bars for data points that have been removed
                        md.splice(numData, numMetaData - numData);
                    } else if (numData > numMetaData) {
                        // Add new elements
                        for (var index = numMetaData; index < numData; ++index) {
                            this.addElementAndReset(index);
                        }
                    }
                },

                // Controllers should implement the following
                addElements: noop,
                addElementAndReset: noop,
                draw: noop,
                removeHoverStyle: noop,
                setHoverStyle: noop,
                update: noop
            });

            Chart.DatasetController.extend = helpers.inherits;
        };
    }, {}],
    24: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.elements = {};

            Chart.Element = function(configuration) {
                helpers.extend(this, configuration);
                this.initialize.apply(this, arguments);
            };
            helpers.extend(Chart.Element.prototype, {
                initialize: function() {
                    this.hidden = false;
                },
                pivot: function() {
                    if (!this._view) {
                        this._view = helpers.clone(this._model);
                    }
                    this._start = helpers.clone(this._view);
                    return this;
                },
                transition: function(ease) {
                    if (!this._view) {
                        this._view = helpers.clone(this._model);
                    }

                    // No animation -> No Transition
                    if (ease === 1) {
                        this._view = this._model;
                        this._start = null;
                        return this;
                    }

                    if (!this._start) {
                        this.pivot();
                    }

                    helpers.each(this._model, function(value, key) {

                        if (key[0] === '_' || !this._model.hasOwnProperty(key)) {
                            // Only non-underscored properties
                        }

                        // Init if doesn't exist
                        else if (!this._view.hasOwnProperty(key)) {
                            if (typeof value === 'number' && !isNaN(this._view[key])) {
                                this._view[key] = value * ease;
                            } else {
                                this._view[key] = value;
                            }
                        }

                        // No unnecessary computations
                        else if (value === this._view[key]) {
                            // It's the same! Woohoo!
                        }

                        // Color transitions if possible
                        else if (typeof value === 'string') {
                            try {
                                var color = helpers.color(this._start[key]).mix(helpers.color(this._model[key]), ease);
                                this._view[key] = color.rgbString();
                            } catch (err) {
                                this._view[key] = value;
                            }
                        }
                        // Number transitions
                        else if (typeof value === 'number') {
                            var startVal = this._start[key] !== undefined && isNaN(this._start[key]) === false ? this._start[key] : 0;
                            this._view[key] = ((this._model[key] - startVal) * ease) + startVal;
                        }
                        // Everything else
                        else {
                            this._view[key] = value;
                        }
                    }, this);

                    return this;
                },
                tooltipPosition: function() {
                    return {
                        x: this._model.x,
                        y: this._model.y
                    };
                },
                hasValue: function() {
                    return helpers.isNumber(this._model.x) && helpers.isNumber(this._model.y);
                }
            });

            Chart.Element.extend = helpers.inherits;

        };

    }, {}],
    25: [function(require, module, exports) {
        /*global window: false */
        /*global document: false */
        "use strict";

        var color = require('chartjs-color');

        module.exports = function(Chart) {

            //Global Chart helpers object for utility methods and classes
            var helpers = Chart.helpers = {};

            //-- Basic js utility methods
            helpers.each = function(loopable, callback, self, reverse) {
                // Check to see if null or undefined firstly.
                var i, len;
                if (helpers.isArray(loopable)) {
                    len = loopable.length;
                    if (reverse) {
                        for (i = len - 1; i >= 0; i--) {
                            callback.call(self, loopable[i], i);
                        }
                    } else {
                        for (i = 0; i < len; i++) {
                            callback.call(self, loopable[i], i);
                        }
                    }
                } else if (typeof loopable === 'object') {
                    var keys = Object.keys(loopable);
                    len = keys.length;
                    for (i = 0; i < len; i++) {
                        callback.call(self, loopable[keys[i]], keys[i]);
                    }
                }
            };
            helpers.clone = function(obj) {
                var objClone = {};
                helpers.each(obj, function(value, key) {
                    if (obj.hasOwnProperty(key)) {
                        if (helpers.isArray(value)) {
                            objClone[key] = value.slice(0);
                        } else if (typeof value === 'object' && value !== null) {
                            objClone[key] = helpers.clone(value);
                        } else {
                            objClone[key] = value;
                        }
                    }
                });
                return objClone;
            };
            helpers.extend = function(base) {
                var len = arguments.length;
                var additionalArgs = [];
                for (var i = 1; i < len; i++) {
                    additionalArgs.push(arguments[i]);
                }
                helpers.each(additionalArgs, function(extensionObject) {
                    helpers.each(extensionObject, function(value, key) {
                        if (extensionObject.hasOwnProperty(key)) {
                            base[key] = value;
                        }
                    });
                });
                return base;
            };
            // Need a special merge function to chart configs since they are now grouped
            helpers.configMerge = function(_base) {
                var base = helpers.clone(_base);
                helpers.each(Array.prototype.slice.call(arguments, 1), function(extension) {
                    helpers.each(extension, function(value, key) {
                        if (extension.hasOwnProperty(key)) {
                            if (key === 'scales') {
                                // Scale config merging is complex. Add out own function here for that
                                base[key] = helpers.scaleMerge(base.hasOwnProperty(key) ? base[key] : {}, value);

                            } else if (key === 'scale') {
                                // Used in polar area & radar charts since there is only one scale
                                base[key] = helpers.configMerge(base.hasOwnProperty(key) ? base[key] : {}, Chart.scaleService.getScaleDefaults(value.type), value);
                            } else if (base.hasOwnProperty(key) && helpers.isArray(base[key]) && helpers.isArray(value)) {
                                // In this case we have an array of objects replacing another array. Rather than doing a strict replace,
                                // merge. This allows easy scale option merging
                                var baseArray = base[key];

                                helpers.each(value, function(valueObj, index) {

                                    if (index < baseArray.length) {
                                        if (typeof baseArray[index] === 'object' && baseArray[index] !== null && typeof valueObj === 'object' && valueObj !== null) {
                                            // Two objects are coming together. Do a merge of them.
                                            baseArray[index] = helpers.configMerge(baseArray[index], valueObj);
                                        } else {
                                            // Just overwrite in this case since there is nothing to merge
                                            baseArray[index] = valueObj;
                                        }
                                    } else {
                                        baseArray.push(valueObj); // nothing to merge
                                    }
                                });

                            } else if (base.hasOwnProperty(key) && typeof base[key] === "object" && base[key] !== null && typeof value === "object") {
                                // If we are overwriting an object with an object, do a merge of the properties.
                                base[key] = helpers.configMerge(base[key], value);

                            } else {
                                // can just overwrite the value in this case
                                base[key] = value;
                            }
                        }
                    });
                });

                return base;
            };
            helpers.extendDeep = function(_base) {
                return _extendDeep.apply(this, arguments);

                function _extendDeep(dst) {
                    helpers.each(arguments, function(obj) {
                        if (obj !== dst) {
                            helpers.each(obj, function(value, key) {
                                if (dst[key] && dst[key].constructor && dst[key].constructor === Object) {
                                    _extendDeep(dst[key], value);
                                } else {
                                    dst[key] = value;
                                }
                            });
                        }
                    });
                    return dst;
                }
            };
            helpers.scaleMerge = function(_base, extension) {
                var base = helpers.clone(_base);

                helpers.each(extension, function(value, key) {
                    if (extension.hasOwnProperty(key)) {
                        if (key === 'xAxes' || key === 'yAxes') {
                            // These properties are arrays of items
                            if (base.hasOwnProperty(key)) {
                                helpers.each(value, function(valueObj, index) {
                                    var axisType = helpers.getValueOrDefault(valueObj.type, key === 'xAxes' ? 'category' : 'linear');
                                    var axisDefaults = Chart.scaleService.getScaleDefaults(axisType);
                                    if (index >= base[key].length || !base[key][index].type) {
                                        base[key].push(helpers.configMerge(axisDefaults, valueObj));
                                    } else if (valueObj.type && valueObj.type !== base[key][index].type) {
                                        // Type changed. Bring in the new defaults before we bring in valueObj so that valueObj can override the correct scale defaults
                                        base[key][index] = helpers.configMerge(base[key][index], axisDefaults, valueObj);
                                    } else {
                                        // Type is the same
                                        base[key][index] = helpers.configMerge(base[key][index], valueObj);
                                    }
                                });
                            } else {
                                base[key] = [];
                                helpers.each(value, function(valueObj) {
                                    var axisType = helpers.getValueOrDefault(valueObj.type, key === 'xAxes' ? 'category' : 'linear');
                                    base[key].push(helpers.configMerge(Chart.scaleService.getScaleDefaults(axisType), valueObj));
                                });
                            }
                        } else if (base.hasOwnProperty(key) && typeof base[key] === "object" && base[key] !== null && typeof value === "object") {
                            // If we are overwriting an object with an object, do a merge of the properties.
                            base[key] = helpers.configMerge(base[key], value);

                        } else {
                            // can just overwrite the value in this case
                            base[key] = value;
                        }
                    }
                });

                return base;
            };
            helpers.getValueAtIndexOrDefault = function(value, index, defaultValue) {
                if (value === undefined || value === null) {
                    return defaultValue;
                }

                if (helpers.isArray(value)) {
                    return index < value.length ? value[index] : defaultValue;
                }

                return value;
            };
            helpers.getValueOrDefault = function(value, defaultValue) {
                return value === undefined ? defaultValue : value;
            };
            helpers.indexOf = function(arrayToSearch, item) {
                if (Array.prototype.indexOf) {
                    return arrayToSearch.indexOf(item);
                } else {
                    for (var i = 0; i < arrayToSearch.length; i++) {
                        if (arrayToSearch[i] === item)
                            return i;
                    }
                    return -1;
                }
            };
            helpers.where = function(collection, filterCallback) {
                var filtered = [];

                helpers.each(collection, function(item) {
                    if (filterCallback(item)) {
                        filtered.push(item);
                    }
                });

                return filtered;
            };
            helpers.findIndex = function(arrayToSearch, callback, thisArg) {
                var index = -1;
                if (Array.prototype.findIndex) {
                    index = arrayToSearch.findIndex(callback, thisArg);
                } else {
                    for (var i = 0; i < arrayToSearch.length; ++i) {
                        thisArg = thisArg !== undefined ? thisArg : arrayToSearch;

                        if (callback.call(thisArg, arrayToSearch[i], i, arrayToSearch)) {
                            index = i;
                            break;
                        }
                    }
                }

                return index;
            };
            helpers.findNextWhere = function(arrayToSearch, filterCallback, startIndex) {
                // Default to start of the array
                if (startIndex === undefined || startIndex === null) {
                    startIndex = -1;
                }
                for (var i = startIndex + 1; i < arrayToSearch.length; i++) {
                    var currentItem = arrayToSearch[i];
                    if (filterCallback(currentItem)) {
                        return currentItem;
                    }
                }
            };
            helpers.findPreviousWhere = function(arrayToSearch, filterCallback, startIndex) {
                // Default to end of the array
                if (startIndex === undefined || startIndex === null) {
                    startIndex = arrayToSearch.length;
                }
                for (var i = startIndex - 1; i >= 0; i--) {
                    var currentItem = arrayToSearch[i];
                    if (filterCallback(currentItem)) {
                        return currentItem;
                    }
                }
            };
            helpers.inherits = function(extensions) {
                //Basic javascript inheritance based on the model created in Backbone.js
                var parent = this;
                var ChartElement = (extensions && extensions.hasOwnProperty("constructor")) ? extensions.constructor : function() {
                    return parent.apply(this, arguments);
                };

                var Surrogate = function() {
                    this.constructor = ChartElement;
                };
                Surrogate.prototype = parent.prototype;
                ChartElement.prototype = new Surrogate();

                ChartElement.extend = helpers.inherits;

                if (extensions) {
                    helpers.extend(ChartElement.prototype, extensions);
                }

                ChartElement.__super__ = parent.prototype;

                return ChartElement;
            };
            helpers.noop = function() {};
            helpers.uid = (function() {
                var id = 0;
                return function() {
                    return id++;
                };
            })();
            helpers.warn = function(str) {
                //Method for warning of errors
                if (console && typeof console.warn === "function") {
                    console.warn(str);
                }
            };
            //-- Math methods
            helpers.isNumber = function(n) {
                return !isNaN(parseFloat(n)) && isFinite(n);
            };
            helpers.almostEquals = function(x, y, epsilon) {
                return Math.abs(x - y) < epsilon;
            };
            helpers.max = function(array) {
                return array.reduce(function(max, value) {
                    if (!isNaN(value)) {
                        return Math.max(max, value);
                    } else {
                        return max;
                    }
                }, Number.NEGATIVE_INFINITY);
            };
            helpers.min = function(array) {
                return array.reduce(function(min, value) {
                    if (!isNaN(value)) {
                        return Math.min(min, value);
                    } else {
                        return min;
                    }
                }, Number.POSITIVE_INFINITY);
            };
            helpers.sign = function(x) {
                if (Math.sign) {
                    return Math.sign(x);
                } else {
                    x = +x; // convert to a number
                    if (x === 0 || isNaN(x)) {
                        return x;
                    }
                    return x > 0 ? 1 : -1;
                }
            };
            helpers.log10 = function(x) {
                if (Math.log10) {
                    return Math.log10(x);
                } else {
                    return Math.log(x) / Math.LN10;
                }
            };
            helpers.toRadians = function(degrees) {
                return degrees * (Math.PI / 180);
            };
            helpers.toDegrees = function(radians) {
                return radians * (180 / Math.PI);
            };
            // Gets the angle from vertical upright to the point about a centre.
            helpers.getAngleFromPoint = function(centrePoint, anglePoint) {
                var distanceFromXCenter = anglePoint.x - centrePoint.x,
                    distanceFromYCenter = anglePoint.y - centrePoint.y,
                    radialDistanceFromCenter = Math.sqrt(distanceFromXCenter * distanceFromXCenter + distanceFromYCenter * distanceFromYCenter);

                var angle = Math.atan2(distanceFromYCenter, distanceFromXCenter);

                if (angle < (-0.5 * Math.PI)) {
                    angle += 2.0 * Math.PI; // make sure the returned angle is in the range of (-PI/2, 3PI/2]
                }

                return {
                    angle: angle,
                    distance: radialDistanceFromCenter
                };
            };
            helpers.aliasPixel = function(pixelWidth) {
                return (pixelWidth % 2 === 0) ? 0 : 0.5;
            };
            helpers.splineCurve = function(firstPoint, middlePoint, afterPoint, t) {
                //Props to Rob Spencer at scaled innovation for his post on splining between points
                //http://scaledinnovation.com/analytics/splines/aboutSplines.html

                // This function must also respect "skipped" points

                var previous = firstPoint.skip ? middlePoint : firstPoint,
                    current = middlePoint,
                    next = afterPoint.skip ? middlePoint : afterPoint;

                var d01 = Math.sqrt(Math.pow(current.x - previous.x, 2) + Math.pow(current.y - previous.y, 2));
                var d12 = Math.sqrt(Math.pow(next.x - current.x, 2) + Math.pow(next.y - current.y, 2));

                var s01 = d01 / (d01 + d12);
                var s12 = d12 / (d01 + d12);

                // If all points are the same, s01 & s02 will be inf
                s01 = isNaN(s01) ? 0 : s01;
                s12 = isNaN(s12) ? 0 : s12;

                var fa = t * s01; // scaling factor for triangle Ta
                var fb = t * s12;

                return {
                    previous: {
                        x: current.x - fa * (next.x - previous.x),
                        y: current.y - fa * (next.y - previous.y)
                    },
                    next: {
                        x: current.x + fb * (next.x - previous.x),
                        y: current.y + fb * (next.y - previous.y)
                    }
                };
            };
            helpers.nextItem = function(collection, index, loop) {
                if (loop) {
                    return index >= collection.length - 1 ? collection[0] : collection[index + 1];
                }

                return index >= collection.length - 1 ? collection[collection.length - 1] : collection[index + 1];
            };
            helpers.previousItem = function(collection, index, loop) {
                if (loop) {
                    return index <= 0 ? collection[collection.length - 1] : collection[index - 1];
                }
                return index <= 0 ? collection[0] : collection[index - 1];
            };
            // Implementation of the nice number algorithm used in determining where axis labels will go
            helpers.niceNum = function(range, round) {
                var exponent = Math.floor(helpers.log10(range));
                var fraction = range / Math.pow(10, exponent);
                var niceFraction;

                if (round) {
                    if (fraction < 1.5) {
                        niceFraction = 1;
                    } else if (fraction < 3) {
                        niceFraction = 2;
                    } else if (fraction < 7) {
                        niceFraction = 5;
                    } else {
                        niceFraction = 10;
                    }
                } else {
                    if (fraction <= 1.0) {
                        niceFraction = 1;
                    } else if (fraction <= 2) {
                        niceFraction = 2;
                    } else if (fraction <= 5) {
                        niceFraction = 5;
                    } else {
                        niceFraction = 10;
                    }
                }

                return niceFraction * Math.pow(10, exponent);
            };
            //Easing functions adapted from Robert Penner's easing equations
            //http://www.robertpenner.com/easing/
            var easingEffects = helpers.easingEffects = {
                linear: function(t) {
                    return t;
                },
                easeInQuad: function(t) {
                    return t * t;
                },
                easeOutQuad: function(t) {
                    return -1 * t * (t - 2);
                },
                easeInOutQuad: function(t) {
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * t * t;
                    }
                    return -1 / 2 * ((--t) * (t - 2) - 1);
                },
                easeInCubic: function(t) {
                    return t * t * t;
                },
                easeOutCubic: function(t) {
                    return 1 * ((t = t / 1 - 1) * t * t + 1);
                },
                easeInOutCubic: function(t) {
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * t * t * t;
                    }
                    return 1 / 2 * ((t -= 2) * t * t + 2);
                },
                easeInQuart: function(t) {
                    return t * t * t * t;
                },
                easeOutQuart: function(t) {
                    return -1 * ((t = t / 1 - 1) * t * t * t - 1);
                },
                easeInOutQuart: function(t) {
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * t * t * t * t;
                    }
                    return -1 / 2 * ((t -= 2) * t * t * t - 2);
                },
                easeInQuint: function(t) {
                    return 1 * (t /= 1) * t * t * t * t;
                },
                easeOutQuint: function(t) {
                    return 1 * ((t = t / 1 - 1) * t * t * t * t + 1);
                },
                easeInOutQuint: function(t) {
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * t * t * t * t * t;
                    }
                    return 1 / 2 * ((t -= 2) * t * t * t * t + 2);
                },
                easeInSine: function(t) {
                    return -1 * Math.cos(t / 1 * (Math.PI / 2)) + 1;
                },
                easeOutSine: function(t) {
                    return 1 * Math.sin(t / 1 * (Math.PI / 2));
                },
                easeInOutSine: function(t) {
                    return -1 / 2 * (Math.cos(Math.PI * t / 1) - 1);
                },
                easeInExpo: function(t) {
                    return (t === 0) ? 1 : 1 * Math.pow(2, 10 * (t / 1 - 1));
                },
                easeOutExpo: function(t) {
                    return (t === 1) ? 1 : 1 * (-Math.pow(2, -10 * t / 1) + 1);
                },
                easeInOutExpo: function(t) {
                    if (t === 0) {
                        return 0;
                    }
                    if (t === 1) {
                        return 1;
                    }
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * Math.pow(2, 10 * (t - 1));
                    }
                    return 1 / 2 * (-Math.pow(2, -10 * --t) + 2);
                },
                easeInCirc: function(t) {
                    if (t >= 1) {
                        return t;
                    }
                    return -1 * (Math.sqrt(1 - (t /= 1) * t) - 1);
                },
                easeOutCirc: function(t) {
                    return 1 * Math.sqrt(1 - (t = t / 1 - 1) * t);
                },
                easeInOutCirc: function(t) {
                    if ((t /= 1 / 2) < 1) {
                        return -1 / 2 * (Math.sqrt(1 - t * t) - 1);
                    }
                    return 1 / 2 * (Math.sqrt(1 - (t -= 2) * t) + 1);
                },
                easeInElastic: function(t) {
                    var s = 1.70158;
                    var p = 0;
                    var a = 1;
                    if (t === 0) {
                        return 0;
                    }
                    if ((t /= 1) === 1) {
                        return 1;
                    }
                    if (!p) {
                        p = 1 * 0.3;
                    }
                    if (a < Math.abs(1)) {
                        a = 1;
                        s = p / 4;
                    } else {
                        s = p / (2 * Math.PI) * Math.asin(1 / a);
                    }
                    return -(a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * 1 - s) * (2 * Math.PI) / p));
                },
                easeOutElastic: function(t) {
                    var s = 1.70158;
                    var p = 0;
                    var a = 1;
                    if (t === 0) {
                        return 0;
                    }
                    if ((t /= 1) === 1) {
                        return 1;
                    }
                    if (!p) {
                        p = 1 * 0.3;
                    }
                    if (a < Math.abs(1)) {
                        a = 1;
                        s = p / 4;
                    } else {
                        s = p / (2 * Math.PI) * Math.asin(1 / a);
                    }
                    return a * Math.pow(2, -10 * t) * Math.sin((t * 1 - s) * (2 * Math.PI) / p) + 1;
                },
                easeInOutElastic: function(t) {
                    var s = 1.70158;
                    var p = 0;
                    var a = 1;
                    if (t === 0) {
                        return 0;
                    }
                    if ((t /= 1 / 2) === 2) {
                        return 1;
                    }
                    if (!p) {
                        p = 1 * (0.3 * 1.5);
                    }
                    if (a < Math.abs(1)) {
                        a = 1;
                        s = p / 4;
                    } else {
                        s = p / (2 * Math.PI) * Math.asin(1 / a);
                    }
                    if (t < 1) {
                        return -0.5 * (a * Math.pow(2, 10 * (t -= 1)) * Math.sin((t * 1 - s) * (2 * Math.PI) / p));
                    }
                    return a * Math.pow(2, -10 * (t -= 1)) * Math.sin((t * 1 - s) * (2 * Math.PI) / p) * 0.5 + 1;
                },
                easeInBack: function(t) {
                    var s = 1.70158;
                    return 1 * (t /= 1) * t * ((s + 1) * t - s);
                },
                easeOutBack: function(t) {
                    var s = 1.70158;
                    return 1 * ((t = t / 1 - 1) * t * ((s + 1) * t + s) + 1);
                },
                easeInOutBack: function(t) {
                    var s = 1.70158;
                    if ((t /= 1 / 2) < 1) {
                        return 1 / 2 * (t * t * (((s *= (1.525)) + 1) * t - s));
                    }
                    return 1 / 2 * ((t -= 2) * t * (((s *= (1.525)) + 1) * t + s) + 2);
                },
                easeInBounce: function(t) {
                    return 1 - easingEffects.easeOutBounce(1 - t);
                },
                easeOutBounce: function(t) {
                    if ((t /= 1) < (1 / 2.75)) {
                        return 1 * (7.5625 * t * t);
                    } else if (t < (2 / 2.75)) {
                        return 1 * (7.5625 * (t -= (1.5 / 2.75)) * t + 0.75);
                    } else if (t < (2.5 / 2.75)) {
                        return 1 * (7.5625 * (t -= (2.25 / 2.75)) * t + 0.9375);
                    } else {
                        return 1 * (7.5625 * (t -= (2.625 / 2.75)) * t + 0.984375);
                    }
                },
                easeInOutBounce: function(t) {
                    if (t < 1 / 2) {
                        return easingEffects.easeInBounce(t * 2) * 0.5;
                    }
                    return easingEffects.easeOutBounce(t * 2 - 1) * 0.5 + 1 * 0.5;
                }
            };
            //Request animation polyfill - http://www.paulirish.com/2011/requestanimationframe-for-smart-animating/
            helpers.requestAnimFrame = (function() {
                return window.requestAnimationFrame ||
                    window.webkitRequestAnimationFrame ||
                    window.mozRequestAnimationFrame ||
                    window.oRequestAnimationFrame ||
                    window.msRequestAnimationFrame ||
                    function(callback) {
                        return window.setTimeout(callback, 1000 / 60);
                    };
            })();
            helpers.cancelAnimFrame = (function() {
                return window.cancelAnimationFrame ||
                    window.webkitCancelAnimationFrame ||
                    window.mozCancelAnimationFrame ||
                    window.oCancelAnimationFrame ||
                    window.msCancelAnimationFrame ||
                    function(callback) {
                        return window.clearTimeout(callback, 1000 / 60);
                    };
            })();
            //-- DOM methods
            helpers.getRelativePosition = function(evt, chart) {
                var mouseX, mouseY;
                var e = evt.originalEvent || evt,
                    canvas = evt.currentTarget || evt.srcElement,
                    boundingRect = canvas.getBoundingClientRect();

                if (e.touches && e.touches.length > 0) {
                    mouseX = e.touches[0].clientX;
                    mouseY = e.touches[0].clientY;

                } else {
                    mouseX = e.clientX;
                    mouseY = e.clientY;
                }

                // Scale mouse coordinates into canvas coordinates
                // by following the pattern laid out by 'jerryj' in the comments of
                // http://www.html5canvastutorials.com/advanced/html5-canvas-mouse-coordinates/
                var paddingLeft = parseFloat(helpers.getStyle(canvas, 'padding-left'));
                var paddingTop = parseFloat(helpers.getStyle(canvas, 'padding-top'));
                var paddingRight = parseFloat(helpers.getStyle(canvas, 'padding-right'));
                var paddingBottom = parseFloat(helpers.getStyle(canvas, 'padding-bottom'));
                var width = boundingRect.right - boundingRect.left - paddingLeft - paddingRight;
                var height = boundingRect.bottom - boundingRect.top - paddingTop - paddingBottom;

                // We divide by the current device pixel ratio, because the canvas is scaled up by that amount in each direction. However
                // the backend model is in unscaled coordinates. Since we are going to deal with our model coordinates, we go back here
                mouseX = Math.round((mouseX - boundingRect.left - paddingLeft) / (width) * canvas.width / chart.currentDevicePixelRatio);
                mouseY = Math.round((mouseY - boundingRect.top - paddingTop) / (height) * canvas.height / chart.currentDevicePixelRatio);

                return {
                    x: mouseX,
                    y: mouseY
                };

            };
            helpers.addEvent = function(node, eventType, method) {
                if (node.addEventListener) {
                    node.addEventListener(eventType, method);
                } else if (node.attachEvent) {
                    node.attachEvent("on" + eventType, method);
                } else {
                    node["on" + eventType] = method;
                }
            };
            helpers.removeEvent = function(node, eventType, handler) {
                if (node.removeEventListener) {
                    node.removeEventListener(eventType, handler, false);
                } else if (node.detachEvent) {
                    node.detachEvent("on" + eventType, handler);
                } else {
                    node["on" + eventType] = helpers.noop;
                }
            };
            helpers.bindEvents = function(chartInstance, arrayOfEvents, handler) {
                // Create the events object if it's not already present
                if (!chartInstance.events)
                    chartInstance.events = {};

                helpers.each(arrayOfEvents, function(eventName) {
                    chartInstance.events[eventName] = function() {
                        handler.apply(chartInstance, arguments);
                    };
                    helpers.addEvent(chartInstance.chart.canvas, eventName, chartInstance.events[eventName]);
                });
            };
            helpers.unbindEvents = function(chartInstance, arrayOfEvents) {
                helpers.each(arrayOfEvents, function(handler, eventName) {
                    helpers.removeEvent(chartInstance.chart.canvas, eventName, handler);
                });
            };

            // Private helper function to convert max-width/max-height values that may be percentages into a number
            function parseMaxStyle(styleValue, node, parentProperty) {
                var valueInPixels;
                if (typeof(styleValue) === 'string') {
                    valueInPixels = parseInt(styleValue, 10);

                    if (styleValue.indexOf('%') != -1) {
                        // percentage * size in dimension
                        valueInPixels = valueInPixels / 100 * node.parentNode[parentProperty];
                    }
                } else {
                    valueInPixels = styleValue;
                }

                return valueInPixels;
            }

            // Private helper to get a constraint dimension
            // @param domNode : the node to check the constraint on
            // @param maxStyle : the style that defines the maximum for the direction we are using (max-width / max-height)
            // @param percentageProperty : property of parent to use when calculating width as a percentage
            function getConstraintDimension(domNode, maxStyle, percentageProperty) {
                var constrainedDimension;
                var constrainedNode = document.defaultView.getComputedStyle(domNode)[maxStyle];
                var constrainedContainer = document.defaultView.getComputedStyle(domNode.parentNode)[maxStyle];
                var hasCNode = constrainedNode !== null && constrainedNode !== "none";
                var hasCContainer = constrainedContainer !== null && constrainedContainer !== "none";

                if (hasCNode || hasCContainer) {
                    constrainedDimension = Math.min((hasCNode ? parseMaxStyle(constrainedNode, domNode, percentageProperty) : Number.POSITIVE_INFINITY), (hasCContainer ? parseMaxStyle(constrainedContainer, domNode.parentNode, percentageProperty) : Number.POSITIVE_INFINITY));
                }
                return constrainedDimension;
            }
            // returns Number or undefined if no constraint
            helpers.getConstraintWidth = function(domNode) {
                return getConstraintDimension(domNode, 'max-width', 'clientWidth');
            };
            // returns Number or undefined if no constraint
            helpers.getConstraintHeight = function(domNode) {
                return getConstraintDimension(domNode, 'max-height', 'clientHeight');
            };
            helpers.getMaximumWidth = function(domNode) {
                var container = domNode.parentNode;
                var padding = parseInt(helpers.getStyle(container, 'padding-left')) + parseInt(helpers.getStyle(container, 'padding-right'));

                var w = container.clientWidth - padding;
                var cw = helpers.getConstraintWidth(domNode);
                if (cw !== undefined) {
                    w = Math.min(w, cw);
                }

                return w;
            };
            helpers.getMaximumHeight = function(domNode) {
                var container = domNode.parentNode;
                var padding = parseInt(helpers.getStyle(container, 'padding-top')) + parseInt(helpers.getStyle(container, 'padding-bottom'));

                var h = container.clientHeight - padding;
                var ch = helpers.getConstraintHeight(domNode);
                if (ch !== undefined) {
                    h = Math.min(h, ch);
                }

                return h;
            };
            helpers.getStyle = function(el, property) {
                return el.currentStyle ?
                    el.currentStyle[property] :
                    document.defaultView.getComputedStyle(el, null).getPropertyValue(property);
            };
            helpers.retinaScale = function(chart) {
                var ctx = chart.ctx;
                var width = chart.canvas.width;
                var height = chart.canvas.height;
                var pixelRatio = chart.currentDevicePixelRatio = window.devicePixelRatio || 1;

                if (pixelRatio !== 1) {
                    ctx.canvas.height = height * pixelRatio;
                    ctx.canvas.width = width * pixelRatio;
                    ctx.scale(pixelRatio, pixelRatio);

                    // Store the device pixel ratio so that we can go backwards in `destroy`.
                    // The devicePixelRatio changes with zoom, so there are no guarantees that it is the same
                    // when destroy is called
                    chart.originalDevicePixelRatio = chart.originalDevicePixelRatio || pixelRatio;
                }

                ctx.canvas.style.width = width + 'px';
                ctx.canvas.style.height = height + 'px';
            };
            //-- Canvas methods
            helpers.clear = function(chart) {
                chart.ctx.clearRect(0, 0, chart.width, chart.height);
            };
            helpers.fontString = function(pixelSize, fontStyle, fontFamily) {
                return fontStyle + " " + pixelSize + "px " + fontFamily;
            };
            helpers.longestText = function(ctx, font, arrayOfStrings, cache) {
                cache = cache || {};
                cache.data = cache.data || {};
                cache.garbageCollect = cache.garbageCollect || [];

                if (cache.font !== font) {
                    cache.data = {};
                    cache.garbageCollect = [];
                    cache.font = font;
                }

                ctx.font = font;
                var longest = 0;
                helpers.each(arrayOfStrings, function(string) {
                    // Undefined strings should not be measured
                    if (string !== undefined && string !== null) {
                        var textWidth = cache.data[string];
                        if (!textWidth) {
                            textWidth = cache.data[string] = ctx.measureText(string).width;
                            cache.garbageCollect.push(string);
                        }

                        if (textWidth > longest) {
                            longest = textWidth;
                        }
                    }
                });

                var gcLen = cache.garbageCollect.length / 2;
                if (gcLen > arrayOfStrings.length) {
                    for (var i = 0; i < gcLen; i++) {
                        delete cache.data[cache.garbageCollect[i]];
                    }
                    cache.garbageCollect.splice(0, gcLen);
                }

                return longest;
            };
            helpers.drawRoundedRectangle = function(ctx, x, y, width, height, radius) {
                ctx.beginPath();
                ctx.moveTo(x + radius, y);
                ctx.lineTo(x + width - radius, y);
                ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
                ctx.lineTo(x + width, y + height - radius);
                ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
                ctx.lineTo(x + radius, y + height);
                ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
                ctx.lineTo(x, y + radius);
                ctx.quadraticCurveTo(x, y, x + radius, y);
                ctx.closePath();
            };
            helpers.color = function(c) {
                if (!color) {
                    console.log('Color.js not found!');
                    return c;
                }

                /* global CanvasGradient */
                if (c instanceof CanvasGradient) {
                    return color(Chart.defaults.global.defaultColor);
                }

                return color(c);
            };
            helpers.addResizeListener = function(node, callback) {
                // Hide an iframe before the node
                var hiddenIframe = document.createElement('iframe');
                var hiddenIframeClass = 'chartjs-hidden-iframe';

                if (hiddenIframe.classlist) {
                    // can use classlist
                    hiddenIframe.classlist.add(hiddenIframeClass);
                } else {
                    hiddenIframe.setAttribute('class', hiddenIframeClass);
                }

                // Set the style
                hiddenIframe.style.width = '100%';
                hiddenIframe.style.display = 'block';
                hiddenIframe.style.border = 0;
                hiddenIframe.style.height = 0;
                hiddenIframe.style.margin = 0;
                hiddenIframe.style.position = 'absolute';
                hiddenIframe.style.left = 0;
                hiddenIframe.style.right = 0;
                hiddenIframe.style.top = 0;
                hiddenIframe.style.bottom = 0;

                // Insert the iframe so that contentWindow is available
                node.insertBefore(hiddenIframe, node.firstChild);

                (hiddenIframe.contentWindow || hiddenIframe).onresize = function() {
                    if (callback) {
                        callback();
                    }
                };
            };
            helpers.removeResizeListener = function(node) {
                var hiddenIframe = node.querySelector('.chartjs-hidden-iframe');

                // Remove the resize detect iframe
                if (hiddenIframe) {
                    hiddenIframe.parentNode.removeChild(hiddenIframe);
                }
            };
            helpers.isArray = function(obj) {
                if (!Array.isArray) {
                    return Object.prototype.toString.call(obj) === '[object Array]';
                }
                return Array.isArray(obj);
            };
            helpers.pushAllIfDefined = function(element, array) {
                if (typeof element === "undefined") {
                    return;
                }

                if (helpers.isArray(element)) {
                    array.push.apply(array, element);
                } else {
                    array.push(element);
                }
            };
            helpers.callCallback = function(fn, args, _tArg) {
                if (fn && typeof fn.call === 'function') {
                    fn.apply(_tArg, args);
                }
            };
            helpers.getHoverColor = function(color) {
                /* global CanvasPattern */
                return (color instanceof CanvasPattern) ?
                    color :
                    helpers.color(color).saturate(0.5).darken(0.1).rgbString();
            };
        };

    }, {
        "chartjs-color": 2
    }],
    26: [function(require, module, exports) {
        "use strict";

        module.exports = function() {

            //Occupy the global variable of Chart, and create a simple base class
            var Chart = function(context, config) {
                this.config = config;

                // Support a jQuery'd canvas element
                if (context.length && context[0].getContext) {
                    context = context[0];
                }

                // Support a canvas domnode
                if (context.getContext) {
                    context = context.getContext("2d");
                }

                this.ctx = context;
                this.canvas = context.canvas;

                // Figure out what the size of the chart will be.
                // If the canvas has a specified width and height, we use those else
                // we look to see if the canvas node has a CSS width and height.
                // If there is still no height, fill the parent container
                this.width = context.canvas.width || parseInt(Chart.helpers.getStyle(context.canvas, 'width')) || Chart.helpers.getMaximumWidth(context.canvas);
                this.height = context.canvas.height || parseInt(Chart.helpers.getStyle(context.canvas, 'height')) || Chart.helpers.getMaximumHeight(context.canvas);

                this.aspectRatio = this.width / this.height;

                if (isNaN(this.aspectRatio) || isFinite(this.aspectRatio) === false) {
                    // If the canvas has no size, try and figure out what the aspect ratio will be.
                    // Some charts prefer square canvases (pie, radar, etc). If that is specified, use that
                    // else use the canvas default ratio of 2
                    this.aspectRatio = config.aspectRatio !== undefined ? config.aspectRatio : 2;
                }

                // Store the original style of the element so we can set it back
                this.originalCanvasStyleWidth = context.canvas.style.width;
                this.originalCanvasStyleHeight = context.canvas.style.height;

                // High pixel density displays - multiply the size of the canvas height/width by the device pixel ratio, then scale.
                Chart.helpers.retinaScale(this);

                if (config) {
                    this.controller = new Chart.Controller(this);
                }

                // Always bind this so that if the responsive state changes we still work
                var _this = this;
                Chart.helpers.addResizeListener(context.canvas.parentNode, function() {
                    if (_this.controller && _this.controller.config.options.responsive) {
                        _this.controller.resize();
                    }
                });

                return this.controller ? this.controller : this;

            };

            //Globally expose the defaults to allow for user updating/changing
            Chart.defaults = {
                global: {
                    responsive: true,
                    responsiveAnimationDuration: 0,
                    maintainAspectRatio: true,
                    events: ["mousemove", "mouseout", "click", "touchstart", "touchmove"],
                    hover: {
                        onHover: null,
                        mode: 'single',
                        animationDuration: 400
                    },
                    onClick: null,
                    defaultColor: 'rgba(0,0,0,0.1)',
                    defaultFontColor: '#666',
                    defaultFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                    defaultFontSize: 12,
                    defaultFontStyle: 'normal',
                    showLines: true,

                    // Element defaults defined in element extensions
                    elements: {},

                    // Legend callback string
                    legendCallback: function(chart) {
                        var text = [];
                        text.push('<ul class="' + chart.id + '-legend">');
                        for (var i = 0; i < chart.data.datasets.length; i++) {
                            text.push('<li><span style="background-color:' + chart.data.datasets[i].backgroundColor + '"></span>');
                            if (chart.data.datasets[i].label) {
                                text.push(chart.data.datasets[i].label);
                            }
                            text.push('</li>');
                        }
                        text.push('</ul>');

                        return text.join("");
                    }
                }
            };

            return Chart;

        };

    }, {}],
    27: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            // The layout service is very self explanatory.  It's responsible for the layout within a chart.
            // Scales, Legends and Plugins all rely on the layout service and can easily register to be placed anywhere they need
            // It is this service's responsibility of carrying out that layout.
            Chart.layoutService = {
                defaults: {},

                // Register a box to a chartInstance. A box is simply a reference to an object that requires layout. eg. Scales, Legend, Plugins.
                addBox: function(chartInstance, box) {
                    if (!chartInstance.boxes) {
                        chartInstance.boxes = [];
                    }
                    chartInstance.boxes.push(box);
                },

                removeBox: function(chartInstance, box) {
                    if (!chartInstance.boxes) {
                        return;
                    }
                    chartInstance.boxes.splice(chartInstance.boxes.indexOf(box), 1);
                },

                // The most important function
                update: function(chartInstance, width, height) {

                    if (!chartInstance) {
                        return;
                    }

                    var xPadding = 0;
                    var yPadding = 0;

                    var leftBoxes = helpers.where(chartInstance.boxes, function(box) {
                        return box.options.position === "left";
                    });
                    var rightBoxes = helpers.where(chartInstance.boxes, function(box) {
                        return box.options.position === "right";
                    });
                    var topBoxes = helpers.where(chartInstance.boxes, function(box) {
                        return box.options.position === "top";
                    });
                    var bottomBoxes = helpers.where(chartInstance.boxes, function(box) {
                        return box.options.position === "bottom";
                    });

                    // Boxes that overlay the chartarea such as the radialLinear scale
                    var chartAreaBoxes = helpers.where(chartInstance.boxes, function(box) {
                        return box.options.position === "chartArea";
                    });

                    // Ensure that full width boxes are at the very top / bottom
                    topBoxes.sort(function(a, b) {
                        return (b.options.fullWidth ? 1 : 0) - (a.options.fullWidth ? 1 : 0);
                    });
                    bottomBoxes.sort(function(a, b) {
                        return (a.options.fullWidth ? 1 : 0) - (b.options.fullWidth ? 1 : 0);
                    });

                    // Essentially we now have any number of boxes on each of the 4 sides.
                    // Our canvas looks like the following.
                    // The areas L1 and L2 are the left axes. R1 is the right axis, T1 is the top axis and
                    // B1 is the bottom axis
                    // There are also 4 quadrant-like locations (left to right instead of clockwise) reserved for chart overlays
                    // These locations are single-box locations only, when trying to register a chartArea location that is already taken,
                    // an error will be thrown.
                    //
                    // |----------------------------------------------------|
                    // |                  T1 (Full Width)                   |
                    // |----------------------------------------------------|
                    // |    |    |                 T2                  |    |
                    // |    |----|-------------------------------------|----|
                    // |    |    | C1 |                           | C2 |    |
                    // |    |    |----|                           |----|    |
                    // |    |    |                                     |    |
                    // | L1 | L2 |           ChartArea (C0)            | R1 |
                    // |    |    |                                     |    |
                    // |    |    |----|                           |----|    |
                    // |    |    | C3 |                           | C4 |    |
                    // |    |----|-------------------------------------|----|
                    // |    |    |                 B1                  |    |
                    // |----------------------------------------------------|
                    // |                  B2 (Full Width)                   |
                    // |----------------------------------------------------|
                    //
                    // What we do to find the best sizing, we do the following
                    // 1. Determine the minimum size of the chart area.
                    // 2. Split the remaining width equally between each vertical axis
                    // 3. Split the remaining height equally between each horizontal axis
                    // 4. Give each layout the maximum size it can be. The layout will return it's minimum size
                    // 5. Adjust the sizes of each axis based on it's minimum reported size.
                    // 6. Refit each axis
                    // 7. Position each axis in the final location
                    // 8. Tell the chart the final location of the chart area
                    // 9. Tell any axes that overlay the chart area the positions of the chart area

                    // Step 1
                    var chartWidth = width - (2 * xPadding);
                    var chartHeight = height - (2 * yPadding);
                    var chartAreaWidth = chartWidth / 2; // min 50%
                    var chartAreaHeight = chartHeight / 2; // min 50%

                    // Step 2
                    var verticalBoxWidth = (width - chartAreaWidth) / (leftBoxes.length + rightBoxes.length);

                    // Step 3
                    var horizontalBoxHeight = (height - chartAreaHeight) / (topBoxes.length + bottomBoxes.length);

                    // Step 4
                    var maxChartAreaWidth = chartWidth;
                    var maxChartAreaHeight = chartHeight;
                    var minBoxSizes = [];

                    helpers.each(leftBoxes.concat(rightBoxes, topBoxes, bottomBoxes), getMinimumBoxSize);

                    function getMinimumBoxSize(box) {
                        var minSize;
                        var isHorizontal = box.isHorizontal();

                        if (isHorizontal) {
                            minSize = box.update(box.options.fullWidth ? chartWidth : maxChartAreaWidth, horizontalBoxHeight);
                            maxChartAreaHeight -= minSize.height;
                        } else {
                            minSize = box.update(verticalBoxWidth, chartAreaHeight);
                            maxChartAreaWidth -= minSize.width;
                        }

                        minBoxSizes.push({
                            horizontal: isHorizontal,
                            minSize: minSize,
                            box: box
                        });
                    }

                    // At this point, maxChartAreaHeight and maxChartAreaWidth are the size the chart area could
                    // be if the axes are drawn at their minimum sizes.

                    // Steps 5 & 6
                    var totalLeftBoxesWidth = xPadding;
                    var totalRightBoxesWidth = xPadding;
                    var totalTopBoxesHeight = yPadding;
                    var totalBottomBoxesHeight = yPadding;

                    // Update, and calculate the left and right margins for the horizontal boxes
                    helpers.each(leftBoxes.concat(rightBoxes), fitBox);

                    helpers.each(leftBoxes, function(box) {
                        totalLeftBoxesWidth += box.width;
                    });

                    helpers.each(rightBoxes, function(box) {
                        totalRightBoxesWidth += box.width;
                    });

                    // Set the Left and Right margins for the horizontal boxes
                    helpers.each(topBoxes.concat(bottomBoxes), fitBox);

                    // Function to fit a box
                    function fitBox(box) {
                        var minBoxSize = helpers.findNextWhere(minBoxSizes, function(minBoxSize) {
                            return minBoxSize.box === box;
                        });

                        if (minBoxSize) {
                            if (box.isHorizontal()) {
                                var scaleMargin = {
                                    left: totalLeftBoxesWidth,
                                    right: totalRightBoxesWidth,
                                    top: 0,
                                    bottom: 0
                                };

                                // Don't use min size here because of label rotation. When the labels are rotated, their rotation highly depends
                                // on the margin. Sometimes they need to increase in size slightly
                                box.update(box.options.fullWidth ? chartWidth : maxChartAreaWidth, chartHeight / 2, scaleMargin);
                            } else {
                                box.update(minBoxSize.minSize.width, maxChartAreaHeight);
                            }
                        }
                    }

                    // Figure out how much margin is on the top and bottom of the vertical boxes
                    helpers.each(topBoxes, function(box) {
                        totalTopBoxesHeight += box.height;
                    });

                    helpers.each(bottomBoxes, function(box) {
                        totalBottomBoxesHeight += box.height;
                    });

                    // Let the left layout know the final margin
                    helpers.each(leftBoxes.concat(rightBoxes), finalFitVerticalBox);

                    function finalFitVerticalBox(box) {
                        var minBoxSize = helpers.findNextWhere(minBoxSizes, function(minBoxSize) {
                            return minBoxSize.box === box;
                        });

                        var scaleMargin = {
                            left: 0,
                            right: 0,
                            top: totalTopBoxesHeight,
                            bottom: totalBottomBoxesHeight
                        };

                        if (minBoxSize) {
                            box.update(minBoxSize.minSize.width, maxChartAreaHeight, scaleMargin);
                        }
                    }

                    // Recalculate because the size of each layout might have changed slightly due to the margins (label rotation for instance)
                    totalLeftBoxesWidth = xPadding;
                    totalRightBoxesWidth = xPadding;
                    totalTopBoxesHeight = yPadding;
                    totalBottomBoxesHeight = yPadding;

                    helpers.each(leftBoxes, function(box) {
                        totalLeftBoxesWidth += box.width;
                    });

                    helpers.each(rightBoxes, function(box) {
                        totalRightBoxesWidth += box.width;
                    });

                    helpers.each(topBoxes, function(box) {
                        totalTopBoxesHeight += box.height;
                    });
                    helpers.each(bottomBoxes, function(box) {
                        totalBottomBoxesHeight += box.height;
                    });

                    // Figure out if our chart area changed. This would occur if the dataset layout label rotation
                    // changed due to the application of the margins in step 6. Since we can only get bigger, this is safe to do
                    // without calling `fit` again
                    var newMaxChartAreaHeight = height - totalTopBoxesHeight - totalBottomBoxesHeight;
                    var newMaxChartAreaWidth = width - totalLeftBoxesWidth - totalRightBoxesWidth;

                    if (newMaxChartAreaWidth !== maxChartAreaWidth || newMaxChartAreaHeight !== maxChartAreaHeight) {
                        helpers.each(leftBoxes, function(box) {
                            box.height = newMaxChartAreaHeight;
                        });

                        helpers.each(rightBoxes, function(box) {
                            box.height = newMaxChartAreaHeight;
                        });

                        helpers.each(topBoxes, function(box) {
                            if (!box.options.fullWidth) {
                                box.width = newMaxChartAreaWidth;
                            }
                        });

                        helpers.each(bottomBoxes, function(box) {
                            if (!box.options.fullWidth) {
                                box.width = newMaxChartAreaWidth;
                            }
                        });

                        maxChartAreaHeight = newMaxChartAreaHeight;
                        maxChartAreaWidth = newMaxChartAreaWidth;
                    }

                    // Step 7 - Position the boxes
                    var left = xPadding;
                    var top = yPadding;
                    var right = 0;
                    var bottom = 0;

                    helpers.each(leftBoxes.concat(topBoxes), placeBox);

                    // Account for chart width and height
                    left += maxChartAreaWidth;
                    top += maxChartAreaHeight;

                    helpers.each(rightBoxes, placeBox);
                    helpers.each(bottomBoxes, placeBox);

                    function placeBox(box) {
                        if (box.isHorizontal()) {
                            box.left = box.options.fullWidth ? xPadding : totalLeftBoxesWidth;
                            box.right = box.options.fullWidth ? width - xPadding : totalLeftBoxesWidth + maxChartAreaWidth;
                            box.top = top;
                            box.bottom = top + box.height;

                            // Move to next point
                            top = box.bottom;

                        } else {

                            box.left = left;
                            box.right = left + box.width;
                            box.top = totalTopBoxesHeight;
                            box.bottom = totalTopBoxesHeight + maxChartAreaHeight;

                            // Move to next point
                            left = box.right;
                        }
                    }

                    // Step 8
                    chartInstance.chartArea = {
                        left: totalLeftBoxesWidth,
                        top: totalTopBoxesHeight,
                        right: totalLeftBoxesWidth + maxChartAreaWidth,
                        bottom: totalTopBoxesHeight + maxChartAreaHeight
                    };

                    // Step 9
                    helpers.each(chartAreaBoxes, function(box) {
                        box.left = chartInstance.chartArea.left;
                        box.top = chartInstance.chartArea.top;
                        box.right = chartInstance.chartArea.right;
                        box.bottom = chartInstance.chartArea.bottom;

                        box.update(maxChartAreaWidth, maxChartAreaHeight);
                    });
                }
            };
        };

    }, {}],
    28: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;
            var noop = helpers.noop;

            Chart.defaults.global.legend = {

                display: true,
                position: 'top',
                fullWidth: true, // marks that this box should take the full width of the canvas (pushing down other boxes)
                reverse: false,

                // a callback that will handle
                onClick: function(e, legendItem) {
                    var index = legendItem.datasetIndex;
                    var ci = this.chart;
                    var meta = ci.getDatasetMeta(index);

                    // See controller.isDatasetVisible comment
                    meta.hidden = meta.hidden === null ? !ci.data.datasets[index].hidden : null;

                    // We hid a dataset ... rerender the chart
                    ci.update();
                },

                labels: {
                    boxWidth: 40,
                    padding: 10,
                    // Generates labels shown in the legend
                    // Valid properties to return:
                    // text : text to display
                    // fillStyle : fill of coloured box
                    // strokeStyle: stroke of coloured box
                    // hidden : if this legend item refers to a hidden item
                    // lineCap : cap style for line
                    // lineDash
                    // lineDashOffset :
                    // lineJoin :
                    // lineWidth :
                    generateLabels: function(chart) {
                        var data = chart.data;
                        return helpers.isArray(data.datasets) ? data.datasets.map(function(dataset, i) {
                            return {
                                text: dataset.label,
                                fillStyle: dataset.backgroundColor,
                                hidden: !chart.isDatasetVisible(i),
                                lineCap: dataset.borderCapStyle,
                                lineDash: dataset.borderDash,
                                lineDashOffset: dataset.borderDashOffset,
                                lineJoin: dataset.borderJoinStyle,
                                lineWidth: dataset.borderWidth,
                                strokeStyle: dataset.borderColor,

                                // Below is extra data used for toggling the datasets
                                datasetIndex: i
                            };
                        }, this) : [];
                    }
                }
            };

            Chart.Legend = Chart.Element.extend({

                initialize: function(config) {
                    helpers.extend(this, config);

                    // Contains hit boxes for each dataset (in dataset order)
                    this.legendHitBoxes = [];

                    // Are we in doughnut mode which has a different data type
                    this.doughnutMode = false;
                },

                // These methods are ordered by lifecyle. Utilities then follow.
                // Any function defined here is inherited by all legend types.
                // Any function can be extended by the legend type

                beforeUpdate: noop,
                update: function(maxWidth, maxHeight, margins) {

                    // Update Lifecycle - Probably don't want to ever extend or overwrite this function ;)
                    this.beforeUpdate();

                    // Absorb the master measurements
                    this.maxWidth = maxWidth;
                    this.maxHeight = maxHeight;
                    this.margins = margins;

                    // Dimensions
                    this.beforeSetDimensions();
                    this.setDimensions();
                    this.afterSetDimensions();
                    // Labels
                    this.beforeBuildLabels();
                    this.buildLabels();
                    this.afterBuildLabels();

                    // Fit
                    this.beforeFit();
                    this.fit();
                    this.afterFit();
                    //
                    this.afterUpdate();

                    return this.minSize;
                },
                afterUpdate: noop,

                //

                beforeSetDimensions: noop,
                setDimensions: function() {
                    // Set the unconstrained dimension before label rotation
                    if (this.isHorizontal()) {
                        // Reset position before calculating rotation
                        this.width = this.maxWidth;
                        this.left = 0;
                        this.right = this.width;
                    } else {
                        this.height = this.maxHeight;

                        // Reset position before calculating rotation
                        this.top = 0;
                        this.bottom = this.height;
                    }

                    // Reset padding
                    this.paddingLeft = 0;
                    this.paddingTop = 0;
                    this.paddingRight = 0;
                    this.paddingBottom = 0;

                    // Reset minSize
                    this.minSize = {
                        width: 0,
                        height: 0
                    };
                },
                afterSetDimensions: noop,

                //

                beforeBuildLabels: noop,
                buildLabels: function() {
                    this.legendItems = this.options.labels.generateLabels.call(this, this.chart);
                    if (this.options.reverse) {
                        this.legendItems.reverse();
                    }
                },
                afterBuildLabels: noop,

                //

                beforeFit: noop,
                fit: function() {
                    var opts = this.options;
                    var labelOpts = opts.labels;
                    var display = opts.display;

                    var ctx = this.ctx;

                    var globalDefault = Chart.defaults.global,
                        itemOrDefault = helpers.getValueOrDefault,
                        fontSize = itemOrDefault(labelOpts.fontSize, globalDefault.defaultFontSize),
                        fontStyle = itemOrDefault(labelOpts.fontStyle, globalDefault.defaultFontStyle),
                        fontFamily = itemOrDefault(labelOpts.fontFamily, globalDefault.defaultFontFamily),
                        labelFont = helpers.fontString(fontSize, fontStyle, fontFamily);

                    // Reset hit boxes
                    var hitboxes = this.legendHitBoxes = [];

                    var minSize = this.minSize;
                    var isHorizontal = this.isHorizontal();

                    if (isHorizontal) {
                        minSize.width = this.maxWidth; // fill all the width
                        minSize.height = display ? 10 : 0;
                    } else {
                        minSize.width = display ? 10 : 0;
                        minSize.height = this.maxHeight; // fill all the height
                    }

                    // Increase sizes here
                    if (display) {
                        if (isHorizontal) {
                            // Labels

                            // Width of each line of legend boxes. Labels wrap onto multiple lines when there are too many to fit on one
                            var lineWidths = this.lineWidths = [0];
                            var totalHeight = this.legendItems.length ? fontSize + (labelOpts.padding) : 0;

                            ctx.textAlign = "left";
                            ctx.textBaseline = 'top';
                            ctx.font = labelFont;

                            helpers.each(this.legendItems, function(legendItem, i) {
                                var width = labelOpts.boxWidth + (fontSize / 2) + ctx.measureText(legendItem.text).width;
                                if (lineWidths[lineWidths.length - 1] + width + labelOpts.padding >= this.width) {
                                    totalHeight += fontSize + (labelOpts.padding);
                                    lineWidths[lineWidths.length] = this.left;
                                }

                                // Store the hitbox width and height here. Final position will be updated in `draw`
                                hitboxes[i] = {
                                    left: 0,
                                    top: 0,
                                    width: width,
                                    height: fontSize
                                };

                                lineWidths[lineWidths.length - 1] += width + labelOpts.padding;
                            }, this);

                            minSize.height += totalHeight;

                        } else {
                            // TODO vertical
                        }
                    }

                    this.width = minSize.width;
                    this.height = minSize.height;
                },
                afterFit: noop,

                // Shared Methods
                isHorizontal: function() {
                    return this.options.position === "top" || this.options.position === "bottom";
                },

                // Actualy draw the legend on the canvas
                draw: function() {
                    var opts = this.options;
                    var labelOpts = opts.labels;
                    var globalDefault = Chart.defaults.global,
                        lineDefault = globalDefault.elements.line,
                        legendWidth = this.width,
                        lineWidths = this.lineWidths;

                    if (opts.display) {
                        var ctx = this.ctx,
                            cursor = {
                                x: this.left + ((legendWidth - lineWidths[0]) / 2),
                                y: this.top + labelOpts.padding,
                                line: 0
                            },
                            itemOrDefault = helpers.getValueOrDefault,
                            fontColor = itemOrDefault(labelOpts.fontColor, globalDefault.defaultFontColor),
                            fontSize = itemOrDefault(labelOpts.fontSize, globalDefault.defaultFontSize),
                            fontStyle = itemOrDefault(labelOpts.fontStyle, globalDefault.defaultFontStyle),
                            fontFamily = itemOrDefault(labelOpts.fontFamily, globalDefault.defaultFontFamily),
                            labelFont = helpers.fontString(fontSize, fontStyle, fontFamily);

                        // Horizontal
                        if (this.isHorizontal()) {
                            // Labels
                            ctx.textAlign = "left";
                            ctx.textBaseline = 'top';
                            ctx.lineWidth = 0.5;
                            ctx.strokeStyle = fontColor; // for strikethrough effect
                            ctx.fillStyle = fontColor; // render in correct colour
                            ctx.font = labelFont;

                            var boxWidth = labelOpts.boxWidth,
                                hitboxes = this.legendHitBoxes;

                            helpers.each(this.legendItems, function(legendItem, i) {
                                var textWidth = ctx.measureText(legendItem.text).width,
                                    width = boxWidth + (fontSize / 2) + textWidth,
                                    x = cursor.x,
                                    y = cursor.y;

                                if (x + width >= legendWidth) {
                                    y = cursor.y += fontSize + (labelOpts.padding);
                                    cursor.line++;
                                    x = cursor.x = this.left + ((legendWidth - lineWidths[cursor.line]) / 2);
                                }

                                // Set the ctx for the box
                                ctx.save();

                                ctx.fillStyle = itemOrDefault(legendItem.fillStyle, globalDefault.defaultColor);
                                ctx.lineCap = itemOrDefault(legendItem.lineCap, lineDefault.borderCapStyle);
                                ctx.lineDashOffset = itemOrDefault(legendItem.lineDashOffset, lineDefault.borderDashOffset);
                                ctx.lineJoin = itemOrDefault(legendItem.lineJoin, lineDefault.borderJoinStyle);
                                ctx.lineWidth = itemOrDefault(legendItem.lineWidth, lineDefault.borderWidth);
                                ctx.strokeStyle = itemOrDefault(legendItem.strokeStyle, globalDefault.defaultColor);

                                if (ctx.setLineDash) {
                                    // IE 9 and 10 do not support line dash
                                    ctx.setLineDash(itemOrDefault(legendItem.lineDash, lineDefault.borderDash));
                                }

                                // Draw the box
                                ctx.strokeRect(x, y, boxWidth, fontSize);
                                ctx.fillRect(x, y, boxWidth, fontSize);

                                ctx.restore();

                                hitboxes[i].left = x;
                                hitboxes[i].top = y;

                                // Fill the actual label
                                ctx.fillText(legendItem.text, boxWidth + (fontSize / 2) + x, y);

                                if (legendItem.hidden) {
                                    // Strikethrough the text if hidden
                                    ctx.beginPath();
                                    ctx.lineWidth = 2;
                                    ctx.moveTo(boxWidth + (fontSize / 2) + x, y + (fontSize / 2));
                                    ctx.lineTo(boxWidth + (fontSize / 2) + x + textWidth, y + (fontSize / 2));
                                    ctx.stroke();
                                }

                                cursor.x += width + (labelOpts.padding);
                            }, this);
                        } else {

                        }
                    }
                },

                // Handle an event
                handleEvent: function(e) {
                    var position = helpers.getRelativePosition(e, this.chart.chart),
                        x = position.x,
                        y = position.y,
                        opts = this.options;

                    if (x >= this.left && x <= this.right && y >= this.top && y <= this.bottom) {
                        // See if we are touching one of the dataset boxes
                        var lh = this.legendHitBoxes;
                        for (var i = 0; i < lh.length; ++i) {
                            var hitBox = lh[i];

                            if (x >= hitBox.left && x <= hitBox.left + hitBox.width && y >= hitBox.top && y <= hitBox.top + hitBox.height) {
                                // Touching an element
                                if (opts.onClick) {
                                    opts.onClick.call(this, e, this.legendItems[i]);
                                }
                                break;
                            }
                        }
                    }
                }
            });

        };

    }, {}],
    29: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {
            var helpers = Chart.helpers;

            // Plugins are stored here
            Chart.plugins = [];
            Chart.pluginService = {
                // Register a new plugin
                register: function(plugin) {
                    var p = Chart.plugins;
                    if (p.indexOf(plugin) === -1) {
                        p.push(plugin);
                    }
                },

                // Remove a registered plugin
                remove: function(plugin) {
                    var p = Chart.plugins;
                    var idx = p.indexOf(plugin);
                    if (idx !== -1) {
                        p.splice(idx, 1);
                    }
                },

                // Iterate over all plugins
                notifyPlugins: function(method, args, scope) {
                    helpers.each(Chart.plugins, function(plugin) {
                        if (plugin[method] && typeof plugin[method] === 'function') {
                            plugin[method].apply(scope, args);
                        }
                    }, scope);
                }
            };

            var noop = helpers.noop;
            Chart.PluginBase = Chart.Element.extend({
                // Plugin methods. All functions are passed the chart instance

                // Called at start of chart init
                beforeInit: noop,

                // Called at end of chart init
                afterInit: noop,

                // Called at start of update
                beforeUpdate: noop,

                // Called at end of update
                afterUpdate: noop,

                // Called at start of draw
                beforeDraw: noop,

                // Called at end of draw
                afterDraw: noop,

                // Called during destroy
                destroy: noop,
            });
        };

    }, {}],
    30: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.scale = {
                display: true,
                position: "left",

                // grid line settings
                gridLines: {
                    display: true,
                    color: "rgba(0, 0, 0, 0.1)",
                    lineWidth: 1,
                    drawOnChartArea: true,
                    drawTicks: true,
                    tickMarkLength: 10,
                    zeroLineWidth: 1,
                    zeroLineColor: "rgba(0,0,0,0.25)",
                    offsetGridLines: false
                },

                // scale label
                scaleLabel: {
                    // actual label
                    labelString: '',

                    // display property
                    display: false
                },

                // label settings
                ticks: {
                    beginAtZero: false,
                    minRotation: 0,
                    maxRotation: 50,
                    mirror: false,
                    padding: 10,
                    reverse: false,
                    display: true,
                    autoSkip: true,
                    autoSkipPadding: 0,
                    labelOffset: 0,
                    callback: function(value) {
                        return '' + value;
                    }
                }
            };

            Chart.Scale = Chart.Element.extend({

                // These methods are ordered by lifecyle. Utilities then follow.
                // Any function defined here is inherited by all scale types.
                // Any function can be extended by the scale type

                beforeUpdate: function() {
                    helpers.callCallback(this.options.beforeUpdate, [this]);
                },
                update: function(maxWidth, maxHeight, margins) {

                    // Update Lifecycle - Probably don't want to ever extend or overwrite this function ;)
                    this.beforeUpdate();

                    // Absorb the master measurements
                    this.maxWidth = maxWidth;
                    this.maxHeight = maxHeight;
                    this.margins = helpers.extend({
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0
                    }, margins);

                    // Dimensions
                    this.beforeSetDimensions();
                    this.setDimensions();
                    this.afterSetDimensions();

                    // Data min/max
                    this.beforeDataLimits();
                    this.determineDataLimits();
                    this.afterDataLimits();

                    // Ticks
                    this.beforeBuildTicks();
                    this.buildTicks();
                    this.afterBuildTicks();

                    this.beforeTickToLabelConversion();
                    this.convertTicksToLabels();
                    this.afterTickToLabelConversion();

                    // Tick Rotation
                    this.beforeCalculateTickRotation();
                    this.calculateTickRotation();
                    this.afterCalculateTickRotation();
                    // Fit
                    this.beforeFit();
                    this.fit();
                    this.afterFit();
                    //
                    this.afterUpdate();

                    return this.minSize;

                },
                afterUpdate: function() {
                    helpers.callCallback(this.options.afterUpdate, [this]);
                },

                //

                beforeSetDimensions: function() {
                    helpers.callCallback(this.options.beforeSetDimensions, [this]);
                },
                setDimensions: function() {
                    // Set the unconstrained dimension before label rotation
                    if (this.isHorizontal()) {
                        // Reset position before calculating rotation
                        this.width = this.maxWidth;
                        this.left = 0;
                        this.right = this.width;
                    } else {
                        this.height = this.maxHeight;

                        // Reset position before calculating rotation
                        this.top = 0;
                        this.bottom = this.height;
                    }

                    // Reset padding
                    this.paddingLeft = 0;
                    this.paddingTop = 0;
                    this.paddingRight = 0;
                    this.paddingBottom = 0;
                },
                afterSetDimensions: function() {
                    helpers.callCallback(this.options.afterSetDimensions, [this]);
                },

                // Data limits
                beforeDataLimits: function() {
                    helpers.callCallback(this.options.beforeDataLimits, [this]);
                },
                determineDataLimits: helpers.noop,
                afterDataLimits: function() {
                    helpers.callCallback(this.options.afterDataLimits, [this]);
                },

                //
                beforeBuildTicks: function() {
                    helpers.callCallback(this.options.beforeBuildTicks, [this]);
                },
                buildTicks: helpers.noop,
                afterBuildTicks: function() {
                    helpers.callCallback(this.options.afterBuildTicks, [this]);
                },

                beforeTickToLabelConversion: function() {
                    helpers.callCallback(this.options.beforeTickToLabelConversion, [this]);
                },
                convertTicksToLabels: function() {
                    // Convert ticks to strings
                    this.ticks = this.ticks.map(function(numericalTick, index, ticks) {
                            if (this.options.ticks.userCallback) {
                                return this.options.ticks.userCallback(numericalTick, index, ticks);
                            }
                            return this.options.ticks.callback(numericalTick, index, ticks);
                        },
                        this);
                },
                afterTickToLabelConversion: function() {
                    helpers.callCallback(this.options.afterTickToLabelConversion, [this]);
                },

                //

                beforeCalculateTickRotation: function() {
                    helpers.callCallback(this.options.beforeCalculateTickRotation, [this]);
                },
                calculateTickRotation: function() {
                    //Get the width of each grid by calculating the difference
                    //between x offsets between 0 and 1.
                    var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                    var tickFontStyle = helpers.getValueOrDefault(this.options.ticks.fontStyle, Chart.defaults.global.defaultFontStyle);
                    var tickFontFamily = helpers.getValueOrDefault(this.options.ticks.fontFamily, Chart.defaults.global.defaultFontFamily);
                    var tickLabelFont = helpers.fontString(tickFontSize, tickFontStyle, tickFontFamily);
                    this.ctx.font = tickLabelFont;

                    var firstWidth = this.ctx.measureText(this.ticks[0]).width;
                    var lastWidth = this.ctx.measureText(this.ticks[this.ticks.length - 1]).width;
                    var firstRotated;

                    this.labelRotation = this.options.ticks.minRotation || 0;
                    this.paddingRight = 0;
                    this.paddingLeft = 0;

                    if (this.options.display) {
                        if (this.isHorizontal()) {
                            this.paddingRight = lastWidth / 2 + 3;
                            this.paddingLeft = firstWidth / 2 + 3;

                            if (!this.longestTextCache) {
                                this.longestTextCache = {};
                            }
                            var originalLabelWidth = helpers.longestText(this.ctx, tickLabelFont, this.ticks, this.longestTextCache);
                            var labelWidth = originalLabelWidth;
                            var cosRotation;
                            var sinRotation;

                            // Allow 3 pixels x2 padding either side for label readability
                            // only the index matters for a dataset scale, but we want a consistent interface between scales
                            var tickWidth = this.getPixelForTick(1) - this.getPixelForTick(0) - 6;

                            //Max label rotation can be set or default to 90 - also act as a loop counter
                            while (labelWidth > tickWidth && this.labelRotation < this.options.ticks.maxRotation) {
                                cosRotation = Math.cos(helpers.toRadians(this.labelRotation));
                                sinRotation = Math.sin(helpers.toRadians(this.labelRotation));

                                firstRotated = cosRotation * firstWidth;

                                // We're right aligning the text now.
                                if (firstRotated + tickFontSize / 2 > this.yLabelWidth) {
                                    this.paddingLeft = firstRotated + tickFontSize / 2;
                                }

                                this.paddingRight = tickFontSize / 2;

                                if (sinRotation * originalLabelWidth > this.maxHeight) {
                                    // go back one step
                                    this.labelRotation--;
                                    break;
                                }

                                this.labelRotation++;
                                labelWidth = cosRotation * originalLabelWidth;
                            }
                        }
                    }

                    if (this.margins) {
                        this.paddingLeft = Math.max(this.paddingLeft - this.margins.left, 0);
                        this.paddingRight = Math.max(this.paddingRight - this.margins.right, 0);
                    }
                },
                afterCalculateTickRotation: function() {
                    helpers.callCallback(this.options.afterCalculateTickRotation, [this]);
                },

                //

                beforeFit: function() {
                    helpers.callCallback(this.options.beforeFit, [this]);
                },
                fit: function() {
                    // Reset
                    var minSize = this.minSize = {
                        width: 0,
                        height: 0
                    };

                    var opts = this.options;
                    var tickOpts = opts.ticks;
                    var scaleLabelOpts = opts.scaleLabel;
                    var globalOpts = Chart.defaults.global;
                    var display = opts.display;
                    var isHorizontal = this.isHorizontal();

                    var tickFontSize = helpers.getValueOrDefault(tickOpts.fontSize, globalOpts.defaultFontSize);
                    var tickFontStyle = helpers.getValueOrDefault(tickOpts.fontStyle, globalOpts.defaultFontStyle);
                    var tickFontFamily = helpers.getValueOrDefault(tickOpts.fontFamily, globalOpts.defaultFontFamily);
                    var tickLabelFont = helpers.fontString(tickFontSize, tickFontStyle, tickFontFamily);

                    var scaleLabelFontSize = helpers.getValueOrDefault(scaleLabelOpts.fontSize, globalOpts.defaultFontSize);
                    var scaleLabelFontStyle = helpers.getValueOrDefault(scaleLabelOpts.fontStyle, globalOpts.defaultFontStyle);
                    var scaleLabelFontFamily = helpers.getValueOrDefault(scaleLabelOpts.fontFamily, globalOpts.defaultFontFamily);
                    var scaleLabelFont = helpers.fontString(scaleLabelFontSize, scaleLabelFontStyle, scaleLabelFontFamily);

                    var tickMarkLength = opts.gridLines.tickMarkLength;

                    // Width
                    if (isHorizontal) {
                        // subtract the margins to line up with the chartArea if we are a full width scale
                        minSize.width = this.isFullWidth() ? this.maxWidth - this.margins.left - this.margins.right : this.maxWidth;
                    } else {
                        minSize.width = display ? tickMarkLength : 0;
                    }

                    // height
                    if (isHorizontal) {
                        minSize.height = display ? tickMarkLength : 0;
                    } else {
                        minSize.height = this.maxHeight; // fill all the height
                    }

                    // Are we showing a title for the scale?
                    if (scaleLabelOpts.display && display) {
                        if (isHorizontal) {
                            minSize.height += (scaleLabelFontSize * 1.5);
                        } else {
                            minSize.width += (scaleLabelFontSize * 1.5);
                        }
                    }

                    if (tickOpts.display && display) {
                        // Don't bother fitting the ticks if we are not showing them
                        if (!this.longestTextCache) {
                            this.longestTextCache = {};
                        }

                        var largestTextWidth = helpers.longestText(this.ctx, tickLabelFont, this.ticks, this.longestTextCache);

                        if (isHorizontal) {
                            // A horizontal axis is more constrained by the height.
                            this.longestLabelWidth = largestTextWidth;

                            // TODO - improve this calculation
                            var labelHeight = (Math.sin(helpers.toRadians(this.labelRotation)) * this.longestLabelWidth) + 1.5 * tickFontSize;

                            minSize.height = Math.min(this.maxHeight, minSize.height + labelHeight);
                            this.ctx.font = tickLabelFont;

                            var firstLabelWidth = this.ctx.measureText(this.ticks[0]).width;
                            var lastLabelWidth = this.ctx.measureText(this.ticks[this.ticks.length - 1]).width;

                            // Ensure that our ticks are always inside the canvas. When rotated, ticks are right aligned which means that the right padding is dominated
                            // by the font height
                            var cosRotation = Math.cos(helpers.toRadians(this.labelRotation));
                            var sinRotation = Math.sin(helpers.toRadians(this.labelRotation));
                            this.paddingLeft = this.labelRotation !== 0 ? (cosRotation * firstLabelWidth) + 3 : firstLabelWidth / 2 + 3; // add 3 px to move away from canvas edges
                            this.paddingRight = this.labelRotation !== 0 ? (sinRotation * (tickFontSize / 2)) + 3 : lastLabelWidth / 2 + 3; // when rotated
                        } else {
                            // A vertical axis is more constrained by the width. Labels are the dominant factor here, so get that length first
                            var maxLabelWidth = this.maxWidth - minSize.width;

                            // Account for padding
                            var mirror = tickOpts.mirror;
                            if (!mirror) {
                                largestTextWidth += this.options.ticks.padding;
                            } else {
                                // If mirrored text is on the inside so don't expand
                                largestTextWidth = 0;
                            }

                            if (largestTextWidth < maxLabelWidth) {
                                // We don't need all the room
                                minSize.width += largestTextWidth;
                            } else {
                                // Expand to max size
                                minSize.width = this.maxWidth;
                            }

                            this.paddingTop = tickFontSize / 2;
                            this.paddingBottom = tickFontSize / 2;
                        }
                    }

                    if (this.margins) {
                        this.paddingLeft = Math.max(this.paddingLeft - this.margins.left, 0);
                        this.paddingTop = Math.max(this.paddingTop - this.margins.top, 0);
                        this.paddingRight = Math.max(this.paddingRight - this.margins.right, 0);
                        this.paddingBottom = Math.max(this.paddingBottom - this.margins.bottom, 0);
                    }

                    this.width = minSize.width;
                    this.height = minSize.height;

                },
                afterFit: function() {
                    helpers.callCallback(this.options.afterFit, [this]);
                },

                // Shared Methods
                isHorizontal: function() {
                    return this.options.position === "top" || this.options.position === "bottom";
                },
                isFullWidth: function() {
                    return (this.options.fullWidth);
                },

                // Get the correct value. NaN bad inputs, If the value type is object get the x or y based on whether we are horizontal or not
                getRightValue: function getRightValue(rawValue) {
                    // Null and undefined values first
                    if (rawValue === null || typeof(rawValue) === 'undefined') {
                        return NaN;
                    }
                    // isNaN(object) returns true, so make sure NaN is checking for a number
                    if (typeof(rawValue) === 'number' && isNaN(rawValue)) {
                        return NaN;
                    }
                    // If it is in fact an object, dive in one more level
                    if (typeof(rawValue) === "object") {
                        if (rawValue instanceof Date) {
                            return rawValue;
                        } else {
                            return getRightValue(this.isHorizontal() ? rawValue.x : rawValue.y);
                        }
                    }

                    // Value is good, return it
                    return rawValue;
                },

                // Used to get the value to display in the tooltip for the data at the given index
                // function getLabelForIndex(index, datasetIndex)
                getLabelForIndex: helpers.noop,

                // Used to get data value locations.  Value can either be an index or a numerical value
                getPixelForValue: helpers.noop,

                // Used to get the data value from a given pixel. This is the inverse of getPixelForValue
                getValueForPixel: helpers.noop,

                // Used for tick location, should
                getPixelForTick: function(index, includeOffset) {
                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        var tickWidth = innerWidth / Math.max((this.ticks.length - ((this.options.gridLines.offsetGridLines) ? 0 : 1)), 1);
                        var pixel = (tickWidth * index) + this.paddingLeft;

                        if (includeOffset) {
                            pixel += tickWidth / 2;
                        }

                        var finalVal = this.left + Math.round(pixel);
                        finalVal += this.isFullWidth() ? this.margins.left : 0;
                        return finalVal;
                    } else {
                        var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                        return this.top + (index * (innerHeight / (this.ticks.length - 1)));
                    }
                },

                // Utility for getting the pixel location of a percentage of scale
                getPixelForDecimal: function(decimal /*, includeOffset*/ ) {
                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        var valueOffset = (innerWidth * decimal) + this.paddingLeft;

                        var finalVal = this.left + Math.round(valueOffset);
                        finalVal += this.isFullWidth() ? this.margins.left : 0;
                        return finalVal;
                    } else {
                        return this.top + (decimal * this.height);
                    }
                },

                // Actualy draw the scale on the canvas
                // @param {rectangle} chartArea : the area of the chart to draw full grid lines on
                draw: function(chartArea) {
                    if (this.options.display) {

                        var setContextLineSettings;
                        var isRotated = this.labelRotation !== 0;
                        var skipRatio;
                        var scaleLabelX;
                        var scaleLabelY;
                        var useAutoskipper = this.options.ticks.autoSkip;


                        // figure out the maximum number of gridlines to show
                        var maxTicks;

                        if (this.options.ticks.maxTicksLimit) {
                            maxTicks = this.options.ticks.maxTicksLimit;
                        }

                        var tickFontColor = helpers.getValueOrDefault(this.options.ticks.fontColor, Chart.defaults.global.defaultFontColor);
                        var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                        var tickFontStyle = helpers.getValueOrDefault(this.options.ticks.fontStyle, Chart.defaults.global.defaultFontStyle);
                        var tickFontFamily = helpers.getValueOrDefault(this.options.ticks.fontFamily, Chart.defaults.global.defaultFontFamily);
                        var tickLabelFont = helpers.fontString(tickFontSize, tickFontStyle, tickFontFamily);
                        var tl = this.options.gridLines.tickMarkLength;

                        var scaleLabelFontColor = helpers.getValueOrDefault(this.options.scaleLabel.fontColor, Chart.defaults.global.defaultFontColor);
                        var scaleLabelFontSize = helpers.getValueOrDefault(this.options.scaleLabel.fontSize, Chart.defaults.global.defaultFontSize);
                        var scaleLabelFontStyle = helpers.getValueOrDefault(this.options.scaleLabel.fontStyle, Chart.defaults.global.defaultFontStyle);
                        var scaleLabelFontFamily = helpers.getValueOrDefault(this.options.scaleLabel.fontFamily, Chart.defaults.global.defaultFontFamily);
                        var scaleLabelFont = helpers.fontString(scaleLabelFontSize, scaleLabelFontStyle, scaleLabelFontFamily);

                        var cosRotation = Math.cos(helpers.toRadians(this.labelRotation));
                        var sinRotation = Math.sin(helpers.toRadians(this.labelRotation));
                        var longestRotatedLabel = this.longestLabelWidth * cosRotation;
                        var rotatedLabelHeight = tickFontSize * sinRotation;

                        // Make sure we draw text in the correct color and font
                        this.ctx.fillStyle = tickFontColor;

                        if (this.isHorizontal()) {
                            setContextLineSettings = true;
                            var yTickStart = this.options.position === "bottom" ? this.top : this.bottom - tl;
                            var yTickEnd = this.options.position === "bottom" ? this.top + tl : this.bottom;
                            skipRatio = false;

                            if (((longestRotatedLabel / 2) + this.options.ticks.autoSkipPadding) * this.ticks.length > (this.width - (this.paddingLeft + this.paddingRight))) {
                                skipRatio = 1 + Math.floor((((longestRotatedLabel / 2) + this.options.ticks.autoSkipPadding) * this.ticks.length) / (this.width - (this.paddingLeft + this.paddingRight)));
                            }

                            // if they defined a max number of ticks,
                            // increase skipRatio until that number is met
                            if (maxTicks && this.ticks.length > maxTicks) {
                                while (!skipRatio || this.ticks.length / (skipRatio || 1) > maxTicks) {
                                    if (!skipRatio) {
                                        skipRatio = 1;
                                    }
                                    skipRatio += 1;
                                }
                            }

                            if (!useAutoskipper) {
                                skipRatio = false;
                            }

                            helpers.each(this.ticks, function(label, index) {
                                // Blank ticks
                                var isLastTick = this.ticks.length === index + 1;

                                // Since we always show the last tick,we need may need to hide the last shown one before
                                var shouldSkip = (skipRatio > 1 && index % skipRatio > 0) || (index % skipRatio === 0 && index + skipRatio > this.ticks.length);
                                if (shouldSkip && !isLastTick || (label === undefined || label === null)) {
                                    return;
                                }
                                var xLineValue = this.getPixelForTick(index); // xvalues for grid lines
                                var xLabelValue = this.getPixelForTick(index, this.options.gridLines.offsetGridLines); // x values for ticks (need to consider offsetLabel option)

                                if (this.options.gridLines.display) {
                                    if (index === (typeof this.zeroLineIndex !== 'undefined' ? this.zeroLineIndex : 0)) {
                                        // Draw the first index specially
                                        this.ctx.lineWidth = this.options.gridLines.zeroLineWidth;
                                        this.ctx.strokeStyle = this.options.gridLines.zeroLineColor;
                                        setContextLineSettings = true; // reset next time
                                    } else if (setContextLineSettings) {
                                        this.ctx.lineWidth = this.options.gridLines.lineWidth;
                                        this.ctx.strokeStyle = this.options.gridLines.color;
                                        setContextLineSettings = false;
                                    }

                                    xLineValue += helpers.aliasPixel(this.ctx.lineWidth);

                                    // Draw the label area
                                    this.ctx.beginPath();

                                    if (this.options.gridLines.drawTicks) {
                                        this.ctx.moveTo(xLineValue, yTickStart);
                                        this.ctx.lineTo(xLineValue, yTickEnd);
                                    }

                                    // Draw the chart area
                                    if (this.options.gridLines.drawOnChartArea) {
                                        this.ctx.moveTo(xLineValue, chartArea.top);
                                        this.ctx.lineTo(xLineValue, chartArea.bottom);
                                    }

                                    // Need to stroke in the loop because we are potentially changing line widths & colours
                                    this.ctx.stroke();
                                }

                                if (this.options.ticks.display) {
                                    this.ctx.save();
                                    this.ctx.translate(xLabelValue + this.options.ticks.labelOffset, (isRotated) ? this.top + 12 : this.options.position === "top" ? this.bottom - tl : this.top + tl);
                                    this.ctx.rotate(helpers.toRadians(this.labelRotation) * -1);
                                    this.ctx.font = tickLabelFont;
                                    this.ctx.textAlign = (isRotated) ? "right" : "center";
                                    this.ctx.textBaseline = (isRotated) ? "middle" : this.options.position === "top" ? "bottom" : "top";
                                    this.ctx.fillText(label, 0, 0);
                                    this.ctx.restore();
                                }
                            }, this);

                            if (this.options.scaleLabel.display) {
                                // Draw the scale label
                                this.ctx.textAlign = "center";
                                this.ctx.textBaseline = 'middle';
                                this.ctx.fillStyle = scaleLabelFontColor; // render in correct colour
                                this.ctx.font = scaleLabelFont;

                                scaleLabelX = this.left + ((this.right - this.left) / 2); // midpoint of the width
                                scaleLabelY = this.options.position === 'bottom' ? this.bottom - (scaleLabelFontSize / 2) : this.top + (scaleLabelFontSize / 2);

                                this.ctx.fillText(this.options.scaleLabel.labelString, scaleLabelX, scaleLabelY);
                            }

                        } else {
                            setContextLineSettings = true;
                            var xTickStart = this.options.position === "right" ? this.left : this.right - 5;
                            var xTickEnd = this.options.position === "right" ? this.left + 5 : this.right;

                            helpers.each(this.ticks, function(label, index) {
                                // If the callback returned a null or undefined value, do not draw this line
                                if (label === undefined || label === null) {
                                    return;
                                }

                                var yLineValue = this.getPixelForTick(index); // xvalues for grid lines

                                if (this.options.gridLines.display) {
                                    if (index === (typeof this.zeroLineIndex !== 'undefined' ? this.zeroLineIndex : 0)) {
                                        // Draw the first index specially
                                        this.ctx.lineWidth = this.options.gridLines.zeroLineWidth;
                                        this.ctx.strokeStyle = this.options.gridLines.zeroLineColor;
                                        setContextLineSettings = true; // reset next time
                                    } else if (setContextLineSettings) {
                                        this.ctx.lineWidth = this.options.gridLines.lineWidth;
                                        this.ctx.strokeStyle = this.options.gridLines.color;
                                        setContextLineSettings = false;
                                    }

                                    yLineValue += helpers.aliasPixel(this.ctx.lineWidth);

                                    // Draw the label area
                                    this.ctx.beginPath();

                                    if (this.options.gridLines.drawTicks) {
                                        this.ctx.moveTo(xTickStart, yLineValue);
                                        this.ctx.lineTo(xTickEnd, yLineValue);
                                    }

                                    // Draw the chart area
                                    if (this.options.gridLines.drawOnChartArea) {
                                        this.ctx.moveTo(chartArea.left, yLineValue);
                                        this.ctx.lineTo(chartArea.right, yLineValue);
                                    }

                                    // Need to stroke in the loop because we are potentially changing line widths & colours
                                    this.ctx.stroke();
                                }

                                if (this.options.ticks.display) {
                                    var xLabelValue;
                                    var yLabelValue = this.getPixelForTick(index, this.options.gridLines.offsetGridLines); // x values for ticks (need to consider offsetLabel option)

                                    this.ctx.save();

                                    if (this.options.position === "left") {
                                        if (this.options.ticks.mirror) {
                                            xLabelValue = this.right + this.options.ticks.padding;
                                            this.ctx.textAlign = "left";
                                        } else {
                                            xLabelValue = this.right - this.options.ticks.padding;
                                            this.ctx.textAlign = "right";
                                        }
                                    } else {
                                        // right side
                                        if (this.options.ticks.mirror) {
                                            xLabelValue = this.left - this.options.ticks.padding;
                                            this.ctx.textAlign = "right";
                                        } else {
                                            xLabelValue = this.left + this.options.ticks.padding;
                                            this.ctx.textAlign = "left";
                                        }
                                    }

                                    this.ctx.translate(xLabelValue, yLabelValue + this.options.ticks.labelOffset);
                                    this.ctx.rotate(helpers.toRadians(this.labelRotation) * -1);
                                    this.ctx.font = tickLabelFont;
                                    this.ctx.textBaseline = "middle";
                                    this.ctx.fillText(label, 0, 0);
                                    this.ctx.restore();
                                }
                            }, this);

                            if (this.options.scaleLabel.display) {
                                // Draw the scale label
                                scaleLabelX = this.options.position === 'left' ? this.left + (scaleLabelFontSize / 2) : this.right - (scaleLabelFontSize / 2);
                                scaleLabelY = this.top + ((this.bottom - this.top) / 2);
                                var rotation = this.options.position === 'left' ? -0.5 * Math.PI : 0.5 * Math.PI;

                                this.ctx.save();
                                this.ctx.translate(scaleLabelX, scaleLabelY);
                                this.ctx.rotate(rotation);
                                this.ctx.textAlign = "center";
                                this.ctx.fillStyle = scaleLabelFontColor; // render in correct colour
                                this.ctx.font = scaleLabelFont;
                                this.ctx.textBaseline = 'middle';
                                this.ctx.fillText(this.options.scaleLabel.labelString, 0, 0);
                                this.ctx.restore();
                            }
                        }

                        // Draw the line at the edge of the axis
                        this.ctx.lineWidth = this.options.gridLines.lineWidth;
                        this.ctx.strokeStyle = this.options.gridLines.color;
                        var x1 = this.left,
                            x2 = this.right,
                            y1 = this.top,
                            y2 = this.bottom;

                        if (this.isHorizontal()) {
                            y1 = y2 = this.options.position === 'top' ? this.bottom : this.top;
                            y1 += helpers.aliasPixel(this.ctx.lineWidth);
                            y2 += helpers.aliasPixel(this.ctx.lineWidth);
                        } else {
                            x1 = x2 = this.options.position === 'left' ? this.right : this.left;
                            x1 += helpers.aliasPixel(this.ctx.lineWidth);
                            x2 += helpers.aliasPixel(this.ctx.lineWidth);
                        }

                        this.ctx.beginPath();
                        this.ctx.moveTo(x1, y1);
                        this.ctx.lineTo(x2, y2);
                        this.ctx.stroke();
                    }
                }
            });
        };

    }, {}],
    31: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.scaleService = {
                // Scale registration object. Extensions can register new scale types (such as log or DB scales) and then
                // use the new chart options to grab the correct scale
                constructors: {},
                // Use a registration function so that we can move to an ES6 map when we no longer need to support
                // old browsers

                // Scale config defaults
                defaults: {},
                registerScaleType: function(type, scaleConstructor, defaults) {
                    this.constructors[type] = scaleConstructor;
                    this.defaults[type] = helpers.clone(defaults);
                },
                getScaleConstructor: function(type) {
                    return this.constructors.hasOwnProperty(type) ? this.constructors[type] : undefined;
                },
                getScaleDefaults: function(type) {
                    // Return the scale defaults merged with the global settings so that we always use the latest ones
                    return this.defaults.hasOwnProperty(type) ? helpers.scaleMerge(Chart.defaults.scale, this.defaults[type]) : {};
                },
                updateScaleDefaults: function(type, additions) {
                    var defaults = this.defaults;
                    if (defaults.hasOwnProperty(type)) {
                        defaults[type] = helpers.extend(defaults[type], additions);
                    }
                },
                addScalesToLayout: function(chartInstance) {
                    // Adds each scale to the chart.boxes array to be sized accordingly
                    helpers.each(chartInstance.scales, function(scale) {
                        Chart.layoutService.addBox(chartInstance, scale);
                    });
                }
            };
        };
    }, {}],
    32: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.global.title = {
                display: false,
                position: 'top',
                fullWidth: true, // marks that this box should take the full width of the canvas (pushing down other boxes)

                fontStyle: 'bold',
                padding: 10,

                // actual title
                text: ''
            };

            var noop = helpers.noop;
            Chart.Title = Chart.Element.extend({

                initialize: function(config) {
                    helpers.extend(this, config);
                    this.options = helpers.configMerge(Chart.defaults.global.title, config.options);

                    // Contains hit boxes for each dataset (in dataset order)
                    this.legendHitBoxes = [];
                },

                // These methods are ordered by lifecyle. Utilities then follow.

                beforeUpdate: noop,
                update: function(maxWidth, maxHeight, margins) {

                    // Update Lifecycle - Probably don't want to ever extend or overwrite this function ;)
                    this.beforeUpdate();

                    // Absorb the master measurements
                    this.maxWidth = maxWidth;
                    this.maxHeight = maxHeight;
                    this.margins = margins;

                    // Dimensions
                    this.beforeSetDimensions();
                    this.setDimensions();
                    this.afterSetDimensions();
                    // Labels
                    this.beforeBuildLabels();
                    this.buildLabels();
                    this.afterBuildLabels();

                    // Fit
                    this.beforeFit();
                    this.fit();
                    this.afterFit();
                    //
                    this.afterUpdate();

                    return this.minSize;

                },
                afterUpdate: noop,

                //

                beforeSetDimensions: noop,
                setDimensions: function() {
                    // Set the unconstrained dimension before label rotation
                    if (this.isHorizontal()) {
                        // Reset position before calculating rotation
                        this.width = this.maxWidth;
                        this.left = 0;
                        this.right = this.width;
                    } else {
                        this.height = this.maxHeight;

                        // Reset position before calculating rotation
                        this.top = 0;
                        this.bottom = this.height;
                    }

                    // Reset padding
                    this.paddingLeft = 0;
                    this.paddingTop = 0;
                    this.paddingRight = 0;
                    this.paddingBottom = 0;

                    // Reset minSize
                    this.minSize = {
                        width: 0,
                        height: 0
                    };
                },
                afterSetDimensions: noop,

                //

                beforeBuildLabels: noop,
                buildLabels: noop,
                afterBuildLabels: noop,

                //

                beforeFit: noop,
                fit: function() {

                    var ctx = this.ctx,
                        valueOrDefault = helpers.getValueOrDefault,
                        opts = this.options,
                        globalDefaults = Chart.defaults.global,
                        display = opts.display,
                        fontSize = valueOrDefault(opts.fontSize, globalDefaults.defaultFontSize),
                        minSize = this.minSize;

                    if (this.isHorizontal()) {
                        minSize.width = this.maxWidth; // fill all the width
                        minSize.height = display ? fontSize + (opts.padding * 2) : 0;
                    } else {
                        minSize.width = display ? fontSize + (opts.padding * 2) : 0;
                        minSize.height = this.maxHeight; // fill all the height
                    }

                    this.width = minSize.width;
                    this.height = minSize.height;

                },
                afterFit: noop,

                // Shared Methods
                isHorizontal: function() {
                    var pos = this.options.position;
                    return pos === "top" || pos === "bottom";
                },

                // Actualy draw the title block on the canvas
                draw: function() {
                    var ctx = this.ctx,
                        valueOrDefault = helpers.getValueOrDefault,
                        opts = this.options,
                        globalDefaults = Chart.defaults.global;

                    if (opts.display) {
                        var fontSize = valueOrDefault(opts.fontSize, globalDefaults.defaultFontSize),
                            fontStyle = valueOrDefault(opts.fontStyle, globalDefaults.defaultFontStyle),
                            fontFamily = valueOrDefault(opts.fontFamily, globalDefaults.defaultFontFamily),
                            titleFont = helpers.fontString(fontSize, fontStyle, fontFamily),
                            rotation = 0,
                            titleX,
                            titleY;

                        ctx.fillStyle = valueOrDefault(opts.fontColor, globalDefaults.defaultFontColor); // render in correct colour
                        ctx.font = titleFont;

                        // Horizontal
                        if (this.isHorizontal()) {
                            titleX = this.left + ((this.right - this.left) / 2); // midpoint of the width
                            titleY = this.top + ((this.bottom - this.top) / 2); // midpoint of the height
                        } else {
                            titleX = opts.position === 'left' ? this.left + (fontSize / 2) : this.right - (fontSize / 2);
                            titleY = this.top + ((this.bottom - this.top) / 2);
                            rotation = Math.PI * (opts.position === 'left' ? -0.5 : 0.5);
                        }

                        ctx.save();
                        ctx.translate(titleX, titleY);
                        ctx.rotate(rotation);
                        ctx.textAlign = 'center';
                        ctx.textBaseline = 'middle';
                        ctx.fillText(opts.text, 0, 0);
                        ctx.restore();
                    }
                }
            });
        };
    }, {}],
    33: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.global.tooltips = {
                enabled: true,
                custom: null,
                mode: 'single',
                backgroundColor: "rgba(0,0,0,0.8)",
                titleFontStyle: "bold",
                titleSpacing: 2,
                titleMarginBottom: 6,
                titleColor: "#fff",
                titleAlign: "left",
                bodySpacing: 2,
                bodyColor: "#fff",
                bodyAlign: "left",
                footerFontStyle: "bold",
                footerSpacing: 2,
                footerMarginTop: 6,
                footerColor: "#fff",
                footerAlign: "left",
                yPadding: 6,
                xPadding: 6,
                yAlign: 'center',
                xAlign: 'center',
                caretSize: 5,
                cornerRadius: 6,
                multiKeyBackground: '#fff',
                callbacks: {
                    // Args are: (tooltipItems, data)
                    beforeTitle: helpers.noop,
                    title: function(tooltipItems, data) {
                        // Pick first xLabel for now
                        var title = '';

                        if (tooltipItems.length > 0) {
                            if (tooltipItems[0].xLabel) {
                                title = tooltipItems[0].xLabel;
                            } else if (data.labels.length > 0 && tooltipItems[0].index < data.labels.length) {
                                title = data.labels[tooltipItems[0].index];
                            }
                        }

                        return title;
                    },
                    afterTitle: helpers.noop,

                    // Args are: (tooltipItems, data)
                    beforeBody: helpers.noop,

                    // Args are: (tooltipItem, data)
                    beforeLabel: helpers.noop,
                    label: function(tooltipItem, data) {
                        var datasetLabel = data.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel;
                    },
                    afterLabel: helpers.noop,

                    // Args are: (tooltipItems, data)
                    afterBody: helpers.noop,

                    // Args are: (tooltipItems, data)
                    beforeFooter: helpers.noop,
                    footer: helpers.noop,
                    afterFooter: helpers.noop
                }
            };

            // Helper to push or concat based on if the 2nd parameter is an array or not
            function pushOrConcat(base, toPush) {
                if (toPush) {
                    if (helpers.isArray(toPush)) {
                        base = base.concat(toPush);
                    } else {
                        base.push(toPush);
                    }
                }

                return base;
            }

            Chart.Tooltip = Chart.Element.extend({
                initialize: function() {
                    var options = this._options;
                    helpers.extend(this, {
                        _model: {
                            // Positioning
                            xPadding: options.tooltips.xPadding,
                            yPadding: options.tooltips.yPadding,
                            xAlign: options.tooltips.yAlign,
                            yAlign: options.tooltips.xAlign,

                            // Body
                            bodyColor: options.tooltips.bodyColor,
                            _bodyFontFamily: helpers.getValueOrDefault(options.tooltips.bodyFontFamily, Chart.defaults.global.defaultFontFamily),
                            _bodyFontStyle: helpers.getValueOrDefault(options.tooltips.bodyFontStyle, Chart.defaults.global.defaultFontStyle),
                            _bodyAlign: options.tooltips.bodyAlign,
                            bodyFontSize: helpers.getValueOrDefault(options.tooltips.bodyFontSize, Chart.defaults.global.defaultFontSize),
                            bodySpacing: options.tooltips.bodySpacing,

                            // Title
                            titleColor: options.tooltips.titleColor,
                            _titleFontFamily: helpers.getValueOrDefault(options.tooltips.titleFontFamily, Chart.defaults.global.defaultFontFamily),
                            _titleFontStyle: helpers.getValueOrDefault(options.tooltips.titleFontStyle, Chart.defaults.global.defaultFontStyle),
                            titleFontSize: helpers.getValueOrDefault(options.tooltips.titleFontSize, Chart.defaults.global.defaultFontSize),
                            _titleAlign: options.tooltips.titleAlign,
                            titleSpacing: options.tooltips.titleSpacing,
                            titleMarginBottom: options.tooltips.titleMarginBottom,

                            // Footer
                            footerColor: options.tooltips.footerColor,
                            _footerFontFamily: helpers.getValueOrDefault(options.tooltips.footerFontFamily, Chart.defaults.global.defaultFontFamily),
                            _footerFontStyle: helpers.getValueOrDefault(options.tooltips.footerFontStyle, Chart.defaults.global.defaultFontStyle),
                            footerFontSize: helpers.getValueOrDefault(options.tooltips.footerFontSize, Chart.defaults.global.defaultFontSize),
                            _footerAlign: options.tooltips.footerAlign,
                            footerSpacing: options.tooltips.footerSpacing,
                            footerMarginTop: options.tooltips.footerMarginTop,

                            // Appearance
                            caretSize: options.tooltips.caretSize,
                            cornerRadius: options.tooltips.cornerRadius,
                            backgroundColor: options.tooltips.backgroundColor,
                            opacity: 0,
                            legendColorBackground: options.tooltips.multiKeyBackground
                        }
                    });
                },

                // Get the title
                // Args are: (tooltipItem, data)
                getTitle: function() {
                    var beforeTitle = this._options.tooltips.callbacks.beforeTitle.apply(this, arguments),
                        title = this._options.tooltips.callbacks.title.apply(this, arguments),
                        afterTitle = this._options.tooltips.callbacks.afterTitle.apply(this, arguments);

                    var lines = [];
                    lines = pushOrConcat(lines, beforeTitle);
                    lines = pushOrConcat(lines, title);
                    lines = pushOrConcat(lines, afterTitle);

                    return lines;
                },

                // Args are: (tooltipItem, data)
                getBeforeBody: function() {
                    var lines = this._options.tooltips.callbacks.beforeBody.apply(this, arguments);
                    return helpers.isArray(lines) ? lines : lines !== undefined ? [lines] : [];
                },

                // Args are: (tooltipItem, data)
                getBody: function(tooltipItems, data) {
                    var lines = [];

                    helpers.each(tooltipItems, function(bodyItem) {
                        helpers.pushAllIfDefined(this._options.tooltips.callbacks.beforeLabel.call(this, bodyItem, data), lines);
                        helpers.pushAllIfDefined(this._options.tooltips.callbacks.label.call(this, bodyItem, data), lines);
                        helpers.pushAllIfDefined(this._options.tooltips.callbacks.afterLabel.call(this, bodyItem, data), lines);
                    }, this);

                    return lines;
                },

                // Args are: (tooltipItem, data)
                getAfterBody: function() {
                    var lines = this._options.tooltips.callbacks.afterBody.apply(this, arguments);
                    return helpers.isArray(lines) ? lines : lines !== undefined ? [lines] : [];
                },

                // Get the footer and beforeFooter and afterFooter lines
                // Args are: (tooltipItem, data)
                getFooter: function() {
                    var beforeFooter = this._options.tooltips.callbacks.beforeFooter.apply(this, arguments);
                    var footer = this._options.tooltips.callbacks.footer.apply(this, arguments);
                    var afterFooter = this._options.tooltips.callbacks.afterFooter.apply(this, arguments);

                    var lines = [];
                    lines = pushOrConcat(lines, beforeFooter);
                    lines = pushOrConcat(lines, footer);
                    lines = pushOrConcat(lines, afterFooter);

                    return lines;
                },

                getAveragePosition: function(elements) {

                    if (!elements.length) {
                        return false;
                    }

                    var xPositions = [];
                    var yPositions = [];

                    helpers.each(elements, function(el) {
                        if (el) {
                            var pos = el.tooltipPosition();
                            xPositions.push(pos.x);
                            yPositions.push(pos.y);
                        }
                    });

                    var x = 0,
                        y = 0;
                    for (var i = 0; i < xPositions.length; i++) {
                        x += xPositions[i];
                        y += yPositions[i];
                    }

                    return {
                        x: Math.round(x / xPositions.length),
                        y: Math.round(y / xPositions.length)
                    };

                },

                update: function(changed) {
                    if (this._active.length) {
                        this._model.opacity = 1;

                        var element = this._active[0],
                            labelColors = [],
                            tooltipPosition;

                        var tooltipItems = [];

                        if (this._options.tooltips.mode === 'single') {
                            var yScale = element._yScale || element._scale; // handle radar || polarArea charts
                            tooltipItems.push({
                                xLabel: element._xScale ? element._xScale.getLabelForIndex(element._index, element._datasetIndex) : '',
                                yLabel: yScale ? yScale.getLabelForIndex(element._index, element._datasetIndex) : '',
                                index: element._index,
                                datasetIndex: element._datasetIndex
                            });
                            tooltipPosition = this.getAveragePosition(this._active);
                        } else {
                            helpers.each(this._data.datasets, function(dataset, datasetIndex) {
                                if (!this._chartInstance.isDatasetVisible(datasetIndex)) {
                                    return;
                                }

                                var meta = this._chartInstance.getDatasetMeta(datasetIndex);
                                var currentElement = meta.data[element._index];
                                if (currentElement) {
                                    var yScale = element._yScale || element._scale; // handle radar || polarArea charts

                                    tooltipItems.push({
                                        xLabel: currentElement._xScale ? currentElement._xScale.getLabelForIndex(currentElement._index, currentElement._datasetIndex) : '',
                                        yLabel: yScale ? yScale.getLabelForIndex(currentElement._index, currentElement._datasetIndex) : '',
                                        index: element._index,
                                        datasetIndex: datasetIndex
                                    });
                                }
                            }, this);

                            helpers.each(this._active, function(active) {
                                if (active) {
                                    labelColors.push({
                                        borderColor: active._view.borderColor,
                                        backgroundColor: active._view.backgroundColor
                                    });
                                }
                            }, null);

                            tooltipPosition = this.getAveragePosition(this._active);
                        }

                        // Build the Text Lines
                        helpers.extend(this._model, {
                            title: this.getTitle(tooltipItems, this._data),
                            beforeBody: this.getBeforeBody(tooltipItems, this._data),
                            body: this.getBody(tooltipItems, this._data),
                            afterBody: this.getAfterBody(tooltipItems, this._data),
                            footer: this.getFooter(tooltipItems, this._data)
                        });

                        helpers.extend(this._model, {
                            x: Math.round(tooltipPosition.x),
                            y: Math.round(tooltipPosition.y),
                            caretPadding: helpers.getValueOrDefault(tooltipPosition.padding, 2),
                            labelColors: labelColors
                        });

                        // We need to determine alignment of
                        var tooltipSize = this.getTooltipSize(this._model);
                        this.determineAlignment(tooltipSize); // Smart Tooltip placement to stay on the canvas

                        helpers.extend(this._model, this.getBackgroundPoint(this._model, tooltipSize));
                    } else {
                        this._model.opacity = 0;
                    }

                    if (changed && this._options.tooltips.custom) {
                        this._options.tooltips.custom.call(this, this._model);
                    }

                    return this;
                },
                getTooltipSize: function getTooltipSize(vm) {
                    var ctx = this._chart.ctx;

                    var size = {
                        height: vm.yPadding * 2, // Tooltip Padding
                        width: 0
                    };
                    var combinedBodyLength = vm.body.length + vm.beforeBody.length + vm.afterBody.length;

                    size.height += vm.title.length * vm.titleFontSize; // Title Lines
                    size.height += (vm.title.length - 1) * vm.titleSpacing; // Title Line Spacing
                    size.height += vm.title.length ? vm.titleMarginBottom : 0; // Title's bottom Margin
                    size.height += combinedBodyLength * vm.bodyFontSize; // Body Lines
                    size.height += combinedBodyLength ? (combinedBodyLength - 1) * vm.bodySpacing : 0; // Body Line Spacing
                    size.height += vm.footer.length ? vm.footerMarginTop : 0; // Footer Margin
                    size.height += vm.footer.length * (vm.footerFontSize); // Footer Lines
                    size.height += vm.footer.length ? (vm.footer.length - 1) * vm.footerSpacing : 0; // Footer Line Spacing

                    // Width
                    ctx.font = helpers.fontString(vm.titleFontSize, vm._titleFontStyle, vm._titleFontFamily);
                    helpers.each(vm.title, function(line) {
                        size.width = Math.max(size.width, ctx.measureText(line).width);
                    });

                    ctx.font = helpers.fontString(vm.bodyFontSize, vm._bodyFontStyle, vm._bodyFontFamily);
                    helpers.each(vm.beforeBody.concat(vm.afterBody), function(line) {
                        size.width = Math.max(size.width, ctx.measureText(line).width);
                    });
                    helpers.each(vm.body, function(line) {
                        size.width = Math.max(size.width, ctx.measureText(line).width + (this._options.tooltips.mode !== 'single' ? (vm.bodyFontSize + 2) : 0));
                    }, this);

                    ctx.font = helpers.fontString(vm.footerFontSize, vm._footerFontStyle, vm._footerFontFamily);
                    helpers.each(vm.footer, function(line) {
                        size.width = Math.max(size.width, ctx.measureText(line).width);
                    });
                    size.width += 2 * vm.xPadding;

                    return size;
                },
                determineAlignment: function determineAlignment(size) {
                    if (this._model.y < size.height) {
                        this._model.yAlign = 'top';
                    } else if (this._model.y > (this._chart.height - size.height)) {
                        this._model.yAlign = 'bottom';
                    }

                    var lf, rf; // functions to determine left, right alignment
                    var olf, orf; // functions to determine if left/right alignment causes tooltip to go outside chart
                    var yf; // function to get the y alignment if the tooltip goes outside of the left or right edges
                    var _this = this;
                    var midX = (this._chartInstance.chartArea.left + this._chartInstance.chartArea.right) / 2;
                    var midY = (this._chartInstance.chartArea.top + this._chartInstance.chartArea.bottom) / 2;

                    if (this._model.yAlign === 'center') {
                        lf = function(x) {
                            return x <= midX;
                        };
                        rf = function(x) {
                            return x > midX;
                        };
                    } else {
                        lf = function(x) {
                            return x <= (size.width / 2);
                        };
                        rf = function(x) {
                            return x >= (_this._chart.width - (size.width / 2));
                        };
                    }

                    olf = function(x) {
                        return x + size.width > _this._chart.width;
                    };
                    orf = function(x) {
                        return x - size.width < 0;
                    };
                    yf = function(y) {
                        return y <= midY ? 'top' : 'bottom';
                    };

                    if (lf(this._model.x)) {
                        this._model.xAlign = 'left';

                        // Is tooltip too wide and goes over the right side of the chart.?
                        if (olf(this._model.x)) {
                            this._model.xAlign = 'center';
                            this._model.yAlign = yf(this._model.y);
                        }
                    } else if (rf(this._model.x)) {
                        this._model.xAlign = 'right';

                        // Is tooltip too wide and goes outside left edge of canvas?
                        if (orf(this._model.x)) {
                            this._model.xAlign = 'center';
                            this._model.yAlign = yf(this._model.y);
                        }
                    }
                },
                getBackgroundPoint: function getBackgroundPoint(vm, size) {
                    // Background Position
                    var pt = {
                        x: vm.x,
                        y: vm.y
                    };

                    if (vm.xAlign === 'right') {
                        pt.x -= size.width;
                    } else if (vm.xAlign === 'center') {
                        pt.x -= (size.width / 2);
                    }

                    if (vm.yAlign === 'top') {
                        pt.y += vm.caretPadding + vm.caretSize;
                    } else if (vm.yAlign === 'bottom') {
                        pt.y -= size.height + vm.caretPadding + vm.caretSize;
                    } else {
                        pt.y -= (size.height / 2);
                    }

                    if (vm.yAlign === 'center') {
                        if (vm.xAlign === 'left') {
                            pt.x += vm.caretPadding + vm.caretSize;
                        } else if (vm.xAlign === 'right') {
                            pt.x -= vm.caretPadding + vm.caretSize;
                        }
                    } else {
                        if (vm.xAlign === 'left') {
                            pt.x -= vm.cornerRadius + vm.caretPadding;
                        } else if (vm.xAlign === 'right') {
                            pt.x += vm.cornerRadius + vm.caretPadding;
                        }
                    }

                    return pt;
                },
                drawCaret: function drawCaret(tooltipPoint, size, opacity, caretPadding) {
                    var vm = this._view;
                    var ctx = this._chart.ctx;
                    var x1, x2, x3;
                    var y1, y2, y3;

                    if (vm.yAlign === 'center') {
                        // Left or right side
                        if (vm.xAlign === 'left') {
                            x1 = tooltipPoint.x;
                            x2 = x1 - vm.caretSize;
                            x3 = x1;
                        } else {
                            x1 = tooltipPoint.x + size.width;
                            x2 = x1 + vm.caretSize;
                            x3 = x1;
                        }

                        y2 = tooltipPoint.y + (size.height / 2);
                        y1 = y2 - vm.caretSize;
                        y3 = y2 + vm.caretSize;
                    } else {
                        if (vm.xAlign === 'left') {
                            x1 = tooltipPoint.x + vm.cornerRadius;
                            x2 = x1 + vm.caretSize;
                            x3 = x2 + vm.caretSize;
                        } else if (vm.xAlign === 'right') {
                            x1 = tooltipPoint.x + size.width - vm.cornerRadius;
                            x2 = x1 - vm.caretSize;
                            x3 = x2 - vm.caretSize;
                        } else {
                            x2 = tooltipPoint.x + (size.width / 2);
                            x1 = x2 - vm.caretSize;
                            x3 = x2 + vm.caretSize;
                        }

                        if (vm.yAlign === 'top') {
                            y1 = tooltipPoint.y;
                            y2 = y1 - vm.caretSize;
                            y3 = y1;
                        } else {
                            y1 = tooltipPoint.y + size.height;
                            y2 = y1 + vm.caretSize;
                            y3 = y1;
                        }
                    }

                    var bgColor = helpers.color(vm.backgroundColor);
                    ctx.fillStyle = bgColor.alpha(opacity * bgColor.alpha()).rgbString();
                    ctx.beginPath();
                    ctx.moveTo(x1, y1);
                    ctx.lineTo(x2, y2);
                    ctx.lineTo(x3, y3);
                    ctx.closePath();
                    ctx.fill();
                },
                drawTitle: function drawTitle(pt, vm, ctx, opacity) {
                    if (vm.title.length) {
                        ctx.textAlign = vm._titleAlign;
                        ctx.textBaseline = "top";

                        var titleColor = helpers.color(vm.titleColor);
                        ctx.fillStyle = titleColor.alpha(opacity * titleColor.alpha()).rgbString();
                        ctx.font = helpers.fontString(vm.titleFontSize, vm._titleFontStyle, vm._titleFontFamily);

                        helpers.each(vm.title, function(title, i) {
                            ctx.fillText(title, pt.x, pt.y);
                            pt.y += vm.titleFontSize + vm.titleSpacing; // Line Height and spacing

                            if (i + 1 === vm.title.length) {
                                pt.y += vm.titleMarginBottom - vm.titleSpacing; // If Last, add margin, remove spacing
                            }
                        });
                    }
                },
                drawBody: function drawBody(pt, vm, ctx, opacity) {
                    ctx.textAlign = vm._bodyAlign;
                    ctx.textBaseline = "top";

                    var bodyColor = helpers.color(vm.bodyColor);
                    ctx.fillStyle = bodyColor.alpha(opacity * bodyColor.alpha()).rgbString();
                    ctx.font = helpers.fontString(vm.bodyFontSize, vm._bodyFontStyle, vm._bodyFontFamily);

                    // Before Body
                    helpers.each(vm.beforeBody, function(beforeBody) {
                        ctx.fillText(beforeBody, pt.x, pt.y);
                        pt.y += vm.bodyFontSize + vm.bodySpacing;
                    });

                    helpers.each(vm.body, function(body, i) {
                        // Draw Legend-like boxes if needed
                        if (this._options.tooltips.mode !== 'single') {
                            // Fill a white rect so that colours merge nicely if the opacity is < 1
                            ctx.fillStyle = helpers.color(vm.legendColorBackground).alpha(opacity).rgbaString();
                            ctx.fillRect(pt.x, pt.y, vm.bodyFontSize, vm.bodyFontSize);

                            // Border
                            ctx.strokeStyle = helpers.color(vm.labelColors[i].borderColor).alpha(opacity).rgbaString();
                            ctx.strokeRect(pt.x, pt.y, vm.bodyFontSize, vm.bodyFontSize);

                            // Inner square
                            ctx.fillStyle = helpers.color(vm.labelColors[i].backgroundColor).alpha(opacity).rgbaString();
                            ctx.fillRect(pt.x + 1, pt.y + 1, vm.bodyFontSize - 2, vm.bodyFontSize - 2);

                            ctx.fillStyle = helpers.color(vm.bodyColor).alpha(opacity).rgbaString(); // Return fill style for text
                        }

                        // Body Line
                        ctx.fillText(body, pt.x + (this._options.tooltips.mode !== 'single' ? (vm.bodyFontSize + 2) : 0), pt.y);

                        pt.y += vm.bodyFontSize + vm.bodySpacing;
                    }, this);

                    // After Body
                    helpers.each(vm.afterBody, function(afterBody) {
                        ctx.fillText(afterBody, pt.x, pt.y);
                        pt.y += vm.bodyFontSize;
                    });

                    pt.y -= vm.bodySpacing; // Remove last body spacing
                },
                drawFooter: function drawFooter(pt, vm, ctx, opacity) {
                    if (vm.footer.length) {
                        pt.y += vm.footerMarginTop;

                        ctx.textAlign = vm._footerAlign;
                        ctx.textBaseline = "top";

                        var footerColor = helpers.color(vm.footerColor);
                        ctx.fillStyle = footerColor.alpha(opacity * footerColor.alpha()).rgbString();
                        ctx.font = helpers.fontString(vm.footerFontSize, vm._footerFontStyle, vm._footerFontFamily);

                        helpers.each(vm.footer, function(footer) {
                            ctx.fillText(footer, pt.x, pt.y);
                            pt.y += vm.footerFontSize + vm.footerSpacing;
                        });
                    }
                },
                draw: function draw() {
                    var ctx = this._chart.ctx;
                    var vm = this._view;

                    if (vm.opacity === 0) {
                        return;
                    }

                    var caretPadding = vm.caretPadding;
                    var tooltipSize = this.getTooltipSize(vm);
                    var pt = {
                        x: vm.x,
                        y: vm.y
                    };

                    // IE11/Edge does not like very small opacities, so snap to 0
                    var opacity = Math.abs(vm.opacity < 1e-3) ? 0 : vm.opacity;

                    if (this._options.tooltips.enabled) {
                        // Draw Background
                        var bgColor = helpers.color(vm.backgroundColor);
                        ctx.fillStyle = bgColor.alpha(opacity * bgColor.alpha()).rgbString();
                        helpers.drawRoundedRectangle(ctx, pt.x, pt.y, tooltipSize.width, tooltipSize.height, vm.cornerRadius);
                        ctx.fill();

                        // Draw Caret
                        this.drawCaret(pt, tooltipSize, opacity, caretPadding);

                        // Draw Title, Body, and Footer
                        pt.x += vm.xPadding;
                        pt.y += vm.yPadding;

                        // Titles
                        this.drawTitle(pt, vm, ctx, opacity);

                        // Body
                        this.drawBody(pt, vm, ctx, opacity);

                        // Footer
                        this.drawFooter(pt, vm, ctx, opacity);
                    }
                }
            });
        };

    }, {}],
    34: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart, moment) {

            var helpers = Chart.helpers,
                globalOpts = Chart.defaults.global;

            globalOpts.elements.arc = {
                backgroundColor: globalOpts.defaultColor,
                borderColor: "#fff",
                borderWidth: 2
            };

            Chart.elements.Arc = Chart.Element.extend({
                inLabelRange: function(mouseX) {
                    var vm = this._view;

                    if (vm) {
                        return (Math.pow(mouseX - vm.x, 2) < Math.pow(vm.radius + vm.hoverRadius, 2));
                    } else {
                        return false;
                    }
                },
                inRange: function(chartX, chartY) {
                    var vm = this._view;

                    if (vm) {
                        var pointRelativePosition = helpers.getAngleFromPoint(vm, {
                                x: chartX,
                                y: chartY
                            }),
                            angle = pointRelativePosition.angle,
                            distance = pointRelativePosition.distance;

                        //Sanitise angle range
                        var startAngle = vm.startAngle;
                        var endAngle = vm.endAngle;
                        while (endAngle < startAngle) {
                            endAngle += 2.0 * Math.PI;
                        }
                        while (angle > endAngle) {
                            angle -= 2.0 * Math.PI;
                        }
                        while (angle < startAngle) {
                            angle += 2.0 * Math.PI;
                        }

                        //Check if within the range of the open/close angle
                        var betweenAngles = (angle >= startAngle && angle <= endAngle),
                            withinRadius = (distance >= vm.innerRadius && distance <= vm.outerRadius);

                        return (betweenAngles && withinRadius);
                    } else {
                        return false;
                    }
                },
                tooltipPosition: function() {
                    var vm = this._view;

                    var centreAngle = vm.startAngle + ((vm.endAngle - vm.startAngle) / 2),
                        rangeFromCentre = (vm.outerRadius - vm.innerRadius) / 2 + vm.innerRadius;
                    return {
                        x: vm.x + (Math.cos(centreAngle) * rangeFromCentre),
                        y: vm.y + (Math.sin(centreAngle) * rangeFromCentre)
                    };
                },
                draw: function() {

                    var ctx = this._chart.ctx,
                        vm = this._view,
                        sA = vm.startAngle,
                        eA = vm.endAngle;

                    ctx.beginPath();

                    ctx.arc(vm.x, vm.y, vm.outerRadius, sA, eA);
                    ctx.arc(vm.x, vm.y, vm.innerRadius, eA, sA, true);

                    ctx.closePath();
                    ctx.strokeStyle = vm.borderColor;
                    ctx.lineWidth = vm.borderWidth;

                    ctx.fillStyle = vm.backgroundColor;

                    ctx.fill();
                    ctx.lineJoin = 'bevel';

                    if (vm.borderWidth) {
                        ctx.stroke();
                    }
                }
            });
        };

    }, {}],
    35: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            Chart.defaults.global.elements.line = {
                tension: 0.4,
                backgroundColor: Chart.defaults.global.defaultColor,
                borderWidth: 3,
                borderColor: Chart.defaults.global.defaultColor,
                borderCapStyle: 'butt',
                borderDash: [],
                borderDashOffset: 0.0,
                borderJoinStyle: 'miter',
                fill: true // do we fill in the area between the line and its base axis
            };

            Chart.elements.Line = Chart.Element.extend({
                lineToNextPoint: function(previousPoint, point, nextPoint, skipHandler, previousSkipHandler) {
                    var ctx = this._chart.ctx;

                    if (point._view.skip) {
                        skipHandler.call(this, previousPoint, point, nextPoint);
                    } else if (previousPoint._view.skip) {
                        previousSkipHandler.call(this, previousPoint, point, nextPoint);
                    } else if (point._view.tension === 0) {
                        ctx.lineTo(point._view.x, point._view.y);
                    } else {
                        // Line between points
                        ctx.bezierCurveTo(
                            previousPoint._view.controlPointNextX,
                            previousPoint._view.controlPointNextY,
                            point._view.controlPointPreviousX,
                            point._view.controlPointPreviousY,
                            point._view.x,
                            point._view.y
                        );
                    }
                },

                draw: function() {
                    var _this = this;

                    var vm = this._view;
                    var ctx = this._chart.ctx;
                    var first = this._children[0];
                    var last = this._children[this._children.length - 1];

                    function loopBackToStart(drawLineToCenter) {
                        if (!first._view.skip && !last._view.skip) {
                            // Draw a bezier line from last to first
                            ctx.bezierCurveTo(
                                last._view.controlPointNextX,
                                last._view.controlPointNextY,
                                first._view.controlPointPreviousX,
                                first._view.controlPointPreviousY,
                                first._view.x,
                                first._view.y
                            );
                        } else if (drawLineToCenter) {
                            // Go to center
                            ctx.lineTo(_this._view.scaleZero.x, _this._view.scaleZero.y);
                        }
                    }

                    ctx.save();

                    // If we had points and want to fill this line, do so.
                    if (this._children.length > 0 && vm.fill) {
                        // Draw the background first (so the border is always on top)
                        ctx.beginPath();

                        helpers.each(this._children, function(point, index) {
                            var previous = helpers.previousItem(this._children, index);
                            var next = helpers.nextItem(this._children, index);

                            // First point moves to it's starting position no matter what
                            if (index === 0) {
                                if (this._loop) {
                                    ctx.moveTo(vm.scaleZero.x, vm.scaleZero.y);
                                } else {
                                    ctx.moveTo(point._view.x, vm.scaleZero);
                                }

                                if (point._view.skip) {
                                    if (!this._loop) {
                                        ctx.moveTo(next._view.x, this._view.scaleZero);
                                    }
                                } else {
                                    ctx.lineTo(point._view.x, point._view.y);
                                }
                            } else {
                                this.lineToNextPoint(previous, point, next, function(previousPoint, point, nextPoint) {
                                    if (this._loop) {
                                        // Go to center
                                        ctx.lineTo(this._view.scaleZero.x, this._view.scaleZero.y);
                                    } else {
                                        ctx.lineTo(previousPoint._view.x, this._view.scaleZero);
                                        ctx.moveTo(nextPoint._view.x, this._view.scaleZero);
                                    }
                                }, function(previousPoint, point) {
                                    // If we skipped the last point, draw a line to ourselves so that the fill is nice
                                    ctx.lineTo(point._view.x, point._view.y);
                                });
                            }
                        }, this);

                        // For radial scales, loop back around to the first point
                        if (this._loop) {
                            loopBackToStart(true);
                        } else {
                            //Round off the line by going to the base of the chart, back to the start, then fill.
                            ctx.lineTo(this._children[this._children.length - 1]._view.x, vm.scaleZero);
                            ctx.lineTo(this._children[0]._view.x, vm.scaleZero);
                        }

                        ctx.fillStyle = vm.backgroundColor || Chart.defaults.global.defaultColor;
                        ctx.closePath();
                        ctx.fill();
                    }

                    // Now draw the line between all the points with any borders
                    ctx.lineCap = vm.borderCapStyle || Chart.defaults.global.elements.line.borderCapStyle;

                    // IE 9 and 10 do not support line dash
                    if (ctx.setLineDash) {
                        ctx.setLineDash(vm.borderDash || Chart.defaults.global.elements.line.borderDash);
                    }

                    ctx.lineDashOffset = vm.borderDashOffset || Chart.defaults.global.elements.line.borderDashOffset;
                    ctx.lineJoin = vm.borderJoinStyle || Chart.defaults.global.elements.line.borderJoinStyle;
                    ctx.lineWidth = vm.borderWidth || Chart.defaults.global.elements.line.borderWidth;
                    ctx.strokeStyle = vm.borderColor || Chart.defaults.global.defaultColor;
                    ctx.beginPath();

                    helpers.each(this._children, function(point, index) {
                        var previous = helpers.previousItem(this._children, index);
                        var next = helpers.nextItem(this._children, index);

                        if (index === 0) {
                            ctx.moveTo(point._view.x, point._view.y);
                        } else {
                            this.lineToNextPoint(previous, point, next, function(previousPoint, point, nextPoint) {
                                ctx.moveTo(nextPoint._view.x, nextPoint._view.y);
                            }, function(previousPoint, point) {
                                // If we skipped the last point, move up to our point preventing a line from being drawn
                                ctx.moveTo(point._view.x, point._view.y);
                            });
                        }
                    }, this);

                    if (this._loop && this._children.length > 0) {
                        loopBackToStart();
                    }

                    ctx.stroke();
                    ctx.restore();
                }
            });
        };
    }, {}],
    36: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers,
                globalOpts = Chart.defaults.global;

            globalOpts.elements.point = {
                radius: 3,
                pointStyle: 'circle',
                backgroundColor: globalOpts.defaultColor,
                borderWidth: 1,
                borderColor: globalOpts.defaultColor,
                // Hover
                hitRadius: 1,
                hoverRadius: 4,
                hoverBorderWidth: 1
            };


            Chart.elements.Point = Chart.Element.extend({
                inRange: function(mouseX, mouseY) {
                    var vm = this._view;
                    return vm ? ((Math.pow(mouseX - vm.x, 2) + Math.pow(mouseY - vm.y, 2)) < Math.pow(vm.hitRadius + vm.radius, 2)) : false;
                },
                inLabelRange: function(mouseX) {
                    var vm = this._view;
                    return vm ? (Math.pow(mouseX - vm.x, 2) < Math.pow(vm.radius + vm.hitRadius, 2)) : false;
                },
                tooltipPosition: function() {
                    var vm = this._view;
                    return {
                        x: vm.x,
                        y: vm.y,
                        padding: vm.radius + vm.borderWidth
                    };
                },
                draw: function() {
                    var vm = this._view,
                        x = vm.x,
                        y = vm.y;
                    var ctx = this._chart.ctx;

                    if (vm.skip) {
                        return;
                    }

                    var pointStyle = vm.pointStyle;
                    if (typeof pointStyle === 'object' && ((pointStyle.toString() === '[object HTMLImageElement]') || (pointStyle.toString() === '[object HTMLCanvasElement]'))) {
                        ctx.drawImage(pointStyle, x - pointStyle.width / 2, y - pointStyle.height / 2);
                        return;
                    }

                    if (!isNaN(vm.radius) && vm.radius > 0) {

                        ctx.strokeStyle = vm.borderColor || Chart.defaults.global.defaultColor;
                        ctx.lineWidth = helpers.getValueOrDefault(vm.borderWidth, Chart.defaults.global.elements.point.borderWidth);

                        ctx.fillStyle = vm.backgroundColor || Chart.defaults.global.defaultColor;

                        var radius = vm.radius;

                        var xOffset,
                            yOffset;

                        switch (pointStyle) {
                            // Default includes circle
                            default: ctx.beginPath();
                            ctx.arc(x, y, radius, 0, Math.PI * 2);
                            ctx.closePath();
                            ctx.fill();
                            break;
                            case 'triangle':
                                    ctx.beginPath();
                                var edgeLength = 3 * radius / Math.sqrt(3);
                                var height = edgeLength * Math.sqrt(3) / 2;
                                ctx.moveTo(x - edgeLength / 2, y + height / 3);
                                ctx.lineTo(x + edgeLength / 2, y + height / 3);
                                ctx.lineTo(x, y - 2 * height / 3);
                                ctx.closePath();
                                ctx.fill();
                                break;
                            case 'rect':
                                    ctx.fillRect(x - 1 / Math.SQRT2 * radius, y - 1 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius);
                                ctx.strokeRect(x - 1 / Math.SQRT2 * radius, y - 1 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius);
                                break;
                            case 'rectRot':
                                    ctx.translate(x, y);
                                ctx.rotate(Math.PI / 4);
                                ctx.fillRect(-1 / Math.SQRT2 * radius, -1 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius);
                                ctx.strokeRect(-1 / Math.SQRT2 * radius, -1 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius, 2 / Math.SQRT2 * radius);
                                ctx.setTransform(1, 0, 0, 1, 0, 0);
                                break;
                            case 'cross':
                                    ctx.beginPath();
                                ctx.moveTo(x, y + radius);
                                ctx.lineTo(x, y - radius);
                                ctx.moveTo(x - radius, y);
                                ctx.lineTo(x + radius, y);
                                ctx.closePath();
                                break;
                            case 'crossRot':
                                    ctx.beginPath();
                                xOffset = Math.cos(Math.PI / 4) * radius;
                                yOffset = Math.sin(Math.PI / 4) * radius;
                                ctx.moveTo(x - xOffset, y - yOffset);
                                ctx.lineTo(x + xOffset, y + yOffset);
                                ctx.moveTo(x - xOffset, y + yOffset);
                                ctx.lineTo(x + xOffset, y - yOffset);
                                ctx.closePath();
                                break;
                            case 'star':
                                    ctx.beginPath();
                                ctx.moveTo(x, y + radius);
                                ctx.lineTo(x, y - radius);
                                ctx.moveTo(x - radius, y);
                                ctx.lineTo(x + radius, y);
                                xOffset = Math.cos(Math.PI / 4) * radius;
                                yOffset = Math.sin(Math.PI / 4) * radius;
                                ctx.moveTo(x - xOffset, y - yOffset);
                                ctx.lineTo(x + xOffset, y + yOffset);
                                ctx.moveTo(x - xOffset, y + yOffset);
                                ctx.lineTo(x + xOffset, y - yOffset);
                                ctx.closePath();
                                break;
                            case 'line':
                                    ctx.beginPath();
                                ctx.moveTo(x - radius, y);
                                ctx.lineTo(x + radius, y);
                                ctx.closePath();
                                break;
                            case 'dash':
                                    ctx.beginPath();
                                ctx.moveTo(x, y);
                                ctx.lineTo(x + radius, y);
                                ctx.closePath();
                                break;
                        }

                        ctx.stroke();
                    }
                }
            });
        };
    }, {}],
    37: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers,
                globalOpts = Chart.defaults.global;

            globalOpts.elements.rectangle = {
                backgroundColor: globalOpts.defaultColor,
                borderWidth: 0,
                borderColor: globalOpts.defaultColor,
                borderSkipped: 'bottom'
            };

            Chart.elements.Rectangle = Chart.Element.extend({
                draw: function() {
                    var ctx = this._chart.ctx;
                    var vm = this._view;

                    var halfWidth = vm.width / 2,
                        leftX = vm.x - halfWidth,
                        rightX = vm.x + halfWidth,
                        top = vm.base - (vm.base - vm.y),
                        halfStroke = vm.borderWidth / 2;

                    // Canvas doesn't allow us to stroke inside the width so we can
                    // adjust the sizes to fit if we're setting a stroke on the line
                    if (vm.borderWidth) {
                        leftX += halfStroke;
                        rightX -= halfStroke;
                        top += halfStroke;
                    }

                    ctx.beginPath();
                    ctx.fillStyle = vm.backgroundColor;
                    ctx.strokeStyle = vm.borderColor;
                    ctx.lineWidth = vm.borderWidth;

                    // Corner points, from bottom-left to bottom-right clockwise
                    // | 1 2 |
                    // | 0 3 |
                    var corners = [
                        [leftX, vm.base],
                        [leftX, top],
                        [rightX, top],
                        [rightX, vm.base]
                    ];

                    // Find first (starting) corner with fallback to 'bottom' 
                    var borders = ['bottom', 'left', 'top', 'right'];
                    var startCorner = borders.indexOf(vm.borderSkipped, 0);
                    if (startCorner === -1)
                        startCorner = 0;

                    function cornerAt(index) {
                        return corners[(startCorner + index) % 4];
                    }

                    // Draw rectangle from 'startCorner'
                    ctx.moveTo.apply(ctx, cornerAt(0));
                    for (var i = 1; i < 4; i++)
                        ctx.lineTo.apply(ctx, cornerAt(i));

                    ctx.fill();
                    if (vm.borderWidth) {
                        ctx.stroke();
                    }
                },
                height: function() {
                    var vm = this._view;
                    return vm.base - vm.y;
                },
                inRange: function(mouseX, mouseY) {
                    var vm = this._view;
                    return vm ?
                        (vm.y < vm.base ?
                            (mouseX >= vm.x - vm.width / 2 && mouseX <= vm.x + vm.width / 2) && (mouseY >= vm.y && mouseY <= vm.base) :
                            (mouseX >= vm.x - vm.width / 2 && mouseX <= vm.x + vm.width / 2) && (mouseY >= vm.base && mouseY <= vm.y)) :
                        false;
                },
                inLabelRange: function(mouseX) {
                    var vm = this._view;
                    return vm ? (mouseX >= vm.x - vm.width / 2 && mouseX <= vm.x + vm.width / 2) : false;
                },
                tooltipPosition: function() {
                    var vm = this._view;
                    return {
                        x: vm.x,
                        y: vm.y
                    };
                }
            });

        };
    }, {}],
    38: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;
            // Default config for a category scale
            var defaultConfig = {
                position: "bottom"
            };

            var DatasetScale = Chart.Scale.extend({
                // Implement this so that 
                determineDataLimits: function() {
                    this.minIndex = 0;
                    this.maxIndex = this.chart.data.labels.length - 1;
                    var findIndex;

                    if (this.options.ticks.min !== undefined) {
                        // user specified min value
                        findIndex = helpers.indexOf(this.chart.data.labels, this.options.ticks.min);
                        this.minIndex = findIndex !== -1 ? findIndex : this.minIndex;
                    }

                    if (this.options.ticks.max !== undefined) {
                        // user specified max value
                        findIndex = helpers.indexOf(this.chart.data.labels, this.options.ticks.max);
                        this.maxIndex = findIndex !== -1 ? findIndex : this.maxIndex;
                    }

                    this.min = this.chart.data.labels[this.minIndex];
                    this.max = this.chart.data.labels[this.maxIndex];
                },

                buildTicks: function(index) {
                    // If we are viewing some subset of labels, slice the original array
                    this.ticks = (this.minIndex === 0 && this.maxIndex === this.chart.data.labels.length - 1) ? this.chart.data.labels : this.chart.data.labels.slice(this.minIndex, this.maxIndex + 1);
                },

                getLabelForIndex: function(index, datasetIndex) {
                    return this.ticks[index];
                },

                // Used to get data value locations.  Value can either be an index or a numerical value
                getPixelForValue: function(value, index, datasetIndex, includeOffset) {
                    // 1 is added because we need the length but we have the indexes
                    var offsetAmt = Math.max((this.maxIndex + 1 - this.minIndex - ((this.options.gridLines.offsetGridLines) ? 0 : 1)), 1);

                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        var valueWidth = innerWidth / offsetAmt;
                        var widthOffset = (valueWidth * (index - this.minIndex)) + this.paddingLeft;

                        if (this.options.gridLines.offsetGridLines && includeOffset) {
                            widthOffset += (valueWidth / 2);
                        }

                        return this.left + Math.round(widthOffset);
                    } else {
                        var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                        var valueHeight = innerHeight / offsetAmt;
                        var heightOffset = (valueHeight * (index - this.minIndex)) + this.paddingTop;

                        if (this.options.gridLines.offsetGridLines && includeOffset) {
                            heightOffset += (valueHeight / 2);
                        }

                        return this.top + Math.round(heightOffset);
                    }
                },
                getPixelForTick: function(index, includeOffset) {
                    return this.getPixelForValue(this.ticks[index], index + this.minIndex, null, includeOffset);
                },
                getValueForPixel: function(pixel) {
                    var value;
                    var offsetAmt = Math.max((this.ticks.length - ((this.options.gridLines.offsetGridLines) ? 0 : 1)), 1);
                    var horz = this.isHorizontal();
                    var innerDimension = horz ? this.width - (this.paddingLeft + this.paddingRight) : this.height - (this.paddingTop + this.paddingBottom);
                    var valueDimension = innerDimension / offsetAmt;

                    if (this.options.gridLines.offsetGridLines) {
                        pixel -= (valueDimension / 2);
                    }
                    pixel -= horz ? this.paddingLeft : this.paddingTop;

                    if (pixel <= 0) {
                        value = 0;
                    } else {
                        value = Math.round(pixel / valueDimension);
                    }

                    return value;
                }
            });

            Chart.scaleService.registerScaleType("category", DatasetScale, defaultConfig);

        };
    }, {}],
    39: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            var defaultConfig = {
                position: "left",
                ticks: {
                    callback: function(tickValue, index, ticks) {
                        // If we have lots of ticks, don't use the ones
                        var delta = ticks.length > 3 ? ticks[2] - ticks[1] : ticks[1] - ticks[0];

                        // If we have a number like 2.5 as the delta, figure out how many decimal places we need
                        if (Math.abs(delta) > 1) {
                            if (tickValue !== Math.floor(tickValue)) {
                                // not an integer
                                delta = tickValue - Math.floor(tickValue);
                            }
                        }

                        var logDelta = helpers.log10(Math.abs(delta));
                        var tickString = '';

                        if (tickValue !== 0) {
                            var numDecimal = -1 * Math.floor(logDelta);
                            numDecimal = Math.max(Math.min(numDecimal, 20), 0); // toFixed has a max of 20 decimal places
                            tickString = tickValue.toFixed(numDecimal);
                        } else {
                            tickString = '0'; // never show decimal places for 0
                        }

                        return tickString;
                    }
                }
            };

            var LinearScale = Chart.Scale.extend({
                determineDataLimits: function() {
                    // First Calculate the range
                    this.min = null;
                    this.max = null;

                    if (this.options.stacked) {
                        var valuesPerType = {};
                        var hasPositiveValues = false;
                        var hasNegativeValues = false;

                        helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                            var meta = this.chart.getDatasetMeta(datasetIndex);
                            if (valuesPerType[meta.type] === undefined) {
                                valuesPerType[meta.type] = {
                                    positiveValues: [],
                                    negativeValues: []
                                };
                            }

                            // Store these per type
                            var positiveValues = valuesPerType[meta.type].positiveValues;
                            var negativeValues = valuesPerType[meta.type].negativeValues;

                            if (this.chart.isDatasetVisible(datasetIndex) && (this.isHorizontal() ? meta.xAxisID === this.id : meta.yAxisID === this.id)) {
                                helpers.each(dataset.data, function(rawValue, index) {
                                    var value = +this.getRightValue(rawValue);
                                    if (isNaN(value) || meta.data[index].hidden) {
                                        return;
                                    }

                                    positiveValues[index] = positiveValues[index] || 0;
                                    negativeValues[index] = negativeValues[index] || 0;

                                    if (this.options.relativePoints) {
                                        positiveValues[index] = 100;
                                    } else {
                                        if (value < 0) {
                                            hasNegativeValues = true;
                                            negativeValues[index] += value;
                                        } else {
                                            hasPositiveValues = true;
                                            positiveValues[index] += value;
                                        }
                                    }
                                }, this);
                            }
                        }, this);

                        helpers.each(valuesPerType, function(valuesForType) {
                            var values = valuesForType.positiveValues.concat(valuesForType.negativeValues);
                            var minVal = helpers.min(values);
                            var maxVal = helpers.max(values);
                            this.min = this.min === null ? minVal : Math.min(this.min, minVal);
                            this.max = this.max === null ? maxVal : Math.max(this.max, maxVal);
                        }, this);

                    } else {
                        helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                            var meta = this.chart.getDatasetMeta(datasetIndex);
                            if (this.chart.isDatasetVisible(datasetIndex) && (this.isHorizontal() ? meta.xAxisID === this.id : meta.yAxisID === this.id)) {
                                helpers.each(dataset.data, function(rawValue, index) {
                                    var value = +this.getRightValue(rawValue);
                                    if (isNaN(value) || meta.data[index].hidden) {
                                        return;
                                    }

                                    if (this.min === null) {
                                        this.min = value;
                                    } else if (value < this.min) {
                                        this.min = value;
                                    }

                                    if (this.max === null) {
                                        this.max = value;
                                    } else if (value > this.max) {
                                        this.max = value;
                                    }
                                }, this);
                            }
                        }, this);
                    }

                    // If we are forcing it to begin at 0, but 0 will already be rendered on the chart,
                    // do nothing since that would make the chart weird. If the user really wants a weird chart
                    // axis, they can manually override it
                    if (this.options.ticks.beginAtZero) {
                        var minSign = helpers.sign(this.min);
                        var maxSign = helpers.sign(this.max);

                        if (minSign < 0 && maxSign < 0) {
                            // move the top up to 0
                            this.max = 0;
                        } else if (minSign > 0 && maxSign > 0) {
                            // move the botttom down to 0
                            this.min = 0;
                        }
                    }

                    if (this.options.ticks.min !== undefined) {
                        this.min = this.options.ticks.min;
                    } else if (this.options.ticks.suggestedMin !== undefined) {
                        this.min = Math.min(this.min, this.options.ticks.suggestedMin);
                    }

                    if (this.options.ticks.max !== undefined) {
                        this.max = this.options.ticks.max;
                    } else if (this.options.ticks.suggestedMax !== undefined) {
                        this.max = Math.max(this.max, this.options.ticks.suggestedMax);
                    }

                    if (this.min === this.max) {
                        this.max++;

                        if (!this.options.ticks.beginAtZero) {
                            this.min--;
                        }
                    }
                },
                buildTicks: function() {

                    // Then calulate the ticks
                    this.ticks = [];

                    // Figure out what the max number of ticks we can support it is based on the size of
                    // the axis area. For now, we say that the minimum tick spacing in pixels must be 50
                    // We also limit the maximum number of ticks to 11 which gives a nice 10 squares on
                    // the graph

                    var maxTicks;

                    if (this.isHorizontal()) {
                        maxTicks = Math.min(this.options.ticks.maxTicksLimit ? this.options.ticks.maxTicksLimit : 11, Math.ceil(this.width / 50));
                    } else {
                        // The factor of 2 used to scale the font size has been experimentally determined.
                        var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                        maxTicks = Math.min(this.options.ticks.maxTicksLimit ? this.options.ticks.maxTicksLimit : 11, Math.ceil(this.height / (2 * tickFontSize)));
                    }

                    // Make sure we always have at least 2 ticks
                    maxTicks = Math.max(2, maxTicks);

                    // To get a "nice" value for the tick spacing, we will use the appropriately named
                    // "nice number" algorithm. See http://stackoverflow.com/questions/8506881/nice-label-algorithm-for-charts-with-minimum-ticks
                    // for details.

                    var spacing;
                    var fixedStepSizeSet = (this.options.ticks.fixedStepSize && this.options.ticks.fixedStepSize > 0) || (this.options.ticks.stepSize && this.options.ticks.stepSize > 0);
                    if (fixedStepSizeSet) {
                        spacing = helpers.getValueOrDefault(this.options.ticks.fixedStepSize, this.options.ticks.stepSize);
                    } else {
                        var niceRange = helpers.niceNum(this.max - this.min, false);
                        spacing = helpers.niceNum(niceRange / (maxTicks - 1), true);
                    }
                    var niceMin = Math.floor(this.min / spacing) * spacing;
                    var niceMax = Math.ceil(this.max / spacing) * spacing;
                    var numSpaces = (niceMax - niceMin) / spacing;

                    // If very close to our rounded value, use it.
                    if (helpers.almostEquals(numSpaces, Math.round(numSpaces), spacing / 1000)) {
                        numSpaces = Math.round(numSpaces);
                    } else {
                        numSpaces = Math.ceil(numSpaces);
                    }

                    // Put the values into the ticks array
                    this.ticks.push(this.options.ticks.min !== undefined ? this.options.ticks.min : niceMin);
                    for (var j = 1; j < numSpaces; ++j) {
                        this.ticks.push(niceMin + (j * spacing));
                    }
                    this.ticks.push(this.options.ticks.max !== undefined ? this.options.ticks.max : niceMax);

                    if (this.options.position === "left" || this.options.position === "right") {
                        // We are in a vertical orientation. The top value is the highest. So reverse the array
                        this.ticks.reverse();
                    }

                    // At this point, we need to update our max and min given the tick values since we have expanded the
                    // range of the scale
                    this.max = helpers.max(this.ticks);
                    this.min = helpers.min(this.ticks);

                    if (this.options.ticks.reverse) {
                        this.ticks.reverse();

                        this.start = this.max;
                        this.end = this.min;
                    } else {
                        this.start = this.min;
                        this.end = this.max;
                    }
                },
                getLabelForIndex: function(index, datasetIndex) {
                    return +this.getRightValue(this.chart.data.datasets[datasetIndex].data[index]);
                },
                convertTicksToLabels: function() {
                    this.ticksAsNumbers = this.ticks.slice();
                    this.zeroLineIndex = this.ticks.indexOf(0);

                    Chart.Scale.prototype.convertTicksToLabels.call(this);
                },
                // Utils
                getPixelForValue: function(value, index, datasetIndex, includeOffset) {
                    // This must be called after fit has been run so that
                    //      this.left, this.top, this.right, and this.bottom have been defined
                    var rightValue = +this.getRightValue(value);
                    var pixel;
                    var range = this.end - this.start;

                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        pixel = this.left + (innerWidth / range * (rightValue - this.start));
                        return Math.round(pixel + this.paddingLeft);
                    } else {
                        var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                        pixel = (this.bottom - this.paddingBottom) - (innerHeight / range * (rightValue - this.start));
                        return Math.round(pixel);
                    }
                },
                getValueForPixel: function(pixel) {
                    var offset;

                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        offset = (pixel - this.left - this.paddingLeft) / innerWidth;
                    } else {
                        var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                        offset = (this.bottom - this.paddingBottom - pixel) / innerHeight;
                    }

                    return this.start + ((this.end - this.start) * offset);
                },
                getPixelForTick: function(index, includeOffset) {
                    return this.getPixelForValue(this.ticksAsNumbers[index], null, null, includeOffset);
                }
            });
            Chart.scaleService.registerScaleType("linear", LinearScale, defaultConfig);

        };
    }, {}],
    40: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            var defaultConfig = {
                position: "left",

                // label settings
                ticks: {
                    callback: function(value, index, arr) {
                        var remain = value / (Math.pow(10, Math.floor(Chart.helpers.log10(value))));

                        if (remain === 1 || remain === 2 || remain === 5 || index === 0 || index === arr.length - 1) {
                            return value.toExponential();
                        } else {
                            return '';
                        }
                    }
                }
            };

            var LogarithmicScale = Chart.Scale.extend({
                determineDataLimits: function() {
                    // Calculate Range
                    this.min = null;
                    this.max = null;

                    if (this.options.stacked) {
                        var valuesPerType = {};

                        helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                            var meta = this.chart.getDatasetMeta(datasetIndex);
                            if (this.chart.isDatasetVisible(datasetIndex) && (this.isHorizontal() ? meta.xAxisID === this.id : meta.yAxisID === this.id)) {
                                if (valuesPerType[meta.type] === undefined) {
                                    valuesPerType[meta.type] = [];
                                }

                                helpers.each(dataset.data, function(rawValue, index) {
                                    var values = valuesPerType[meta.type];
                                    var value = +this.getRightValue(rawValue);
                                    if (isNaN(value) || meta.data[index].hidden) {
                                        return;
                                    }

                                    values[index] = values[index] || 0;

                                    if (this.options.relativePoints) {
                                        values[index] = 100;
                                    } else {
                                        // Don't need to split positive and negative since the log scale can't handle a 0 crossing
                                        values[index] += value;
                                    }
                                }, this);
                            }
                        }, this);

                        helpers.each(valuesPerType, function(valuesForType) {
                            var minVal = helpers.min(valuesForType);
                            var maxVal = helpers.max(valuesForType);
                            this.min = this.min === null ? minVal : Math.min(this.min, minVal);
                            this.max = this.max === null ? maxVal : Math.max(this.max, maxVal);
                        }, this);

                    } else {
                        helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                            var meta = this.chart.getDatasetMeta(datasetIndex);
                            if (this.chart.isDatasetVisible(datasetIndex) && (this.isHorizontal() ? meta.xAxisID === this.id : meta.yAxisID === this.id)) {
                                helpers.each(dataset.data, function(rawValue, index) {
                                    var value = +this.getRightValue(rawValue);
                                    if (isNaN(value) || meta.data[index].hidden) {
                                        return;
                                    }

                                    if (this.min === null) {
                                        this.min = value;
                                    } else if (value < this.min) {
                                        this.min = value;
                                    }

                                    if (this.max === null) {
                                        this.max = value;
                                    } else if (value > this.max) {
                                        this.max = value;
                                    }
                                }, this);
                            }
                        }, this);
                    }

                    this.min = this.options.ticks.min !== undefined ? this.options.ticks.min : this.min;
                    this.max = this.options.ticks.max !== undefined ? this.options.ticks.max : this.max;

                    if (this.min === this.max) {
                        if (this.min !== 0 && this.min !== null) {
                            this.min = Math.pow(10, Math.floor(helpers.log10(this.min)) - 1);
                            this.max = Math.pow(10, Math.floor(helpers.log10(this.max)) + 1);
                        } else {
                            this.min = 1;
                            this.max = 10;
                        }
                    }
                },
                buildTicks: function() {
                    // Reset the ticks array. Later on, we will draw a grid line at these positions
                    // The array simply contains the numerical value of the spots where ticks will be
                    this.ticks = [];

                    // Figure out what the max number of ticks we can support it is based on the size of
                    // the axis area. For now, we say that the minimum tick spacing in pixels must be 50
                    // We also limit the maximum number of ticks to 11 which gives a nice 10 squares on
                    // the graph

                    var tickVal = this.options.ticks.min !== undefined ? this.options.ticks.min : Math.pow(10, Math.floor(helpers.log10(this.min)));

                    while (tickVal < this.max) {
                        this.ticks.push(tickVal);

                        var exp = Math.floor(helpers.log10(tickVal));
                        var significand = Math.floor(tickVal / Math.pow(10, exp)) + 1;

                        if (significand === 10) {
                            significand = 1;
                            ++exp;
                        }

                        tickVal = significand * Math.pow(10, exp);
                    }

                    var lastTick = this.options.ticks.max !== undefined ? this.options.ticks.max : tickVal;
                    this.ticks.push(lastTick);

                    if (this.options.position === "left" || this.options.position === "right") {
                        // We are in a vertical orientation. The top value is the highest. So reverse the array
                        this.ticks.reverse();
                    }

                    // At this point, we need to update our max and min given the tick values since we have expanded the
                    // range of the scale
                    this.max = helpers.max(this.ticks);
                    this.min = helpers.min(this.ticks);

                    if (this.options.ticks.reverse) {
                        this.ticks.reverse();

                        this.start = this.max;
                        this.end = this.min;
                    } else {
                        this.start = this.min;
                        this.end = this.max;
                    }
                },
                convertTicksToLabels: function() {
                    this.tickValues = this.ticks.slice();

                    Chart.Scale.prototype.convertTicksToLabels.call(this);
                },
                // Get the correct tooltip label
                getLabelForIndex: function(index, datasetIndex) {
                    return +this.getRightValue(this.chart.data.datasets[datasetIndex].data[index]);
                },
                getPixelForTick: function(index, includeOffset) {
                    return this.getPixelForValue(this.tickValues[index], null, null, includeOffset);
                },
                getPixelForValue: function(value, index, datasetIndex, includeOffset) {
                    var pixel;

                    var newVal = +this.getRightValue(value);
                    var range = helpers.log10(this.end) - helpers.log10(this.start);

                    if (this.isHorizontal()) {

                        if (newVal === 0) {
                            pixel = this.left + this.paddingLeft;
                        } else {
                            var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                            pixel = this.left + (innerWidth / range * (helpers.log10(newVal) - helpers.log10(this.start)));
                            pixel += this.paddingLeft;
                        }
                    } else {
                        // Bottom - top since pixels increase downard on a screen
                        if (newVal === 0) {
                            pixel = this.top + this.paddingTop;
                        } else {
                            var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                            pixel = (this.bottom - this.paddingBottom) - (innerHeight / range * (helpers.log10(newVal) - helpers.log10(this.start)));
                        }
                    }

                    return pixel;
                },
                getValueForPixel: function(pixel) {
                    var offset;
                    var range = helpers.log10(this.end) - helpers.log10(this.start);
                    var value;

                    if (this.isHorizontal()) {
                        var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                        value = this.start * Math.pow(10, (pixel - this.left - this.paddingLeft) * range / innerWidth);
                    } else {
                        var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                        value = Math.pow(10, (this.bottom - this.paddingBottom - pixel) * range / innerHeight) / this.start;
                    }

                    return value;
                }

            });
            Chart.scaleService.registerScaleType("logarithmic", LogarithmicScale, defaultConfig);

        };
    }, {}],
    41: [function(require, module, exports) {
        "use strict";

        module.exports = function(Chart) {

            var helpers = Chart.helpers;

            var defaultConfig = {
                display: true,

                //Boolean - Whether to animate scaling the chart from the centre
                animate: true,
                lineArc: false,
                position: "chartArea",

                angleLines: {
                    display: true,
                    color: "rgba(0, 0, 0, 0.1)",
                    lineWidth: 1
                },

                // label settings
                ticks: {
                    //Boolean - Show a backdrop to the scale label
                    showLabelBackdrop: true,

                    //String - The colour of the label backdrop
                    backdropColor: "rgba(255,255,255,0.75)",

                    //Number - The backdrop padding above & below the label in pixels
                    backdropPaddingY: 2,

                    //Number - The backdrop padding to the side of the label in pixels
                    backdropPaddingX: 2
                },

                pointLabels: {
                    //Number - Point label font size in pixels
                    fontSize: 10,

                    //Function - Used to convert point labels
                    callback: function(label) {
                        return label;
                    }
                }
            };

            var LinearRadialScale = Chart.Scale.extend({
                getValueCount: function() {
                    return this.chart.data.labels.length;
                },
                setDimensions: function() {
                    // Set the unconstrained dimension before label rotation
                    this.width = this.maxWidth;
                    this.height = this.maxHeight;
                    this.xCenter = Math.round(this.width / 2);
                    this.yCenter = Math.round(this.height / 2);

                    var minSize = helpers.min([this.height, this.width]);
                    var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                    this.drawingArea = (this.options.display) ? (minSize / 2) - (tickFontSize / 2 + this.options.ticks.backdropPaddingY) : (minSize / 2);
                },
                determineDataLimits: function() {
                    this.min = null;
                    this.max = null;

                    helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                        if (this.chart.isDatasetVisible(datasetIndex)) {
                            var meta = this.chart.getDatasetMeta(datasetIndex);
                            helpers.each(dataset.data, function(rawValue, index) {
                                var value = +this.getRightValue(rawValue);
                                if (isNaN(value) || meta.data[index].hidden) {
                                    return;
                                }

                                if (this.min === null) {
                                    this.min = value;
                                } else if (value < this.min) {
                                    this.min = value;
                                }

                                if (this.max === null) {
                                    this.max = value;
                                } else if (value > this.max) {
                                    this.max = value;
                                }
                            }, this);
                        }
                    }, this);

                    // If we are forcing it to begin at 0, but 0 will already be rendered on the chart,
                    // do nothing since that would make the chart weird. If the user really wants a weird chart
                    // axis, they can manually override it
                    if (this.options.ticks.beginAtZero) {
                        var minSign = helpers.sign(this.min);
                        var maxSign = helpers.sign(this.max);

                        if (minSign < 0 && maxSign < 0) {
                            // move the top up to 0
                            this.max = 0;
                        } else if (minSign > 0 && maxSign > 0) {
                            // move the botttom down to 0
                            this.min = 0;
                        }
                    }

                    if (this.options.ticks.min !== undefined) {
                        this.min = this.options.ticks.min;
                    } else if (this.options.ticks.suggestedMin !== undefined) {
                        this.min = Math.min(this.min, this.options.ticks.suggestedMin);
                    }

                    if (this.options.ticks.max !== undefined) {
                        this.max = this.options.ticks.max;
                    } else if (this.options.ticks.suggestedMax !== undefined) {
                        this.max = Math.max(this.max, this.options.ticks.suggestedMax);
                    }

                    if (this.min === this.max) {
                        this.min--;
                        this.max++;
                    }
                },
                buildTicks: function() {


                    this.ticks = [];

                    // Figure out what the max number of ticks we can support it is based on the size of
                    // the axis area. For now, we say that the minimum tick spacing in pixels must be 50
                    // We also limit the maximum number of ticks to 11 which gives a nice 10 squares on
                    // the graph
                    var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                    var maxTicks = Math.min(this.options.ticks.maxTicksLimit ? this.options.ticks.maxTicksLimit : 11, Math.ceil(this.drawingArea / (1.5 * tickFontSize)));
                    maxTicks = Math.max(2, maxTicks); // Make sure we always have at least 2 ticks

                    // To get a "nice" value for the tick spacing, we will use the appropriately named
                    // "nice number" algorithm. See http://stackoverflow.com/questions/8506881/nice-label-algorithm-for-charts-with-minimum-ticks
                    // for details.

                    var niceRange = helpers.niceNum(this.max - this.min, false);
                    var spacing = helpers.niceNum(niceRange / (maxTicks - 1), true);
                    var niceMin = Math.floor(this.min / spacing) * spacing;
                    var niceMax = Math.ceil(this.max / spacing) * spacing;

                    var numSpaces = Math.ceil((niceMax - niceMin) / spacing);

                    // Put the values into the ticks array
                    this.ticks.push(this.options.ticks.min !== undefined ? this.options.ticks.min : niceMin);
                    for (var j = 1; j < numSpaces; ++j) {
                        this.ticks.push(niceMin + (j * spacing));
                    }
                    this.ticks.push(this.options.ticks.max !== undefined ? this.options.ticks.max : niceMax);

                    // At this point, we need to update our max and min given the tick values since we have expanded the
                    // range of the scale
                    this.max = helpers.max(this.ticks);
                    this.min = helpers.min(this.ticks);

                    if (this.options.ticks.reverse) {
                        this.ticks.reverse();

                        this.start = this.max;
                        this.end = this.min;
                    } else {
                        this.start = this.min;
                        this.end = this.max;
                    }

                    this.zeroLineIndex = this.ticks.indexOf(0);
                },
                convertTicksToLabels: function() {
                    Chart.Scale.prototype.convertTicksToLabels.call(this);

                    // Point labels
                    this.pointLabels = this.chart.data.labels.map(this.options.pointLabels.callback, this);
                },
                getLabelForIndex: function(index, datasetIndex) {
                    return +this.getRightValue(this.chart.data.datasets[datasetIndex].data[index]);
                },
                fit: function() {
                    /*
                     * Right, this is really confusing and there is a lot of maths going on here
                     * The gist of the problem is here: https://gist.github.com/nnnick/696cc9c55f4b0beb8fe9
                     *
                     * Reaction: https://dl.dropboxusercontent.com/u/34601363/toomuchscience.gif
                     *
                     * Solution:
                     *
                     * We assume the radius of the polygon is half the size of the canvas at first
                     * at each index we check if the text overlaps.
                     *
                     * Where it does, we store that angle and that index.
                     *
                     * After finding the largest index and angle we calculate how much we need to remove
                     * from the shape radius to move the point inwards by that x.
                     *
                     * We average the left and right distances to get the maximum shape radius that can fit in the box
                     * along with labels.
                     *
                     * Once we have that, we can find the centre point for the chart, by taking the x text protrusion
                     * on each side, removing that from the size, halving it and adding the left x protrusion width.
                     *
                     * This will mean we have a shape fitted to the canvas, as large as it can be with the labels
                     * and position it in the most space efficient manner
                     *
                     * https://dl.dropboxusercontent.com/u/34601363/yeahscience.gif
                     */

                    var pointLabelFontSize = helpers.getValueOrDefault(this.options.pointLabels.fontSize, Chart.defaults.global.defaultFontSize);
                    var pointLabeFontStyle = helpers.getValueOrDefault(this.options.pointLabels.fontStyle, Chart.defaults.global.defaultFontStyle);
                    var pointLabeFontFamily = helpers.getValueOrDefault(this.options.pointLabels.fontFamily, Chart.defaults.global.defaultFontFamily);
                    var pointLabeFont = helpers.fontString(pointLabelFontSize, pointLabeFontStyle, pointLabeFontFamily);

                    // Get maximum radius of the polygon. Either half the height (minus the text width) or half the width.
                    // Use this to calculate the offset + change. - Make sure L/R protrusion is at least 0 to stop issues with centre points
                    var largestPossibleRadius = helpers.min([(this.height / 2 - pointLabelFontSize - 5), this.width / 2]),
                        pointPosition,
                        i,
                        textWidth,
                        halfTextWidth,
                        furthestRight = this.width,
                        furthestRightIndex,
                        furthestRightAngle,
                        furthestLeft = 0,
                        furthestLeftIndex,
                        furthestLeftAngle,
                        xProtrusionLeft,
                        xProtrusionRight,
                        radiusReductionRight,
                        radiusReductionLeft,
                        maxWidthRadius;
                    this.ctx.font = pointLabeFont;

                    for (i = 0; i < this.getValueCount(); i++) {
                        // 5px to space the text slightly out - similar to what we do in the draw function.
                        pointPosition = this.getPointPosition(i, largestPossibleRadius);
                        textWidth = this.ctx.measureText(this.pointLabels[i] ? this.pointLabels[i] : '').width + 5;
                        if (i === 0 || i === this.getValueCount() / 2) {
                            // If we're at index zero, or exactly the middle, we're at exactly the top/bottom
                            // of the radar chart, so text will be aligned centrally, so we'll half it and compare
                            // w/left and right text sizes
                            halfTextWidth = textWidth / 2;
                            if (pointPosition.x + halfTextWidth > furthestRight) {
                                furthestRight = pointPosition.x + halfTextWidth;
                                furthestRightIndex = i;
                            }
                            if (pointPosition.x - halfTextWidth < furthestLeft) {
                                furthestLeft = pointPosition.x - halfTextWidth;
                                furthestLeftIndex = i;
                            }
                        } else if (i < this.getValueCount() / 2) {
                            // Less than half the values means we'll left align the text
                            if (pointPosition.x + textWidth > furthestRight) {
                                furthestRight = pointPosition.x + textWidth;
                                furthestRightIndex = i;
                            }
                        } else if (i > this.getValueCount() / 2) {
                            // More than half the values means we'll right align the text
                            if (pointPosition.x - textWidth < furthestLeft) {
                                furthestLeft = pointPosition.x - textWidth;
                                furthestLeftIndex = i;
                            }
                        }
                    }

                    xProtrusionLeft = furthestLeft;
                    xProtrusionRight = Math.ceil(furthestRight - this.width);

                    furthestRightAngle = this.getIndexAngle(furthestRightIndex);
                    furthestLeftAngle = this.getIndexAngle(furthestLeftIndex);

                    radiusReductionRight = xProtrusionRight / Math.sin(furthestRightAngle + Math.PI / 2);
                    radiusReductionLeft = xProtrusionLeft / Math.sin(furthestLeftAngle + Math.PI / 2);

                    // Ensure we actually need to reduce the size of the chart
                    radiusReductionRight = (helpers.isNumber(radiusReductionRight)) ? radiusReductionRight : 0;
                    radiusReductionLeft = (helpers.isNumber(radiusReductionLeft)) ? radiusReductionLeft : 0;

                    this.drawingArea = Math.round(largestPossibleRadius - (radiusReductionLeft + radiusReductionRight) / 2);
                    this.setCenterPoint(radiusReductionLeft, radiusReductionRight);
                },
                setCenterPoint: function(leftMovement, rightMovement) {

                    var maxRight = this.width - rightMovement - this.drawingArea,
                        maxLeft = leftMovement + this.drawingArea;

                    this.xCenter = Math.round(((maxLeft + maxRight) / 2) + this.left);
                    // Always vertically in the centre as the text height doesn't change
                    this.yCenter = Math.round((this.height / 2) + this.top);
                },

                getIndexAngle: function(index) {
                    var angleMultiplier = (Math.PI * 2) / this.getValueCount();
                    // Start from the top instead of right, so remove a quarter of the circle

                    return index * angleMultiplier - (Math.PI / 2);
                },
                getDistanceFromCenterForValue: function(value) {
                    if (value === null) {
                        return 0; // null always in center
                    }

                    // Take into account half font size + the yPadding of the top value
                    var scalingFactor = this.drawingArea / (this.max - this.min);
                    if (this.options.reverse) {
                        return (this.max - value) * scalingFactor;
                    } else {
                        return (value - this.min) * scalingFactor;
                    }
                },
                getPointPosition: function(index, distanceFromCenter) {
                    var thisAngle = this.getIndexAngle(index);
                    return {
                        x: Math.round(Math.cos(thisAngle) * distanceFromCenter) + this.xCenter,
                        y: Math.round(Math.sin(thisAngle) * distanceFromCenter) + this.yCenter
                    };
                },
                getPointPositionForValue: function(index, value) {
                    return this.getPointPosition(index, this.getDistanceFromCenterForValue(value));
                },
                draw: function() {
                    if (this.options.display) {
                        var ctx = this.ctx;
                        helpers.each(this.ticks, function(label, index) {
                            // Don't draw a centre value (if it is minimum)
                            if (index > 0 || this.options.reverse) {
                                var yCenterOffset = this.getDistanceFromCenterForValue(this.ticks[index]);
                                var yHeight = this.yCenter - yCenterOffset;

                                // Draw circular lines around the scale
                                if (this.options.gridLines.display) {
                                    ctx.strokeStyle = this.options.gridLines.color;
                                    ctx.lineWidth = this.options.gridLines.lineWidth;

                                    if (this.options.lineArc) {
                                        // Draw circular arcs between the points
                                        ctx.beginPath();
                                        ctx.arc(this.xCenter, this.yCenter, yCenterOffset, 0, Math.PI * 2);
                                        ctx.closePath();
                                        ctx.stroke();
                                    } else {
                                        // Draw straight lines connecting each index
                                        ctx.beginPath();
                                        for (var i = 0; i < this.getValueCount(); i++) {
                                            var pointPosition = this.getPointPosition(i, this.getDistanceFromCenterForValue(this.ticks[index]));
                                            if (i === 0) {
                                                ctx.moveTo(pointPosition.x, pointPosition.y);
                                            } else {
                                                ctx.lineTo(pointPosition.x, pointPosition.y);
                                            }
                                        }
                                        ctx.closePath();
                                        ctx.stroke();
                                    }
                                }

                                if (this.options.ticks.display) {
                                    var tickFontColor = helpers.getValueOrDefault(this.options.ticks.fontColor, Chart.defaults.global.defaultFontColor);
                                    var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                                    var tickFontStyle = helpers.getValueOrDefault(this.options.ticks.fontStyle, Chart.defaults.global.defaultFontStyle);
                                    var tickFontFamily = helpers.getValueOrDefault(this.options.ticks.fontFamily, Chart.defaults.global.defaultFontFamily);
                                    var tickLabelFont = helpers.fontString(tickFontSize, tickFontStyle, tickFontFamily);
                                    ctx.font = tickLabelFont;

                                    if (this.options.ticks.showLabelBackdrop) {
                                        var labelWidth = ctx.measureText(label).width;
                                        ctx.fillStyle = this.options.ticks.backdropColor;
                                        ctx.fillRect(
                                            this.xCenter - labelWidth / 2 - this.options.ticks.backdropPaddingX,
                                            yHeight - tickFontSize / 2 - this.options.ticks.backdropPaddingY,
                                            labelWidth + this.options.ticks.backdropPaddingX * 2,
                                            tickFontSize + this.options.ticks.backdropPaddingY * 2
                                        );
                                    }

                                    ctx.textAlign = 'center';
                                    ctx.textBaseline = "middle";
                                    ctx.fillStyle = tickFontColor;
                                    ctx.fillText(label, this.xCenter, yHeight);
                                }
                            }
                        }, this);

                        if (!this.options.lineArc) {
                            ctx.lineWidth = this.options.angleLines.lineWidth;
                            ctx.strokeStyle = this.options.angleLines.color;

                            for (var i = this.getValueCount() - 1; i >= 0; i--) {
                                if (this.options.angleLines.display) {
                                    var outerPosition = this.getPointPosition(i, this.getDistanceFromCenterForValue(this.options.reverse ? this.min : this.max));
                                    ctx.beginPath();
                                    ctx.moveTo(this.xCenter, this.yCenter);
                                    ctx.lineTo(outerPosition.x, outerPosition.y);
                                    ctx.stroke();
                                    ctx.closePath();
                                }
                                // Extra 3px out for some label spacing
                                var pointLabelPosition = this.getPointPosition(i, this.getDistanceFromCenterForValue(this.options.reverse ? this.min : this.max) + 5);

                                var pointLabelFontColor = helpers.getValueOrDefault(this.options.pointLabels.fontColor, Chart.defaults.global.defaultFontColor);
                                var pointLabelFontSize = helpers.getValueOrDefault(this.options.pointLabels.fontSize, Chart.defaults.global.defaultFontSize);
                                var pointLabeFontStyle = helpers.getValueOrDefault(this.options.pointLabels.fontStyle, Chart.defaults.global.defaultFontStyle);
                                var pointLabeFontFamily = helpers.getValueOrDefault(this.options.pointLabels.fontFamily, Chart.defaults.global.defaultFontFamily);
                                var pointLabeFont = helpers.fontString(pointLabelFontSize, pointLabeFontStyle, pointLabeFontFamily);

                                ctx.font = pointLabeFont;
                                ctx.fillStyle = pointLabelFontColor;

                                var labelsCount = this.pointLabels.length,
                                    halfLabelsCount = this.pointLabels.length / 2,
                                    quarterLabelsCount = halfLabelsCount / 2,
                                    upperHalf = (i < quarterLabelsCount || i > labelsCount - quarterLabelsCount),
                                    exactQuarter = (i === quarterLabelsCount || i === labelsCount - quarterLabelsCount);
                                if (i === 0) {
                                    ctx.textAlign = 'center';
                                } else if (i === halfLabelsCount) {
                                    ctx.textAlign = 'center';
                                } else if (i < halfLabelsCount) {
                                    ctx.textAlign = 'left';
                                } else {
                                    ctx.textAlign = 'right';
                                }

                                // Set the correct text baseline based on outer positioning
                                if (exactQuarter) {
                                    ctx.textBaseline = 'middle';
                                } else if (upperHalf) {
                                    ctx.textBaseline = 'bottom';
                                } else {
                                    ctx.textBaseline = 'top';
                                }

                                ctx.fillText(this.pointLabels[i] ? this.pointLabels[i] : '', pointLabelPosition.x, pointLabelPosition.y);
                            }
                        }
                    }
                }
            });
            Chart.scaleService.registerScaleType("radialLinear", LinearRadialScale, defaultConfig);

        };
    }, {}],
    42: [function(require, module, exports) {
        /*global window: false */
        "use strict";

        var moment = require('moment');
        moment = typeof(moment) === 'function' ? moment : window.moment;

        module.exports = function(Chart) {

            var helpers = Chart.helpers;
            var time = {
                units: [{
                    name: 'millisecond',
                    steps: [1, 2, 5, 10, 20, 50, 100, 250, 500]
                }, {
                    name: 'second',
                    steps: [1, 2, 5, 10, 30]
                }, {
                    name: 'minute',
                    steps: [1, 2, 5, 10, 30]
                }, {
                    name: 'hour',
                    steps: [1, 2, 3, 6, 12]
                }, {
                    name: 'day',
                    steps: [1, 2, 5]
                }, {
                    name: 'week',
                    maxStep: 4
                }, {
                    name: 'month',
                    maxStep: 3
                }, {
                    name: 'quarter',
                    maxStep: 4
                }, {
                    name: 'year',
                    maxStep: false
                }]
            };

            var defaultConfig = {
                position: "bottom",

                time: {
                    parser: false, // false == a pattern string from http://momentjs.com/docs/#/parsing/string-format/ or a custom callback that converts its argument to a moment
                    format: false, // DEPRECATED false == date objects, moment object, callback or a pattern string from http://momentjs.com/docs/#/parsing/string-format/
                    unit: false, // false == automatic or override with week, month, year, etc.
                    round: false, // none, or override with week, month, year, etc.
                    displayFormat: false, // DEPRECATED
                    isoWeekday: false, // override week start day - see http://momentjs.com/docs/#/get-set/iso-weekday/

                    // defaults to unit's corresponding unitFormat below or override using pattern string from http://momentjs.com/docs/#/displaying/format/
                    displayFormats: {
                        'millisecond': 'h:mm:ss.SSS a', // 11:20:01.123 AM,
                        'second': 'h:mm:ss a', // 11:20:01 AM
                        'minute': 'h:mm:ss a', // 11:20:01 AM
                        'hour': 'MMM D, hA', // Sept 4, 5PM
                        'day': 'll', // Sep 4 2015
                        'week': 'll', // Week 46, or maybe "[W]WW - YYYY" ?
                        'month': 'MMM YYYY', // Sept 2015
                        'quarter': '[Q]Q - YYYY', // Q3
                        'year': 'YYYY' // 2015
                    }
                },
                ticks: {
                    autoSkip: false
                }
            };

            var TimeScale = Chart.Scale.extend({
                initialize: function() {
                    if (!moment) {
                        throw new Error('Chart.js - Moment.js could not be found! You must include it before Chart.js to use the time scale. Download at https://momentjs.com');
                    }

                    Chart.Scale.prototype.initialize.call(this);
                },
                getLabelMoment: function(datasetIndex, index) {
                    return this.labelMoments[datasetIndex][index];
                },
                getMomentStartOf: function(tick) {
                    if (this.options.time.unit === 'week' && this.options.time.isoWeekday !== false) {
                        return tick.clone().startOf('isoWeek').isoWeekday(this.options.time.isoWeekday);
                    } else {
                        return tick.clone().startOf(this.tickUnit);
                    }
                },
                determineDataLimits: function() {
                    this.labelMoments = [];

                    // Only parse these once. If the dataset does not have data as x,y pairs, we will use
                    // these
                    var scaleLabelMoments = [];
                    if (this.chart.data.labels && this.chart.data.labels.length > 0) {
                        helpers.each(this.chart.data.labels, function(label, index) {
                            var labelMoment = this.parseTime(label);

                            if (labelMoment.isValid()) {
                                if (this.options.time.round) {
                                    labelMoment.startOf(this.options.time.round);
                                }
                                scaleLabelMoments.push(labelMoment);
                            }
                        }, this);

                        this.firstTick = moment.min.call(this, scaleLabelMoments);
                        this.lastTick = moment.max.call(this, scaleLabelMoments);
                    } else {
                        this.firstTick = null;
                        this.lastTick = null;
                    }

                    helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                        var momentsForDataset = [];
                        var datasetVisible = this.chart.isDatasetVisible(datasetIndex);

                        if (typeof dataset.data[0] === 'object') {
                            helpers.each(dataset.data, function(value, index) {
                                var labelMoment = this.parseTime(this.getRightValue(value));

                                if (labelMoment.isValid()) {
                                    if (this.options.time.round) {
                                        labelMoment.startOf(this.options.time.round);
                                    }
                                    momentsForDataset.push(labelMoment);

                                    if (datasetVisible) {
                                        // May have gone outside the scale ranges, make sure we keep the first and last ticks updated
                                        this.firstTick = this.firstTick !== null ? moment.min(this.firstTick, labelMoment) : labelMoment;
                                        this.lastTick = this.lastTick !== null ? moment.max(this.lastTick, labelMoment) : labelMoment;
                                    }
                                }
                            }, this);
                        } else {
                            // We have no labels. Use the ones from the scale
                            momentsForDataset = scaleLabelMoments;
                        }

                        this.labelMoments.push(momentsForDataset);
                    }, this);

                    // Set these after we've done all the data
                    if (this.options.time.min) {
                        this.firstTick = this.parseTime(this.options.time.min);
                    }

                    if (this.options.time.max) {
                        this.lastTick = this.parseTime(this.options.time.max);
                    }

                    // We will modify these, so clone for later
                    this.firstTick = (this.firstTick || moment()).clone();
                    this.lastTick = (this.lastTick || moment()).clone();
                },
                buildTicks: function(index) {

                    this.ctx.save();
                    var tickFontSize = helpers.getValueOrDefault(this.options.ticks.fontSize, Chart.defaults.global.defaultFontSize);
                    var tickFontStyle = helpers.getValueOrDefault(this.options.ticks.fontStyle, Chart.defaults.global.defaultFontStyle);
                    var tickFontFamily = helpers.getValueOrDefault(this.options.ticks.fontFamily, Chart.defaults.global.defaultFontFamily);
                    var tickLabelFont = helpers.fontString(tickFontSize, tickFontStyle, tickFontFamily);
                    this.ctx.font = tickLabelFont;

                    this.ticks = [];
                    this.unitScale = 1; // How much we scale the unit by, ie 2 means 2x unit per step
                    this.scaleSizeInUnits = 0; // How large the scale is in the base unit (seconds, minutes, etc)

                    // Set unit override if applicable
                    if (this.options.time.unit) {
                        this.tickUnit = this.options.time.unit || 'day';
                        this.displayFormat = this.options.time.displayFormats[this.tickUnit];
                        this.scaleSizeInUnits = this.lastTick.diff(this.firstTick, this.tickUnit, true);
                        this.unitScale = helpers.getValueOrDefault(this.options.time.unitStepSize, 1);
                    } else {
                        // Determine the smallest needed unit of the time
                        var innerWidth = this.isHorizontal() ? this.width - (this.paddingLeft + this.paddingRight) : this.height - (this.paddingTop + this.paddingBottom);

                        // Crude approximation of what the label length might be
                        var tempFirstLabel = this.tickFormatFunction(this.firstTick, 0, []);
                        var tickLabelWidth = this.ctx.measureText(tempFirstLabel).width;
                        var cosRotation = Math.cos(helpers.toRadians(this.options.ticks.maxRotation));
                        var sinRotation = Math.sin(helpers.toRadians(this.options.ticks.maxRotation));
                        tickLabelWidth = (tickLabelWidth * cosRotation) + (tickFontSize * sinRotation);
                        var labelCapacity = innerWidth / (tickLabelWidth);

                        // Start as small as possible
                        this.tickUnit = 'millisecond';
                        this.scaleSizeInUnits = this.lastTick.diff(this.firstTick, this.tickUnit, true);
                        this.displayFormat = this.options.time.displayFormats[this.tickUnit];

                        var unitDefinitionIndex = 0;
                        var unitDefinition = time.units[unitDefinitionIndex];

                        // While we aren't ideal and we don't have units left
                        while (unitDefinitionIndex < time.units.length) {
                            // Can we scale this unit. If `false` we can scale infinitely
                            this.unitScale = 1;

                            if (helpers.isArray(unitDefinition.steps) && Math.ceil(this.scaleSizeInUnits / labelCapacity) < helpers.max(unitDefinition.steps)) {
                                // Use one of the prefedined steps
                                for (var idx = 0; idx < unitDefinition.steps.length; ++idx) {
                                    if (unitDefinition.steps[idx] >= Math.ceil(this.scaleSizeInUnits / labelCapacity)) {
                                        this.unitScale = helpers.getValueOrDefault(this.options.time.unitStepSize, unitDefinition.steps[idx]);
                                        break;
                                    }
                                }

                                break;
                            } else if ((unitDefinition.maxStep === false) || (Math.ceil(this.scaleSizeInUnits / labelCapacity) < unitDefinition.maxStep)) {
                                // We have a max step. Scale this unit
                                this.unitScale = helpers.getValueOrDefault(this.options.time.unitStepSize, Math.ceil(this.scaleSizeInUnits / labelCapacity));
                                break;
                            } else {
                                // Move to the next unit up
                                ++unitDefinitionIndex;
                                unitDefinition = time.units[unitDefinitionIndex];

                                this.tickUnit = unitDefinition.name;
                                var leadingUnitBuffer = this.firstTick.diff(this.getMomentStartOf(this.firstTick), this.tickUnit, true);
                                var trailingUnitBuffer = this.getMomentStartOf(this.lastTick.clone().add(1, this.tickUnit)).diff(this.lastTick, this.tickUnit, true);
                                this.scaleSizeInUnits = this.lastTick.diff(this.firstTick, this.tickUnit, true) + leadingUnitBuffer + trailingUnitBuffer;
                                this.displayFormat = this.options.time.displayFormats[unitDefinition.name];
                            }
                        }
                    }

                    var roundedStart;

                    // Only round the first tick if we have no hard minimum
                    if (!this.options.time.min) {
                        this.firstTick = this.getMomentStartOf(this.firstTick);
                        roundedStart = this.firstTick;
                    } else {
                        roundedStart = this.getMomentStartOf(this.firstTick);
                    }

                    // Only round the last tick if we have no hard maximum
                    if (!this.options.time.max) {
                        var roundedEnd = this.getMomentStartOf(this.lastTick);
                        if (roundedEnd.diff(this.lastTick, this.tickUnit, true) !== 0) {
                            // Do not use end of because we need this to be in the next time unit
                            this.lastTick = this.getMomentStartOf(this.lastTick.add(1, this.tickUnit));
                        }
                    }

                    this.smallestLabelSeparation = this.width;

                    helpers.each(this.chart.data.datasets, function(dataset, datasetIndex) {
                        for (var i = 1; i < this.labelMoments[datasetIndex].length; i++) {
                            this.smallestLabelSeparation = Math.min(this.smallestLabelSeparation, this.labelMoments[datasetIndex][i].diff(this.labelMoments[datasetIndex][i - 1], this.tickUnit, true));
                        }
                    }, this);

                    // Tick displayFormat override
                    if (this.options.time.displayFormat) {
                        this.displayFormat = this.options.time.displayFormat;
                    }

                    // first tick. will have been rounded correctly if options.time.min is not specified
                    this.ticks.push(this.firstTick.clone());

                    // For every unit in between the first and last moment, create a moment and add it to the ticks tick
                    for (var i = 1; i <= this.scaleSizeInUnits; ++i) {
                        var newTick = roundedStart.clone().add(i, this.tickUnit);

                        // Are we greater than the max time
                        if (this.options.time.max && newTick.diff(this.lastTick, this.tickUnit, true) >= 0) {
                            break;
                        }

                        if (i % this.unitScale === 0) {
                            this.ticks.push(newTick);
                        }
                    }

                    // Always show the right tick
                    var diff = this.ticks[this.ticks.length - 1].diff(this.lastTick, this.tickUnit);
                    if (diff !== 0 || this.scaleSizeInUnits === 0) {
                        // this is a weird case. If the <max> option is the same as the end option, we can't just diff the times because the tick was created from the roundedStart
                        // but the last tick was not rounded.
                        if (this.options.time.max) {
                            this.ticks.push(this.lastTick.clone());
                            this.scaleSizeInUnits = this.lastTick.diff(this.ticks[0], this.tickUnit, true);
                        } else {
                            this.ticks.push(this.lastTick.clone());
                            this.scaleSizeInUnits = this.lastTick.diff(this.firstTick, this.tickUnit, true);
                        }
                    }

                    this.ctx.restore();
                },
                // Get tooltip label
                getLabelForIndex: function(index, datasetIndex) {
                    var label = this.chart.data.labels && index < this.chart.data.labels.length ? this.chart.data.labels[index] : '';

                    if (typeof this.chart.data.datasets[datasetIndex].data[0] === 'object') {
                        label = this.getRightValue(this.chart.data.datasets[datasetIndex].data[index]);
                    }

                    // Format nicely
                    if (this.options.time.tooltipFormat) {
                        label = this.parseTime(label).format(this.options.time.tooltipFormat);
                    }

                    return label;
                },
                // Function to format an individual tick mark
                tickFormatFunction: function tickFormatFunction(tick, index, ticks) {
                    var formattedTick = tick.format(this.displayFormat);
                    var tickOpts = this.options.ticks;
                    var callback = helpers.getValueOrDefault(tickOpts.callback, tickOpts.userCallback);

                    if (callback) {
                        return callback(formattedTick, index, ticks);
                    } else {
                        return formattedTick;
                    }
                },
                convertTicksToLabels: function() {
                    this.tickMoments = this.ticks;
                    this.ticks = this.ticks.map(this.tickFormatFunction, this);
                },
                getPixelForValue: function(value, index, datasetIndex, includeOffset) {
                    var labelMoment = value && value.isValid && value.isValid() ? value : this.getLabelMoment(datasetIndex, index);

                    if (labelMoment) {
                        var offset = labelMoment.diff(this.firstTick, this.tickUnit, true);

                        var decimal = offset / this.scaleSizeInUnits;

                        if (this.isHorizontal()) {
                            var innerWidth = this.width - (this.paddingLeft + this.paddingRight);
                            var valueWidth = innerWidth / Math.max(this.ticks.length - 1, 1);
                            var valueOffset = (innerWidth * decimal) + this.paddingLeft;

                            return this.left + Math.round(valueOffset);
                        } else {
                            var innerHeight = this.height - (this.paddingTop + this.paddingBottom);
                            var valueHeight = innerHeight / Math.max(this.ticks.length - 1, 1);
                            var heightOffset = (innerHeight * decimal) + this.paddingTop;

                            return this.top + Math.round(heightOffset);
                        }
                    }
                },
                getPixelForTick: function(index, includeOffset) {
                    return this.getPixelForValue(this.tickMoments[index], null, null, includeOffset);
                },
                getValueForPixel: function(pixel) {
                    var innerDimension = this.isHorizontal() ? this.width - (this.paddingLeft + this.paddingRight) : this.height - (this.paddingTop + this.paddingBottom);
                    var offset = (pixel - (this.isHorizontal() ? this.left + this.paddingLeft : this.top + this.paddingTop)) / innerDimension;
                    offset *= this.scaleSizeInUnits;
                    return this.firstTick.clone().add(moment.duration(offset, this.tickUnit).asSeconds(), 'seconds');
                },
                parseTime: function(label) {
                    if (typeof this.options.time.parser === 'string') {
                        return moment(label, this.options.time.parser);
                    }
                    if (typeof this.options.time.parser === 'function') {
                        return this.options.time.parser(label);
                    }
                    // Date objects
                    if (typeof label.getMonth === 'function' || typeof label === 'number') {
                        return moment(label);
                    }
                    // Moment support
                    if (label.isValid && label.isValid()) {
                        return label;
                    }
                    // Custom parsing (return an instance of moment)
                    if (typeof this.options.time.format !== 'string' && this.options.time.format.call) {
                        console.warn("options.time.format is deprecated and replaced by options.time.parser. See http://nnnick.github.io/Chart.js/docs-v2/#scales-time-scale");
                        return this.options.time.format(label);
                    }
                    // Moment format parsing
                    return moment(label, this.options.time.format);
                }
            });
            Chart.scaleService.registerScaleType("time", TimeScale, defaultConfig);

        };

    }, {
        "moment": 6
    }]
}, {}, [7]);

/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.5.5
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
! function(a) {
    "use strict";
    "function" == typeof define && define.amd ? define(["jquery"], a) : "undefined" != typeof exports ? module.exports = a(require("jquery")) : a(jQuery)
}(function(a) {
    "use strict";
    var b = window.Slick || {};
    b = function() {
        function c(c, d) {
            var f, g, h, e = this;
            if (e.defaults = {
                    accessibility: !0,
                    adaptiveHeight: !1,
                    appendArrows: a(c),
                    appendDots: a(c),
                    arrows: !0,
                    asNavFor: null,
                    prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="previous">Previous</button>',
                    nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="next">Next</button>',
                    autoplay: !1,
                    autoplaySpeed: 3e3,
                    centerMode: !1,
                    centerPadding: "50px",
                    cssEase: "ease",
                    customPaging: function(a, b) {
                        return '<button type="button" data-role="none">' + (b + 1) + "</button>"
                    },
                    dots: !1,
                    dotsClass: "slick-dots",
                    draggable: !0,
                    easing: "linear",
                    edgeFriction: .35,
                    fade: !1,
                    focusOnSelect: !1,
                    infinite: !0,
                    initialSlide: 0,
                    lazyLoad: "ondemand",
                    mobileFirst: !1,
                    pauseOnHover: !0,
                    pauseOnDotsHover: !1,
                    respondTo: "window",
                    responsive: null,
                    rows: 1,
                    rtl: !1,
                    slide: "",
                    slidesPerRow: 1,
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    speed: 500,
                    swipe: !0,
                    swipeToSlide: !1,
                    touchMove: !0,
                    touchThreshold: 5,
                    useCSS: !0,
                    variableWidth: !1,
                    vertical: !1,
                    verticalSwiping: !1,
                    waitForAnimate: !0
                }, e.initials = {
                    animating: !1,
                    dragging: !1,
                    autoPlayTimer: null,
                    currentDirection: 0,
                    currentLeft: null,
                    currentSlide: 0,
                    direction: 1,
                    $dots: null,
                    listWidth: null,
                    listHeight: null,
                    loadIndex: 0,
                    $nextArrow: null,
                    $prevArrow: null,
                    slideCount: null,
                    slideWidth: null,
                    $slideTrack: null,
                    $slides: null,
                    sliding: !1,
                    slideOffset: 0,
                    swipeLeft: null,
                    $list: null,
                    touchObject: {},
                    transformsEnabled: !1,
                    unslicked: !1
                }, a.extend(e, e.initials), e.activeBreakpoint = null, e.animType = null, e.animProp = null, e.breakpoints = [], e.breakpointSettings = [], e.cssTransitions = !1, e.hidden = "hidden", e.paused = !1, e.positionProp = null, e.respondTo = null, e.rowCount = 1, e.shouldClick = !0, e.$slider = a(c), e.$slidesCache = null, e.transformType = null, e.transitionType = null, e.visibilityChange = "visibilitychange", e.windowWidth = 0, e.windowTimer = null, f = a(c).data("slick") || {}, e.options = a.extend({}, e.defaults, f, d), e.currentSlide = e.options.initialSlide, e.originalSettings = e.options, g = e.options.responsive || null, g && g.length > -1) {
                e.respondTo = e.options.respondTo || "window";
                for (h in g) g.hasOwnProperty(h) && (e.breakpoints.push(g[h].breakpoint), e.breakpointSettings[g[h].breakpoint] = g[h].settings);
                e.breakpoints.sort(function(a, b) {
                    return e.options.mobileFirst === !0 ? a - b : b - a
                })
            }
            "undefined" != typeof document.mozHidden ? (e.hidden = "mozHidden", e.visibilityChange = "mozvisibilitychange") : "undefined" != typeof document.webkitHidden && (e.hidden = "webkitHidden", e.visibilityChange = "webkitvisibilitychange"), e.autoPlay = a.proxy(e.autoPlay, e), e.autoPlayClear = a.proxy(e.autoPlayClear, e), e.changeSlide = a.proxy(e.changeSlide, e), e.clickHandler = a.proxy(e.clickHandler, e), e.selectHandler = a.proxy(e.selectHandler, e), e.setPosition = a.proxy(e.setPosition, e), e.swipeHandler = a.proxy(e.swipeHandler, e), e.dragHandler = a.proxy(e.dragHandler, e), e.keyHandler = a.proxy(e.keyHandler, e), e.autoPlayIterator = a.proxy(e.autoPlayIterator, e), e.instanceUid = b++, e.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/, e.init(!0), e.checkResponsive(!0)
        }
        var b = 0;
        return c
    }(), b.prototype.addSlide = b.prototype.slickAdd = function(b, c, d) {
        var e = this;
        if ("boolean" == typeof c) d = c, c = null;
        else if (0 > c || c >= e.slideCount) return !1;
        e.unload(), "number" == typeof c ? 0 === c && 0 === e.$slides.length ? a(b).appendTo(e.$slideTrack) : d ? a(b).insertBefore(e.$slides.eq(c)) : a(b).insertAfter(e.$slides.eq(c)) : d === !0 ? a(b).prependTo(e.$slideTrack) : a(b).appendTo(e.$slideTrack), e.$slides = e.$slideTrack.children(this.options.slide), e.$slideTrack.children(this.options.slide).detach(), e.$slideTrack.append(e.$slides), e.$slides.each(function(b, c) {
            a(c).attr("data-slick-index", b)
        }), e.$slidesCache = e.$slides, e.reinit()
    }, b.prototype.animateHeight = function() {
        var a = this;
        if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
            var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
            a.$list.animate({
                height: b
            }, a.options.speed)
        }
    }, b.prototype.animateSlide = function(b, c) {
        var d = {},
            e = this;
        e.animateHeight(), e.options.rtl === !0 && e.options.vertical === !1 && (b = -b), e.transformsEnabled === !1 ? e.options.vertical === !1 ? e.$slideTrack.animate({
            left: b
        }, e.options.speed, e.options.easing, c) : e.$slideTrack.animate({
            top: b
        }, e.options.speed, e.options.easing, c) : e.cssTransitions === !1 ? (e.options.rtl === !0 && (e.currentLeft = -e.currentLeft), a({
            animStart: e.currentLeft
        }).animate({
            animStart: b
        }, {
            duration: e.options.speed,
            easing: e.options.easing,
            step: function(a) {
                a = Math.ceil(a), e.options.vertical === !1 ? (d[e.animType] = "translate(" + a + "px, 0px)", e.$slideTrack.css(d)) : (d[e.animType] = "translate(0px," + a + "px)", e.$slideTrack.css(d))
            },
            complete: function() {
                c && c.call()
            }
        })) : (e.applyTransition(), b = Math.ceil(b), d[e.animType] = e.options.vertical === !1 ? "translate3d(" + b + "px, 0px, 0px)" : "translate3d(0px," + b + "px, 0px)", e.$slideTrack.css(d), c && setTimeout(function() {
            e.disableTransition(), c.call()
        }, e.options.speed))
    }, b.prototype.asNavFor = function(b) {
        var c = this,
            d = c.options.asNavFor;
        d && null !== d && (d = a(d).not(c.$slider)), null !== d && "object" == typeof d && d.each(function() {
            var c = a(this).slick("getSlick");
            c.unslicked || c.slideHandler(b, !0)
        })
    }, b.prototype.applyTransition = function(a) {
        var b = this,
            c = {};
        c[b.transitionType] = b.options.fade === !1 ? b.transformType + " " + b.options.speed + "ms " + b.options.cssEase : "opacity " + b.options.speed + "ms " + b.options.cssEase, b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
    }, b.prototype.autoPlay = function() {
        var a = this;
        a.autoPlayTimer && clearInterval(a.autoPlayTimer), a.slideCount > a.options.slidesToShow && a.paused !== !0 && (a.autoPlayTimer = setInterval(a.autoPlayIterator, a.options.autoplaySpeed))
    }, b.prototype.autoPlayClear = function() {
        var a = this;
        a.autoPlayTimer && clearInterval(a.autoPlayTimer)
    }, b.prototype.autoPlayIterator = function() {
        var a = this;
        a.options.infinite === !1 ? 1 === a.direction ? (a.currentSlide + 1 === a.slideCount - 1 && (a.direction = 0), a.slideHandler(a.currentSlide + a.options.slidesToScroll)) : (0 === a.currentSlide - 1 && (a.direction = 1), a.slideHandler(a.currentSlide - a.options.slidesToScroll)) : a.slideHandler(a.currentSlide + a.options.slidesToScroll)
    }, b.prototype.buildArrows = function() {
        var b = this;
        b.options.arrows === !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow = a(b.options.prevArrow), b.$nextArrow = a(b.options.nextArrow), b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.appendTo(b.options.appendArrows), b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.appendTo(b.options.appendArrows), b.options.infinite !== !0 && b.$prevArrow.addClass("slick-disabled"))
    }, b.prototype.buildDots = function() {
        var c, d, b = this;
        if (b.options.dots === !0 && b.slideCount > b.options.slidesToShow) {
            for (d = '<ul class="' + b.options.dotsClass + '">', c = 0; c <= b.getDotCount(); c += 1) d += "<li>" + b.options.customPaging.call(this, b, c) + "</li>";
            d += "</ul>", b.$dots = a(d).appendTo(b.options.appendDots), b.$dots.find("li").first().addClass("slick-active").attr("aria-hidden", "false")
        }
    }, b.prototype.buildOut = function() {
        var b = this;
        b.$slides = b.$slider.children(":not(.slick-cloned)").addClass("slick-slide"), b.slideCount = b.$slides.length, b.$slides.each(function(b, c) {
            a(c).attr("data-slick-index", b).data("originalStyling", a(c).attr("style") || "")
        }), b.$slidesCache = b.$slides, b.$slider.addClass("slick-slider"), b.$slideTrack = 0 === b.slideCount ? a('<div class="slick-track"/>').appendTo(b.$slider) : b.$slides.wrapAll('<div class="slick-track"/>').parent(), b.$list = b.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent(), b.$slideTrack.css("opacity", 0), (b.options.centerMode === !0 || b.options.swipeToSlide === !0) && (b.options.slidesToScroll = 1), a("img[data-lazy]", b.$slider).not("[src]").addClass("slick-loading"), b.setupInfinite(), b.buildArrows(), b.buildDots(), b.updateDots(), b.options.accessibility === !0 && b.$list.prop("tabIndex", 0), b.setSlideClasses("number" == typeof this.currentSlide ? this.currentSlide : 0), b.options.draggable === !0 && b.$list.addClass("draggable")
    }, b.prototype.buildRows = function() {
        var b, c, d, e, f, g, h, a = this;
        if (e = document.createDocumentFragment(), g = a.$slider.children(), a.options.rows > 1) {
            for (h = a.options.slidesPerRow * a.options.rows, f = Math.ceil(g.length / h), b = 0; f > b; b++) {
                var i = document.createElement("div");
                for (c = 0; c < a.options.rows; c++) {
                    var j = document.createElement("div");
                    for (d = 0; d < a.options.slidesPerRow; d++) {
                        var k = b * h + (c * a.options.slidesPerRow + d);
                        g.get(k) && j.appendChild(g.get(k))
                    }
                    i.appendChild(j)
                }
                e.appendChild(i)
            }
            a.$slider.html(e), a.$slider.children().children().children().css({
                width: 100 / a.options.slidesPerRow + "%",
                display: "inline-block"
            })
        }
    }, b.prototype.checkResponsive = function(b) {
        var d, e, f, c = this,
            g = !1,
            h = c.$slider.width(),
            i = window.innerWidth || a(window).width();
        if ("window" === c.respondTo ? f = i : "slider" === c.respondTo ? f = h : "min" === c.respondTo && (f = Math.min(i, h)), c.originalSettings.responsive && c.originalSettings.responsive.length > -1 && null !== c.originalSettings.responsive) {
            e = null;
            for (d in c.breakpoints) c.breakpoints.hasOwnProperty(d) && (c.originalSettings.mobileFirst === !1 ? f < c.breakpoints[d] && (e = c.breakpoints[d]) : f > c.breakpoints[d] && (e = c.breakpoints[d]));
            null !== e ? null !== c.activeBreakpoint ? e !== c.activeBreakpoint && (c.activeBreakpoint = e, "unslick" === c.breakpointSettings[e] ? c.unslick(e) : (c.options = a.extend({}, c.originalSettings, c.breakpointSettings[e]), b === !0 && (c.currentSlide = c.options.initialSlide), c.refresh(b)), g = e) : (c.activeBreakpoint = e, "unslick" === c.breakpointSettings[e] ? c.unslick(e) : (c.options = a.extend({}, c.originalSettings, c.breakpointSettings[e]), b === !0 && (c.currentSlide = c.options.initialSlide), c.refresh(b)), g = e) : null !== c.activeBreakpoint && (c.activeBreakpoint = null, c.options = c.originalSettings, b === !0 && (c.currentSlide = c.options.initialSlide), c.refresh(b), g = e), b || g === !1 || c.$slider.trigger("breakpoint", [c, g])
        }
    }, b.prototype.changeSlide = function(b, c) {
        var f, g, h, d = this,
            e = a(b.target);
        switch (e.is("a") && b.preventDefault(), e.is("li") || (e = e.closest("li")), h = 0 !== d.slideCount % d.options.slidesToScroll, f = h ? 0 : (d.slideCount - d.currentSlide) % d.options.slidesToScroll, b.data.message) {
            case "previous":
                g = 0 === f ? d.options.slidesToScroll : d.options.slidesToShow - f, d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide - g, !1, c);
                break;
            case "next":
                g = 0 === f ? d.options.slidesToScroll : f, d.slideCount > d.options.slidesToShow && d.slideHandler(d.currentSlide + g, !1, c);
                break;
            case "index":
                var i = 0 === b.data.index ? 0 : b.data.index || e.index() * d.options.slidesToScroll;
                d.slideHandler(d.checkNavigable(i), !1, c), e.children().trigger("focus");
                break;
            default:
                return
        }
    }, b.prototype.checkNavigable = function(a) {
        var c, d, b = this;
        if (c = b.getNavigableIndexes(), d = 0, a > c[c.length - 1]) a = c[c.length - 1];
        else
            for (var e in c) {
                if (a < c[e]) {
                    a = d;
                    break
                }
                d = c[e]
            }
        return a
    }, b.prototype.cleanUpEvents = function() {
        var b = this;
        b.options.dots && null !== b.$dots && (a("li", b.$dots).off("click.slick", b.changeSlide), b.options.pauseOnDotsHover === !0 && b.options.autoplay === !0 && a("li", b.$dots).off("mouseenter.slick", a.proxy(b.setPaused, b, !0)).off("mouseleave.slick", a.proxy(b.setPaused, b, !1))), b.options.arrows === !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow && b.$prevArrow.off("click.slick", b.changeSlide), b.$nextArrow && b.$nextArrow.off("click.slick", b.changeSlide)), b.$list.off("touchstart.slick mousedown.slick", b.swipeHandler), b.$list.off("touchmove.slick mousemove.slick", b.swipeHandler), b.$list.off("touchend.slick mouseup.slick", b.swipeHandler), b.$list.off("touchcancel.slick mouseleave.slick", b.swipeHandler), b.$list.off("click.slick", b.clickHandler), a(document).off(b.visibilityChange, b.visibility), b.$list.off("mouseenter.slick", a.proxy(b.setPaused, b, !0)), b.$list.off("mouseleave.slick", a.proxy(b.setPaused, b, !1)), b.options.accessibility === !0 && b.$list.off("keydown.slick", b.keyHandler), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().off("click.slick", b.selectHandler), a(window).off("orientationchange.slick.slick-" + b.instanceUid, b.orientationChange), a(window).off("resize.slick.slick-" + b.instanceUid, b.resize), a("[draggable!=true]", b.$slideTrack).off("dragstart", b.preventDefault), a(window).off("load.slick.slick-" + b.instanceUid, b.setPosition), a(document).off("ready.slick.slick-" + b.instanceUid, b.setPosition)
    }, b.prototype.cleanUpRows = function() {
        var b, a = this;
        a.options.rows > 1 && (b = a.$slides.children().children(), b.removeAttr("style"), a.$slider.html(b))
    }, b.prototype.clickHandler = function(a) {
        var b = this;
        b.shouldClick === !1 && (a.stopImmediatePropagation(), a.stopPropagation(), a.preventDefault())
    }, b.prototype.destroy = function(b) {
        var c = this;
        c.autoPlayClear(), c.touchObject = {}, c.cleanUpEvents(), a(".slick-cloned", c.$slider).detach(), c.$dots && c.$dots.remove(), c.$prevArrow && "object" != typeof c.options.prevArrow && c.$prevArrow.remove(), c.$nextArrow && "object" != typeof c.options.nextArrow && c.$nextArrow.remove(), c.$slides && (c.$slides.removeClass("slick-slide slick-active slick-center slick-visible").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function() {
            a(this).attr("style", a(this).data("originalStyling"))
        }), c.$slideTrack.children(this.options.slide).detach(), c.$slideTrack.detach(), c.$list.detach(), c.$slider.append(c.$slides)), c.cleanUpRows(), c.$slider.removeClass("slick-slider"), c.$slider.removeClass("slick-initialized"), c.unslicked = !0, b || c.$slider.trigger("destroy", [c])
    }, b.prototype.disableTransition = function(a) {
        var b = this,
            c = {};
        c[b.transitionType] = "", b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
    }, b.prototype.fadeSlide = function(a, b) {
        var c = this;
        c.cssTransitions === !1 ? (c.$slides.eq(a).css({
            zIndex: 1e3
        }), c.$slides.eq(a).animate({
            opacity: 1
        }, c.options.speed, c.options.easing, b)) : (c.applyTransition(a), c.$slides.eq(a).css({
            opacity: 1,
            zIndex: 1e3
        }), b && setTimeout(function() {
            c.disableTransition(a), b.call()
        }, c.options.speed))
    }, b.prototype.filterSlides = b.prototype.slickFilter = function(a) {
        var b = this;
        null !== a && (b.unload(), b.$slideTrack.children(this.options.slide).detach(), b.$slidesCache.filter(a).appendTo(b.$slideTrack), b.reinit())
    }, b.prototype.getCurrent = b.prototype.slickCurrentSlide = function() {
        var a = this;
        return a.currentSlide
    }, b.prototype.getDotCount = function() {
        var a = this,
            b = 0,
            c = 0,
            d = 0;
        if (a.options.infinite === !0)
            for (; b < a.slideCount;) ++d, b = c + a.options.slidesToShow, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        else if (a.options.centerMode === !0) d = a.slideCount;
        else
            for (; b < a.slideCount;) ++d, b = c + a.options.slidesToShow, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        return d - 1
    }, b.prototype.getLeft = function(a) {
        var c, d, f, b = this,
            e = 0;
        return b.slideOffset = 0, d = b.$slides.first().outerHeight(), b.options.infinite === !0 ? (b.slideCount > b.options.slidesToShow && (b.slideOffset = -1 * b.slideWidth * b.options.slidesToShow, e = -1 * d * b.options.slidesToShow), 0 !== b.slideCount % b.options.slidesToScroll && a + b.options.slidesToScroll > b.slideCount && b.slideCount > b.options.slidesToShow && (a > b.slideCount ? (b.slideOffset = -1 * (b.options.slidesToShow - (a - b.slideCount)) * b.slideWidth, e = -1 * (b.options.slidesToShow - (a - b.slideCount)) * d) : (b.slideOffset = -1 * b.slideCount % b.options.slidesToScroll * b.slideWidth, e = -1 * b.slideCount % b.options.slidesToScroll * d))) : a + b.options.slidesToShow > b.slideCount && (b.slideOffset = (a + b.options.slidesToShow - b.slideCount) * b.slideWidth, e = (a + b.options.slidesToShow - b.slideCount) * d), b.slideCount <= b.options.slidesToShow && (b.slideOffset = 0, e = 0), b.options.centerMode === !0 && b.options.infinite === !0 ? b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2) - b.slideWidth : b.options.centerMode === !0 && (b.slideOffset = 0, b.slideOffset += b.slideWidth * Math.floor(b.options.slidesToShow / 2)), c = b.options.vertical === !1 ? -1 * a * b.slideWidth + b.slideOffset : -1 * a * d + e, b.options.variableWidth === !0 && (f = b.slideCount <= b.options.slidesToShow || b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow), c = f[0] ? -1 * f[0].offsetLeft : 0, b.options.centerMode === !0 && (f = b.options.infinite === !1 ? b.$slideTrack.children(".slick-slide").eq(a) : b.$slideTrack.children(".slick-slide").eq(a + b.options.slidesToShow + 1), c = f[0] ? -1 * f[0].offsetLeft : 0, c += (b.$list.width() - f.outerWidth()) / 2)), c
    }, b.prototype.getOption = b.prototype.slickGetOption = function(a) {
        var b = this;
        return b.options[a]
    }, b.prototype.getNavigableIndexes = function() {
        var e, a = this,
            b = 0,
            c = 0,
            d = [];
        for (a.options.infinite === !1 ? e = a.slideCount : (b = -1 * a.options.slidesToScroll, c = -1 * a.options.slidesToScroll, e = 2 * a.slideCount); e > b;) d.push(b), b = c + a.options.slidesToScroll, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
        return d
    }, b.prototype.getSlick = function() {
        return this
    }, b.prototype.getSlideCount = function() {
        var c, d, e, b = this;
        return e = b.options.centerMode === !0 ? b.slideWidth * Math.floor(b.options.slidesToShow / 2) : 0, b.options.swipeToSlide === !0 ? (b.$slideTrack.find(".slick-slide").each(function(c, f) {
            return f.offsetLeft - e + a(f).outerWidth() / 2 > -1 * b.swipeLeft ? (d = f, !1) : void 0
        }), c = Math.abs(a(d).attr("data-slick-index") - b.currentSlide) || 1) : b.options.slidesToScroll
    }, b.prototype.goTo = b.prototype.slickGoTo = function(a, b) {
        var c = this;
        c.changeSlide({
            data: {
                message: "index",
                index: parseInt(a)
            }
        }, b)
    }, b.prototype.init = function(b) {
        var c = this;
        a(c.$slider).hasClass("slick-initialized") || (a(c.$slider).addClass("slick-initialized"), c.buildRows(), c.buildOut(), c.setProps(), c.startLoad(), c.loadSlider(), c.initializeEvents(), c.updateArrows(), c.updateDots()), b && c.$slider.trigger("init", [c])
    }, b.prototype.initArrowEvents = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.on("click.slick", {
            message: "previous"
        }, a.changeSlide), a.$nextArrow.on("click.slick", {
            message: "next"
        }, a.changeSlide))
    }, b.prototype.initDotEvents = function() {
        var b = this;
        b.options.dots === !0 && b.slideCount > b.options.slidesToShow && a("li", b.$dots).on("click.slick", {
            message: "index"
        }, b.changeSlide), b.options.dots === !0 && b.options.pauseOnDotsHover === !0 && b.options.autoplay === !0 && a("li", b.$dots).on("mouseenter.slick", a.proxy(b.setPaused, b, !0)).on("mouseleave.slick", a.proxy(b.setPaused, b, !1))
    }, b.prototype.initializeEvents = function() {
        var b = this;
        b.initArrowEvents(), b.initDotEvents(), b.$list.on("touchstart.slick mousedown.slick", {
            action: "start"
        }, b.swipeHandler), b.$list.on("touchmove.slick mousemove.slick", {
            action: "move"
        }, b.swipeHandler), b.$list.on("touchend.slick mouseup.slick", {
            action: "end"
        }, b.swipeHandler), b.$list.on("touchcancel.slick mouseleave.slick", {
            action: "end"
        }, b.swipeHandler), b.$list.on("click.slick", b.clickHandler), a(document).on(b.visibilityChange, a.proxy(b.visibility, b)), b.$list.on("mouseenter.slick", a.proxy(b.setPaused, b, !0)), b.$list.on("mouseleave.slick", a.proxy(b.setPaused, b, !1)), b.options.accessibility === !0 && b.$list.on("keydown.slick", b.keyHandler), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler), a(window).on("orientationchange.slick.slick-" + b.instanceUid, a.proxy(b.orientationChange, b)), a(window).on("resize.slick.slick-" + b.instanceUid, a.proxy(b.resize, b)), a("[draggable!=true]", b.$slideTrack).on("dragstart", b.preventDefault), a(window).on("load.slick.slick-" + b.instanceUid, b.setPosition), a(document).on("ready.slick.slick-" + b.instanceUid, b.setPosition)
    }, b.prototype.initUI = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.show(), a.$nextArrow.show()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.show(), a.options.autoplay === !0 && a.autoPlay()
    }, b.prototype.keyHandler = function(a) {
        var b = this;
        37 === a.keyCode && b.options.accessibility === !0 ? b.changeSlide({
            data: {
                message: "previous"
            }
        }) : 39 === a.keyCode && b.options.accessibility === !0 && b.changeSlide({
            data: {
                message: "next"
            }
        })
    }, b.prototype.lazyLoad = function() {
        function g(b) {
            a("img[data-lazy]", b).each(function() {
                var b = a(this),
                    c = a(this).attr("data-lazy"),
                    d = document.createElement("img");
                d.onload = function() {
                    b.animate({
                        opacity: 1
                    }, 200)
                }, d.src = c, b.css({
                    opacity: 0
                }).attr("src", c).removeAttr("data-lazy").removeClass("slick-loading")
            })
        }
        var c, d, e, f, b = this;
        b.options.centerMode === !0 ? b.options.infinite === !0 ? (e = b.currentSlide + (b.options.slidesToShow / 2 + 1), f = e + b.options.slidesToShow + 2) : (e = Math.max(0, b.currentSlide - (b.options.slidesToShow / 2 + 1)), f = 2 + (b.options.slidesToShow / 2 + 1) + b.currentSlide) : (e = b.options.infinite ? b.options.slidesToShow + b.currentSlide : b.currentSlide, f = e + b.options.slidesToShow, b.options.fade === !0 && (e > 0 && e--, f <= b.slideCount && f++)), c = b.$slider.find(".slick-slide").slice(e, f), g(c), b.slideCount <= b.options.slidesToShow ? (d = b.$slider.find(".slick-slide"), g(d)) : b.currentSlide >= b.slideCount - b.options.slidesToShow ? (d = b.$slider.find(".slick-cloned").slice(0, b.options.slidesToShow), g(d)) : 0 === b.currentSlide && (d = b.$slider.find(".slick-cloned").slice(-1 * b.options.slidesToShow), g(d))
    }, b.prototype.loadSlider = function() {
        var a = this;
        a.setPosition(), a.$slideTrack.css({
            opacity: 1
        }), a.$slider.removeClass("slick-loading"), a.initUI(), "progressive" === a.options.lazyLoad && a.progressiveLazyLoad()
    }, b.prototype.next = b.prototype.slickNext = function() {
        var a = this;
        a.changeSlide({
            data: {
                message: "next"
            }
        })
    }, b.prototype.orientationChange = function() {
        var a = this;
        a.checkResponsive(), a.setPosition()
    }, b.prototype.pause = b.prototype.slickPause = function() {
        var a = this;
        a.autoPlayClear(), a.paused = !0
    }, b.prototype.play = b.prototype.slickPlay = function() {
        var a = this;
        a.paused = !1, a.autoPlay()
    }, b.prototype.postSlide = function(a) {
        var b = this;
        b.$slider.trigger("afterChange", [b, a]), b.animating = !1, b.setPosition(), b.swipeLeft = null, b.options.autoplay === !0 && b.paused === !1 && b.autoPlay()
    }, b.prototype.prev = b.prototype.slickPrev = function() {
        var a = this;
        a.changeSlide({
            data: {
                message: "previous"
            }
        })
    }, b.prototype.preventDefault = function(a) {
        a.preventDefault()
    }, b.prototype.progressiveLazyLoad = function() {
        var c, d, b = this;
        c = a("img[data-lazy]", b.$slider).length, c > 0 && (d = a("img[data-lazy]", b.$slider).first(), d.attr("src", d.attr("data-lazy")).removeClass("slick-loading").load(function() {
            d.removeAttr("data-lazy"), b.progressiveLazyLoad(), b.options.adaptiveHeight === !0 && b.setPosition()
        }).error(function() {
            d.removeAttr("data-lazy"), b.progressiveLazyLoad()
        }))
    }, b.prototype.refresh = function(b) {
        var c = this,
            d = c.currentSlide;
        c.destroy(!0), a.extend(c, c.initials), c.init(), b || c.changeSlide({
            data: {
                message: "index",
                index: d
            }
        }, !1)
    }, b.prototype.reinit = function() {
        var b = this;
        b.$slides = b.$slideTrack.children(b.options.slide).addClass("slick-slide"), b.slideCount = b.$slides.length, b.currentSlide >= b.slideCount && 0 !== b.currentSlide && (b.currentSlide = b.currentSlide - b.options.slidesToScroll), b.slideCount <= b.options.slidesToShow && (b.currentSlide = 0), b.setProps(), b.setupInfinite(), b.buildArrows(), b.updateArrows(), b.initArrowEvents(), b.buildDots(), b.updateDots(), b.initDotEvents(), b.options.focusOnSelect === !0 && a(b.$slideTrack).children().on("click.slick", b.selectHandler), b.setSlideClasses(0), b.setPosition(), b.$slider.trigger("reInit", [b])
    }, b.prototype.resize = function() {
        var b = this;
        a(window).width() !== b.windowWidth && (clearTimeout(b.windowDelay), b.windowDelay = window.setTimeout(function() {
            b.windowWidth = a(window).width(), b.checkResponsive(), b.unslicked || b.setPosition()
        }, 50))
    }, b.prototype.removeSlide = b.prototype.slickRemove = function(a, b, c) {
        var d = this;
        return "boolean" == typeof a ? (b = a, a = b === !0 ? 0 : d.slideCount - 1) : a = b === !0 ? --a : a, d.slideCount < 1 || 0 > a || a > d.slideCount - 1 ? !1 : (d.unload(), c === !0 ? d.$slideTrack.children().remove() : d.$slideTrack.children(this.options.slide).eq(a).remove(), d.$slides = d.$slideTrack.children(this.options.slide), d.$slideTrack.children(this.options.slide).detach(), d.$slideTrack.append(d.$slides), d.$slidesCache = d.$slides, d.reinit(), void 0)
    }, b.prototype.setCSS = function(a) {
        var d, e, b = this,
            c = {};
        b.options.rtl === !0 && (a = -a), d = "left" == b.positionProp ? Math.ceil(a) + "px" : "0px", e = "top" == b.positionProp ? Math.ceil(a) + "px" : "0px", c[b.positionProp] = a, b.transformsEnabled === !1 ? b.$slideTrack.css(c) : (c = {}, b.cssTransitions === !1 ? (c[b.animType] = "translate(" + d + ", " + e + ")", b.$slideTrack.css(c)) : (c[b.animType] = "translate3d(" + d + ", " + e + ", 0px)", b.$slideTrack.css(c)))
    }, b.prototype.setDimensions = function() {
        var a = this;
        a.options.vertical === !1 ? a.options.centerMode === !0 && a.$list.css({
            padding: "0px " + a.options.centerPadding
        }) : (a.$list.height(a.$slides.first().outerHeight(!0) * a.options.slidesToShow), a.options.centerMode === !0 && a.$list.css({
            padding: a.options.centerPadding + " 0px"
        })), a.listWidth = a.$list.width(), a.listHeight = a.$list.height(), a.options.vertical === !1 && a.options.variableWidth === !1 ? (a.slideWidth = Math.ceil(a.listWidth / a.options.slidesToShow), a.$slideTrack.width(Math.ceil(a.slideWidth * a.$slideTrack.children(".slick-slide").length))) : a.options.variableWidth === !0 ? a.$slideTrack.width(5e3 * a.slideCount) : (a.slideWidth = Math.ceil(a.listWidth), a.$slideTrack.height(Math.ceil(a.$slides.first().outerHeight(!0) * a.$slideTrack.children(".slick-slide").length)));
        var b = a.$slides.first().outerWidth(!0) - a.$slides.first().width();
        a.options.variableWidth === !1 && a.$slideTrack.children(".slick-slide").width(a.slideWidth - b)
    }, b.prototype.setFade = function() {
        var c, b = this;
        b.$slides.each(function(d, e) {
            c = -1 * b.slideWidth * d, b.options.rtl === !0 ? a(e).css({
                position: "relative",
                right: c,
                top: 0,
                zIndex: 800,
                opacity: 0
            }) : a(e).css({
                position: "relative",
                left: c,
                top: 0,
                zIndex: 800,
                opacity: 0
            })
        }), b.$slides.eq(b.currentSlide).css({
            zIndex: 900,
            opacity: 1
        })
    }, b.prototype.setHeight = function() {
        var a = this;
        if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
            var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
            a.$list.css("height", b)
        }
    }, b.prototype.setOption = b.prototype.slickSetOption = function(a, b, c) {
        var d = this;
        d.options[a] = b, c === !0 && (d.unload(), d.reinit())
    }, b.prototype.setPosition = function() {
        var a = this;
        a.setDimensions(), a.setHeight(), a.options.fade === !1 ? a.setCSS(a.getLeft(a.currentSlide)) : a.setFade(), a.$slider.trigger("setPosition", [a])
    }, b.prototype.setProps = function() {
        var a = this,
            b = document.body.style;
        a.positionProp = a.options.vertical === !0 ? "top" : "left", "top" === a.positionProp ? a.$slider.addClass("slick-vertical") : a.$slider.removeClass("slick-vertical"), (void 0 !== b.WebkitTransition || void 0 !== b.MozTransition || void 0 !== b.msTransition) && a.options.useCSS === !0 && (a.cssTransitions = !0), void 0 !== b.OTransform && (a.animType = "OTransform", a.transformType = "-o-transform", a.transitionType = "OTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.MozTransform && (a.animType = "MozTransform", a.transformType = "-moz-transform", a.transitionType = "MozTransition", void 0 === b.perspectiveProperty && void 0 === b.MozPerspective && (a.animType = !1)), void 0 !== b.webkitTransform && (a.animType = "webkitTransform", a.transformType = "-webkit-transform", a.transitionType = "webkitTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.msTransform && (a.animType = "msTransform", a.transformType = "-ms-transform", a.transitionType = "msTransition", void 0 === b.msTransform && (a.animType = !1)), void 0 !== b.transform && a.animType !== !1 && (a.animType = "transform", a.transformType = "transform", a.transitionType = "transition"), a.transformsEnabled = null !== a.animType && a.animType !== !1
    }, b.prototype.setSlideClasses = function(a) {
        var c, d, e, f, b = this;
        b.$slider.find(".slick-slide").removeClass("slick-active").attr("aria-hidden", "true").removeClass("slick-center"), d = b.$slider.find(".slick-slide"), b.options.centerMode === !0 ? (c = Math.floor(b.options.slidesToShow / 2), b.options.infinite === !0 && (a >= c && a <= b.slideCount - 1 - c ? b.$slides.slice(a - c, a + c + 1).addClass("slick-active").attr("aria-hidden", "false") : (e = b.options.slidesToShow + a, d.slice(e - c + 1, e + c + 2).addClass("slick-active").attr("aria-hidden", "false")), 0 === a ? d.eq(d.length - 1 - b.options.slidesToShow).addClass("slick-center") : a === b.slideCount - 1 && d.eq(b.options.slidesToShow).addClass("slick-center")), b.$slides.eq(a).addClass("slick-center")) : a >= 0 && a <= b.slideCount - b.options.slidesToShow ? b.$slides.slice(a, a + b.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false") : d.length <= b.options.slidesToShow ? d.addClass("slick-active").attr("aria-hidden", "false") : (f = b.slideCount % b.options.slidesToShow, e = b.options.infinite === !0 ? b.options.slidesToShow + a : a, b.options.slidesToShow == b.options.slidesToScroll && b.slideCount - a < b.options.slidesToShow ? d.slice(e - (b.options.slidesToShow - f), e + f).addClass("slick-active").attr("aria-hidden", "false") : d.slice(e, e + b.options.slidesToShow).addClass("slick-active").attr("aria-hidden", "false")), "ondemand" === b.options.lazyLoad && b.lazyLoad()
    }, b.prototype.setupInfinite = function() {
        var c, d, e, b = this;
        if (b.options.fade === !0 && (b.options.centerMode = !1), b.options.infinite === !0 && b.options.fade === !1 && (d = null, b.slideCount > b.options.slidesToShow)) {
            for (e = b.options.centerMode === !0 ? b.options.slidesToShow + 1 : b.options.slidesToShow, c = b.slideCount; c > b.slideCount - e; c -= 1) d = c - 1, a(b.$slides[d]).clone(!0).attr("id", "").attr("data-slick-index", d - b.slideCount).prependTo(b.$slideTrack).addClass("slick-cloned");
            for (c = 0; e > c; c += 1) d = c, a(b.$slides[d]).clone(!0).attr("id", "").attr("data-slick-index", d + b.slideCount).appendTo(b.$slideTrack).addClass("slick-cloned");
            b.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
                a(this).attr("id", "")
            })
        }
    }, b.prototype.setPaused = function(a) {
        var b = this;
        b.options.autoplay === !0 && b.options.pauseOnHover === !0 && (b.paused = a, a ? b.autoPlayClear() : b.autoPlay())
    }, b.prototype.selectHandler = function(b) {
        var c = this,
            d = a(b.target).is(".slick-slide") ? a(b.target) : a(b.target).parents(".slick-slide"),
            e = parseInt(d.attr("data-slick-index"));
        return e || (e = 0), c.slideCount <= c.options.slidesToShow ? (c.$slider.find(".slick-slide").removeClass("slick-active").attr("aria-hidden", "true"), c.$slides.eq(e).addClass("slick-active").attr("aria-hidden", "false"), c.options.centerMode === !0 && (c.$slider.find(".slick-slide").removeClass("slick-center"), c.$slides.eq(e).addClass("slick-center")), c.asNavFor(e), void 0) : (c.slideHandler(e), void 0)
    }, b.prototype.slideHandler = function(a, b, c) {
        var d, e, f, g, h = null,
            i = this;
        return b = b || !1, i.animating === !0 && i.options.waitForAnimate === !0 || i.options.fade === !0 && i.currentSlide === a || i.slideCount <= i.options.slidesToShow ? void 0 : (b === !1 && i.asNavFor(a), d = a, h = i.getLeft(d), g = i.getLeft(i.currentSlide), i.currentLeft = null === i.swipeLeft ? g : i.swipeLeft, i.options.infinite === !1 && i.options.centerMode === !1 && (0 > a || a > i.getDotCount() * i.options.slidesToScroll) ? (i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
            i.postSlide(d)
        }) : i.postSlide(d)), void 0) : i.options.infinite === !1 && i.options.centerMode === !0 && (0 > a || a > i.slideCount - i.options.slidesToScroll) ? (i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
            i.postSlide(d)
        }) : i.postSlide(d)), void 0) : (i.options.autoplay === !0 && clearInterval(i.autoPlayTimer), e = 0 > d ? 0 !== i.slideCount % i.options.slidesToScroll ? i.slideCount - i.slideCount % i.options.slidesToScroll : i.slideCount + d : d >= i.slideCount ? 0 !== i.slideCount % i.options.slidesToScroll ? 0 : d - i.slideCount : d, i.animating = !0, i.$slider.trigger("beforeChange", [i, i.currentSlide, e]), f = i.currentSlide, i.currentSlide = e, i.setSlideClasses(i.currentSlide), i.updateDots(), i.updateArrows(), i.options.fade === !0 ? (c !== !0 ? i.fadeSlide(e, function() {
            i.postSlide(e)
        }) : i.postSlide(e), i.animateHeight(), void 0) : (c !== !0 ? i.animateSlide(h, function() {
            i.postSlide(e)
        }) : i.postSlide(e), void 0)))
    }, b.prototype.startLoad = function() {
        var a = this;
        a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.hide(), a.$nextArrow.hide()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.hide(), a.$slider.addClass("slick-loading")
    }, b.prototype.swipeDirection = function() {
        var a, b, c, d, e = this;
        return a = e.touchObject.startX - e.touchObject.curX, b = e.touchObject.startY - e.touchObject.curY, c = Math.atan2(b, a), d = Math.round(180 * c / Math.PI), 0 > d && (d = 360 - Math.abs(d)), 45 >= d && d >= 0 ? e.options.rtl === !1 ? "left" : "right" : 360 >= d && d >= 315 ? e.options.rtl === !1 ? "left" : "right" : d >= 135 && 225 >= d ? e.options.rtl === !1 ? "right" : "left" : e.options.verticalSwiping === !0 ? d >= 35 && 135 >= d ? "left" : "right" : "vertical"
    }, b.prototype.swipeEnd = function() {
        var c, b = this;
        if (b.dragging = !1, b.shouldClick = b.touchObject.swipeLength > 10 ? !1 : !0, void 0 === b.touchObject.curX) return !1;
        if (b.touchObject.edgeHit === !0 && b.$slider.trigger("edge", [b, b.swipeDirection()]), b.touchObject.swipeLength >= b.touchObject.minSwipe) switch (b.swipeDirection()) {
            case "left":
                c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide + b.getSlideCount()) : b.currentSlide + b.getSlideCount(), b.slideHandler(c), b.currentDirection = 0, b.touchObject = {}, b.$slider.trigger("swipe", [b, "left"]);
                break;
            case "right":
                c = b.options.swipeToSlide ? b.checkNavigable(b.currentSlide - b.getSlideCount()) : b.currentSlide - b.getSlideCount(), b.slideHandler(c), b.currentDirection = 1, b.touchObject = {}, b.$slider.trigger("swipe", [b, "right"])
        } else b.touchObject.startX !== b.touchObject.curX && (b.slideHandler(b.currentSlide), b.touchObject = {})
    }, b.prototype.swipeHandler = function(a) {
        var b = this;
        if (!(b.options.swipe === !1 || "ontouchend" in document && b.options.swipe === !1 || b.options.draggable === !1 && -1 !== a.type.indexOf("mouse"))) switch (b.touchObject.fingerCount = a.originalEvent && void 0 !== a.originalEvent.touches ? a.originalEvent.touches.length : 1, b.touchObject.minSwipe = b.listWidth / b.options.touchThreshold, b.options.verticalSwiping === !0 && (b.touchObject.minSwipe = b.listHeight / b.options.touchThreshold), a.data.action) {
            case "start":
                b.swipeStart(a);
                break;
            case "move":
                b.swipeMove(a);
                break;
            case "end":
                b.swipeEnd(a)
        }
    }, b.prototype.swipeMove = function(a) {
        var d, e, f, g, h, b = this;
        return h = void 0 !== a.originalEvent ? a.originalEvent.touches : null, !b.dragging || h && 1 !== h.length ? !1 : (d = b.getLeft(b.currentSlide), b.touchObject.curX = void 0 !== h ? h[0].pageX : a.clientX, b.touchObject.curY = void 0 !== h ? h[0].pageY : a.clientY, b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curX - b.touchObject.startX, 2))), b.options.verticalSwiping === !0 && (b.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(b.touchObject.curY - b.touchObject.startY, 2)))), e = b.swipeDirection(), "vertical" !== e ? (void 0 !== a.originalEvent && b.touchObject.swipeLength > 4 && a.preventDefault(), g = (b.options.rtl === !1 ? 1 : -1) * (b.touchObject.curX > b.touchObject.startX ? 1 : -1), b.options.verticalSwiping === !0 && (g = b.touchObject.curY > b.touchObject.startY ? 1 : -1), f = b.touchObject.swipeLength, b.touchObject.edgeHit = !1, b.options.infinite === !1 && (0 === b.currentSlide && "right" === e || b.currentSlide >= b.getDotCount() && "left" === e) && (f = b.touchObject.swipeLength * b.options.edgeFriction, b.touchObject.edgeHit = !0), b.swipeLeft = b.options.vertical === !1 ? d + f * g : d + f * (b.$list.height() / b.listWidth) * g, b.options.verticalSwiping === !0 && (b.swipeLeft = d + f * g), b.options.fade === !0 || b.options.touchMove === !1 ? !1 : b.animating === !0 ? (b.swipeLeft = null, !1) : (b.setCSS(b.swipeLeft), void 0)) : void 0)
    }, b.prototype.swipeStart = function(a) {
        var c, b = this;
        return 1 !== b.touchObject.fingerCount || b.slideCount <= b.options.slidesToShow ? (b.touchObject = {}, !1) : (void 0 !== a.originalEvent && void 0 !== a.originalEvent.touches && (c = a.originalEvent.touches[0]), b.touchObject.startX = b.touchObject.curX = void 0 !== c ? c.pageX : a.clientX, b.touchObject.startY = b.touchObject.curY = void 0 !== c ? c.pageY : a.clientY, b.dragging = !0, void 0)
    }, b.prototype.unfilterSlides = b.prototype.slickUnfilter = function() {
        var a = this;
        null !== a.$slidesCache && (a.unload(), a.$slideTrack.children(this.options.slide).detach(), a.$slidesCache.appendTo(a.$slideTrack), a.reinit())
    }, b.prototype.unload = function() {
        var b = this;
        a(".slick-cloned", b.$slider).remove(), b.$dots && b.$dots.remove(), b.$prevArrow && "object" != typeof b.options.prevArrow && b.$prevArrow.remove(), b.$nextArrow && "object" != typeof b.options.nextArrow && b.$nextArrow.remove(), b.$slides.removeClass("slick-slide slick-active slick-visible").attr("aria-hidden", "true").css("width", "")
    }, b.prototype.unslick = function(a) {
        var b = this;
        b.$slider.trigger("unslick", [b, a]), b.destroy()
    }, b.prototype.updateArrows = function() {
        var b, a = this;
        b = Math.floor(a.options.slidesToShow / 2), a.options.arrows === !0 && a.options.infinite !== !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.removeClass("slick-disabled"), a.$nextArrow.removeClass("slick-disabled"), 0 === a.currentSlide ? (a.$prevArrow.addClass("slick-disabled"), a.$nextArrow.removeClass("slick-disabled")) : a.currentSlide >= a.slideCount - a.options.slidesToShow && a.options.centerMode === !1 ? (a.$nextArrow.addClass("slick-disabled"), a.$prevArrow.removeClass("slick-disabled")) : a.currentSlide >= a.slideCount - 1 && a.options.centerMode === !0 && (a.$nextArrow.addClass("slick-disabled"), a.$prevArrow.removeClass("slick-disabled")))
    }, b.prototype.updateDots = function() {
        var a = this;
        null !== a.$dots && (a.$dots.find("li").removeClass("slick-active").attr("aria-hidden", "true"), a.$dots.find("li").eq(Math.floor(a.currentSlide / a.options.slidesToScroll)).addClass("slick-active").attr("aria-hidden", "false"))
    }, b.prototype.visibility = function() {
        var a = this;
        document[a.hidden] ? (a.paused = !0, a.autoPlayClear()) : a.options.autoplay === !0 && (a.paused = !1, a.autoPlay())
    }, a.fn.slick = function() {
        var g, a = this,
            c = arguments[0],
            d = Array.prototype.slice.call(arguments, 1),
            e = a.length,
            f = 0;
        for (f; e > f; f++)
            if ("object" == typeof c || "undefined" == typeof c ? a[f].slick = new b(a[f], c) : g = a[f].slick[c].apply(a[f].slick, d), "undefined" != typeof g) return g;
        return a
    }
});